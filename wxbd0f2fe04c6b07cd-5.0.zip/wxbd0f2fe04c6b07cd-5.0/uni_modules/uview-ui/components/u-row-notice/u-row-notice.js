require("../../../../@babel/runtime/helpers/Arrayincludes");(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["uni_modules/uview-ui/components/u-row-notice/u-row-notice"], {
  1666: function _(n, t, e) {
    "use strict";

    e.r(t);
    var i = e(1667),
      o = e(1669);
    for (var r in o) ["default"].indexOf(r) < 0 && function (n) {
      e.d(t, n, function () {
        return o[n];
      });
    }(r);
    e(1672);
    var u,
      c = e(230),
      a = Object(c["default"])(o["default"], i["render"], i["staticRenderFns"], !1, null, "9adf94ee", null, !1, i["components"], u);
    a.options.__file = "uni_modules/uview-ui/components/u-row-notice/u-row-notice.vue", t["default"] = a.exports;
  },
  1667: function _(n, t, e) {
    "use strict";

    e.r(t);
    var i = e(1668);
    e.d(t, "render", function () {
      return i["render"];
    }), e.d(t, "staticRenderFns", function () {
      return i["staticRenderFns"];
    }), e.d(t, "recyclableRender", function () {
      return i["recyclableRender"];
    }), e.d(t, "components", function () {
      return i["components"];
    });
  },
  1668: function _(n, t, e) {
    "use strict";

    var i;
    e.r(t), e.d(t, "render", function () {
      return o;
    }), e.d(t, "staticRenderFns", function () {
      return u;
    }), e.d(t, "recyclableRender", function () {
      return r;
    }), e.d(t, "components", function () {
      return i;
    });
    try {
      i = {
        uIcon: function uIcon() {
          return Promise.all([e.e("common/vendor"), e.e("uni_modules/uview-ui/components/u-icon/u-icon")]).then(e.bind(null, 1431));
        }
      };
    } catch (c) {
      if (-1 === c.message.indexOf("Cannot find module") || -1 === c.message.indexOf(".vue")) throw c;
      console.error(c.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
    }
    var o = function o() {
        var n = this,
          t = n.$createElement,
          e = (n._self._c, n.__get_style([n.animationStyle])),
          i = n.__get_style([n.textStyle]),
          o = ["link", "closable"].includes(n.mode);
        n.$mp.data = Object.assign({}, {
          $root: {
            s0: e,
            s1: i,
            g0: o
          }
        });
      },
      r = !1,
      u = [];
    o._withStripped = !0;
  },
  1669: function _(n, t, e) {
    "use strict";

    e.r(t);
    var i = e(1670),
      o = e.n(i);
    for (var r in i) ["default"].indexOf(r) < 0 && function (n) {
      e.d(t, n, function () {
        return i[n];
      });
    }(r);
    t["default"] = o.a;
  },
  1670: function _(n, t, e) {
    "use strict";

    (function (n) {
      var i = e(4);
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var o = i(e(255)),
        r = i(e(257)),
        u = i(e(1671)),
        c = {
          name: "u-row-notice",
          mixins: [n.$u.mpMixin, n.$u.mixin, u.default],
          data: function data() {
            return {
              animationDuration: "0",
              animationPlayState: "paused",
              nvueInit: !0,
              show: !0
            };
          },
          watch: {
            text: {
              immediate: !0,
              handler: function handler(t, e) {
                this.vue(), n.$u.test.string(t) || n.$u.error("noticebar组件direction为row时，要求text参数为字符串形式");
              }
            },
            fontSize: function fontSize() {
              this.vue();
            },
            speed: function speed() {
              this.vue();
            }
          },
          computed: {
            textStyle: function textStyle() {
              var t = {};
              return t.color = this.color, t.fontSize = n.$u.addUnit(this.fontSize), t;
            },
            animationStyle: function animationStyle() {
              var n = {};
              return n.animationDuration = this.animationDuration, n.animationPlayState = this.animationPlayState, n;
            },
            innerText: function innerText() {
              for (var n = [], t = 20, e = this.text.split(""), i = 0; i < e.length; i += t) n.push(e.slice(i, i + t).join(""));
              return n;
            }
          },
          mounted: function mounted() {
            this.init();
          },
          methods: {
            init: function init() {
              this.vue(), n.$u.test.string(this.text) || n.$u.error("noticebar组件direction为row时，要求text参数为字符串形式");
            },
            vue: function vue() {
              var t = this;
              return (0, r.default)(o.default.mark(function e() {
                var i;
                return o.default.wrap(function (e) {
                  while (1) switch (e.prev = e.next) {
                    case 0:
                      return 0, i = 0, e.next = 3, n.$u.sleep();
                    case 3:
                      return e.next = 5, t.$uGetRect(".u-notice__content__text");
                    case 5:
                      return i = e.sent.width, e.next = 8, t.$uGetRect(".u-notice__content");
                    case 8:
                      e.sent.width, t.animationDuration = "".concat(i / n.$u.getPx(t.speed), "s"), t.animationPlayState = "paused", setTimeout(function () {
                        t.animationPlayState = "running";
                      }, 10);
                    case 12:
                    case "end":
                      return e.stop();
                  }
                }, e);
              }))();
            },
            nvue: function nvue() {
              return (0, r.default)(o.default.mark(function n() {
                return o.default.wrap(function (n) {
                  while (1) switch (n.prev = n.next) {
                    case 0:
                    case "end":
                      return n.stop();
                  }
                }, n);
              }))();
            },
            loopAnimation: function loopAnimation(n, t) {},
            getNvueRect: function getNvueRect(n) {},
            clickHandler: function clickHandler(n) {
              this.$emit("click");
            },
            close: function close() {
              this.$emit("close");
            }
          }
        };
      t.default = c;
    }).call(this, e(2)["default"]);
  },
  1672: function _(n, t, e) {
    "use strict";

    e.r(t);
    var i = e(1673),
      o = e.n(i);
    for (var r in i) ["default"].indexOf(r) < 0 && function (n) {
      e.d(t, n, function () {
        return i[n];
      });
    }(r);
    t["default"] = o.a;
  },
  1673: function _(n, t, e) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['uni_modules/uview-ui/components/u-row-notice/u-row-notice-create-component', {
  'uni_modules/uview-ui/components/u-row-notice/u-row-notice-create-component': function uni_modulesUviewUiComponentsURowNoticeURowNoticeCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1666));
  }
}, [['uni_modules/uview-ui/components/u-row-notice/u-row-notice-create-component']]]);