(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["uni_modules/uview-ui/components/u-safe-bottom/u-safe-bottom"], {
  1642: function _(e, n, t) {
    "use strict";

    t.r(n);
    var u = t(1643),
      r = t(1645);
    for (var o in r) ["default"].indexOf(o) < 0 && function (e) {
      t.d(n, e, function () {
        return r[e];
      });
    }(o);
    t(1648);
    var i,
      c = t(230),
      a = Object(c["default"])(r["default"], u["render"], u["staticRenderFns"], !1, null, "40b3d0de", null, !1, u["components"], i);
    a.options.__file = "uni_modules/uview-ui/components/u-safe-bottom/u-safe-bottom.vue", n["default"] = a.exports;
  },
  1643: function _(e, n, t) {
    "use strict";

    t.r(n);
    var u = t(1644);
    t.d(n, "render", function () {
      return u["render"];
    }), t.d(n, "staticRenderFns", function () {
      return u["staticRenderFns"];
    }), t.d(n, "recyclableRender", function () {
      return u["recyclableRender"];
    }), t.d(n, "components", function () {
      return u["components"];
    });
  },
  1644: function _(e, n, t) {
    "use strict";

    var u;
    t.r(n), t.d(n, "render", function () {
      return r;
    }), t.d(n, "staticRenderFns", function () {
      return i;
    }), t.d(n, "recyclableRender", function () {
      return o;
    }), t.d(n, "components", function () {
      return u;
    });
    var r = function r() {
        var e = this,
          n = e.$createElement,
          t = (e._self._c, e.__get_style([e.style]));
        e.$mp.data = Object.assign({}, {
          $root: {
            s0: t
          }
        });
      },
      o = !1,
      i = [];
    r._withStripped = !0;
  },
  1645: function _(e, n, t) {
    "use strict";

    t.r(n);
    var u = t(1646),
      r = t.n(u);
    for (var o in u) ["default"].indexOf(o) < 0 && function (e) {
      t.d(n, e, function () {
        return u[e];
      });
    }(o);
    n["default"] = r.a;
  },
  1646: function _(e, n, t) {
    "use strict";

    (function (e) {
      var u = t(4);
      Object.defineProperty(n, "__esModule", {
        value: !0
      }), n.default = void 0;
      var r = u(t(1647)),
        o = {
          name: "u-safe-bottom",
          mixins: [e.$u.mpMixin, e.$u.mixin, r.default],
          data: function data() {
            return {
              safeAreaBottomHeight: 0,
              isNvue: !1
            };
          },
          computed: {
            style: function style() {
              var n = {};
              return e.$u.deepMerge(n, e.$u.addStyle(this.customStyle));
            }
          },
          mounted: function mounted() {}
        };
      n.default = o;
    }).call(this, t(2)["default"]);
  },
  1648: function _(e, n, t) {
    "use strict";

    t.r(n);
    var u = t(1649),
      r = t.n(u);
    for (var o in u) ["default"].indexOf(o) < 0 && function (e) {
      t.d(n, e, function () {
        return u[e];
      });
    }(o);
    n["default"] = r.a;
  },
  1649: function _(e, n, t) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['uni_modules/uview-ui/components/u-safe-bottom/u-safe-bottom-create-component', {
  'uni_modules/uview-ui/components/u-safe-bottom/u-safe-bottom-create-component': function uni_modulesUviewUiComponentsUSafeBottomUSafeBottomCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1642));
  }
}, [['uni_modules/uview-ui/components/u-safe-bottom/u-safe-bottom-create-component']]]);