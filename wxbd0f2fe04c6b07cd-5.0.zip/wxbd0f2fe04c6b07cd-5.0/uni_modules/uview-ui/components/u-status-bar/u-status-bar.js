(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["uni_modules/uview-ui/components/u-status-bar/u-status-bar"], {
  1634: function _(t, n, e) {
    "use strict";

    e.r(n);
    var u = e(1635),
      r = e(1637);
    for (var i in r) ["default"].indexOf(i) < 0 && function (t) {
      e.d(n, t, function () {
        return r[t];
      });
    }(i);
    e(1640);
    var a,
      o = e(230),
      s = Object(o["default"])(r["default"], u["render"], u["staticRenderFns"], !1, null, "124d52a9", null, !1, u["components"], a);
    s.options.__file = "uni_modules/uview-ui/components/u-status-bar/u-status-bar.vue", n["default"] = s.exports;
  },
  1635: function _(t, n, e) {
    "use strict";

    e.r(n);
    var u = e(1636);
    e.d(n, "render", function () {
      return u["render"];
    }), e.d(n, "staticRenderFns", function () {
      return u["staticRenderFns"];
    }), e.d(n, "recyclableRender", function () {
      return u["recyclableRender"];
    }), e.d(n, "components", function () {
      return u["components"];
    });
  },
  1636: function _(t, n, e) {
    "use strict";

    var u;
    e.r(n), e.d(n, "render", function () {
      return r;
    }), e.d(n, "staticRenderFns", function () {
      return a;
    }), e.d(n, "recyclableRender", function () {
      return i;
    }), e.d(n, "components", function () {
      return u;
    });
    var r = function r() {
        var t = this,
          n = t.$createElement,
          e = (t._self._c, t.__get_style([t.style]));
        t.$mp.data = Object.assign({}, {
          $root: {
            s0: e
          }
        });
      },
      i = !1,
      a = [];
    r._withStripped = !0;
  },
  1637: function _(t, n, e) {
    "use strict";

    e.r(n);
    var u = e(1638),
      r = e.n(u);
    for (var i in u) ["default"].indexOf(i) < 0 && function (t) {
      e.d(n, t, function () {
        return u[t];
      });
    }(i);
    n["default"] = r.a;
  },
  1638: function _(t, n, e) {
    "use strict";

    (function (t) {
      var u = e(4);
      Object.defineProperty(n, "__esModule", {
        value: !0
      }), n.default = void 0;
      var r = u(e(1639)),
        i = {
          name: "u-status-bar",
          mixins: [t.$u.mpMixin, t.$u.mixin, r.default],
          data: function data() {
            return {};
          },
          computed: {
            style: function style() {
              var n = {};
              return n.height = t.$u.addUnit(t.$u.sys().statusBarHeight, "px"), n.backgroundColor = this.bgColor, t.$u.deepMerge(n, t.$u.addStyle(this.customStyle));
            }
          }
        };
      n.default = i;
    }).call(this, e(2)["default"]);
  },
  1640: function _(t, n, e) {
    "use strict";

    e.r(n);
    var u = e(1641),
      r = e.n(u);
    for (var i in u) ["default"].indexOf(i) < 0 && function (t) {
      e.d(n, t, function () {
        return u[t];
      });
    }(i);
    n["default"] = r.a;
  },
  1641: function _(t, n, e) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['uni_modules/uview-ui/components/u-status-bar/u-status-bar-create-component', {
  'uni_modules/uview-ui/components/u-status-bar/u-status-bar-create-component': function uni_modulesUviewUiComponentsUStatusBarUStatusBarCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1634));
  }
}, [['uni_modules/uview-ui/components/u-status-bar/u-status-bar-create-component']]]);