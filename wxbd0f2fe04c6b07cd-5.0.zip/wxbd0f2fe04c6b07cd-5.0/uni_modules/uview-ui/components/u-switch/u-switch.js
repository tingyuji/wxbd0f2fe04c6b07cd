(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["uni_modules/uview-ui/components/u-switch/u-switch"], {
  1101: function _(t, e, n) {
    "use strict";

    n.r(e);
    var i = n(1102),
      o = n(1104);
    for (var r in o) ["default"].indexOf(r) < 0 && function (t) {
      n.d(e, t, function () {
        return o[t];
      });
    }(r);
    n(1107);
    var s,
      u = n(230),
      c = Object(u["default"])(o["default"], i["render"], i["staticRenderFns"], !1, null, "3a8aa7a9", null, !1, i["components"], s);
    c.options.__file = "uni_modules/uview-ui/components/u-switch/u-switch.vue", e["default"] = c.exports;
  },
  1102: function _(t, e, n) {
    "use strict";

    n.r(e);
    var i = n(1103);
    n.d(e, "render", function () {
      return i["render"];
    }), n.d(e, "staticRenderFns", function () {
      return i["staticRenderFns"];
    }), n.d(e, "recyclableRender", function () {
      return i["recyclableRender"];
    }), n.d(e, "components", function () {
      return i["components"];
    });
  },
  1103: function _(t, e, n) {
    "use strict";

    var i;
    n.r(e), n.d(e, "render", function () {
      return o;
    }), n.d(e, "staticRenderFns", function () {
      return s;
    }), n.d(e, "recyclableRender", function () {
      return r;
    }), n.d(e, "components", function () {
      return i;
    });
    try {
      i = {
        uLoadingIcon: function uLoadingIcon() {
          return Promise.all([n.e("common/vendor"), n.e("uni_modules/uview-ui/components/u-loading-icon/u-loading-icon")]).then(n.bind(null, 1650));
        }
      };
    } catch (u) {
      if (-1 === u.message.indexOf("Cannot find module") || -1 === u.message.indexOf(".vue")) throw u;
      console.error(u.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
    }
    var o = function o() {
        var t = this,
          e = t.$createElement,
          n = (t._self._c, t.__get_style([t.switchStyle, t.$u.addStyle(t.customStyle)])),
          i = t.__get_style([t.bgStyle]),
          o = t.__get_style([t.nodeStyle]);
        t.$mp.data = Object.assign({}, {
          $root: {
            s0: n,
            s1: i,
            s2: o
          }
        });
      },
      r = !1,
      s = [];
    o._withStripped = !0;
  },
  1104: function _(t, e, n) {
    "use strict";

    n.r(e);
    var i = n(1105),
      o = n.n(i);
    for (var r in i) ["default"].indexOf(r) < 0 && function (t) {
      n.d(e, t, function () {
        return i[t];
      });
    }(r);
    e["default"] = o.a;
  },
  1105: function _(t, e, n) {
    "use strict";

    (function (t) {
      var i = n(4);
      Object.defineProperty(e, "__esModule", {
        value: !0
      }), e.default = void 0;
      var o = i(n(1106)),
        r = {
          name: "u-switch",
          mixins: [t.$u.mpMixin, t.$u.mixin, o.default],
          watch: {
            value: {
              immediate: !0,
              handler: function handler(e) {
                e !== this.inactiveValue && e !== this.activeValue && t.$u.error("v-model绑定的值必须为inactiveValue、activeValue二者之一");
              }
            }
          },
          data: function data() {
            return {
              bgColor: "#ffffff"
            };
          },
          computed: {
            isActive: function isActive() {
              return this.value === this.activeValue;
            },
            switchStyle: function switchStyle() {
              var e = {};
              return e.width = t.$u.addUnit(2 * this.size + 2), e.height = t.$u.addUnit(Number(this.size) + 2), this.customInactiveColor && (e.borderColor = "rgba(0, 0, 0, 0)"), e.backgroundColor = this.isActive ? this.activeColor : this.inactiveColor, e;
            },
            nodeStyle: function nodeStyle() {
              var e = {};
              e.width = t.$u.addUnit(this.size - this.space), e.height = t.$u.addUnit(this.size - this.space);
              var n = this.isActive ? t.$u.addUnit(this.space) : t.$u.addUnit(this.size);
              return e.transform = "translateX(-".concat(n, ")"), e;
            },
            bgStyle: function bgStyle() {
              var e = {};
              return e.width = t.$u.addUnit(2 * Number(this.size) - this.size / 2), e.height = t.$u.addUnit(this.size), e.backgroundColor = this.inactiveColor, e.transform = "scale(".concat(this.isActive ? 0 : 1, ")"), e;
            },
            customInactiveColor: function customInactiveColor() {
              return "#fff" !== this.inactiveColor && "#ffffff" !== this.inactiveColor;
            }
          },
          methods: {
            clickHandler: function clickHandler() {
              var t = this;
              if (!this.disabled && !this.loading) {
                var e = this.isActive ? this.inactiveValue : this.activeValue;
                this.asyncChange || this.$emit("input", e), this.$nextTick(function () {
                  t.$emit("change", e);
                });
              }
            }
          }
        };
      e.default = r;
    }).call(this, n(2)["default"]);
  },
  1107: function _(t, e, n) {
    "use strict";

    n.r(e);
    var i = n(1108),
      o = n.n(i);
    for (var r in i) ["default"].indexOf(r) < 0 && function (t) {
      n.d(e, t, function () {
        return i[t];
      });
    }(r);
    e["default"] = o.a;
  },
  1108: function _(t, e, n) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['uni_modules/uview-ui/components/u-switch/u-switch-create-component', {
  'uni_modules/uview-ui/components/u-switch/u-switch-create-component': function uni_modulesUviewUiComponentsUSwitchUSwitchCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1101));
  }
}, [['uni_modules/uview-ui/components/u-switch/u-switch-create-component']]]);