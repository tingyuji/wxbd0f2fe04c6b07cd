require("../../../../@babel/runtime/helpers/Arrayincludes");(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["uni_modules/uview-ui/components/u-column-notice/u-column-notice"], {
  1658: function _(n, e, t) {
    "use strict";

    t.r(e);
    var o = t(1659),
      i = t(1661);
    for (var r in i) ["default"].indexOf(r) < 0 && function (n) {
      t.d(e, n, function () {
        return i[n];
      });
    }(r);
    t(1664);
    var u,
      c = t(230),
      s = Object(c["default"])(i["default"], o["render"], o["staticRenderFns"], !1, null, "3bda0f19", null, !1, o["components"], u);
    s.options.__file = "uni_modules/uview-ui/components/u-column-notice/u-column-notice.vue", e["default"] = s.exports;
  },
  1659: function _(n, e, t) {
    "use strict";

    t.r(e);
    var o = t(1660);
    t.d(e, "render", function () {
      return o["render"];
    }), t.d(e, "staticRenderFns", function () {
      return o["staticRenderFns"];
    }), t.d(e, "recyclableRender", function () {
      return o["recyclableRender"];
    }), t.d(e, "components", function () {
      return o["components"];
    });
  },
  1660: function _(n, e, t) {
    "use strict";

    var o;
    t.r(e), t.d(e, "render", function () {
      return i;
    }), t.d(e, "staticRenderFns", function () {
      return u;
    }), t.d(e, "recyclableRender", function () {
      return r;
    }), t.d(e, "components", function () {
      return o;
    });
    try {
      o = {
        uIcon: function uIcon() {
          return Promise.all([t.e("common/vendor"), t.e("uni_modules/uview-ui/components/u-icon/u-icon")]).then(t.bind(null, 1431));
        }
      };
    } catch (c) {
      if (-1 === c.message.indexOf("Cannot find module") || -1 === c.message.indexOf(".vue")) throw c;
      console.error(c.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
    }
    var i = function i() {
        var n = this,
          e = n.$createElement,
          t = (n._self._c, n.__get_style([n.textStyle])),
          o = ["link", "closable"].includes(n.mode);
        n.$mp.data = Object.assign({}, {
          $root: {
            s0: t,
            g0: o
          }
        });
      },
      r = !1,
      u = [];
    i._withStripped = !0;
  },
  1661: function _(n, e, t) {
    "use strict";

    t.r(e);
    var o = t(1662),
      i = t.n(o);
    for (var r in o) ["default"].indexOf(r) < 0 && function (n) {
      t.d(e, n, function () {
        return o[n];
      });
    }(r);
    e["default"] = i.a;
  },
  1662: function _(n, e, t) {
    "use strict";

    (function (n) {
      var o = t(4);
      Object.defineProperty(e, "__esModule", {
        value: !0
      }), e.default = void 0;
      var i = o(t(1663)),
        r = {
          mixins: [n.$u.mpMixin, n.$u.mixin, i.default],
          watch: {
            text: {
              immediate: !0,
              handler: function handler(e, t) {
                n.$u.test.array(e) || n.$u.error("noticebar组件direction为column时，要求text参数为数组形式");
              }
            }
          },
          computed: {
            textStyle: function textStyle() {
              var e = {};
              return e.color = this.color, e.fontSize = n.$u.addUnit(this.fontSize), e;
            },
            vertical: function vertical() {
              return "horizontal" != this.mode;
            }
          },
          data: function data() {
            return {
              index: 0
            };
          },
          methods: {
            noticeChange: function noticeChange(n) {
              this.index = n.detail.current;
            },
            clickHandler: function clickHandler() {
              this.$emit("click", this.index);
            },
            close: function close() {
              this.$emit("close");
            }
          }
        };
      e.default = r;
    }).call(this, t(2)["default"]);
  },
  1664: function _(n, e, t) {
    "use strict";

    t.r(e);
    var o = t(1665),
      i = t.n(o);
    for (var r in o) ["default"].indexOf(r) < 0 && function (n) {
      t.d(e, n, function () {
        return o[n];
      });
    }(r);
    e["default"] = i.a;
  },
  1665: function _(n, e, t) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['uni_modules/uview-ui/components/u-column-notice/u-column-notice-create-component', {
  'uni_modules/uview-ui/components/u-column-notice/u-column-notice-create-component': function uni_modulesUviewUiComponentsUColumnNoticeUColumnNoticeCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1658));
  }
}, [['uni_modules/uview-ui/components/u-column-notice/u-column-notice-create-component']]]);