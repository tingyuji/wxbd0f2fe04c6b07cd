(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["uni_modules/uview-ui/components/u-count-down/u-count-down"], {
  1401: function _(t, n, i) {
    "use strict";

    i.r(n);
    var e = i(1402),
      r = i(1404);
    for (var u in r) ["default"].indexOf(u) < 0 && function (t) {
      i.d(n, t, function () {
        return r[t];
      });
    }(u);
    i(1408);
    var o,
      a = i(230),
      c = Object(a["default"])(r["default"], e["render"], e["staticRenderFns"], !1, null, "463368ae", null, !1, e["components"], o);
    c.options.__file = "uni_modules/uview-ui/components/u-count-down/u-count-down.vue", n["default"] = c.exports;
  },
  1402: function _(t, n, i) {
    "use strict";

    i.r(n);
    var e = i(1403);
    i.d(n, "render", function () {
      return e["render"];
    }), i.d(n, "staticRenderFns", function () {
      return e["staticRenderFns"];
    }), i.d(n, "recyclableRender", function () {
      return e["recyclableRender"];
    }), i.d(n, "components", function () {
      return e["components"];
    });
  },
  1403: function _(t, n, i) {
    "use strict";

    var e;
    i.r(n), i.d(n, "render", function () {
      return r;
    }), i.d(n, "staticRenderFns", function () {
      return o;
    }), i.d(n, "recyclableRender", function () {
      return u;
    }), i.d(n, "components", function () {
      return e;
    });
    var r = function r() {
        var t = this,
          n = t.$createElement;
        t._self._c;
      },
      u = !1,
      o = [];
    r._withStripped = !0;
  },
  1404: function _(t, n, i) {
    "use strict";

    i.r(n);
    var e = i(1405),
      r = i.n(e);
    for (var u in e) ["default"].indexOf(u) < 0 && function (t) {
      i.d(n, t, function () {
        return e[t];
      });
    }(u);
    n["default"] = r.a;
  },
  1405: function _(t, n, i) {
    "use strict";

    (function (t) {
      var e = i(4);
      Object.defineProperty(n, "__esModule", {
        value: !0
      }), n.default = void 0;
      var r = e(i(1406)),
        u = i(1407),
        o = {
          name: "u-count-down",
          mixins: [t.$u.mpMixin, t.$u.mixin, r.default],
          data: function data() {
            return {
              timer: null,
              timeData: (0, u.parseTimeData)(0),
              formattedTime: "0",
              runing: !1,
              endTime: 0,
              remainTime: 0
            };
          },
          watch: {
            time: function time(t) {
              this.reset();
            }
          },
          mounted: function mounted() {
            this.init();
          },
          methods: {
            init: function init() {
              this.reset();
            },
            start: function start() {
              this.runing || (this.runing = !0, this.endTime = Date.now() + this.remainTime, this.toTick());
            },
            toTick: function toTick() {
              this.millisecond ? this.microTick() : this.macroTick();
            },
            macroTick: function macroTick() {
              var t = this;
              this.clearTimeout(), this.timer = setTimeout(function () {
                var n = t.getRemainTime();
                (0, u.isSameSecond)(n, t.remainTime) && 0 !== n || t.setRemainTime(n), 0 !== t.remainTime && t.macroTick();
              }, 30);
            },
            microTick: function microTick() {
              var t = this;
              this.clearTimeout(), this.timer = setTimeout(function () {
                t.setRemainTime(t.getRemainTime()), 0 !== t.remainTime && t.microTick();
              }, 50);
            },
            getRemainTime: function getRemainTime() {
              return Math.max(this.endTime - Date.now(), 0);
            },
            setRemainTime: function setRemainTime(t) {
              this.remainTime = t;
              var n = (0, u.parseTimeData)(t);
              this.$emit("change", n), this.formattedTime = (0, u.parseFormat)(this.format, n), t <= 0 && (this.pause(), this.$emit("finish"));
            },
            reset: function reset() {
              this.pause(), this.remainTime = this.time, this.setRemainTime(this.remainTime), this.autoStart && this.start();
            },
            pause: function pause() {
              this.runing = !1, this.clearTimeout();
            },
            clearTimeout: function (t) {
              function n() {
                return t.apply(this, arguments);
              }
              return n.toString = function () {
                return t.toString();
              }, n;
            }(function () {
              clearTimeout(this.timer), this.timer = null;
            })
          },
          beforeDestroy: function beforeDestroy() {
            this.clearTimeout();
          }
        };
      n.default = o;
    }).call(this, i(2)["default"]);
  },
  1408: function _(t, n, i) {
    "use strict";

    i.r(n);
    var e = i(1409),
      r = i.n(e);
    for (var u in e) ["default"].indexOf(u) < 0 && function (t) {
      i.d(n, t, function () {
        return e[t];
      });
    }(u);
    n["default"] = r.a;
  },
  1409: function _(t, n, i) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['uni_modules/uview-ui/components/u-count-down/u-count-down-create-component', {
  'uni_modules/uview-ui/components/u-count-down/u-count-down-create-component': function uni_modulesUviewUiComponentsUCountDownUCountDownCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1401));
  }
}, [['uni_modules/uview-ui/components/u-count-down/u-count-down-create-component']]]);