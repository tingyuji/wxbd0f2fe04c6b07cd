(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["uni_modules/uview-ui/components/u-loading-icon/u-loading-icon"], {
  1650: function _(n, e, t) {
    "use strict";

    t.r(e);
    var i = t(1651),
      r = t(1653);
    for (var o in r) ["default"].indexOf(o) < 0 && function (n) {
      t.d(e, n, function () {
        return r[n];
      });
    }(o);
    t(1656);
    var u,
      d = t(230),
      c = Object(d["default"])(r["default"], i["render"], i["staticRenderFns"], !1, null, "0fe228ae", null, !1, i["components"], u);
    c.options.__file = "uni_modules/uview-ui/components/u-loading-icon/u-loading-icon.vue", e["default"] = c.exports;
  },
  1651: function _(n, e, t) {
    "use strict";

    t.r(e);
    var i = t(1652);
    t.d(e, "render", function () {
      return i["render"];
    }), t.d(e, "staticRenderFns", function () {
      return i["staticRenderFns"];
    }), t.d(e, "recyclableRender", function () {
      return i["recyclableRender"];
    }), t.d(e, "components", function () {
      return i["components"];
    });
  },
  1652: function _(n, e, t) {
    "use strict";

    var i;
    t.r(e), t.d(e, "render", function () {
      return r;
    }), t.d(e, "staticRenderFns", function () {
      return u;
    }), t.d(e, "recyclableRender", function () {
      return o;
    }), t.d(e, "components", function () {
      return i;
    });
    var r = function r() {
        var n = this,
          e = n.$createElement,
          t = (n._self._c, n.show ? n.__get_style([n.$u.addStyle(n.customStyle)]) : null),
          i = n.show && !n.webviewHide ? n.$u.addUnit(n.size) : null,
          r = n.show && !n.webviewHide ? n.$u.addUnit(n.size) : null,
          o = n.show && n.text ? n.$u.addUnit(n.textSize) : null;
        n.$mp.data = Object.assign({}, {
          $root: {
            s0: t,
            g0: i,
            g1: r,
            g2: o
          }
        });
      },
      o = !1,
      u = [];
    r._withStripped = !0;
  },
  1653: function _(n, e, t) {
    "use strict";

    t.r(e);
    var i = t(1654),
      r = t.n(i);
    for (var o in i) ["default"].indexOf(o) < 0 && function (n) {
      t.d(e, n, function () {
        return i[n];
      });
    }(o);
    e["default"] = r.a;
  },
  1654: function _(n, e, t) {
    "use strict";

    (function (n) {
      var i = t(4);
      Object.defineProperty(e, "__esModule", {
        value: !0
      }), e.default = void 0;
      var r = i(t(1655)),
        o = {
          name: "u-loading-icon",
          mixins: [n.$u.mpMixin, n.$u.mixin, r.default],
          data: function data() {
            return {
              array12: Array.from({
                length: 12
              }),
              aniAngel: 360,
              webviewHide: !1,
              loading: !1
            };
          },
          computed: {
            otherBorderColor: function otherBorderColor() {
              var e = n.$u.colorGradient(this.color, "#ffffff", 100)[80];
              return "circle" === this.mode ? this.inactiveColor ? this.inactiveColor : e : "transparent";
            }
          },
          watch: {
            show: function show(n) {}
          },
          mounted: function mounted() {
            this.init();
          },
          methods: {
            init: function init() {
              setTimeout(function () {}, 20);
            },
            addEventListenerToWebview: function addEventListenerToWebview() {
              var n = this,
                e = getCurrentPages(),
                t = e[e.length - 1],
                i = t.$getAppWebview();
              i.addEventListener("hide", function () {
                n.webviewHide = !0;
              }), i.addEventListener("show", function () {
                n.webviewHide = !1;
              });
            }
          }
        };
      e.default = o;
    }).call(this, t(2)["default"]);
  },
  1656: function _(n, e, t) {
    "use strict";

    t.r(e);
    var i = t(1657),
      r = t.n(i);
    for (var o in i) ["default"].indexOf(o) < 0 && function (n) {
      t.d(e, n, function () {
        return i[n];
      });
    }(o);
    e["default"] = r.a;
  },
  1657: function _(n, e, t) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['uni_modules/uview-ui/components/u-loading-icon/u-loading-icon-create-component', {
  'uni_modules/uview-ui/components/u-loading-icon/u-loading-icon-create-component': function uni_modulesUviewUiComponentsULoadingIconULoadingIconCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1650));
  }
}, [['uni_modules/uview-ui/components/u-loading-icon/u-loading-icon-create-component']]]);