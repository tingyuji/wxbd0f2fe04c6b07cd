(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["uni_modules/uview-ui/components/u-notice-bar/u-notice-bar"], {
  1214: function _(n, e, t) {
    "use strict";

    t.r(e);
    var o = t(1215),
      u = t(1217);
    for (var r in u) ["default"].indexOf(r) < 0 && function (n) {
      t.d(e, n, function () {
        return u[n];
      });
    }(r);
    t(1220);
    var i,
      c = t(230),
      s = Object(c["default"])(u["default"], o["render"], o["staticRenderFns"], !1, null, "24c07869", null, !1, o["components"], i);
    s.options.__file = "uni_modules/uview-ui/components/u-notice-bar/u-notice-bar.vue", e["default"] = s.exports;
  },
  1215: function _(n, e, t) {
    "use strict";

    t.r(e);
    var o = t(1216);
    t.d(e, "render", function () {
      return o["render"];
    }), t.d(e, "staticRenderFns", function () {
      return o["staticRenderFns"];
    }), t.d(e, "recyclableRender", function () {
      return o["recyclableRender"];
    }), t.d(e, "components", function () {
      return o["components"];
    });
  },
  1216: function _(n, e, t) {
    "use strict";

    var o;
    t.r(e), t.d(e, "render", function () {
      return u;
    }), t.d(e, "staticRenderFns", function () {
      return i;
    }), t.d(e, "recyclableRender", function () {
      return r;
    }), t.d(e, "components", function () {
      return o;
    });
    try {
      o = {
        uColumnNotice: function uColumnNotice() {
          return Promise.all([t.e("common/vendor"), t.e("uni_modules/uview-ui/components/u-column-notice/u-column-notice")]).then(t.bind(null, 1658));
        },
        uRowNotice: function uRowNotice() {
          return Promise.all([t.e("common/vendor"), t.e("uni_modules/uview-ui/components/u-row-notice/u-row-notice")]).then(t.bind(null, 1666));
        }
      };
    } catch (c) {
      if (-1 === c.message.indexOf("Cannot find module") || -1 === c.message.indexOf(".vue")) throw c;
      console.error(c.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
    }
    var u = function u() {
        var n = this,
          e = n.$createElement,
          t = (n._self._c, n.show ? n.__get_style([{
            backgroundColor: n.bgColor
          }, n.$u.addStyle(n.customStyle)]) : null);
        n.$mp.data = Object.assign({}, {
          $root: {
            s0: t
          }
        });
      },
      r = !1,
      i = [];
    u._withStripped = !0;
  },
  1217: function _(n, e, t) {
    "use strict";

    t.r(e);
    var o = t(1218),
      u = t.n(o);
    for (var r in o) ["default"].indexOf(r) < 0 && function (n) {
      t.d(e, n, function () {
        return o[n];
      });
    }(r);
    e["default"] = u.a;
  },
  1218: function _(n, e, t) {
    "use strict";

    (function (n) {
      var o = t(4);
      Object.defineProperty(e, "__esModule", {
        value: !0
      }), e.default = void 0;
      var u = o(t(1219)),
        r = {
          name: "u-notice-bar",
          mixins: [n.$u.mpMixin, n.$u.mixin, u.default],
          data: function data() {
            return {
              show: !0
            };
          },
          methods: {
            click: function click(n) {
              this.$emit("click", n), this.url && this.linkType && this.openPage();
            },
            close: function close() {
              this.show = !1, this.$emit("close");
            }
          }
        };
      e.default = r;
    }).call(this, t(2)["default"]);
  },
  1220: function _(n, e, t) {
    "use strict";

    t.r(e);
    var o = t(1221),
      u = t.n(o);
    for (var r in o) ["default"].indexOf(r) < 0 && function (n) {
      t.d(e, n, function () {
        return o[n];
      });
    }(r);
    e["default"] = u.a;
  },
  1221: function _(n, e, t) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['uni_modules/uview-ui/components/u-notice-bar/u-notice-bar-create-component', {
  'uni_modules/uview-ui/components/u-notice-bar/u-notice-bar-create-component': function uni_modulesUviewUiComponentsUNoticeBarUNoticeBarCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1214));
  }
}, [['uni_modules/uview-ui/components/u-notice-bar/u-notice-bar-create-component']]]);