(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["pages/real/real"], {
  228: function _(e, t, o) {
    "use strict";

    o.r(t);
    var a = o(229),
      n = o.n(a);
    for (var i in a) ["default"].indexOf(i) < 0 && function (e) {
      o.d(t, e, function () {
        return a[e];
      });
    }(i);
    t["default"] = n.a;
  },
  229: function _(e, t, o) {},
  27: function _(e, t, o) {
    "use strict";

    o.r(t);
    var a = o(28);
    for (var n in a) ["default"].indexOf(n) < 0 && function (e) {
      o.d(t, e, function () {
        return a[e];
      });
    }(n);
    o(228);
    var i,
      s,
      r,
      l,
      c = o(230),
      u = Object(c["default"])(a["default"], i, s, !1, null, null, null, !1, r, l);
    u.options.__file = "App.vue", t["default"] = u.exports;
  },
  28: function _(e, t, o) {
    "use strict";

    o.r(t);
    var a = o(29),
      n = o.n(a);
    for (var i in a) ["default"].indexOf(i) < 0 && function (e) {
      o.d(t, e, function () {
        return a[e];
      });
    }(i);
    t["default"] = n.a;
  },
  29: function _(e, t, o) {
    "use strict";

    (function (e, a) {
      var n = o(4);
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var i = n(o(13)),
        s = (n(o(30)), n(o(31))),
        r = n(o(225)),
        l = o(226),
        c = (o(227), {
          globalData: {
            baseApi: "https://pysq.shipook.com/v2base",
            appApi: "https://pysq.shipook.com/v2app",
            app_url: {},
            base_url: {
              getsmscode: "/common/getsmscode",
              login4wechat: "/thirdlogin/login4wechat",
              login4zjtd: "/thirdlogin/login4zjtd",
              login4baidu: "/thirdlogin/login4baidu",
              userlogin: "/user/userlogin",
              qryuserallinfo: "/user/qryuserallinfo",
              cashorder: "/business/cashorder",
              openvip: "/business/openvip",
              bootup: "/common/bootup",
              updatedeviceinfo: "/common/updatedeviceinfo",
              getbusupgradeinfo: "/busupgrade/getbusupgradeinfo",
              qryuserjbviplist: "/business/qryuserjbviplist"
            },
            tab_work: 0,
            qd: "",
            ver: "010009",
            sec: "48a0088cb506e6b7",
            aaa: "",
            bbb: "",
            deviceId: "",
            wxappid: "",
            userinfo: null,
            crgid: "",
            parentid: "",
            deviceMac: "",
            oaid: "",
            ss: "",
            showPay: !0,
            freetype: null,
            vipList: [],
            svip_char: {},
            ios_status: 1,
            tts_text: "",
            ishidetype: "",
            heimingdan0: "",
            heimingdan1: "",
            heimingdan2: "",
            systemInfo: null,
            timeInfo: 0
          },
          onLaunch: function onLaunch() {
            var t = this;
            this.$store.commit("setAppConfig", r.default), 1154 === e.getLaunchOptionsSync().scene && (a.setStorageSync("ispyq", !0), a.switchTab({
              url: "/pages/make/make?pyq=1"
            }));
            var o = e.getUpdateManager();
            o.onCheckForUpdate(function (e) {
              if (!e.hasUpdate) return !1;
              o.onUpdateReady(function () {
                o.applyUpdate();
              });
            }), a.setInnerAudioOption({
              obeyMuteSwitch: !1
            }), a.getSystemInfo({
              complete: function complete(e) {
                a.setStorageSync("device", e), t.globalData.systemInfo = e;
              }
            }), this.globalData.aaa = this.globalData.sec.split("").reverse().join(""), this.globalData.bbb = this.globalData.sec.substr(1) + this.globalData.sec.substr(0, 1), this.setQd(r.default.qd), this.getPhoneId(), this.start_Up();
          },
          onShow: function onShow() {
            (a.getStorageSync("sid") || a.getStorageSync("uid")) && this.getUserInfo(function (e) {});
          },
          onHide: function onHide() {},
          methods: {
            commonencry: function commonencry() {
              return JSON.stringify(s.default.getEncryption());
            },
            findpyblack: function findpyblack() {
              var e = this,
                t = e.globalData.appApi + "/peiyin/findpyblack";
              s.default.postRequest({}, t, function (t) {
                if (t.model) for (var o = t.model.split(","), a = 0; a < o.length; a++) "0" == o[a] ? (e.globalData.heimingdan0 = !0, e.$store ? e.$store.commit("setheimingdan0", e.globalData.heimingdan0) : e.$vm.$store.commit("setheimingdan0", e.globalData.heimingdan0)) : "1" == o[a] ? e.globalData.heimingdan1 = !0 : "2" == o[a] && (e.globalData.heimingdan2 = !0);
              });
            },
            examineText: function examineText(e, t) {
              var o = this;
              return new Promise(function (n, i) {
                var r = o.globalData.appApi + "/security/green/text";
                s.default.postRequest({
                  text: e
                }, r, function (e) {
                  console.log("文本检查结果", e), "0" !== e.rc && n(!0);
                  var o = {
                    10001: " 广告",
                    20001: "时政",
                    20002: "色情",
                    20003: "辱骂",
                    20006: "违法犯罪",
                    20008: "欺诈",
                    20012: "低俗",
                    20013: "版权",
                    21e3: "其他"
                  };
                  o[e.model.label] ? (a.showModal({
                    title: "提示",
                    content: "文本内容包含".concat(o[e.model.label] ? o[e.model.label] : "", "相关违规文字信息，请修改后重新操作"),
                    cancelText: "联系客服",
                    success: function success(e) {
                      e.confirm ? t && t() : e.cancel && a.navigateTo({
                        url: "/pages/wode/kefu/kefu"
                      });
                    }
                  }), n(!1)) : n(!0);
                });
              });
            },
            examineImg: function examineImg(e, t) {
              var o = this;
              return new Promise(function (n, i) {
                var r = o.globalData.appApi + "/peiyin/wxurllink/examinewximg",
                  l = {
                    url: e
                  };
                s.default.postRequest(l, r, function (e) {
                  "0" !== e.rc && n(!0), console.log("图片检查结果", e);
                  var o = JSON.parse(e.model),
                    i = o.errcode;
                  0 !== i && a.showModal({
                    title: "提示",
                    content: "该图片存在敏感信息，暂无法使用，如有疑问，请联系客服处理",
                    cancelText: "联系客服",
                    success: function success(e) {
                      e.confirm ? t && t() : e.cancel && a.switchTab({
                        url: "/pages/mine/mine"
                      });
                    }
                  }), n(0 === i);
                });
              });
            },
            isShowPay: function isShowPay() {
              var e = a.getStorageSync("device").platform;
              return "ios" !== e && "devtools" != e;
            },
            downMp4ForAlbum: function downMp4ForAlbum(e) {
              console.log("导出MP4", e), a.downloadFile({
                url: e,
                success: function success(e) {
                  console.log("res", e), 200 === e.statusCode && (a.hideLoading(), a.saveVideoToPhotosAlbum({
                    filePath: e.tempFilePath,
                    success: function success() {
                      a.showModal({
                        title: "导出成功",
                        content: "前往相册查看"
                      });
                    }
                  }));
                }
              });
            },
            qryApiLimit: function qryApiLimit(e) {
              var t = this;
              return new Promise(function (o, a) {
                var n = {
                    apiType: e,
                    isVip: t.globalData.userinfo.userrich.isvalidvip
                  },
                  i = t.globalData.appApi + "/peiyin/qryapilimitapp";
                console.log("json", n), console.log("url", i), s.default.postRequest(n, i, function (e) {
                  console.log("api剩余次数", e), o(e);
                });
              });
            },
            updateApiLimit: function updateApiLimit(e) {
              var t = {
                  apiType: e,
                  isVip: this.globalData.userinfo.userrich.isvalidvip
                },
                o = this.globalData.appApi + "/peiyin/uptapilimitapp";
              s.default.postRequest(t, o, function (e) {
                console.log("api更新次数", e);
              });
            },
            setOssPath: function setOssPath(e, t, o) {
              a.uploadFile({
                url: this.globalData.appApi + "/peiyin/music/univerupload",
                filePath: e,
                name: "file",
                formData: {
                  isrestrict: "0",
                  catalogue: t,
                  osstype: "1",
                  comparam: getApp().commonencry()
                },
                success: function success(e) {
                  console.log("上传本地文件到oss", e), o(JSON.parse(e.data).model);
                },
                fail: function fail(e) {
                  a.showToast({
                    title: "图片上传失败！",
                    icon: "none"
                  }), o("fail");
                }
              });
            },
            generatePoster: function generatePoster(e) {
              var t = {
                req: JSON.stringify({
                  qd: this.globalData.qd,
                  ver: this.globalData.ver,
                  sceneStr: this.globalData.userinfo.userinfo.id,
                  page: "pages/make/make"
                })
              };
              console.log("生成分享二维码", t);
              var o = this.globalData.appApi + "/wxgetqrcode";
              a.request({
                url: o,
                method: "POST",
                header: {
                  "content-type": "application/x-www-form-urlencoded",
                  cookie: "SESSION=" + (a.getStorageSync("sid") ? a.getStorageSync("sid") : "")
                },
                data: t,
                success: function success(t) {
                  e(t);
                }
              });
            },
            getShare: function getShare(e) {
              var t = this;
              (e.parentid || e.scene) && setTimeout(function () {
                var o = e.parentid;
                if (e.scene && (o = decodeURIComponent(e.scene)), o) {
                  t.globalData.parentid = o;
                  var n = {
                      parentid: o
                    },
                    i = getApp().globalData.baseApi + "/user/bindparent";
                  s.default.postRequest(n, i, function (e) {
                    console.log("分享绑定", e), a.showToast({
                      title: "绑定上级成功",
                      icon: "none",
                      duration: 2e3
                    }), getApp().getUserInfo(function (e) {});
                  }, function (e) {
                    if (console.log("绑定失败aaaa", e), "1501" == e.rc) a.showToast({
                      title: "您已绑定过上级，不可再次绑定",
                      icon: "none",
                      duration: 2e3
                    });else {
                      var t = e.rd;
                      a.showToast({
                        title: t,
                        icon: "none",
                        duration: 2e3
                      });
                    }
                  });
                }
              }, 1e3);
            },
            getbdKF: function getbdKF() {
              r.default.kfurl && e.openCustomerServiceChat({
                extInfo: {
                  url: r.default.kfurl
                },
                corpId: r.default.kfcorpId,
                showMessageCard: !0,
                sendMessageTitle: "请稍等，客服马上就到(" + this.globalData.userinfo.userinfo.id + ")",
                sendMessageImg: "https://pysqstoss.shipook.com/imgs/20220117/202306011h.png"
              });
            },
            copyObj: function copyObj(e) {
              var t = null;
              if ("object" == (0, i.default)(e) && null !== e) for (var o in t = e instanceof Array ? [] : {}, e) t[o] = this.copyObj(e[o]);else t = e;
              return t;
            },
            getLocation: function getLocation(e) {
              a.getLocation({
                type: "gcj02",
                success: function success(t) {
                  var o = t.latitude,
                    a = t.longitude;
                  console.log(t);
                  var n = {
                      lng: a,
                      lat: o
                    },
                    i = getApp().globalData.baseApi + "/common/getprovince";
                  s.default.postRequest(n, i, function (t) {
                    console.log("通过经纬度获取地址", t), e(t);
                  });
                },
                fail: function fail(t) {
                  e("fail"), a.showToast({
                    title: "获取位置信息失败！",
                    icon: "none"
                  }), console.log("获取位置失败", t);
                }
              });
            },
            setUserInfo: function setUserInfo(e, t) {
              console.log("用户信息2222", e), r.default.free && (e.model.userrich.isvalidsvip = "1"), a.setStorageSync("uid", e.model.userinfo.uid), a.setStorageSync("did", e.model.userinfo.did), this.$store ? this.$store.commit("setUserMessage", e.model) : this.$vm.$store.commit("setUserMessage", e.model), getApp().globalData.userinfo = e.model, t(e);
            },
            wxLogin: function wxLogin(e) {
              a.login({
                provider: "weixin",
                success: function success(t) {
                  var o = {
                      isbind: "0",
                      code: t.code
                    },
                    n = getApp().globalData.baseApi + getApp().globalData.base_url.login4wechat,
                    i = function i(t) {
                      a.setStorageSync("sid", t.model.userinfo.sid), getApp().setUserInfo(t, e);
                    };
                  s.default.postRequest(o, n, i);
                }
              });
            },
            disposeNewUser: function disposeNewUser(e, t) {
              var o = this,
                n = new Date(e.ctime).getTime(),
                i = new Date().getTime(),
                r = i - n,
                l = 6048e5;
              "用户" === e.nickname && r <= l && a.showModal({
                title: "提示",
                content: "需要获取您的微信昵称与头像用于完善资料显示，是否同意获取？",
                success: function success(e) {
                  e.confirm && a.getUserProfile({
                    desc: "用于完善资料显示",
                    success: function success(e) {
                      var a = {
                          nickname: e.userInfo.nickName,
                          avatar: e.userInfo.avatarUrl
                        },
                        n = o.globalData.baseApi + "/user/updateuserinfo";
                      s.default.postRequest(a, n, function (e) {
                        t && t();
                      });
                    }
                  });
                }
              });
            },
            getUserInfo: function getUserInfo(e) {
              var t = this,
                o = this.globalData.baseApi + this.globalData.base_url.qryuserallinfo;
              s.default.postRequest({}, o, function (o) {
                console.log("获取用户信息", o), t.setUserInfo(o, e);
              });
            },
            getPay: function getPay(e, t, o, n, i, r, l) {
              a.showLoading({
                title: "加载中",
                mask: !0
              });
              var c = this,
                u = 10 * Number(o).toFixed(2),
                p = {
                  crgtype: 2,
                  paytype: e,
                  ordername: t,
                  jb: u,
                  rmb: o,
                  orderid: i,
                  ordertype: n,
                  extdata: r,
                  ish5: 3
                };
              console.log(p);
              var d = this.globalData.baseApi + this.globalData.base_url.cashorder;
              this.globalData.crgid = "";
              var f = function f(t) {
                c.callPay(e, t, l);
              };
              s.default.postRequest(p, d, f);
            },
            getVip: function getVip(e, t, o, n, i, r) {
              a.showLoading({
                title: "加载中",
                mask: !0
              });
              var l = this,
                c = {
                  viptype: e,
                  sviptype: t,
                  paytype: o,
                  time: n,
                  extdata: i,
                  ish5: 3
                };
              console.log("开通会员", c);
              var u = this.globalData.baseApi + this.globalData.base_url.openvip,
                p = function p(e) {
                  l.callPay(o, e, r);
                };
              s.default.postRequest(c, u, p);
            },
            callPay: function callPay(e, t, o) {
              2 == e && t.model.orderparams4webchat ? this.wxPayForMp(t, o) : 1 == e && t.model.orderstr4alipay;
            },
            wxPayForApp: function wxPayForApp(e, t) {
              var o = this;
              a.requestPayment({
                provider: "wxpay",
                orderInfo: e.model.orderparams4webchat,
                success: function success(e) {
                  o.getUserInfo(), a.hideLoading(), t(e);
                },
                fail: function fail(e) {
                  a.hideLoading(), a.showToast({
                    title: "支付失败",
                    icon: "none"
                  });
                }
              });
            },
            wxPayForMp: function wxPayForMp(e, t) {
              var o = this;
              a.requestPayment({
                provider: "wxpay",
                timeStamp: e.model.orderparams4webchat.timestamp,
                nonceStr: e.model.orderparams4webchat.noncestr,
                package: "prepay_id=" + e.model.orderparams4webchat.prepayid,
                signType: "MD5",
                paySign: e.model.orderparams4webchat.sign,
                success: function success(e) {
                  o.getUserInfo(), a.hideLoading(), t(e);
                },
                fail: function fail(e) {
                  a.hideLoading();
                }
              });
            },
            aliPayForApp: function aliPayForApp(e, t) {
              var o = this;
              a.requestPayment({
                provider: "alipay",
                orderInfo: e.model.orderstr4alipay,
                success: function success(e) {
                  o.getUserInfo(), a.hideLoading(), t(e);
                },
                fail: function fail(e) {
                  a.hideLoading(), a.showToast({
                    title: "支付失败",
                    icon: "none"
                  });
                }
              });
            },
            zjPayForMp: function zjPayForMp(e, t) {},
            setQd: function setQd(e) {
              var t = "";
              t = this.globalData.systemInfo ? this.globalData.systemInfo.platform : a.getSystemInfoSync().platform, console.log("bradn", t), this.globalData.qd = "ios" == t || "devtools1" == t ? "2" + e.slice(1) : e, console.log("渠道号", this.globalData.qd);
            },
            start_Up: function start_Up() {
              var e,
                t = this,
                o = new Date().toLocaleDateString();
              e = a.getStorageSync("active") ? a.getStorageSync("active") == o ? "0" : "2" : "1";
              var n = {
                  active: e
                },
                i = t.globalData.baseApi + t.globalData.base_url.bootup;
              s.default.postRequest(n, i, function (e) {
                console.log("合肥阅舟科技-设备启动信息", e), t.globalData.appcfg = e.model.appcfg ? JSON.parse(e.model.appcfg) : {}, t.globalData.freetype = e.model.appcfg ? JSON.parse(e.model.appcfg).freetype : "0", t.globalData.svip_char = t.globalData.appcfg.svip_char, t.globalData.vipList = e.model.jbviplist, t.globalData.zifubao = JSON.parse(e.model.appcfg).zifubao, e.model.appcfg && (JSON.parse(e.model.appcfg).iospay ? t.globalData.iospay = JSON.parse(e.model.appcfg).iospay : t.globalData.iospay = 1, JSON.parse(e.model.appcfg).hideiospay ? t.globalData.hideiospay = JSON.parse(e.model.appcfg).hideiospay : t.globalData.hideiospay = 1), t.hidearea(), t.findpyblack(), a.setStorageSync("active", o);
              });
              var r = t.globalData.baseApi + "/business/qujbl";
              s.default.postRequest({}, r, function (e) {
                console.log("获取配置信息", e), t.globalData.isexamine = "1" === e.model.isexm, t.globalData.iswcp = e.model.iswcp, a.$emit("qryttscfg");
              });
            },
            hidearea: function hidearea() {
              var e = this,
                t = {
                  functype: "0"
                },
                o = e.globalData.baseApi + "/business/qryshieldfunc";
              s.default.postRequest(t, o, function (t) {
                var o;
                console.log("屏蔽地区", t), o = "0" == t.rc && t.model.iospay ? t.model.iospay : "1", e.globalData.ishidetype = o, e.globalData.ios_status = "1" == o ? e.globalData.hideiospay : "0" == o ? e.globalData.iospay : 1;
              });
            },
            getPhoneId: function getPhoneId() {},
            getStorageFun: function getStorageFun(e, t) {
              var o = new Date().toLocaleDateString();
              if (!a.getStorageSync(e)) return a.setStorageSync(e, o), void t();
              a.getStorageSync(e) != o && (a.setStorageSync(e, o), a.removeStorageSync("bgmusic"), t());
            },
            showLoginToast: function showLoginToast() {
              a.showModal({
                title: "登录提示",
                content: "您当前未登录，请先去登录",
                cancelText: "取消",
                confirmText: "登录",
                showCancel: !0,
                success: function success(e) {
                  e.confirm && getApp().relogin();
                }
              });
            },
            relogin: function relogin() {
              var e = this,
                t = function t(_t) {
                  e.$vm.$store.commit("setIsunlogin", !1), e.$vm.$store.commit("setUserMessage", _t.model), a.showToast({
                    title: "登录成功"
                  });
                };
              getApp().wxLogin(function (e) {
                t(e);
              });
            },
            prosssCirculation: function prosssCirculation(e, t) {
              var o = {
                asyncId: e
              };
              getApp().globalData.timeInfo = setInterval(function () {
                var e = getApp().globalData.appApi + "/peiyin/asyncProcess/selectProcess";
                s.default.postRequest(o, e, function (e) {
                  "0" === e.rc ? "2" == e.model.processState ? (getApp().stoptimerinfo(), t && (t({
                    type: "1",
                    result: e.model
                  }), a.hideLoading({}))) : "1" == e.model.processState && (getApp().stoptimerinfo(), t && t({
                    type: "0",
                    result: e.model.failDesc
                  }), a.hideLoading({})) : (getApp().stoptimerinfo(), t && t({
                    type: "0",
                    result: e.rd
                  }), a.hideLoading({}));
                }, function (e) {
                  getApp().stoptimerinfo(), t && t({
                    type: "0",
                    result: "操作失败"
                  }), a.hideLoading({});
                });
              }, 3e3);
            },
            stoptimerinfo: function stoptimerinfo() {
              getApp().globalData.timeInfo && (clearInterval(getApp().globalData.timeInfo), getApp().globalData.timeInfo = 0);
            },
            getProcessId: function getProcessId(e, t, o) {
              (0, l.getProcess)(e, t).then(function (e) {
                if ("0" === e.rc) {
                  var t = e.model;
                  getApp().globalData.timeInfo && getApp().stoptimerinfo(), getApp().prosssCirculation(t, o);
                }
              }).catch(function (e) {
                console.log(e);
              });
            }
          },
          mounted: function mounted() {}
        });
      t.default = c;
    }).call(this, o(1)["default"], o(2)["default"]);
  },
  380: function _(e, t, o) {
    "use strict";

    (function (e, t) {
      var a = o(4);
      o(26);
      a(o(25));
      var n = a(o(381));
      e.__webpack_require_UNI_MP_PLUGIN__ = o, t(n.default);
    }).call(this, o(1)["default"], o(2)["createPage"]);
  },
  381: function _(e, t, o) {
    "use strict";

    o.r(t);
    var a = o(382),
      n = o(384);
    for (var i in n) ["default"].indexOf(i) < 0 && function (e) {
      o.d(t, e, function () {
        return n[e];
      });
    }(i);
    o(387);
    var s,
      r = o(230),
      l = Object(r["default"])(n["default"], a["render"], a["staticRenderFns"], !1, null, null, null, !1, a["components"], s);
    l.options.__file = "pages/real/real.vue", t["default"] = l.exports;
  },
  382: function _(e, t, o) {
    "use strict";

    o.r(t);
    var a = o(383);
    o.d(t, "render", function () {
      return a["render"];
    }), o.d(t, "staticRenderFns", function () {
      return a["staticRenderFns"];
    }), o.d(t, "recyclableRender", function () {
      return a["recyclableRender"];
    }), o.d(t, "components", function () {
      return a["components"];
    });
  },
  383: function _(e, t, o) {
    "use strict";

    var a;
    o.r(t), o.d(t, "render", function () {
      return n;
    }), o.d(t, "staticRenderFns", function () {
      return s;
    }), o.d(t, "recyclableRender", function () {
      return i;
    }), o.d(t, "components", function () {
      return a;
    });
    try {
      a = {
        uNoticeBar: function uNoticeBar() {
          return Promise.all([o.e("common/vendor"), o.e("uni_modules/uview-ui/components/u-notice-bar/u-notice-bar")]).then(o.bind(null, 1214));
        },
        uLoadmore: function uLoadmore() {
          return Promise.all([o.e("common/vendor"), o.e("uni_modules/uview-ui/components/u-loadmore/u-loadmore")]).then(o.bind(null, 1222));
        }
      };
    } catch (r) {
      if (-1 === r.message.indexOf("Cannot find module") || -1 === r.message.indexOf(".vue")) throw r;
      console.error(r.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
    }
    var n = function n() {
        var e = this,
          t = e.$createElement,
          o = (e._self._c, e.noticeText.length);
        e._isMounted || (e.e0 = function (t, o) {
          var a = arguments[arguments.length - 1].currentTarget.dataset,
            n = a.eventParams || a["event-params"];
          o = n.item;
          return t.stopPropagation(), e.audio.play(o.soundurl);
        }, e.e1 = function (t, o) {
          var a = arguments[arguments.length - 1].currentTarget.dataset,
            n = a.eventParams || a["event-params"];
          o = n.item;
          return t.stopPropagation(), e.audio.play(o.soundurl);
        }), e.$mp.data = Object.assign({}, {
          $root: {
            g0: o
          }
        });
      },
      i = !1,
      s = [];
    n._withStripped = !0;
  },
  384: function _(e, t, o) {
    "use strict";

    o.r(t);
    var a = o(385),
      n = o.n(a);
    for (var i in a) ["default"].indexOf(i) < 0 && function (e) {
      o.d(t, e, function () {
        return a[e];
      });
    }(i);
    t["default"] = n.a;
  },
  385: function _(e, t, o) {
    "use strict";

    (function (e) {
      var a = o(4);
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var n = a(o(18)),
        i = a(o(11)),
        s = o(227),
        r = o(386),
        l = a(o(369));
      function c(e, t) {
        var o = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var a = Object.getOwnPropertySymbols(e);
          t && (a = a.filter(function (t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
          })), o.push.apply(o, a);
        }
        return o;
      }
      function u(e) {
        for (var t = 1; t < arguments.length; t++) {
          var o = null != arguments[t] ? arguments[t] : {};
          t % 2 ? c(Object(o), !0).forEach(function (t) {
            (0, i.default)(e, t, o[t]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : c(Object(o)).forEach(function (t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t));
          });
        }
        return e;
      }
      var p = {
        computed: u({}, (0, s.mapState)(["titleInfo", "app_config", "is_unlogin"])),
        data: function data() {
          return {
            noticeText: "",
            real_tab: 0,
            top_height: 0,
            scrollLeft: 0,
            moveParams: {
              scrollLeft: 0,
              screenHalfWidth: null
            },
            catlist: [],
            reallist: [],
            list: [],
            recommend: [],
            audio: new l.default(),
            scroll_top: 0,
            page: 1,
            lastPage: !1,
            cattype: "1000"
          };
        },
        created: function created() {
          var t = this;
          e.getSystemInfo({
            success: function success(e) {
              t.moveParams.screenHalfWidth = e.screenWidth / 2;
            }
          });
        },
        onLoad: function onLoad() {
          this.initLayoutInfo(), this.getRecommend(), this.getlivecat(), this.getlivebycat(!1), this.getNotice();
        },
        onShow: function onShow() {
          this.is_unlogin && e.showModal({
            title: "登录提示",
            content: "您当前未登录，请先去登录",
            confirmText: "登录",
            showCancel: !1,
            success: function success(e) {
              e.confirm && getApp().relogin();
            }
          });
        },
        methods: {
          getlivecat: function getlivecat() {
            var t = this;
            (0, r.qrylivecat)({}).then(function (o) {
              t.catlist = o.model, t.$nextTick(function () {
                e.hideLoading();
              });
            });
          },
          getRecommend: function getRecommend() {
            var e = this;
            (0, r.tonereCommend)({}).then(function (t) {
              console.log("每日推荐", t), e.recommend = t.model;
            });
          },
          initLayoutInfo: function initLayoutInfo() {
            var t = this,
              o = e.getMenuButtonBoundingClientRect();
            this.$store.commit("setTitleInfo", o), this.$nextTick(function () {
              var o = e.createSelectorQuery().in(t);
              o.select("#top_con").boundingClientRect(function (e) {
                t.top_height = e.height;
              }).exec();
            });
          },
          getNotice: function getNotice() {
            var e = this,
              t = {
                type: "3"
              };
            (0, r.getnoticeinfov2)(t).then(function (t) {
              if (t.model[0]) {
                var o = t.model[0].endtime,
                  a = t.model[0].starttime,
                  n = new Date(),
                  i = n.getTime() - a,
                  s = o - n.getTime();
                e.noticeText = i > 0 && s > 0 ? t.model[0].content : "";
              }
            });
          },
          jumpRealInfo: function jumpRealInfo(t) {
            e.navigateTo({
              url: "/pages2/real/real_info?speakerid=" + t
            });
          },
          searchReal: function searchReal() {
            e.navigateTo({
              url: "/pages2/real/real_search"
            });
          },
          jumpRealDemo: function jumpRealDemo() {
            e.navigateTo({
              url: "/pages2/real/real_demo"
            });
          },
          setTab: function setTab(t, o) {
            var a = this;
            this.real_tab = t;
            var n = "#ele" + t;
            e.createSelectorQuery().in(this).select(n).boundingClientRect(function (e) {
              var t = e.left - a.moveParams.screenHalfWidth + e.width / 2;
              a.scrollLeft = a.moveParams.scrollLeft + t;
            }).exec(), this.cattype = o.cattype, this.getlivebycat(!1), this.scroll_top = 0 === this.scroll_top ? .01 : 0, this.$uma_wx.trackEvent("swichRealTab", o.catname);
          },
          getlivebycat: function getlivebycat() {
            var t = this,
              o = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            if (o) {
              if (this.lastPage) return;
              this.page += 1;
            } else e.showLoading({
              title: "加载中..."
            }), this.page = 1, this.lastPage = !1;
            var a = {
              page: this.page,
              rows: 20,
              cattype: this.cattype
            };
            (0, r.qrylivebycat)(a).then(function (a) {
              var i;
              (t.page = a.model.curpage, t.lastPage = a.model.lastPage, o) ? (i = t.reallist).push.apply(i, (0, n.default)(a.model.list)) : t.reallist = a.model.list;
              t.$nextTick(function () {
                e.hideLoading();
              });
            });
          },
          scrollMove: function scrollMove(e) {
            this.moveParams.scrollLeft = e.detail.scrollLeft;
          }
        }
      };
      t.default = p;
    }).call(this, o(2)["default"]);
  },
  387: function _(e, t, o) {
    "use strict";

    o.r(t);
    var a = o(388),
      n = o.n(a);
    for (var i in a) ["default"].indexOf(i) < 0 && function (e) {
      o.d(t, e, function () {
        return a[e];
      });
    }(i);
    t["default"] = n.a;
  },
  388: function _(e, t, o) {}
}, [[380, "common/runtime", "common/vendor"]]]);