(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["pages/work/work"], {
  228: function _(e, t, o) {
    "use strict";

    o.r(t);
    var n = o(229),
      i = o.n(n);
    for (var a in n) ["default"].indexOf(a) < 0 && function (e) {
      o.d(t, e, function () {
        return n[e];
      });
    }(a);
    t["default"] = i.a;
  },
  229: function _(e, t, o) {},
  27: function _(e, t, o) {
    "use strict";

    o.r(t);
    var n = o(28);
    for (var i in n) ["default"].indexOf(i) < 0 && function (e) {
      o.d(t, e, function () {
        return n[e];
      });
    }(i);
    o(228);
    var a,
      s,
      r,
      l,
      c = o(230),
      u = Object(c["default"])(n["default"], a, s, !1, null, null, null, !1, r, l);
    u.options.__file = "App.vue", t["default"] = u.exports;
  },
  28: function _(e, t, o) {
    "use strict";

    o.r(t);
    var n = o(29),
      i = o.n(n);
    for (var a in n) ["default"].indexOf(a) < 0 && function (e) {
      o.d(t, e, function () {
        return n[e];
      });
    }(a);
    t["default"] = i.a;
  },
  29: function _(e, t, o) {
    "use strict";

    (function (e, n) {
      var i = o(4);
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var a = i(o(13)),
        s = (i(o(30)), i(o(31))),
        r = i(o(225)),
        l = o(226),
        c = (o(227), {
          globalData: {
            baseApi: "https://pysq.shipook.com/v2base",
            appApi: "https://pysq.shipook.com/v2app",
            app_url: {},
            base_url: {
              getsmscode: "/common/getsmscode",
              login4wechat: "/thirdlogin/login4wechat",
              login4zjtd: "/thirdlogin/login4zjtd",
              login4baidu: "/thirdlogin/login4baidu",
              userlogin: "/user/userlogin",
              qryuserallinfo: "/user/qryuserallinfo",
              cashorder: "/business/cashorder",
              openvip: "/business/openvip",
              bootup: "/common/bootup",
              updatedeviceinfo: "/common/updatedeviceinfo",
              getbusupgradeinfo: "/busupgrade/getbusupgradeinfo",
              qryuserjbviplist: "/business/qryuserjbviplist"
            },
            tab_work: 0,
            qd: "",
            ver: "010009",
            sec: "48a0088cb506e6b7",
            aaa: "",
            bbb: "",
            deviceId: "",
            wxappid: "",
            userinfo: null,
            crgid: "",
            parentid: "",
            deviceMac: "",
            oaid: "",
            ss: "",
            showPay: !0,
            freetype: null,
            vipList: [],
            svip_char: {},
            ios_status: 1,
            tts_text: "",
            ishidetype: "",
            heimingdan0: "",
            heimingdan1: "",
            heimingdan2: "",
            systemInfo: null,
            timeInfo: 0
          },
          onLaunch: function onLaunch() {
            var t = this;
            this.$store.commit("setAppConfig", r.default), 1154 === e.getLaunchOptionsSync().scene && (n.setStorageSync("ispyq", !0), n.switchTab({
              url: "/pages/make/make?pyq=1"
            }));
            var o = e.getUpdateManager();
            o.onCheckForUpdate(function (e) {
              if (!e.hasUpdate) return !1;
              o.onUpdateReady(function () {
                o.applyUpdate();
              });
            }), n.setInnerAudioOption({
              obeyMuteSwitch: !1
            }), n.getSystemInfo({
              complete: function complete(e) {
                n.setStorageSync("device", e), t.globalData.systemInfo = e;
              }
            }), this.globalData.aaa = this.globalData.sec.split("").reverse().join(""), this.globalData.bbb = this.globalData.sec.substr(1) + this.globalData.sec.substr(0, 1), this.setQd(r.default.qd), this.getPhoneId(), this.start_Up();
          },
          onShow: function onShow() {
            (n.getStorageSync("sid") || n.getStorageSync("uid")) && this.getUserInfo(function (e) {});
          },
          onHide: function onHide() {},
          methods: {
            commonencry: function commonencry() {
              return JSON.stringify(s.default.getEncryption());
            },
            findpyblack: function findpyblack() {
              var e = this,
                t = e.globalData.appApi + "/peiyin/findpyblack";
              s.default.postRequest({}, t, function (t) {
                if (t.model) for (var o = t.model.split(","), n = 0; n < o.length; n++) "0" == o[n] ? (e.globalData.heimingdan0 = !0, e.$store ? e.$store.commit("setheimingdan0", e.globalData.heimingdan0) : e.$vm.$store.commit("setheimingdan0", e.globalData.heimingdan0)) : "1" == o[n] ? e.globalData.heimingdan1 = !0 : "2" == o[n] && (e.globalData.heimingdan2 = !0);
              });
            },
            examineText: function examineText(e, t) {
              var o = this;
              return new Promise(function (i, a) {
                var r = o.globalData.appApi + "/security/green/text";
                s.default.postRequest({
                  text: e
                }, r, function (e) {
                  console.log("文本检查结果", e), "0" !== e.rc && i(!0);
                  var o = {
                    10001: " 广告",
                    20001: "时政",
                    20002: "色情",
                    20003: "辱骂",
                    20006: "违法犯罪",
                    20008: "欺诈",
                    20012: "低俗",
                    20013: "版权",
                    21e3: "其他"
                  };
                  o[e.model.label] ? (n.showModal({
                    title: "提示",
                    content: "文本内容包含".concat(o[e.model.label] ? o[e.model.label] : "", "相关违规文字信息，请修改后重新操作"),
                    cancelText: "联系客服",
                    success: function success(e) {
                      e.confirm ? t && t() : e.cancel && n.navigateTo({
                        url: "/pages/wode/kefu/kefu"
                      });
                    }
                  }), i(!1)) : i(!0);
                });
              });
            },
            examineImg: function examineImg(e, t) {
              var o = this;
              return new Promise(function (i, a) {
                var r = o.globalData.appApi + "/peiyin/wxurllink/examinewximg",
                  l = {
                    url: e
                  };
                s.default.postRequest(l, r, function (e) {
                  "0" !== e.rc && i(!0), console.log("图片检查结果", e);
                  var o = JSON.parse(e.model),
                    a = o.errcode;
                  0 !== a && n.showModal({
                    title: "提示",
                    content: "该图片存在敏感信息，暂无法使用，如有疑问，请联系客服处理",
                    cancelText: "联系客服",
                    success: function success(e) {
                      e.confirm ? t && t() : e.cancel && n.switchTab({
                        url: "/pages/mine/mine"
                      });
                    }
                  }), i(0 === a);
                });
              });
            },
            isShowPay: function isShowPay() {
              var e = n.getStorageSync("device").platform;
              return "ios" !== e && "devtools" != e;
            },
            downMp4ForAlbum: function downMp4ForAlbum(e) {
              console.log("导出MP4", e), n.downloadFile({
                url: e,
                success: function success(e) {
                  console.log("res", e), 200 === e.statusCode && (n.hideLoading(), n.saveVideoToPhotosAlbum({
                    filePath: e.tempFilePath,
                    success: function success() {
                      n.showModal({
                        title: "导出成功",
                        content: "前往相册查看"
                      });
                    }
                  }));
                }
              });
            },
            qryApiLimit: function qryApiLimit(e) {
              var t = this;
              return new Promise(function (o, n) {
                var i = {
                    apiType: e,
                    isVip: t.globalData.userinfo.userrich.isvalidvip
                  },
                  a = t.globalData.appApi + "/peiyin/qryapilimitapp";
                console.log("json", i), console.log("url", a), s.default.postRequest(i, a, function (e) {
                  console.log("api剩余次数", e), o(e);
                });
              });
            },
            updateApiLimit: function updateApiLimit(e) {
              var t = {
                  apiType: e,
                  isVip: this.globalData.userinfo.userrich.isvalidvip
                },
                o = this.globalData.appApi + "/peiyin/uptapilimitapp";
              s.default.postRequest(t, o, function (e) {
                console.log("api更新次数", e);
              });
            },
            setOssPath: function setOssPath(e, t, o) {
              n.uploadFile({
                url: this.globalData.appApi + "/peiyin/music/univerupload",
                filePath: e,
                name: "file",
                formData: {
                  isrestrict: "0",
                  catalogue: t,
                  osstype: "1",
                  comparam: getApp().commonencry()
                },
                success: function success(e) {
                  console.log("上传本地文件到oss", e), o(JSON.parse(e.data).model);
                },
                fail: function fail(e) {
                  n.showToast({
                    title: "图片上传失败！",
                    icon: "none"
                  }), o("fail");
                }
              });
            },
            generatePoster: function generatePoster(e) {
              var t = {
                req: JSON.stringify({
                  qd: this.globalData.qd,
                  ver: this.globalData.ver,
                  sceneStr: this.globalData.userinfo.userinfo.id,
                  page: "pages/make/make"
                })
              };
              console.log("生成分享二维码", t);
              var o = this.globalData.appApi + "/wxgetqrcode";
              n.request({
                url: o,
                method: "POST",
                header: {
                  "content-type": "application/x-www-form-urlencoded",
                  cookie: "SESSION=" + (n.getStorageSync("sid") ? n.getStorageSync("sid") : "")
                },
                data: t,
                success: function success(t) {
                  e(t);
                }
              });
            },
            getShare: function getShare(e) {
              var t = this;
              (e.parentid || e.scene) && setTimeout(function () {
                var o = e.parentid;
                if (e.scene && (o = decodeURIComponent(e.scene)), o) {
                  t.globalData.parentid = o;
                  var i = {
                      parentid: o
                    },
                    a = getApp().globalData.baseApi + "/user/bindparent";
                  s.default.postRequest(i, a, function (e) {
                    console.log("分享绑定", e), n.showToast({
                      title: "绑定上级成功",
                      icon: "none",
                      duration: 2e3
                    }), getApp().getUserInfo(function (e) {});
                  }, function (e) {
                    if (console.log("绑定失败aaaa", e), "1501" == e.rc) n.showToast({
                      title: "您已绑定过上级，不可再次绑定",
                      icon: "none",
                      duration: 2e3
                    });else {
                      var t = e.rd;
                      n.showToast({
                        title: t,
                        icon: "none",
                        duration: 2e3
                      });
                    }
                  });
                }
              }, 1e3);
            },
            getbdKF: function getbdKF() {
              r.default.kfurl && e.openCustomerServiceChat({
                extInfo: {
                  url: r.default.kfurl
                },
                corpId: r.default.kfcorpId,
                showMessageCard: !0,
                sendMessageTitle: "请稍等，客服马上就到(" + this.globalData.userinfo.userinfo.id + ")",
                sendMessageImg: "https://pysqstoss.shipook.com/imgs/20220117/202306011h.png"
              });
            },
            copyObj: function copyObj(e) {
              var t = null;
              if ("object" == (0, a.default)(e) && null !== e) for (var o in t = e instanceof Array ? [] : {}, e) t[o] = this.copyObj(e[o]);else t = e;
              return t;
            },
            getLocation: function getLocation(e) {
              n.getLocation({
                type: "gcj02",
                success: function success(t) {
                  var o = t.latitude,
                    n = t.longitude;
                  console.log(t);
                  var i = {
                      lng: n,
                      lat: o
                    },
                    a = getApp().globalData.baseApi + "/common/getprovince";
                  s.default.postRequest(i, a, function (t) {
                    console.log("通过经纬度获取地址", t), e(t);
                  });
                },
                fail: function fail(t) {
                  e("fail"), n.showToast({
                    title: "获取位置信息失败！",
                    icon: "none"
                  }), console.log("获取位置失败", t);
                }
              });
            },
            setUserInfo: function setUserInfo(e, t) {
              console.log("用户信息2222", e), r.default.free && (e.model.userrich.isvalidsvip = "1"), n.setStorageSync("uid", e.model.userinfo.uid), n.setStorageSync("did", e.model.userinfo.did), this.$store ? this.$store.commit("setUserMessage", e.model) : this.$vm.$store.commit("setUserMessage", e.model), getApp().globalData.userinfo = e.model, t(e);
            },
            wxLogin: function wxLogin(e) {
              n.login({
                provider: "weixin",
                success: function success(t) {
                  var o = {
                      isbind: "0",
                      code: t.code
                    },
                    i = getApp().globalData.baseApi + getApp().globalData.base_url.login4wechat,
                    a = function a(t) {
                      n.setStorageSync("sid", t.model.userinfo.sid), getApp().setUserInfo(t, e);
                    };
                  s.default.postRequest(o, i, a);
                }
              });
            },
            disposeNewUser: function disposeNewUser(e, t) {
              var o = this,
                i = new Date(e.ctime).getTime(),
                a = new Date().getTime(),
                r = a - i,
                l = 6048e5;
              "用户" === e.nickname && r <= l && n.showModal({
                title: "提示",
                content: "需要获取您的微信昵称与头像用于完善资料显示，是否同意获取？",
                success: function success(e) {
                  e.confirm && n.getUserProfile({
                    desc: "用于完善资料显示",
                    success: function success(e) {
                      var n = {
                          nickname: e.userInfo.nickName,
                          avatar: e.userInfo.avatarUrl
                        },
                        i = o.globalData.baseApi + "/user/updateuserinfo";
                      s.default.postRequest(n, i, function (e) {
                        t && t();
                      });
                    }
                  });
                }
              });
            },
            getUserInfo: function getUserInfo(e) {
              var t = this,
                o = this.globalData.baseApi + this.globalData.base_url.qryuserallinfo;
              s.default.postRequest({}, o, function (o) {
                console.log("获取用户信息", o), t.setUserInfo(o, e);
              });
            },
            getPay: function getPay(e, t, o, i, a, r, l) {
              n.showLoading({
                title: "加载中",
                mask: !0
              });
              var c = this,
                u = 10 * Number(o).toFixed(2),
                f = {
                  crgtype: 2,
                  paytype: e,
                  ordername: t,
                  jb: u,
                  rmb: o,
                  orderid: a,
                  ordertype: i,
                  extdata: r,
                  ish5: 3
                };
              console.log(f);
              var p = this.globalData.baseApi + this.globalData.base_url.cashorder;
              this.globalData.crgid = "";
              var d = function d(t) {
                c.callPay(e, t, l);
              };
              s.default.postRequest(f, p, d);
            },
            getVip: function getVip(e, t, o, i, a, r) {
              n.showLoading({
                title: "加载中",
                mask: !0
              });
              var l = this,
                c = {
                  viptype: e,
                  sviptype: t,
                  paytype: o,
                  time: i,
                  extdata: a,
                  ish5: 3
                };
              console.log("开通会员", c);
              var u = this.globalData.baseApi + this.globalData.base_url.openvip,
                f = function f(e) {
                  l.callPay(o, e, r);
                };
              s.default.postRequest(c, u, f);
            },
            callPay: function callPay(e, t, o) {
              2 == e && t.model.orderparams4webchat ? this.wxPayForMp(t, o) : 1 == e && t.model.orderstr4alipay;
            },
            wxPayForApp: function wxPayForApp(e, t) {
              var o = this;
              n.requestPayment({
                provider: "wxpay",
                orderInfo: e.model.orderparams4webchat,
                success: function success(e) {
                  o.getUserInfo(), n.hideLoading(), t(e);
                },
                fail: function fail(e) {
                  n.hideLoading(), n.showToast({
                    title: "支付失败",
                    icon: "none"
                  });
                }
              });
            },
            wxPayForMp: function wxPayForMp(e, t) {
              var o = this;
              n.requestPayment({
                provider: "wxpay",
                timeStamp: e.model.orderparams4webchat.timestamp,
                nonceStr: e.model.orderparams4webchat.noncestr,
                package: "prepay_id=" + e.model.orderparams4webchat.prepayid,
                signType: "MD5",
                paySign: e.model.orderparams4webchat.sign,
                success: function success(e) {
                  o.getUserInfo(), n.hideLoading(), t(e);
                },
                fail: function fail(e) {
                  n.hideLoading();
                }
              });
            },
            aliPayForApp: function aliPayForApp(e, t) {
              var o = this;
              n.requestPayment({
                provider: "alipay",
                orderInfo: e.model.orderstr4alipay,
                success: function success(e) {
                  o.getUserInfo(), n.hideLoading(), t(e);
                },
                fail: function fail(e) {
                  n.hideLoading(), n.showToast({
                    title: "支付失败",
                    icon: "none"
                  });
                }
              });
            },
            zjPayForMp: function zjPayForMp(e, t) {},
            setQd: function setQd(e) {
              var t = "";
              t = this.globalData.systemInfo ? this.globalData.systemInfo.platform : n.getSystemInfoSync().platform, console.log("bradn", t), this.globalData.qd = "ios" == t || "devtools1" == t ? "2" + e.slice(1) : e, console.log("渠道号", this.globalData.qd);
            },
            start_Up: function start_Up() {
              var e,
                t = this,
                o = new Date().toLocaleDateString();
              e = n.getStorageSync("active") ? n.getStorageSync("active") == o ? "0" : "2" : "1";
              var i = {
                  active: e
                },
                a = t.globalData.baseApi + t.globalData.base_url.bootup;
              s.default.postRequest(i, a, function (e) {
                console.log("合肥阅舟科技-设备启动信息", e), t.globalData.appcfg = e.model.appcfg ? JSON.parse(e.model.appcfg) : {}, t.globalData.freetype = e.model.appcfg ? JSON.parse(e.model.appcfg).freetype : "0", t.globalData.svip_char = t.globalData.appcfg.svip_char, t.globalData.vipList = e.model.jbviplist, t.globalData.zifubao = JSON.parse(e.model.appcfg).zifubao, e.model.appcfg && (JSON.parse(e.model.appcfg).iospay ? t.globalData.iospay = JSON.parse(e.model.appcfg).iospay : t.globalData.iospay = 1, JSON.parse(e.model.appcfg).hideiospay ? t.globalData.hideiospay = JSON.parse(e.model.appcfg).hideiospay : t.globalData.hideiospay = 1), t.hidearea(), t.findpyblack(), n.setStorageSync("active", o);
              });
              var r = t.globalData.baseApi + "/business/qujbl";
              s.default.postRequest({}, r, function (e) {
                console.log("获取配置信息", e), t.globalData.isexamine = "1" === e.model.isexm, t.globalData.iswcp = e.model.iswcp, n.$emit("qryttscfg");
              });
            },
            hidearea: function hidearea() {
              var e = this,
                t = {
                  functype: "0"
                },
                o = e.globalData.baseApi + "/business/qryshieldfunc";
              s.default.postRequest(t, o, function (t) {
                var o;
                console.log("屏蔽地区", t), o = "0" == t.rc && t.model.iospay ? t.model.iospay : "1", e.globalData.ishidetype = o, e.globalData.ios_status = "1" == o ? e.globalData.hideiospay : "0" == o ? e.globalData.iospay : 1;
              });
            },
            getPhoneId: function getPhoneId() {},
            getStorageFun: function getStorageFun(e, t) {
              var o = new Date().toLocaleDateString();
              if (!n.getStorageSync(e)) return n.setStorageSync(e, o), void t();
              n.getStorageSync(e) != o && (n.setStorageSync(e, o), n.removeStorageSync("bgmusic"), t());
            },
            showLoginToast: function showLoginToast() {
              n.showModal({
                title: "登录提示",
                content: "您当前未登录，请先去登录",
                cancelText: "取消",
                confirmText: "登录",
                showCancel: !0,
                success: function success(e) {
                  e.confirm && getApp().relogin();
                }
              });
            },
            relogin: function relogin() {
              var e = this,
                t = function t(_t) {
                  e.$vm.$store.commit("setIsunlogin", !1), e.$vm.$store.commit("setUserMessage", _t.model), n.showToast({
                    title: "登录成功"
                  });
                };
              getApp().wxLogin(function (e) {
                t(e);
              });
            },
            prosssCirculation: function prosssCirculation(e, t) {
              var o = {
                asyncId: e
              };
              getApp().globalData.timeInfo = setInterval(function () {
                var e = getApp().globalData.appApi + "/peiyin/asyncProcess/selectProcess";
                s.default.postRequest(o, e, function (e) {
                  "0" === e.rc ? "2" == e.model.processState ? (getApp().stoptimerinfo(), t && (t({
                    type: "1",
                    result: e.model
                  }), n.hideLoading({}))) : "1" == e.model.processState && (getApp().stoptimerinfo(), t && t({
                    type: "0",
                    result: e.model.failDesc
                  }), n.hideLoading({})) : (getApp().stoptimerinfo(), t && t({
                    type: "0",
                    result: e.rd
                  }), n.hideLoading({}));
                }, function (e) {
                  getApp().stoptimerinfo(), t && t({
                    type: "0",
                    result: "操作失败"
                  }), n.hideLoading({});
                });
              }, 3e3);
            },
            stoptimerinfo: function stoptimerinfo() {
              getApp().globalData.timeInfo && (clearInterval(getApp().globalData.timeInfo), getApp().globalData.timeInfo = 0);
            },
            getProcessId: function getProcessId(e, t, o) {
              (0, l.getProcess)(e, t).then(function (e) {
                if ("0" === e.rc) {
                  var t = e.model;
                  getApp().globalData.timeInfo && getApp().stoptimerinfo(), getApp().prosssCirculation(t, o);
                }
              }).catch(function (e) {
                console.log(e);
              });
            }
          },
          mounted: function mounted() {}
        });
      t.default = c;
    }).call(this, o(1)["default"], o(2)["default"]);
  },
  398: function _(e, t, o) {
    "use strict";

    (function (e, t) {
      var n = o(4);
      o(26);
      n(o(25));
      var i = n(o(399));
      e.__webpack_require_UNI_MP_PLUGIN__ = o, t(i.default);
    }).call(this, o(1)["default"], o(2)["createPage"]);
  },
  399: function _(e, t, o) {
    "use strict";

    o.r(t);
    var n = o(400),
      i = o(402);
    for (var a in i) ["default"].indexOf(a) < 0 && function (e) {
      o.d(t, e, function () {
        return i[e];
      });
    }(a);
    o(404);
    var s,
      r = o(230),
      l = Object(r["default"])(i["default"], n["render"], n["staticRenderFns"], !1, null, null, null, !1, n["components"], s);
    l.options.__file = "pages/work/work.vue", t["default"] = l.exports;
  },
  400: function _(e, t, o) {
    "use strict";

    o.r(t);
    var n = o(401);
    o.d(t, "render", function () {
      return n["render"];
    }), o.d(t, "staticRenderFns", function () {
      return n["staticRenderFns"];
    }), o.d(t, "recyclableRender", function () {
      return n["recyclableRender"];
    }), o.d(t, "components", function () {
      return n["components"];
    });
  },
  401: function _(e, t, o) {
    "use strict";

    var n;
    o.r(t), o.d(t, "render", function () {
      return i;
    }), o.d(t, "staticRenderFns", function () {
      return s;
    }), o.d(t, "recyclableRender", function () {
      return a;
    }), o.d(t, "components", function () {
      return n;
    });
    try {
      n = {
        uSearch: function uSearch() {
          return Promise.all([o.e("common/vendor"), o.e("uni_modules/uview-ui/components/u-search/u-search")]).then(o.bind(null, 1237));
        },
        uLoadmore: function uLoadmore() {
          return Promise.all([o.e("common/vendor"), o.e("uni_modules/uview-ui/components/u-loadmore/u-loadmore")]).then(o.bind(null, 1222));
        }
      };
    } catch (r) {
      if (-1 === r.message.indexOf("Cannot find module") || -1 === r.message.indexOf(".vue")) throw r;
      console.error(r.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
    }
    var i = function i() {
        var e = this,
          t = e.$createElement,
          o = (e._self._c, e.app_config.nozdy ? 0 === e.list.length && 0 === e.fileList.length : null),
          n = e.app_config.nozdy ? e.list.length : null,
          i = e.app_config.nozdy ? null : 0 === e.list.length && 0 === e.fileList.length,
          a = e.app_config.nozdy ? null : e.list.length;
        e._isMounted || (e.e0 = function (t) {
          e.tab = 0;
        }, e.e1 = function (t) {
          e.tab = 1;
        }, e.e2 = function (t) {
          e.tab = 0;
        }, e.e3 = function (t) {
          e.tab = 2;
        }, e.e4 = function (t) {
          e.tab = 1;
        }, e.e5 = function (t) {
          e.search_text = "";
        }, e.e6 = function (t) {
          e.show_more = !0;
        }, e.e7 = function (t) {
          e.search_text = "";
        }, e.e8 = function (t) {
          e.show_more = !0;
        }, e.e9 = function (t) {
          e.batch_state = !0;
        }, e.e10 = function (t) {
          e.batch_state = !1;
        }, e.e11 = function (t) {
          e.show_more = !1;
        }, e.e12 = function (t) {
          e.show_name = !1;
        }, e.e13 = function (t) {
          e.show_export = !1;
        }, e.e14 = function (t) {
          e.show_nonmember = !1;
        }), e.$mp.data = Object.assign({}, {
          $root: {
            g0: o,
            g1: n,
            g2: i,
            g3: a
          }
        });
      },
      a = !1,
      s = [];
    i._withStripped = !0;
  },
  402: function _(e, t, o) {
    "use strict";

    o.r(t);
    var n = o(403),
      i = o.n(n);
    for (var a in n) ["default"].indexOf(a) < 0 && function (e) {
      o.d(t, e, function () {
        return n[e];
      });
    }(a);
    t["default"] = i.a;
  },
  403: function _(e, t, o) {
    "use strict";

    (function (e) {
      var n = o(4);
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var i = n(o(255)),
        a = n(o(18)),
        s = n(o(257)),
        r = n(o(11)),
        l = o(227),
        c = o(366),
        u = o(226);
      o(25);
      function f(e, t) {
        var o = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(e);
          t && (n = n.filter(function (t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
          })), o.push.apply(o, n);
        }
        return o;
      }
      function p(e) {
        for (var t = 1; t < arguments.length; t++) {
          var o = null != arguments[t] ? arguments[t] : {};
          t % 2 ? f(Object(o), !0).forEach(function (t) {
            (0, r.default)(e, t, o[t]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : f(Object(o)).forEach(function (t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t));
          });
        }
        return e;
      }
      var d = function d() {
          o.e("components/work/remove_work").then(function () {
            return resolve(o(1245));
          }.bind(null, o)).catch(o.oe);
        },
        h = function h() {
          o.e("components/work/file_new_name").then(function () {
            return resolve(o(1252));
          }.bind(null, o)).catch(o.oe);
        },
        g = function g() {
          o.e("components/work/file_item").then(function () {
            return resolve(o(1259));
          }.bind(null, o)).catch(o.oe);
        },
        m = function m() {
          o.e("components/work/file_name").then(function () {
            return resolve(o(1266));
          }.bind(null, o)).catch(o.oe);
        },
        b = function b() {
          o.e("components/work/new_folder").then(function () {
            return resolve(o(1273));
          }.bind(null, o)).catch(o.oe);
        },
        w = function w() {
          o.e("components/work/work_item").then(function () {
            return resolve(o(1280));
          }.bind(null, o)).catch(o.oe);
        },
        v = function v() {
          o.e("components/work/work_more").then(function () {
            return resolve(o(1287));
          }.bind(null, o)).catch(o.oe);
        },
        y = function y() {
          o.e("components/work/work_name").then(function () {
            return resolve(o(1294));
          }.bind(null, o)).catch(o.oe);
        },
        _ = function _() {
          Promise.all([o.e("common/vendor"), o.e("components/work/expopup1")]).then(function () {
            return resolve(o(1301));
          }.bind(null, o)).catch(o.oe);
        },
        k = function k() {
          o.e("components/work/expopup2").then(function () {
            return resolve(o(1308));
          }.bind(null, o)).catch(o.oe);
        },
        D = function D() {
          o.e("components/make/make_nonmember1").then(function () {
            return resolve(o(1315));
          }.bind(null, o)).catch(o.oe);
        },
        S = {
          computed: p(p({}, (0, l.mapState)(["titleInfo", "select_work", "app_config", "is_unlogin"])), {}, {
            isexist: function isexist() {
              var e = new Date(),
                t = 2592e6;
              return e - this.select_work.audioutime < t;
            }
          }),
          components: {
            WorkItem: w,
            WorkMore: v,
            WorkName: y,
            Expopup: _,
            MakeNonmenber: D,
            newFolder: b,
            fileName: m,
            fileItem: g,
            fileNewName: h,
            removeWork: d,
            Expopup2: k
          },
          data: function data() {
            return {
              total: "",
              mytype: 1,
              removeWorkFlag: !1,
              new_file_name: "",
              NewFileNameFlag: !1,
              fileCon: "",
              fileMoreFlag: !1,
              buidFileFlag: !1,
              file_name: "",
              tab: 0,
              show_more: !1,
              show_name: !1,
              fileList: [],
              list: [],
              page: 1,
              lastPage: !1,
              work_name: "",
              batch_state: !1,
              show_export: !1,
              show_export2: !1,
              show_nonmember: !1,
              anchor_gold: !1,
              poptitleVip: "请开通会员后下载",
              select_all_item: !1,
              selct_num: 0,
              search_text: ""
            };
          },
          onHide: function onHide() {
            this.show_more = !1;
          },
          onShow: function onShow() {
            this.is_unlogin && e.showModal({
              title: "登录提示",
              content: "您当前未登录，请先去登录",
              confirmText: "登录",
              showCancel: !1,
              success: function success(e) {
                e.confirm && getApp().relogin();
              }
            });
          },
          onPullDownRefresh: function onPullDownRefresh() {
            this.getList(!1), setTimeout(function () {
              e.stopPullDownRefresh();
            }, 1e3);
          },
          onLoad: function onLoad() {
            var t = this,
              o = e.getMenuButtonBoundingClientRect();
            this.$store.commit("setTitleInfo", o), this.getList(!1), this.getFileList(0), e.$on("updateWork", function (e) {
              t.list = [], t.selct_num = 0, t.getList(!1), t.getFileList(0);
            }), e.$on("updatename", function (e) {
              t.getFileList(0), t.getList(!1);
            });
          },
          onReachBottom: function onReachBottom() {
            this.getList(!0);
          },
          watch: {
            tab: function tab(e) {
              this.getList(!1), this.batch_state = !1;
            },
            list: {
              handler: function handler(e, t) {
                e.length > 0 && e.length == this.selct_num ? this.select_all_item = !0 : this.select_all_item = !1;
              }
            },
            selct_num: {
              handler: function handler(e, t) {
                e > 0 && e == this.list.length ? this.select_all_item = !0 : this.select_all_item = !1;
              }
            }
          },
          methods: {
            jumpdownload: function jumpdownload() {
              var t = this;
              this.isexist ? this.show_export = !0 : e.showModal({
                title: "提示",
                content: "该作品保留时长已过期，需重新合成进行操作",
                confirmText: "重新编辑",
                success: function success(e) {
                  e.confirm && t.reeditWork();
                }
              });
            },
            hideRemoveWork: function hideRemoveWork() {
              this.getList(!1), this.getFileList(0), this.removeWorkFlag = !1, this.show_more = !1;
            },
            yidongWork: function yidongWork() {
              this.removeWorkFlag = !0;
            },
            qxbuild: function qxbuild() {
              e.showTabBar(), this.buidFileFlag = !1;
            },
            build: function build() {
              e.hideTabBar(), this.buidFileFlag = !0;
            },
            hideFileNewName: function hideFileNewName() {
              this.NewFileNameFlag = !1;
            },
            qxfilemore: function qxfilemore() {
              this.fileMoreFlag = !1, e.showTabBar();
            },
            confirmFileNewName: function confirmFileNewName(t) {
              var o = this;
              this.new_file_name = t;
              var n = {
                folderid: this.fileCon.folderid,
                foldername: this.new_file_name
              };
              (0, u.editFile)(n).then(function (e) {
                o.getFileList(0);
              }), this.NewFileNameFlag = !1, this.fileMoreFlag = !1, e.showTabBar();
            },
            renameFile: function renameFile() {
              this.NewFileNameFlag = !0;
            },
            deleteFile: function deleteFile() {
              var t = this;
              e.showModal({
                title: "提示",
                content: "确定删除该文件夹？",
                success: function success(o) {
                  if (o.confirm) {
                    var n = {
                      folderids: t.fileCon.folderid
                    };
                    (0, u.editFile)(n).then(function (o) {
                      e.showToast({
                        title: "删除成功"
                      }), t.getFileList(0), t.fileMoreFlag = !1;
                    });
                  }
                }
              });
            },
            getFileMore: function getFileMore(t) {
              e.hideTabBar(), this.fileCon = t, this.fileMoreFlag = !0;
            },
            getFileList: function getFileList(e) {
              var t = this,
                o = {
                  type: e
                };
              (0, u.getFiles)(o).then(function (e) {
                t.fileList = e.model;
              }).catch(function (e) {});
            },
            selctAllTouchClick: function selctAllTouchClick() {
              this.select_all_item ? (this.list.forEach(function (e) {
                e.batch_state && (e.batch_state = !1);
              }), this.selct_num = 0) : (this.list.forEach(function (e) {
                e.batch_state || (e.batch_state = !0);
              }), this.selct_num = this.list.length);
            },
            generate: function generate() {
              this.show_export = !1, this.show_export2 = !1;
            },
            showVipTip: function showVipTip(e) {
              this.poptitleVip = "请开通会员后下载", "1" == e.is_gold ? (this.anchor_gold = !0, this.poptitleVip = "该作品为超级主播作品，开通超级会员可无限导出") : this.anchor_gold = !1, this.show_nonmember = !0;
            },
            searchWorkInfo: function searchWorkInfo() {
              this.getList(!1);
            },
            deleteInBatches: function deleteInBatches() {
              var t = this,
                o = this.list.filter(function (e) {
                  return e.batch_state;
                });
              0 !== o.length ? e.showModal({
                title: "提示",
                content: "确定删除作品？",
                success: function success(n) {
                  if (n.confirm) {
                    var i = {
                      status: "0",
                      wkids: Array.from(o, function (e) {
                        var t = e.wkid;
                        return t;
                      }).toString()
                    };
                    (0, u.upDateWork)(i).then(function (o) {
                      e.showToast({
                        title: "删除成功"
                      }), t.getList(!1);
                    });
                  }
                }
              }) : e.showToast({
                title: "请选择要删除的作品",
                icon: "none"
              });
            },
            setBatchItem: function setBatchItem(e) {
              var t = this.list[e];
              t.batch_state = !t.batch_state, this.$set(this.list, e, t), 1 == t.batch_state ? this.selct_num += 1 : this.selct_num -= 1;
            },
            jumpWorkDownload: function jumpWorkDownload() {
              e.navigateTo({
                url: "/pages/work/work_download"
              });
            },
            removeWork: function removeWork() {
              var t = this;
              e.showModal({
                title: "提示",
                content: "确定删除该作品！",
                success: function success(e) {
                  e.confirm && t.upDateWorkInfo(0);
                }
              }), this.$uma_wx.trackEvent("delWork");
            },
            renameForWork: function renameForWork() {
              this.work_name = this.select_work.wkname, this.show_name = !0, this.$uma_wx.trackEvent("renameWork");
            },
            confirmWorkName: function confirmWorkName(t) {
              var o = this;
              return (0, s.default)(i.default.mark(function n() {
                var a;
                return i.default.wrap(function (n) {
                  while (1) switch (n.prev = n.next) {
                    case 0:
                      if (o.work_name = t, !(o.work_name.length > 30)) {
                        n.next = 4;
                        break;
                      }
                      return e.showToast({
                        title: "作品名称太长",
                        icon: "none"
                      }), n.abrupt("return");
                    case 4:
                      return e.showLoading({
                        title: "文本确认中..."
                      }), n.next = 7, getApp().examineText(o.work_name);
                    case 7:
                      if (a = n.sent, e.hideLoading(), a) {
                        n.next = 11;
                        break;
                      }
                      return n.abrupt("return");
                    case 11:
                      o.upDateWorkInfo(1), o.show_name = !1;
                    case 13:
                    case "end":
                      return n.stop();
                  }
                }, n);
              }))();
            },
            confirmFileName: function confirmFileName(t) {
              var o = this;
              if (this.file_name = t, this.file_name) {
                var n = {
                  foldername: this.file_name,
                  type: 0
                };
                (0, u.buildFile)(n).then(function (t) {
                  "0" === t.rc && (o.getFileList(0), e.showTabBar(), o.buidFileFlag = !1);
                }).catch(function (t) {
                  "2070" === t.rc && e.showModal({
                    title: "提示",
                    content: "本层级文件夹已达上限！",
                    success: function success(t) {
                      t.confirm && (e.showTabBar(), o.buidFileFlag = !1);
                    }
                  });
                });
              } else e.showModal({
                title: "提示",
                content: "文件夹名称不能为空！"
              });
            },
            reeditWork: function reeditWork() {
              var t = this,
                o = this,
                n = {
                  page: 1,
                  rows: 1,
                  zbid: o.select_work.zbid
                };
              (0, c.qrymakeanchor)(n).then(function (n) {
                o.select_work.zbmsg = n.model.page.list[0], getApp().globalData.text1 ? e.showModal({
                  title: "提示",
                  content: "检测到制作页有未制作的文本，继续配音会清除制作页所有文字且不可恢复，是否继续？",
                  confirmText: "继续编辑",
                  success: function success(o) {
                    o.confirm && (t.show_more = !1, e.$emit("reeditWork", t.select_work), e.switchTab({
                      url: "/pages/make/make"
                    }));
                  }
                }) : (t.show_more = !1, e.$emit("reeditWork", t.select_work), e.switchTab({
                  url: "/pages/make/make"
                }));
              });
            },
            upDateWorkInfo: function upDateWorkInfo(t) {
              var o = this,
                n = {
                  wkid: this.select_work.wkid
                };
              0 === t ? n.status = "0" : 1 === t && (n.wkname = this.work_name), e.showLoading({
                title: 0 === t ? "删除中..." : "处理中..."
              });
              var i = function i(n) {
                if (0 === t) o.list.splice(o.select_work.index, 1), o.list.length < 20 && o.getList(!0);else if (1 === t) {
                  var i = o.list[o.select_work.index];
                  i.wkname = o.work_name, o.$set(o.list, o.select_work.index, i);
                }
                o.show_more = !1, o.$nextTick(function () {
                  e.hideLoading(), e.showToast({
                    title: 0 === t ? "删除成功" : "处理完成",
                    icon: "none"
                  });
                });
              };
              0 === this.tab || 2 === this.tab ? (0, u.upDateWork)(n).then(function (e) {
                i(e);
              }) : (0, u.upDatelLiveWork)(n).then(function (e) {
                i(e);
              });
            },
            getList: function getList(e) {
              var t = this;
              if (e) {
                if (this.lastPage) return;
                this.page += 1;
              } else this.page = 1, this.lastPage = !1;
              var o = function o(_o) {
                  var n;
                  (t.lastPage = _o.model.lastPage, t.total = _o.model.total, e) ? (n = t.list).push.apply(n, (0, a.default)(_o.model.list)) : (t.list = _o.model.list, 0 == t.list.length && t.batch_state && (t.batch_state = !1));
                },
                n = {
                  page: this.page,
                  rows: 20
                };
              0 === this.tab ? ("" != this.search_text && (n.keyword = this.search_text), (0, u.getWorkList)(n).then(function (e) {
                o(e);
              }).catch(function (e) {})) : 2 === this.tab ? (n.multiple = "1", (0, u.getWorkList)(n).then(function (e) {
                o(e);
              }).catch(function (e) {})) : (0, u.getRealList)(n).then(function (e) {
                o(e);
              }).catch(function (e) {});
            }
          }
        };
      t.default = S;
    }).call(this, o(2)["default"]);
  },
  404: function _(e, t, o) {
    "use strict";

    o.r(t);
    var n = o(405),
      i = o.n(n);
    for (var a in n) ["default"].indexOf(a) < 0 && function (e) {
      o.d(t, e, function () {
        return n[e];
      });
    }(a);
    t["default"] = i.a;
  },
  405: function _(e, t, o) {}
}, [[398, "common/runtime", "common/vendor"]]]);