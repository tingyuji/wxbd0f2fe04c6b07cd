(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["pages/work/work_download"], {
  228: function _(e, t, o) {
    "use strict";

    o.r(t);
    var n = o(229),
      a = o.n(n);
    for (var i in n) ["default"].indexOf(i) < 0 && function (e) {
      o.d(t, e, function () {
        return n[e];
      });
    }(i);
    t["default"] = a.a;
  },
  229: function _(e, t, o) {},
  27: function _(e, t, o) {
    "use strict";

    o.r(t);
    var n = o(28);
    for (var a in n) ["default"].indexOf(a) < 0 && function (e) {
      o.d(t, e, function () {
        return n[e];
      });
    }(a);
    o(228);
    var i,
      s,
      r,
      l,
      c = o(230),
      u = Object(c["default"])(n["default"], i, s, !1, null, null, null, !1, r, l);
    u.options.__file = "App.vue", t["default"] = u.exports;
  },
  28: function _(e, t, o) {
    "use strict";

    o.r(t);
    var n = o(29),
      a = o.n(n);
    for (var i in n) ["default"].indexOf(i) < 0 && function (e) {
      o.d(t, e, function () {
        return n[e];
      });
    }(i);
    t["default"] = a.a;
  },
  29: function _(e, t, o) {
    "use strict";

    (function (e, n) {
      var a = o(4);
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var i = a(o(13)),
        s = (a(o(30)), a(o(31))),
        r = a(o(225)),
        l = o(226),
        c = (o(227), {
          globalData: {
            baseApi: "https://pysq.shipook.com/v2base",
            appApi: "https://pysq.shipook.com/v2app",
            app_url: {},
            base_url: {
              getsmscode: "/common/getsmscode",
              login4wechat: "/thirdlogin/login4wechat",
              login4zjtd: "/thirdlogin/login4zjtd",
              login4baidu: "/thirdlogin/login4baidu",
              userlogin: "/user/userlogin",
              qryuserallinfo: "/user/qryuserallinfo",
              cashorder: "/business/cashorder",
              openvip: "/business/openvip",
              bootup: "/common/bootup",
              updatedeviceinfo: "/common/updatedeviceinfo",
              getbusupgradeinfo: "/busupgrade/getbusupgradeinfo",
              qryuserjbviplist: "/business/qryuserjbviplist"
            },
            tab_work: 0,
            qd: "",
            ver: "010009",
            sec: "48a0088cb506e6b7",
            aaa: "",
            bbb: "",
            deviceId: "",
            wxappid: "",
            userinfo: null,
            crgid: "",
            parentid: "",
            deviceMac: "",
            oaid: "",
            ss: "",
            showPay: !0,
            freetype: null,
            vipList: [],
            svip_char: {},
            ios_status: 1,
            tts_text: "",
            ishidetype: "",
            heimingdan0: "",
            heimingdan1: "",
            heimingdan2: "",
            systemInfo: null,
            timeInfo: 0
          },
          onLaunch: function onLaunch() {
            var t = this;
            this.$store.commit("setAppConfig", r.default), 1154 === e.getLaunchOptionsSync().scene && (n.setStorageSync("ispyq", !0), n.switchTab({
              url: "/pages/make/make?pyq=1"
            }));
            var o = e.getUpdateManager();
            o.onCheckForUpdate(function (e) {
              if (!e.hasUpdate) return !1;
              o.onUpdateReady(function () {
                o.applyUpdate();
              });
            }), n.setInnerAudioOption({
              obeyMuteSwitch: !1
            }), n.getSystemInfo({
              complete: function complete(e) {
                n.setStorageSync("device", e), t.globalData.systemInfo = e;
              }
            }), this.globalData.aaa = this.globalData.sec.split("").reverse().join(""), this.globalData.bbb = this.globalData.sec.substr(1) + this.globalData.sec.substr(0, 1), this.setQd(r.default.qd), this.getPhoneId(), this.start_Up();
          },
          onShow: function onShow() {
            (n.getStorageSync("sid") || n.getStorageSync("uid")) && this.getUserInfo(function (e) {});
          },
          onHide: function onHide() {},
          methods: {
            commonencry: function commonencry() {
              return JSON.stringify(s.default.getEncryption());
            },
            findpyblack: function findpyblack() {
              var e = this,
                t = e.globalData.appApi + "/peiyin/findpyblack";
              s.default.postRequest({}, t, function (t) {
                if (t.model) for (var o = t.model.split(","), n = 0; n < o.length; n++) "0" == o[n] ? (e.globalData.heimingdan0 = !0, e.$store ? e.$store.commit("setheimingdan0", e.globalData.heimingdan0) : e.$vm.$store.commit("setheimingdan0", e.globalData.heimingdan0)) : "1" == o[n] ? e.globalData.heimingdan1 = !0 : "2" == o[n] && (e.globalData.heimingdan2 = !0);
              });
            },
            examineText: function examineText(e, t) {
              var o = this;
              return new Promise(function (a, i) {
                var r = o.globalData.appApi + "/security/green/text";
                s.default.postRequest({
                  text: e
                }, r, function (e) {
                  console.log("文本检查结果", e), "0" !== e.rc && a(!0);
                  var o = {
                    10001: " 广告",
                    20001: "时政",
                    20002: "色情",
                    20003: "辱骂",
                    20006: "违法犯罪",
                    20008: "欺诈",
                    20012: "低俗",
                    20013: "版权",
                    21e3: "其他"
                  };
                  o[e.model.label] ? (n.showModal({
                    title: "提示",
                    content: "文本内容包含".concat(o[e.model.label] ? o[e.model.label] : "", "相关违规文字信息，请修改后重新操作"),
                    cancelText: "联系客服",
                    success: function success(e) {
                      e.confirm ? t && t() : e.cancel && n.navigateTo({
                        url: "/pages/wode/kefu/kefu"
                      });
                    }
                  }), a(!1)) : a(!0);
                });
              });
            },
            examineImg: function examineImg(e, t) {
              var o = this;
              return new Promise(function (a, i) {
                var r = o.globalData.appApi + "/peiyin/wxurllink/examinewximg",
                  l = {
                    url: e
                  };
                s.default.postRequest(l, r, function (e) {
                  "0" !== e.rc && a(!0), console.log("图片检查结果", e);
                  var o = JSON.parse(e.model),
                    i = o.errcode;
                  0 !== i && n.showModal({
                    title: "提示",
                    content: "该图片存在敏感信息，暂无法使用，如有疑问，请联系客服处理",
                    cancelText: "联系客服",
                    success: function success(e) {
                      e.confirm ? t && t() : e.cancel && n.switchTab({
                        url: "/pages/mine/mine"
                      });
                    }
                  }), a(0 === i);
                });
              });
            },
            isShowPay: function isShowPay() {
              var e = n.getStorageSync("device").platform;
              return "ios" !== e && "devtools" != e;
            },
            downMp4ForAlbum: function downMp4ForAlbum(e) {
              console.log("导出MP4", e), n.downloadFile({
                url: e,
                success: function success(e) {
                  console.log("res", e), 200 === e.statusCode && (n.hideLoading(), n.saveVideoToPhotosAlbum({
                    filePath: e.tempFilePath,
                    success: function success() {
                      n.showModal({
                        title: "导出成功",
                        content: "前往相册查看"
                      });
                    }
                  }));
                }
              });
            },
            qryApiLimit: function qryApiLimit(e) {
              var t = this;
              return new Promise(function (o, n) {
                var a = {
                    apiType: e,
                    isVip: t.globalData.userinfo.userrich.isvalidvip
                  },
                  i = t.globalData.appApi + "/peiyin/qryapilimitapp";
                console.log("json", a), console.log("url", i), s.default.postRequest(a, i, function (e) {
                  console.log("api剩余次数", e), o(e);
                });
              });
            },
            updateApiLimit: function updateApiLimit(e) {
              var t = {
                  apiType: e,
                  isVip: this.globalData.userinfo.userrich.isvalidvip
                },
                o = this.globalData.appApi + "/peiyin/uptapilimitapp";
              s.default.postRequest(t, o, function (e) {
                console.log("api更新次数", e);
              });
            },
            setOssPath: function setOssPath(e, t, o) {
              n.uploadFile({
                url: this.globalData.appApi + "/peiyin/music/univerupload",
                filePath: e,
                name: "file",
                formData: {
                  isrestrict: "0",
                  catalogue: t,
                  osstype: "1",
                  comparam: getApp().commonencry()
                },
                success: function success(e) {
                  console.log("上传本地文件到oss", e), o(JSON.parse(e.data).model);
                },
                fail: function fail(e) {
                  n.showToast({
                    title: "图片上传失败！",
                    icon: "none"
                  }), o("fail");
                }
              });
            },
            generatePoster: function generatePoster(e) {
              var t = {
                req: JSON.stringify({
                  qd: this.globalData.qd,
                  ver: this.globalData.ver,
                  sceneStr: this.globalData.userinfo.userinfo.id,
                  page: "pages/make/make"
                })
              };
              console.log("生成分享二维码", t);
              var o = this.globalData.appApi + "/wxgetqrcode";
              n.request({
                url: o,
                method: "POST",
                header: {
                  "content-type": "application/x-www-form-urlencoded",
                  cookie: "SESSION=" + (n.getStorageSync("sid") ? n.getStorageSync("sid") : "")
                },
                data: t,
                success: function success(t) {
                  e(t);
                }
              });
            },
            getShare: function getShare(e) {
              var t = this;
              (e.parentid || e.scene) && setTimeout(function () {
                var o = e.parentid;
                if (e.scene && (o = decodeURIComponent(e.scene)), o) {
                  t.globalData.parentid = o;
                  var a = {
                      parentid: o
                    },
                    i = getApp().globalData.baseApi + "/user/bindparent";
                  s.default.postRequest(a, i, function (e) {
                    console.log("分享绑定", e), n.showToast({
                      title: "绑定上级成功",
                      icon: "none",
                      duration: 2e3
                    }), getApp().getUserInfo(function (e) {});
                  }, function (e) {
                    if (console.log("绑定失败aaaa", e), "1501" == e.rc) n.showToast({
                      title: "您已绑定过上级，不可再次绑定",
                      icon: "none",
                      duration: 2e3
                    });else {
                      var t = e.rd;
                      n.showToast({
                        title: t,
                        icon: "none",
                        duration: 2e3
                      });
                    }
                  });
                }
              }, 1e3);
            },
            getbdKF: function getbdKF() {
              r.default.kfurl && e.openCustomerServiceChat({
                extInfo: {
                  url: r.default.kfurl
                },
                corpId: r.default.kfcorpId,
                showMessageCard: !0,
                sendMessageTitle: "请稍等，客服马上就到(" + this.globalData.userinfo.userinfo.id + ")",
                sendMessageImg: "https://pysqstoss.shipook.com/imgs/20220117/202306011h.png"
              });
            },
            copyObj: function copyObj(e) {
              var t = null;
              if ("object" == (0, i.default)(e) && null !== e) for (var o in t = e instanceof Array ? [] : {}, e) t[o] = this.copyObj(e[o]);else t = e;
              return t;
            },
            getLocation: function getLocation(e) {
              n.getLocation({
                type: "gcj02",
                success: function success(t) {
                  var o = t.latitude,
                    n = t.longitude;
                  console.log(t);
                  var a = {
                      lng: n,
                      lat: o
                    },
                    i = getApp().globalData.baseApi + "/common/getprovince";
                  s.default.postRequest(a, i, function (t) {
                    console.log("通过经纬度获取地址", t), e(t);
                  });
                },
                fail: function fail(t) {
                  e("fail"), n.showToast({
                    title: "获取位置信息失败！",
                    icon: "none"
                  }), console.log("获取位置失败", t);
                }
              });
            },
            setUserInfo: function setUserInfo(e, t) {
              console.log("用户信息2222", e), r.default.free && (e.model.userrich.isvalidsvip = "1"), n.setStorageSync("uid", e.model.userinfo.uid), n.setStorageSync("did", e.model.userinfo.did), this.$store ? this.$store.commit("setUserMessage", e.model) : this.$vm.$store.commit("setUserMessage", e.model), getApp().globalData.userinfo = e.model, t(e);
            },
            wxLogin: function wxLogin(e) {
              n.login({
                provider: "weixin",
                success: function success(t) {
                  var o = {
                      isbind: "0",
                      code: t.code
                    },
                    a = getApp().globalData.baseApi + getApp().globalData.base_url.login4wechat,
                    i = function i(t) {
                      n.setStorageSync("sid", t.model.userinfo.sid), getApp().setUserInfo(t, e);
                    };
                  s.default.postRequest(o, a, i);
                }
              });
            },
            disposeNewUser: function disposeNewUser(e, t) {
              var o = this,
                a = new Date(e.ctime).getTime(),
                i = new Date().getTime(),
                r = i - a,
                l = 6048e5;
              "用户" === e.nickname && r <= l && n.showModal({
                title: "提示",
                content: "需要获取您的微信昵称与头像用于完善资料显示，是否同意获取？",
                success: function success(e) {
                  e.confirm && n.getUserProfile({
                    desc: "用于完善资料显示",
                    success: function success(e) {
                      var n = {
                          nickname: e.userInfo.nickName,
                          avatar: e.userInfo.avatarUrl
                        },
                        a = o.globalData.baseApi + "/user/updateuserinfo";
                      s.default.postRequest(n, a, function (e) {
                        t && t();
                      });
                    }
                  });
                }
              });
            },
            getUserInfo: function getUserInfo(e) {
              var t = this,
                o = this.globalData.baseApi + this.globalData.base_url.qryuserallinfo;
              s.default.postRequest({}, o, function (o) {
                console.log("获取用户信息", o), t.setUserInfo(o, e);
              });
            },
            getPay: function getPay(e, t, o, a, i, r, l) {
              n.showLoading({
                title: "加载中",
                mask: !0
              });
              var c = this,
                u = 10 * Number(o).toFixed(2),
                p = {
                  crgtype: 2,
                  paytype: e,
                  ordername: t,
                  jb: u,
                  rmb: o,
                  orderid: i,
                  ordertype: a,
                  extdata: r,
                  ish5: 3
                };
              console.log(p);
              var f = this.globalData.baseApi + this.globalData.base_url.cashorder;
              this.globalData.crgid = "";
              var d = function d(t) {
                c.callPay(e, t, l);
              };
              s.default.postRequest(p, f, d);
            },
            getVip: function getVip(e, t, o, a, i, r) {
              n.showLoading({
                title: "加载中",
                mask: !0
              });
              var l = this,
                c = {
                  viptype: e,
                  sviptype: t,
                  paytype: o,
                  time: a,
                  extdata: i,
                  ish5: 3
                };
              console.log("开通会员", c);
              var u = this.globalData.baseApi + this.globalData.base_url.openvip,
                p = function p(e) {
                  l.callPay(o, e, r);
                };
              s.default.postRequest(c, u, p);
            },
            callPay: function callPay(e, t, o) {
              2 == e && t.model.orderparams4webchat ? this.wxPayForMp(t, o) : 1 == e && t.model.orderstr4alipay;
            },
            wxPayForApp: function wxPayForApp(e, t) {
              var o = this;
              n.requestPayment({
                provider: "wxpay",
                orderInfo: e.model.orderparams4webchat,
                success: function success(e) {
                  o.getUserInfo(), n.hideLoading(), t(e);
                },
                fail: function fail(e) {
                  n.hideLoading(), n.showToast({
                    title: "支付失败",
                    icon: "none"
                  });
                }
              });
            },
            wxPayForMp: function wxPayForMp(e, t) {
              var o = this;
              n.requestPayment({
                provider: "wxpay",
                timeStamp: e.model.orderparams4webchat.timestamp,
                nonceStr: e.model.orderparams4webchat.noncestr,
                package: "prepay_id=" + e.model.orderparams4webchat.prepayid,
                signType: "MD5",
                paySign: e.model.orderparams4webchat.sign,
                success: function success(e) {
                  o.getUserInfo(), n.hideLoading(), t(e);
                },
                fail: function fail(e) {
                  n.hideLoading();
                }
              });
            },
            aliPayForApp: function aliPayForApp(e, t) {
              var o = this;
              n.requestPayment({
                provider: "alipay",
                orderInfo: e.model.orderstr4alipay,
                success: function success(e) {
                  o.getUserInfo(), n.hideLoading(), t(e);
                },
                fail: function fail(e) {
                  n.hideLoading(), n.showToast({
                    title: "支付失败",
                    icon: "none"
                  });
                }
              });
            },
            zjPayForMp: function zjPayForMp(e, t) {},
            setQd: function setQd(e) {
              var t = "";
              t = this.globalData.systemInfo ? this.globalData.systemInfo.platform : n.getSystemInfoSync().platform, console.log("bradn", t), this.globalData.qd = "ios" == t || "devtools1" == t ? "2" + e.slice(1) : e, console.log("渠道号", this.globalData.qd);
            },
            start_Up: function start_Up() {
              var e,
                t = this,
                o = new Date().toLocaleDateString();
              e = n.getStorageSync("active") ? n.getStorageSync("active") == o ? "0" : "2" : "1";
              var a = {
                  active: e
                },
                i = t.globalData.baseApi + t.globalData.base_url.bootup;
              s.default.postRequest(a, i, function (e) {
                console.log("合肥阅舟科技-设备启动信息", e), t.globalData.appcfg = e.model.appcfg ? JSON.parse(e.model.appcfg) : {}, t.globalData.freetype = e.model.appcfg ? JSON.parse(e.model.appcfg).freetype : "0", t.globalData.svip_char = t.globalData.appcfg.svip_char, t.globalData.vipList = e.model.jbviplist, t.globalData.zifubao = JSON.parse(e.model.appcfg).zifubao, e.model.appcfg && (JSON.parse(e.model.appcfg).iospay ? t.globalData.iospay = JSON.parse(e.model.appcfg).iospay : t.globalData.iospay = 1, JSON.parse(e.model.appcfg).hideiospay ? t.globalData.hideiospay = JSON.parse(e.model.appcfg).hideiospay : t.globalData.hideiospay = 1), t.hidearea(), t.findpyblack(), n.setStorageSync("active", o);
              });
              var r = t.globalData.baseApi + "/business/qujbl";
              s.default.postRequest({}, r, function (e) {
                console.log("获取配置信息", e), t.globalData.isexamine = "1" === e.model.isexm, t.globalData.iswcp = e.model.iswcp, n.$emit("qryttscfg");
              });
            },
            hidearea: function hidearea() {
              var e = this,
                t = {
                  functype: "0"
                },
                o = e.globalData.baseApi + "/business/qryshieldfunc";
              s.default.postRequest(t, o, function (t) {
                var o;
                console.log("屏蔽地区", t), o = "0" == t.rc && t.model.iospay ? t.model.iospay : "1", e.globalData.ishidetype = o, e.globalData.ios_status = "1" == o ? e.globalData.hideiospay : "0" == o ? e.globalData.iospay : 1;
              });
            },
            getPhoneId: function getPhoneId() {},
            getStorageFun: function getStorageFun(e, t) {
              var o = new Date().toLocaleDateString();
              if (!n.getStorageSync(e)) return n.setStorageSync(e, o), void t();
              n.getStorageSync(e) != o && (n.setStorageSync(e, o), n.removeStorageSync("bgmusic"), t());
            },
            showLoginToast: function showLoginToast() {
              n.showModal({
                title: "登录提示",
                content: "您当前未登录，请先去登录",
                cancelText: "取消",
                confirmText: "登录",
                showCancel: !0,
                success: function success(e) {
                  e.confirm && getApp().relogin();
                }
              });
            },
            relogin: function relogin() {
              var e = this,
                t = function t(_t) {
                  e.$vm.$store.commit("setIsunlogin", !1), e.$vm.$store.commit("setUserMessage", _t.model), n.showToast({
                    title: "登录成功"
                  });
                };
              getApp().wxLogin(function (e) {
                t(e);
              });
            },
            prosssCirculation: function prosssCirculation(e, t) {
              var o = {
                asyncId: e
              };
              getApp().globalData.timeInfo = setInterval(function () {
                var e = getApp().globalData.appApi + "/peiyin/asyncProcess/selectProcess";
                s.default.postRequest(o, e, function (e) {
                  "0" === e.rc ? "2" == e.model.processState ? (getApp().stoptimerinfo(), t && (t({
                    type: "1",
                    result: e.model
                  }), n.hideLoading({}))) : "1" == e.model.processState && (getApp().stoptimerinfo(), t && t({
                    type: "0",
                    result: e.model.failDesc
                  }), n.hideLoading({})) : (getApp().stoptimerinfo(), t && t({
                    type: "0",
                    result: e.rd
                  }), n.hideLoading({}));
                }, function (e) {
                  getApp().stoptimerinfo(), t && t({
                    type: "0",
                    result: "操作失败"
                  }), n.hideLoading({});
                });
              }, 3e3);
            },
            stoptimerinfo: function stoptimerinfo() {
              getApp().globalData.timeInfo && (clearInterval(getApp().globalData.timeInfo), getApp().globalData.timeInfo = 0);
            },
            getProcessId: function getProcessId(e, t, o) {
              (0, l.getProcess)(e, t).then(function (e) {
                if ("0" === e.rc) {
                  var t = e.model;
                  getApp().globalData.timeInfo && getApp().stoptimerinfo(), getApp().prosssCirculation(t, o);
                }
              }).catch(function (e) {
                console.log(e);
              });
            }
          },
          mounted: function mounted() {}
        });
      t.default = c;
    }).call(this, o(1)["default"], o(2)["default"]);
  },
  406: function _(e, t, o) {
    "use strict";

    (function (e, t) {
      var n = o(4);
      o(26);
      n(o(25));
      var a = n(o(407));
      e.__webpack_require_UNI_MP_PLUGIN__ = o, t(a.default);
    }).call(this, o(1)["default"], o(2)["createPage"]);
  },
  407: function _(e, t, o) {
    "use strict";

    o.r(t);
    var n = o(408),
      a = o(410);
    for (var i in a) ["default"].indexOf(i) < 0 && function (e) {
      o.d(t, e, function () {
        return a[e];
      });
    }(i);
    o(412);
    var s,
      r = o(230),
      l = Object(r["default"])(a["default"], n["render"], n["staticRenderFns"], !1, null, null, null, !1, n["components"], s);
    l.options.__file = "pages/work/work_download.vue", t["default"] = l.exports;
  },
  408: function _(e, t, o) {
    "use strict";

    o.r(t);
    var n = o(409);
    o.d(t, "render", function () {
      return n["render"];
    }), o.d(t, "staticRenderFns", function () {
      return n["staticRenderFns"];
    }), o.d(t, "recyclableRender", function () {
      return n["recyclableRender"];
    }), o.d(t, "components", function () {
      return n["components"];
    });
  },
  409: function _(e, t, o) {
    "use strict";

    var n;
    o.r(t), o.d(t, "render", function () {
      return a;
    }), o.d(t, "staticRenderFns", function () {
      return s;
    }), o.d(t, "recyclableRender", function () {
      return i;
    }), o.d(t, "components", function () {
      return n;
    });
    var a = function a() {
        var e = this,
          t = e.$createElement;
        e._self._c;
      },
      i = !1,
      s = [];
    a._withStripped = !0;
  },
  410: function _(e, t, o) {
    "use strict";

    o.r(t);
    var n = o(411),
      a = o.n(n);
    for (var i in n) ["default"].indexOf(i) < 0 && function (e) {
      o.d(t, e, function () {
        return n[e];
      });
    }(i);
    t["default"] = a.a;
  },
  411: function _(e, t, o) {
    "use strict";

    (function (e) {
      var n = o(4);
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var a = n(o(255)),
        i = n(o(257)),
        s = n(o(11)),
        r = o(227),
        l = o(226);
      function c(e, t) {
        var o = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var n = Object.getOwnPropertySymbols(e);
          t && (n = n.filter(function (t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
          })), o.push.apply(o, n);
        }
        return o;
      }
      function u(e) {
        for (var t = 1; t < arguments.length; t++) {
          var o = null != arguments[t] ? arguments[t] : {};
          t % 2 ? c(Object(o), !0).forEach(function (t) {
            (0, s.default)(e, t, o[t]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : c(Object(o)).forEach(function (t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t));
          });
        }
        return e;
      }
      var p = {
        computed: u({}, (0, r.mapState)(["select_work", "user_message", "showPrivacy_ysxy"])),
        data: function data() {
          return {
            is_showpay: !0
          };
        },
        onLoad: function onLoad() {
          this.is_showpay = getApp().isShowPay(), this.$uma_wx.trackEvent("extendWork");
        },
        methods: {
          importWork: function importWork() {
            var t = "1" === this.user_message.userrich.isvalidvip,
              o = "1" === this.user_message.userrich.isvalidsvip,
              n = "2" === this.select_work.exttype;
            return o || "1" !== this.select_work.feature ? !!(t || o || n) || (e.showModal({
              title: "您还不能导出哦",
              content: "成为VIP会员用户，享导出、分享等会员特权",
              confirmText: "开通会员",
              success: function success(t) {
                t.confirm && e.navigateTo({
                  url: "/pages3/vip"
                });
              }
            }), !1) : (e.showModal({
              title: "您还不能导出哦",
              content: "该作品为超级主播作品，开通SVIP可无限导出",
              confirmText: "开通会员",
              success: function success(t) {
                t.confirm && e.navigateTo({
                  url: "/pages3/vip?current=1"
                });
              }
            }), !1);
          },
          getSrtFile: function getSrtFile() {
            var t = this;
            if (this.importWork()) {
              var o = {
                ossUrl: this.select_work.musicpath,
                format: "mp3"
              };
              (0, l.audioToSrt)(o).then(function () {
                var o = (0, i.default)(a.default.mark(function o(n) {
                  return a.default.wrap(function (o) {
                    while (1) switch (o.prev = o.next) {
                      case 0:
                        e.showLoading({
                          title: "导出中...",
                          mask: !0
                        }), t.asyncId = n.model, t.timer = !0;
                      case 3:
                        if (!t.timer) {
                          o.next = 10;
                          break;
                        }
                        return o.next = 6, t.asyncProcess("fileUrl").then(function (t) {
                          t.model.fileUrl && (e.hideLoading(), e.showModal({
                            title: "复制该链接粘贴至浏览器下载",
                            content: t.model.fileUrl,
                            confirmText: "复制链接",
                            success: function success(o) {
                              o.confirm && e.setClipboardData({
                                data: t.model.fileUrl
                              });
                            }
                          }));
                        });
                      case 6:
                        return o.next = 8, new Promise(function (e) {
                          setTimeout(function () {
                            e(1);
                          }, 3e3);
                        });
                      case 8:
                        o.next = 3;
                        break;
                      case 10:
                      case "end":
                        return o.stop();
                    }
                  }, o);
                }));
                return function (e) {
                  return o.apply(this, arguments);
                };
              }());
            }
          },
          jumpCourseForMp3: function jumpCourseForMp3() {
            e.navigateTo({
              url: "/pages/webview/webview?url=https://pysq.stoss.shipook.com/sharepage/export/v1/index.html"
            });
          },
          downloadMp3: function downloadMp3() {
            if (this.importWork()) {
              var e = this.select_work.wkname.replace(/[\'\"\\\/\b\f\n\r\t\?\&]/g, "");
              this.getMp3ByWxApi(this.select_work.musicpath, "配音鸭-" + e + "-" + Date.parse(new Date()) / 1e3 + ".mp3");
            }
          },
          copyPath: function copyPath() {
            this.importWork() && e.setClipboardData({
              data: this.select_work.musicpath,
              success: function success(t) {
                e.hideToast({}), e.showModal({
                  title: "复制链接成功",
                  showCancel: !1,
                  content: "复制成功，您可以在浏览器中粘贴该链接下载"
                });
              }
            });
          },
          downloadMp4: function downloadMp4() {
            var e = this;
            this.importWork() && (0, l.ttsChangeMp4)({
              mp3url: this.select_work.musicpath
            }).then(function (t) {
              e.getMp4ByWxApi(t.model.mp4url);
            });
          },
          showMp4GreenCurtain: function showMp4GreenCurtain() {
            var t = this;
            this.importWork() && (e.showLoading({
              title: "下载作品中...",
              mask: !0
            }), (0, l.ttsChangeMp4V2)({
              ossUrl: this.select_work.musicpath
            }).then(function () {
              var o = (0, i.default)(a.default.mark(function o(n) {
                return a.default.wrap(function (o) {
                  while (1) switch (o.prev = o.next) {
                    case 0:
                      if (console.log("下载MP4到相册（绿幕带文字）", n), n.model) {
                        o.next = 5;
                        break;
                      }
                      return e.hideLoading(), e.showToast({
                        title: "下载失败",
                        icon: "none"
                      }), o.abrupt("return");
                    case 5:
                      e.showLoading({
                        title: "导出中...",
                        mask: !0
                      }), t.asyncId = n.model, t.timer = !0;
                    case 8:
                      if (!t.timer) {
                        o.next = 15;
                        break;
                      }
                      return o.next = 11, t.asyncProcess("resultUrl").then(function (o) {
                        o.model.resultUrl && (e.hideLoading(), t.getMp4ByWxApi(o.model.resultUrl));
                      });
                    case 11:
                      return o.next = 13, new Promise(function (e) {
                        setTimeout(function () {
                          e(1);
                        }, 3e3);
                      });
                    case 13:
                      o.next = 8;
                      break;
                    case 15:
                    case "end":
                      return o.stop();
                  }
                }, o);
              }));
              return function (e) {
                return o.apply(this, arguments);
              };
            }()));
          },
          asyncProcess: function asyncProcess(e) {
            var t = this;
            return new Promise(function (o) {
              (0, l.selectProcess)({
                asyncId: t.asyncId
              }).then(function (n) {
                o(n), console.log("查询异步任务", n), "0" === n.rc && n.model[e] && (t.timer = !1);
              });
            });
          },
          getMp4ByWxApi: function getMp4ByWxApi(t) {
            var o = e.getStorageSync("device");
            "windows" != o.platform ? (e.showLoading({
              title: "下载中...",
              mask: !0
            }), e.downloadFile({
              url: t,
              success: function success(t) {
                var o = t.tempFilePath;
                e.saveVideoToPhotosAlbum({
                  filePath: o,
                  success: function success(t) {
                    e.hideLoading({}), e.showToast({
                      title: "成功保存至相册"
                    });
                  },
                  fail: function fail(t) {
                    e.hideLoading({}), e.getSetting({
                      success: function success(t) {
                        t.authSetting["scope.writePhotosAlbum"] ? e.showToast({
                          title: "您取消了保存",
                          icon: "none"
                        }) : e.showModal({
                          title: "音频下载失败",
                          content: "您拒绝了微信授权访问相册，所以未能成功下载保存到您的相册，请在接下来的设置页面开启【保存到相册】选项再试一次~",
                          showCancel: !1,
                          confirmText: "知道了",
                          confirmColor: "#1482ff",
                          success: function success(t) {
                            t.confirm && e.openSetting();
                          }
                        });
                      }
                    });
                  }
                });
              }
            })) : this.getMp4ByWindows(t);
          },
          getMp3ByWxApi: function getMp3ByWxApi(t, o) {
            e.getStorageSync("device") || e.getSystemInfo({
              complete: function complete(t) {
                e.setStorageSync("device", t);
              }
            });
            var n = e.getStorageSync("device");
            e.showLoading({
              title: "下载中...",
              mask: !0
            }), e.downloadFile({
              url: t,
              header: {
                "content-type": "application/json"
              },
              filePath: "wxfile://usr/" + o,
              success: function success(t) {
                "windows" != n.platform ? (e.hideLoading({}), e.showModal({
                  title: "音频下载成功",
                  content: "文件位置：内部存储->tencent->MicroMsg->wxanewfiles，在此目录搜索【配音鸭】；如果找不到，请在手机【内部存储】或【文件管理】中，使用搜索（或深度搜索）关键词【配音鸭】即可找到音频文件。（不同品牌手机略有差别）",
                  showCancel: !1,
                  confirmText: "知道了",
                  confirmColor: "#1482ff"
                })) : e.saveFileToDisk ? e.saveFileToDisk({
                  filePath: "wxfile://usr/" + o,
                  success: function success() {
                    e.showToast({
                      title: "保存成功"
                    });
                  },
                  fail: function fail() {
                    e.showToast({
                      title: "取消保存...",
                      icon: "none"
                    });
                  }
                }) : (e.hideLoading({}), e.showModal({
                  title: "提示",
                  content: "当前微信版本过低，无法使用该功能，请在微信界面点击左下角【 ☰-设置-关于微信-检查更新 】升级到最新微信版本后重试。"
                }));
              },
              fail: function fail(t) {
                e.showToast({
                  icon: "none",
                  title: "文件下载失败"
                });
              }
            });
          },
          getMp4ByWindows: function getMp4ByWindows(t) {
            e.showLoading({
              title: "下载中...",
              mask: !0
            }), e.downloadFile({
              url: t,
              success: function success(t) {
                e.saveFileToDisk ? e.saveFileToDisk({
                  filePath: t.tempFilePath,
                  success: function success() {
                    e.showToast({
                      title: "保存成功"
                    });
                  },
                  fail: function fail(t) {
                    console.log("保存失败", t), e.showToast({
                      title: "取消保存...",
                      icon: "none"
                    });
                  }
                }) : (e.hideLoading({}), e.showModal({
                  title: "提示",
                  content: "当前微信版本过低，无法使用该功能，请在微信界面点击左下角【 ☰-设置-关于微信-检查更新 】升级到最新微信版本后重试。"
                }));
              },
              fail: function fail(e) {
                console.log("导出失败", e);
              }
            });
          }
        }
      };
      t.default = p;
    }).call(this, o(2)["default"]);
  },
  412: function _(e, t, o) {
    "use strict";

    o.r(t);
    var n = o(413),
      a = o.n(n);
    for (var i in n) ["default"].indexOf(i) < 0 && function (e) {
      o.d(t, e, function () {
        return n[e];
      });
    }(i);
    t["default"] = a.a;
  },
  413: function _(e, t, o) {}
}, [[406, "common/runtime", "common/vendor"]]]);