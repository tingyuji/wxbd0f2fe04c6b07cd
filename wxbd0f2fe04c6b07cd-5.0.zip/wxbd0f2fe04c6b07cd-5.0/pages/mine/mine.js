(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["pages/mine/mine"], {
  228: function _(e, t, i) {
    "use strict";

    i.r(t);
    var o = i(229),
      n = i.n(o);
    for (var a in o) ["default"].indexOf(a) < 0 && function (e) {
      i.d(t, e, function () {
        return o[e];
      });
    }(a);
    t["default"] = n.a;
  },
  229: function _(e, t, i) {},
  27: function _(e, t, i) {
    "use strict";

    i.r(t);
    var o = i(28);
    for (var n in o) ["default"].indexOf(n) < 0 && function (e) {
      i.d(t, e, function () {
        return o[e];
      });
    }(n);
    i(228);
    var a,
      s,
      r,
      c,
      l = i(230),
      u = Object(l["default"])(o["default"], a, s, !1, null, null, null, !1, r, c);
    u.options.__file = "App.vue", t["default"] = u.exports;
  },
  28: function _(e, t, i) {
    "use strict";

    i.r(t);
    var o = i(29),
      n = i.n(o);
    for (var a in o) ["default"].indexOf(a) < 0 && function (e) {
      i.d(t, e, function () {
        return o[e];
      });
    }(a);
    t["default"] = n.a;
  },
  29: function _(e, t, i) {
    "use strict";

    (function (e, o) {
      var n = i(4);
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var a = n(i(13)),
        s = (n(i(30)), n(i(31))),
        r = n(i(225)),
        c = i(226),
        l = (i(227), {
          globalData: {
            baseApi: "https://pysq.shipook.com/v2base",
            appApi: "https://pysq.shipook.com/v2app",
            app_url: {},
            base_url: {
              getsmscode: "/common/getsmscode",
              login4wechat: "/thirdlogin/login4wechat",
              login4zjtd: "/thirdlogin/login4zjtd",
              login4baidu: "/thirdlogin/login4baidu",
              userlogin: "/user/userlogin",
              qryuserallinfo: "/user/qryuserallinfo",
              cashorder: "/business/cashorder",
              openvip: "/business/openvip",
              bootup: "/common/bootup",
              updatedeviceinfo: "/common/updatedeviceinfo",
              getbusupgradeinfo: "/busupgrade/getbusupgradeinfo",
              qryuserjbviplist: "/business/qryuserjbviplist"
            },
            tab_work: 0,
            qd: "",
            ver: "010009",
            sec: "48a0088cb506e6b7",
            aaa: "",
            bbb: "",
            deviceId: "",
            wxappid: "",
            userinfo: null,
            crgid: "",
            parentid: "",
            deviceMac: "",
            oaid: "",
            ss: "",
            showPay: !0,
            freetype: null,
            vipList: [],
            svip_char: {},
            ios_status: 1,
            tts_text: "",
            ishidetype: "",
            heimingdan0: "",
            heimingdan1: "",
            heimingdan2: "",
            systemInfo: null,
            timeInfo: 0
          },
          onLaunch: function onLaunch() {
            var t = this;
            this.$store.commit("setAppConfig", r.default), 1154 === e.getLaunchOptionsSync().scene && (o.setStorageSync("ispyq", !0), o.switchTab({
              url: "/pages/make/make?pyq=1"
            }));
            var i = e.getUpdateManager();
            i.onCheckForUpdate(function (e) {
              if (!e.hasUpdate) return !1;
              i.onUpdateReady(function () {
                i.applyUpdate();
              });
            }), o.setInnerAudioOption({
              obeyMuteSwitch: !1
            }), o.getSystemInfo({
              complete: function complete(e) {
                o.setStorageSync("device", e), t.globalData.systemInfo = e;
              }
            }), this.globalData.aaa = this.globalData.sec.split("").reverse().join(""), this.globalData.bbb = this.globalData.sec.substr(1) + this.globalData.sec.substr(0, 1), this.setQd(r.default.qd), this.getPhoneId(), this.start_Up();
          },
          onShow: function onShow() {
            (o.getStorageSync("sid") || o.getStorageSync("uid")) && this.getUserInfo(function (e) {});
          },
          onHide: function onHide() {},
          methods: {
            commonencry: function commonencry() {
              return JSON.stringify(s.default.getEncryption());
            },
            findpyblack: function findpyblack() {
              var e = this,
                t = e.globalData.appApi + "/peiyin/findpyblack";
              s.default.postRequest({}, t, function (t) {
                if (t.model) for (var i = t.model.split(","), o = 0; o < i.length; o++) "0" == i[o] ? (e.globalData.heimingdan0 = !0, e.$store ? e.$store.commit("setheimingdan0", e.globalData.heimingdan0) : e.$vm.$store.commit("setheimingdan0", e.globalData.heimingdan0)) : "1" == i[o] ? e.globalData.heimingdan1 = !0 : "2" == i[o] && (e.globalData.heimingdan2 = !0);
              });
            },
            examineText: function examineText(e, t) {
              var i = this;
              return new Promise(function (n, a) {
                var r = i.globalData.appApi + "/security/green/text";
                s.default.postRequest({
                  text: e
                }, r, function (e) {
                  console.log("文本检查结果", e), "0" !== e.rc && n(!0);
                  var i = {
                    10001: " 广告",
                    20001: "时政",
                    20002: "色情",
                    20003: "辱骂",
                    20006: "违法犯罪",
                    20008: "欺诈",
                    20012: "低俗",
                    20013: "版权",
                    21e3: "其他"
                  };
                  i[e.model.label] ? (o.showModal({
                    title: "提示",
                    content: "文本内容包含".concat(i[e.model.label] ? i[e.model.label] : "", "相关违规文字信息，请修改后重新操作"),
                    cancelText: "联系客服",
                    success: function success(e) {
                      e.confirm ? t && t() : e.cancel && o.navigateTo({
                        url: "/pages/wode/kefu/kefu"
                      });
                    }
                  }), n(!1)) : n(!0);
                });
              });
            },
            examineImg: function examineImg(e, t) {
              var i = this;
              return new Promise(function (n, a) {
                var r = i.globalData.appApi + "/peiyin/wxurllink/examinewximg",
                  c = {
                    url: e
                  };
                s.default.postRequest(c, r, function (e) {
                  "0" !== e.rc && n(!0), console.log("图片检查结果", e);
                  var i = JSON.parse(e.model),
                    a = i.errcode;
                  0 !== a && o.showModal({
                    title: "提示",
                    content: "该图片存在敏感信息，暂无法使用，如有疑问，请联系客服处理",
                    cancelText: "联系客服",
                    success: function success(e) {
                      e.confirm ? t && t() : e.cancel && o.switchTab({
                        url: "/pages/mine/mine"
                      });
                    }
                  }), n(0 === a);
                });
              });
            },
            isShowPay: function isShowPay() {
              var e = o.getStorageSync("device").platform;
              return "ios" !== e && "devtools" != e;
            },
            downMp4ForAlbum: function downMp4ForAlbum(e) {
              console.log("导出MP4", e), o.downloadFile({
                url: e,
                success: function success(e) {
                  console.log("res", e), 200 === e.statusCode && (o.hideLoading(), o.saveVideoToPhotosAlbum({
                    filePath: e.tempFilePath,
                    success: function success() {
                      o.showModal({
                        title: "导出成功",
                        content: "前往相册查看"
                      });
                    }
                  }));
                }
              });
            },
            qryApiLimit: function qryApiLimit(e) {
              var t = this;
              return new Promise(function (i, o) {
                var n = {
                    apiType: e,
                    isVip: t.globalData.userinfo.userrich.isvalidvip
                  },
                  a = t.globalData.appApi + "/peiyin/qryapilimitapp";
                console.log("json", n), console.log("url", a), s.default.postRequest(n, a, function (e) {
                  console.log("api剩余次数", e), i(e);
                });
              });
            },
            updateApiLimit: function updateApiLimit(e) {
              var t = {
                  apiType: e,
                  isVip: this.globalData.userinfo.userrich.isvalidvip
                },
                i = this.globalData.appApi + "/peiyin/uptapilimitapp";
              s.default.postRequest(t, i, function (e) {
                console.log("api更新次数", e);
              });
            },
            setOssPath: function setOssPath(e, t, i) {
              o.uploadFile({
                url: this.globalData.appApi + "/peiyin/music/univerupload",
                filePath: e,
                name: "file",
                formData: {
                  isrestrict: "0",
                  catalogue: t,
                  osstype: "1",
                  comparam: getApp().commonencry()
                },
                success: function success(e) {
                  console.log("上传本地文件到oss", e), i(JSON.parse(e.data).model);
                },
                fail: function fail(e) {
                  o.showToast({
                    title: "图片上传失败！",
                    icon: "none"
                  }), i("fail");
                }
              });
            },
            generatePoster: function generatePoster(e) {
              var t = {
                req: JSON.stringify({
                  qd: this.globalData.qd,
                  ver: this.globalData.ver,
                  sceneStr: this.globalData.userinfo.userinfo.id,
                  page: "pages/make/make"
                })
              };
              console.log("生成分享二维码", t);
              var i = this.globalData.appApi + "/wxgetqrcode";
              o.request({
                url: i,
                method: "POST",
                header: {
                  "content-type": "application/x-www-form-urlencoded",
                  cookie: "SESSION=" + (o.getStorageSync("sid") ? o.getStorageSync("sid") : "")
                },
                data: t,
                success: function success(t) {
                  e(t);
                }
              });
            },
            getShare: function getShare(e) {
              var t = this;
              (e.parentid || e.scene) && setTimeout(function () {
                var i = e.parentid;
                if (e.scene && (i = decodeURIComponent(e.scene)), i) {
                  t.globalData.parentid = i;
                  var n = {
                      parentid: i
                    },
                    a = getApp().globalData.baseApi + "/user/bindparent";
                  s.default.postRequest(n, a, function (e) {
                    console.log("分享绑定", e), o.showToast({
                      title: "绑定上级成功",
                      icon: "none",
                      duration: 2e3
                    }), getApp().getUserInfo(function (e) {});
                  }, function (e) {
                    if (console.log("绑定失败aaaa", e), "1501" == e.rc) o.showToast({
                      title: "您已绑定过上级，不可再次绑定",
                      icon: "none",
                      duration: 2e3
                    });else {
                      var t = e.rd;
                      o.showToast({
                        title: t,
                        icon: "none",
                        duration: 2e3
                      });
                    }
                  });
                }
              }, 1e3);
            },
            getbdKF: function getbdKF() {
              r.default.kfurl && e.openCustomerServiceChat({
                extInfo: {
                  url: r.default.kfurl
                },
                corpId: r.default.kfcorpId,
                showMessageCard: !0,
                sendMessageTitle: "请稍等，客服马上就到(" + this.globalData.userinfo.userinfo.id + ")",
                sendMessageImg: "https://pysqstoss.shipook.com/imgs/20220117/202306011h.png"
              });
            },
            copyObj: function copyObj(e) {
              var t = null;
              if ("object" == (0, a.default)(e) && null !== e) for (var i in t = e instanceof Array ? [] : {}, e) t[i] = this.copyObj(e[i]);else t = e;
              return t;
            },
            getLocation: function getLocation(e) {
              o.getLocation({
                type: "gcj02",
                success: function success(t) {
                  var i = t.latitude,
                    o = t.longitude;
                  console.log(t);
                  var n = {
                      lng: o,
                      lat: i
                    },
                    a = getApp().globalData.baseApi + "/common/getprovince";
                  s.default.postRequest(n, a, function (t) {
                    console.log("通过经纬度获取地址", t), e(t);
                  });
                },
                fail: function fail(t) {
                  e("fail"), o.showToast({
                    title: "获取位置信息失败！",
                    icon: "none"
                  }), console.log("获取位置失败", t);
                }
              });
            },
            setUserInfo: function setUserInfo(e, t) {
              console.log("用户信息2222", e), r.default.free && (e.model.userrich.isvalidsvip = "1"), o.setStorageSync("uid", e.model.userinfo.uid), o.setStorageSync("did", e.model.userinfo.did), this.$store ? this.$store.commit("setUserMessage", e.model) : this.$vm.$store.commit("setUserMessage", e.model), getApp().globalData.userinfo = e.model, t(e);
            },
            wxLogin: function wxLogin(e) {
              o.login({
                provider: "weixin",
                success: function success(t) {
                  var i = {
                      isbind: "0",
                      code: t.code
                    },
                    n = getApp().globalData.baseApi + getApp().globalData.base_url.login4wechat,
                    a = function a(t) {
                      o.setStorageSync("sid", t.model.userinfo.sid), getApp().setUserInfo(t, e);
                    };
                  s.default.postRequest(i, n, a);
                }
              });
            },
            disposeNewUser: function disposeNewUser(e, t) {
              var i = this,
                n = new Date(e.ctime).getTime(),
                a = new Date().getTime(),
                r = a - n,
                c = 6048e5;
              "用户" === e.nickname && r <= c && o.showModal({
                title: "提示",
                content: "需要获取您的微信昵称与头像用于完善资料显示，是否同意获取？",
                success: function success(e) {
                  e.confirm && o.getUserProfile({
                    desc: "用于完善资料显示",
                    success: function success(e) {
                      var o = {
                          nickname: e.userInfo.nickName,
                          avatar: e.userInfo.avatarUrl
                        },
                        n = i.globalData.baseApi + "/user/updateuserinfo";
                      s.default.postRequest(o, n, function (e) {
                        t && t();
                      });
                    }
                  });
                }
              });
            },
            getUserInfo: function getUserInfo(e) {
              var t = this,
                i = this.globalData.baseApi + this.globalData.base_url.qryuserallinfo;
              s.default.postRequest({}, i, function (i) {
                console.log("获取用户信息", i), t.setUserInfo(i, e);
              });
            },
            getPay: function getPay(e, t, i, n, a, r, c) {
              o.showLoading({
                title: "加载中",
                mask: !0
              });
              var l = this,
                u = 10 * Number(i).toFixed(2),
                p = {
                  crgtype: 2,
                  paytype: e,
                  ordername: t,
                  jb: u,
                  rmb: i,
                  orderid: a,
                  ordertype: n,
                  extdata: r,
                  ish5: 3
                };
              console.log(p);
              var g = this.globalData.baseApi + this.globalData.base_url.cashorder;
              this.globalData.crgid = "";
              var f = function f(t) {
                l.callPay(e, t, c);
              };
              s.default.postRequest(p, g, f);
            },
            getVip: function getVip(e, t, i, n, a, r) {
              o.showLoading({
                title: "加载中",
                mask: !0
              });
              var c = this,
                l = {
                  viptype: e,
                  sviptype: t,
                  paytype: i,
                  time: n,
                  extdata: a,
                  ish5: 3
                };
              console.log("开通会员", l);
              var u = this.globalData.baseApi + this.globalData.base_url.openvip,
                p = function p(e) {
                  c.callPay(i, e, r);
                };
              s.default.postRequest(l, u, p);
            },
            callPay: function callPay(e, t, i) {
              2 == e && t.model.orderparams4webchat ? this.wxPayForMp(t, i) : 1 == e && t.model.orderstr4alipay;
            },
            wxPayForApp: function wxPayForApp(e, t) {
              var i = this;
              o.requestPayment({
                provider: "wxpay",
                orderInfo: e.model.orderparams4webchat,
                success: function success(e) {
                  i.getUserInfo(), o.hideLoading(), t(e);
                },
                fail: function fail(e) {
                  o.hideLoading(), o.showToast({
                    title: "支付失败",
                    icon: "none"
                  });
                }
              });
            },
            wxPayForMp: function wxPayForMp(e, t) {
              var i = this;
              o.requestPayment({
                provider: "wxpay",
                timeStamp: e.model.orderparams4webchat.timestamp,
                nonceStr: e.model.orderparams4webchat.noncestr,
                package: "prepay_id=" + e.model.orderparams4webchat.prepayid,
                signType: "MD5",
                paySign: e.model.orderparams4webchat.sign,
                success: function success(e) {
                  i.getUserInfo(), o.hideLoading(), t(e);
                },
                fail: function fail(e) {
                  o.hideLoading();
                }
              });
            },
            aliPayForApp: function aliPayForApp(e, t) {
              var i = this;
              o.requestPayment({
                provider: "alipay",
                orderInfo: e.model.orderstr4alipay,
                success: function success(e) {
                  i.getUserInfo(), o.hideLoading(), t(e);
                },
                fail: function fail(e) {
                  o.hideLoading(), o.showToast({
                    title: "支付失败",
                    icon: "none"
                  });
                }
              });
            },
            zjPayForMp: function zjPayForMp(e, t) {},
            setQd: function setQd(e) {
              var t = "";
              t = this.globalData.systemInfo ? this.globalData.systemInfo.platform : o.getSystemInfoSync().platform, console.log("bradn", t), this.globalData.qd = "ios" == t || "devtools1" == t ? "2" + e.slice(1) : e, console.log("渠道号", this.globalData.qd);
            },
            start_Up: function start_Up() {
              var e,
                t = this,
                i = new Date().toLocaleDateString();
              e = o.getStorageSync("active") ? o.getStorageSync("active") == i ? "0" : "2" : "1";
              var n = {
                  active: e
                },
                a = t.globalData.baseApi + t.globalData.base_url.bootup;
              s.default.postRequest(n, a, function (e) {
                console.log("合肥阅舟科技-设备启动信息", e), t.globalData.appcfg = e.model.appcfg ? JSON.parse(e.model.appcfg) : {}, t.globalData.freetype = e.model.appcfg ? JSON.parse(e.model.appcfg).freetype : "0", t.globalData.svip_char = t.globalData.appcfg.svip_char, t.globalData.vipList = e.model.jbviplist, t.globalData.zifubao = JSON.parse(e.model.appcfg).zifubao, e.model.appcfg && (JSON.parse(e.model.appcfg).iospay ? t.globalData.iospay = JSON.parse(e.model.appcfg).iospay : t.globalData.iospay = 1, JSON.parse(e.model.appcfg).hideiospay ? t.globalData.hideiospay = JSON.parse(e.model.appcfg).hideiospay : t.globalData.hideiospay = 1), t.hidearea(), t.findpyblack(), o.setStorageSync("active", i);
              });
              var r = t.globalData.baseApi + "/business/qujbl";
              s.default.postRequest({}, r, function (e) {
                console.log("获取配置信息", e), t.globalData.isexamine = "1" === e.model.isexm, t.globalData.iswcp = e.model.iswcp, o.$emit("qryttscfg");
              });
            },
            hidearea: function hidearea() {
              var e = this,
                t = {
                  functype: "0"
                },
                i = e.globalData.baseApi + "/business/qryshieldfunc";
              s.default.postRequest(t, i, function (t) {
                var i;
                console.log("屏蔽地区", t), i = "0" == t.rc && t.model.iospay ? t.model.iospay : "1", e.globalData.ishidetype = i, e.globalData.ios_status = "1" == i ? e.globalData.hideiospay : "0" == i ? e.globalData.iospay : 1;
              });
            },
            getPhoneId: function getPhoneId() {},
            getStorageFun: function getStorageFun(e, t) {
              var i = new Date().toLocaleDateString();
              if (!o.getStorageSync(e)) return o.setStorageSync(e, i), void t();
              o.getStorageSync(e) != i && (o.setStorageSync(e, i), o.removeStorageSync("bgmusic"), t());
            },
            showLoginToast: function showLoginToast() {
              o.showModal({
                title: "登录提示",
                content: "您当前未登录，请先去登录",
                cancelText: "取消",
                confirmText: "登录",
                showCancel: !0,
                success: function success(e) {
                  e.confirm && getApp().relogin();
                }
              });
            },
            relogin: function relogin() {
              var e = this,
                t = function t(_t) {
                  e.$vm.$store.commit("setIsunlogin", !1), e.$vm.$store.commit("setUserMessage", _t.model), o.showToast({
                    title: "登录成功"
                  });
                };
              getApp().wxLogin(function (e) {
                t(e);
              });
            },
            prosssCirculation: function prosssCirculation(e, t) {
              var i = {
                asyncId: e
              };
              getApp().globalData.timeInfo = setInterval(function () {
                var e = getApp().globalData.appApi + "/peiyin/asyncProcess/selectProcess";
                s.default.postRequest(i, e, function (e) {
                  "0" === e.rc ? "2" == e.model.processState ? (getApp().stoptimerinfo(), t && (t({
                    type: "1",
                    result: e.model
                  }), o.hideLoading({}))) : "1" == e.model.processState && (getApp().stoptimerinfo(), t && t({
                    type: "0",
                    result: e.model.failDesc
                  }), o.hideLoading({})) : (getApp().stoptimerinfo(), t && t({
                    type: "0",
                    result: e.rd
                  }), o.hideLoading({}));
                }, function (e) {
                  getApp().stoptimerinfo(), t && t({
                    type: "0",
                    result: "操作失败"
                  }), o.hideLoading({});
                });
              }, 3e3);
            },
            stoptimerinfo: function stoptimerinfo() {
              getApp().globalData.timeInfo && (clearInterval(getApp().globalData.timeInfo), getApp().globalData.timeInfo = 0);
            },
            getProcessId: function getProcessId(e, t, i) {
              (0, c.getProcess)(e, t).then(function (e) {
                if ("0" === e.rc) {
                  var t = e.model;
                  getApp().globalData.timeInfo && getApp().stoptimerinfo(), getApp().prosssCirculation(t, i);
                }
              }).catch(function (e) {
                console.log(e);
              });
            }
          },
          mounted: function mounted() {}
        });
      t.default = l;
    }).call(this, i(1)["default"], i(2)["default"]);
  },
  422: function _(e, t, i) {
    "use strict";

    (function (e, t) {
      var o = i(4);
      i(26);
      o(i(25));
      var n = o(i(423));
      e.__webpack_require_UNI_MP_PLUGIN__ = i, t(n.default);
    }).call(this, i(1)["default"], i(2)["createPage"]);
  },
  423: function _(e, t, i) {
    "use strict";

    i.r(t);
    var o = i(424),
      n = i(426);
    for (var a in n) ["default"].indexOf(a) < 0 && function (e) {
      i.d(t, e, function () {
        return n[e];
      });
    }(a);
    i(429);
    var s,
      r = i(230),
      c = Object(r["default"])(n["default"], o["render"], o["staticRenderFns"], !1, null, null, null, !1, o["components"], s);
    c.options.__file = "pages/mine/mine.vue", t["default"] = c.exports;
  },
  424: function _(e, t, i) {
    "use strict";

    i.r(t);
    var o = i(425);
    i.d(t, "render", function () {
      return o["render"];
    }), i.d(t, "staticRenderFns", function () {
      return o["staticRenderFns"];
    }), i.d(t, "recyclableRender", function () {
      return o["recyclableRender"];
    }), i.d(t, "components", function () {
      return o["components"];
    });
  },
  425: function _(e, t, i) {
    "use strict";

    var o;
    i.r(t), i.d(t, "render", function () {
      return n;
    }), i.d(t, "staticRenderFns", function () {
      return s;
    }), i.d(t, "recyclableRender", function () {
      return a;
    }), i.d(t, "components", function () {
      return o;
    });
    try {
      o = {
        uPopup: function uPopup() {
          return Promise.all([i.e("common/vendor"), i.e("uni_modules/uview-ui/components/u-popup/u-popup")]).then(i.bind(null, 1093));
        },
        uLine: function uLine() {
          return Promise.all([i.e("common/vendor"), i.e("uni_modules/uview-ui/components/u-line/u-line")]).then(i.bind(null, 1322));
        }
      };
    } catch (r) {
      if (-1 === r.message.indexOf("Cannot find module") || -1 === r.message.indexOf(".vue")) throw r;
      console.error(r.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
    }
    var n = function n() {
        var e = this,
          t = e.$createElement;
        e._self._c;
        e._isMounted || (e.e0 = function (t) {
          e.showExchange = !1;
        });
      },
      a = !1,
      s = [];
    n._withStripped = !0;
  },
  426: function _(e, t, i) {
    "use strict";

    i.r(t);
    var o = i(427),
      n = i.n(o);
    for (var a in o) ["default"].indexOf(a) < 0 && function (e) {
      i.d(t, e, function () {
        return o[e];
      });
    }(a);
    t["default"] = n.a;
  },
  427: function _(e, t, i) {
    "use strict";

    (function (e, o) {
      var n = i(4);
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var a = n(i(255)),
        s = n(i(257)),
        r = n(i(11)),
        c = i(227),
        l = i(428);
      function u(e, t) {
        var i = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var o = Object.getOwnPropertySymbols(e);
          t && (o = o.filter(function (t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
          })), i.push.apply(i, o);
        }
        return i;
      }
      function p(e) {
        for (var t = 1; t < arguments.length; t++) {
          var i = null != arguments[t] ? arguments[t] : {};
          t % 2 ? u(Object(i), !0).forEach(function (t) {
            (0, r.default)(e, t, i[t]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(i)) : u(Object(i)).forEach(function (t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(i, t));
          });
        }
        return e;
      }
      var g = function g() {
          i.e("components/mine/exchange_vip").then(function () {
            return resolve(i(1330));
          }.bind(null, i)).catch(i.oe);
        },
        f = {
          computed: p(p({}, (0, c.mapState)(["user_message", "app_config", "is_unlogin", "showPrivacy_ysxy"])), {}, {
            total: function total() {
              return (Number(this.user_message.userrich.jbcashedrmb) + Number(this.user_message.userrich.jbcashrmb)).toFixed(2);
            }
          }),
          components: {
            exchangeVip: g
          },
          filters: {
            formatVipTime: function formatVipTime(e) {
              return e ? Number(e.substring(0, 4)) > 2030 ? "永久会员" : "有效期至" + e.split(" ")[0] : "";
            }
          },
          data: function data() {
            return {
              nickname: "",
              show_InfoPop: !1,
              is_chooseAvatar: !0,
              avatar_url: "",
              miniProgram: !0,
              showExchange: !1,
              is_showpay: !0,
              user_character: {},
              version: "",
              is_updatevip: !1,
              vip_type: "开通会员",
              vip_time: "开通会员享主播合成声音",
              vip_title: "立即开通",
              vip_bg_url: "https://pysqstoss.shipook.com/static/minisource/10710/vip_bg_img.png",
              tool_main: {
                title: "常用功能",
                list: [{
                  title: "联系客服",
                  icon: "/static/images/mine/lianxikefu.png"
                }, {
                  title: "关注公众号",
                  icon: "/static/images/mine/guanzhugongzhonghao.png"
                }, {
                  title: "绑定上级",
                  icon: "/static/images/mine/bangdingshangji.png"
                }, {
                  title: "兑换会员",
                  icon: "/static/images/mine/kamiduihuan.png"
                }]
              },
              tool_other: {
                title: "其它功能",
                list: [{
                  title: "字符包",
                  icon: "/static/images/mine/gmzf.png"
                }, {
                  title: "字符消耗",
                  icon: "/static/images/mine/zfxh.png"
                }, {
                  title: "电脑版",
                  icon: "/static/images/mine/dnb.png"
                }, {
                  title: "意见反馈",
                  icon: "/static/images/mine/yjfk.png"
                }, {
                  title: "开发票",
                  icon: "/static/images/mine/kfp.png"
                }, {
                  title: "账单",
                  icon: "/static/images/mine/zd.png"
                }, {
                  title: "清除缓存",
                  icon: "/static/images/mine/qchc.png"
                }, {
                  title: "刷新",
                  icon: "/static/images/mine/sx.png"
                }, {
                  title: "设置",
                  icon: "/static/images/mine/setting.png"
                }]
              }
            };
          },
          watch: {
            is_unlogin: function is_unlogin(e) {
              if (e) this.tool_other.list.pop();else {
                var t = {
                  title: "设置",
                  icon: "/static/images/mine/setting.png"
                };
                this.tool_other.list.push(t);
              }
            },
            user_message: {
              handler: function handler(e, t) {
                if (e) if (this.avatar_url = e.userinfo.avatar, this.nickname = e.userinfo.nickname, "1" === e.userrich.isvalidsvip || "1" === e.userrich.isvalidvip ? this.vip_title = "立即续费" : this.vip_title = "立即开通", "1" === e.userrich.isvalidsvip) {
                  this.vip_type = "超级会员";
                  var i = e.userrich.sviptime;
                  Number(i.substring(0, 4)) > 2030 ? this.vip_time = "有效期至永久" : this.vip_time = "有效期至" + i.split(" ")[0], this.vip_bg_url = "https://pysqstoss.shipook.com/static/minisource/10710/svip_bg_img.png";
                } else if ("1" === e.userrich.isvalidvip && "0" === e.userrich.isvalidsvip) {
                  this.vip_type = "普通会员";
                  var o = e.userrich.viptime;
                  Number(o.substring(0, 4)) > 2030 ? this.vip_time = "永久会员" : this.vip_time = "有效期至" + o.split(" ")[0], this.vip_bg_url = "https://pysqstoss.shipook.com/static/minisource/10710/vip_bg_img.png";
                } else this.vip_type = "开通会员", this.vip_time = "开通会员享主播合成声音", this.vip_title = "立即开通", this.vip_bg_url = "https://pysqstoss.shipook.com/static/minisource/10710/vip_bg_img.png";
              },
              deep: !0,
              immediate: !0
            }
          },
          onHide: function onHide() {
            this.showExchange = !1;
          },
          onLoad: function onLoad() {
            this.avatar_url = this.user_message.userinfo.avatar, this.nickname = this.user_message.userinfo.nickname, this.is_showpay = getApp().isShowPay();
            var t = e.getAccountInfoSync();
            this.version = t.miniProgram.version ? t.miniProgram.version : "0.0.0", o.getStorageSync("mine_miniProgram") ? this.miniProgram = !1 : this.miniProgram = !0, this.app_config.free && (this.tool_main = {
              title: "常用功能",
              list: [{
                title: "联系客服",
                icon: "/static/images/mine/lianxikefu.png"
              }, {
                title: "绑定上级",
                icon: "/static/images/mine/bangdingshangji.png"
              }, {
                title: "",
                icon: ""
              }, {
                title: "",
                icon: ""
              }]
            }, this.tool_other = {
              title: "其它功能",
              list: [{
                title: "电脑版",
                icon: "/static/images/mine/dnb.png"
              }, {
                title: "意见反馈",
                icon: "/static/images/mine/yjfk.png"
              }, {
                title: "清除缓存",
                icon: "/static/images/mine/qchc.png"
              }, {
                title: "刷新",
                icon: "/static/images/mine/sx.png"
              }, {
                title: "设置",
                icon: "/static/images/mine/setting.png"
              }]
            });
          },
          onShow: function onShow() {
            var e = this;
            getApp().getUserInfo(function (t) {
              e.$store.commit("setUserMessage", t.model), o.hideLoading();
            }), this.checkUpdateVip(), (0, l.qryTextNum)().then(function (t) {
              e.user_character = t.model;
            }).catch(function (e) {});
          },
          methods: {
            jump2: function jump2() {
              o.navigateTo({
                url: "/pages4/cloning_mine"
              });
            },
            jumpquestion: function jumpquestion() {
              e.openEmbeddedMiniProgram({
                appId: "wxebadf544ddae62cb",
                path: "pages/survey/index?sid=14682316&hash=bmod&navigateBackMiniProgram=true"
              });
            },
            login: function login() {
              var e = this;
              this.is_unlogin && (getApp().relogin(), setTimeout(function (t) {
                e.checkUpdateVip();
              }, 3e3));
            },
            input: function input(e) {
              this.nickname = e.detail.value;
            },
            close: function close() {
              this.show_InfoPop = !1;
            },
            changeAvatar: function changeAvatar() {
              this.show_InfoPop = !0;
            },
            saveInfo: function saveInfo() {
              var e = this,
                t = this;
              if (this.is_chooseAvatar) {
                if (0 != this.nickname.length) {
                  var i = {
                    nickname: this.nickname,
                    avatar: this.avatar_url
                  };
                  (0, l.updateuserinfo)(i).then(function (i) {
                    t.show_InfoPop = !1, getApp().getUserInfo(function (t) {
                      e.$store.commit("setUserMessage", t.model);
                    });
                  });
                } else o.showToast({
                  title: "请填写昵称"
                });
              } else o.showToast({
                title: "请上传头像"
              });
            },
            onChooseAvatar: function onChooseAvatar(e) {
              var t = this;
              getApp().setOssPath(e.detail.avatarUrl, "", function () {
                var e = (0, s.default)(a.default.mark(function e(i) {
                  return a.default.wrap(function (e) {
                    while (1) switch (e.prev = e.next) {
                      case 0:
                        if ("fail" !== i) {
                          e.next = 2;
                          break;
                        }
                        return e.abrupt("return");
                      case 2:
                        t.is_chooseAvatar = !0, t.avatar_url = i.bgmusicurl;
                      case 4:
                      case "end":
                        return e.stop();
                    }
                  }, e);
                }));
                return function (t) {
                  return e.apply(this, arguments);
                };
              }());
            },
            closeprogram: function closeprogram() {
              this.miniProgram = !1, o.setStorageSync("mine_miniProgram", "1");
            },
            checkUpdateVip: function checkUpdateVip() {
              var e = this;
              if (this.is_updatevip = !1, getApp().globalData.userinfo && "1" === this.user_message.userrich.isvalidvip && "0" === this.user_message.userrich.isvalidsvip) {
                var t = {
                  curviptype: getApp().globalData.userinfo.userrich.viptype,
                  cursviptype: "",
                  upviptype: "",
                  upsviptype: "1,2,3"
                };
                (0, l.qryUpgradeVipPrice)(t).then(function (t) {
                  var i = t.model;
                  null != i && i.length > 0 && (e.is_updatevip = !0);
                });
              }
            },
            updateVip: function updateVip() {
              this.is_updatevip ? o.navigateTo({
                url: "/pages3/vip_update"
              }) : o.navigateTo({
                url: "/pages3/vip"
              });
            },
            toolClick: function toolClick(e) {
              this.is_unlogin ? getApp().showLoginToast() : "关注公众号" == e.title ? this.jumpGZH() : "绑定上级" == e.title ? o.navigateTo({
                url: "/pages3/bindparent"
              }) : "兑换会员" == e.title ? this.showExchange = !0 : "字符包" == e.title ? this.jumpCharacterPack() : "字符消耗" == e.title ? this.jumpCharacterInfo() : "电脑版" == e.title ? this.jumpPcVer() : "意见反馈" == e.title ? this.jumpFeedBack() : "开发票" == e.title ? this.jumoReceipt() : "账单" == e.title ? this.jumpToOrder() : "刷新" == e.title ? this.refreshInfo() : "清除缓存" == e.title ? this.clearBufferMemory() : "联系客服" == e.title ? this.getbdKF() : "设置" == e.title && o.navigateTo({
                url: "/pages2/mine/setting"
              });
            },
            jumpToOrder: function jumpToOrder() {
              o.navigateTo({
                url: "/pages5/order"
              });
            },
            getbdKF: function getbdKF() {
              getApp().getbdKF(), this.$uma_wx.trackEvent("openKefu");
            },
            copyId: function copyId() {
              o.setClipboardData({
                data: String(this.user_message.userinfo.id),
                success: function success(e) {
                  o.showToast({
                    title: "复制成功",
                    icon: "none"
                  });
                }
              });
            },
            jumpVip: function jumpVip(e) {
              this.is_unlogin ? getApp().showLoginToast() : ("1" !== this.user_message.userrich.isvalidsvip || this.app_config.free || (e = 1), o.navigateTo({
                url: "/pages3/vip?current=" + (e || 0)
              }));
            },
            jumpPcVer: function jumpPcVer() {
              o.navigateTo({
                url: "/pages4/pccode"
              });
            },
            jumpCourseForExport: function jumpCourseForExport() {
              o.navigateTo({
                url: "/pages/webview/webview?url=https://mp.weixin.qq.com/s/k1wq-7s6a6CIkzWkGELeaA"
              });
            },
            jumpCourseForWindows: function jumpCourseForWindows() {
              var e = "https://mp.weixin.qq.com/s/UOFJ4bcTrhJWf2AhRBX1qg";
              this.app_config.course_windows && (e = this.app_config.course_windows), o.navigateTo({
                url: "/pages/webview/webview?url=" + e
              });
            },
            jumpCourseForPhone: function jumpCourseForPhone() {
              var e = "https://mp.weixin.qq.com/s/W10bhrRDBR11g1YcvciHag";
              this.app_config.course_phone && (e = this.app_config.course_phone), o.navigateTo({
                url: "/pages/webview/webview?url=" + e
              });
            },
            jumpPromotion: function jumpPromotion() {
              this.is_unlogin ? getApp().showLoginToast() : o.navigateTo({
                url: "/pages3/promotion"
              });
            },
            jumpCooperation: function jumpCooperation() {
              o.navigateTo({
                url: "/pages3/expert_share"
              });
            },
            jumpFreeVip: function jumpFreeVip() {
              o.navigateTo({
                url: "/pages3/share"
              });
            },
            jumpGZH: function jumpGZH() {
              o.navigateTo({
                url: "/pages3/gzh"
              });
            },
            jumpCharacterPack: function jumpCharacterPack() {
              "1" === this.user_message.userrich.isvalidsvip ? o.navigateTo({
                url: "/pages3/character_pack2"
              }) : o.showToast({
                title: "当前非超级会员",
                icon: "none"
              });
            },
            jumpCharacterInfo: function jumpCharacterInfo() {
              o.navigateTo({
                url: "/pages3/character_consume"
              });
            },
            jumoReceipt: function jumoReceipt() {
              o.navigateTo({
                url: "/pages3/receipt"
              });
            },
            jumpFeedBack: function jumpFeedBack() {
              o.navigateTo({
                url: "/pages3/feedback"
              });
            },
            refreshInfo: function refreshInfo() {
              var e = this;
              o.showLoading({
                title: "刷新中...",
                mask: !0
              }), getApp().getUserInfo(function (t) {
                e.$store.commit("setUserMessage", t.model), o.hideLoading(), o.showToast({
                  title: "刷新成功"
                });
              });
            },
            clearBufferMemory: function clearBufferMemory() {
              o.showLoading({
                title: "清除中...",
                mask: !0
              }), o.removeStorageSync("bgmusic"), setTimeout(function () {
                o.hideLoading(), o.showToast({
                  title: "清除成功"
                });
              }, 400);
            }
          }
        };
      t.default = f;
    }).call(this, i(1)["default"], i(2)["default"]);
  },
  429: function _(e, t, i) {
    "use strict";

    i.r(t);
    var o = i(430),
      n = i.n(o);
    for (var a in o) ["default"].indexOf(a) < 0 && function (e) {
      i.d(t, e, function () {
        return o[e];
      });
    }(a);
    t["default"] = n.a;
  },
  430: function _(e, t, i) {}
}, [[422, "common/runtime", "common/vendor"]]]);