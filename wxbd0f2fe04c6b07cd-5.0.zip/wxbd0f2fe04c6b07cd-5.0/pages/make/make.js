(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["pages/make/make"], {
  228: function _(t, e, o) {
    "use strict";

    o.r(e);
    var i = o(229),
      s = o.n(i);
    for (var n in i) ["default"].indexOf(n) < 0 && function (t) {
      o.d(e, t, function () {
        return i[t];
      });
    }(n);
    e["default"] = s.a;
  },
  229: function _(t, e, o) {},
  27: function _(t, e, o) {
    "use strict";

    o.r(e);
    var i = o(28);
    for (var s in i) ["default"].indexOf(s) < 0 && function (t) {
      o.d(e, t, function () {
        return i[t];
      });
    }(s);
    o(228);
    var n,
      a,
      r,
      c,
      u = o(230),
      l = Object(u["default"])(i["default"], n, a, !1, null, null, null, !1, r, c);
    l.options.__file = "App.vue", e["default"] = l.exports;
  },
  28: function _(t, e, o) {
    "use strict";

    o.r(e);
    var i = o(29),
      s = o.n(i);
    for (var n in i) ["default"].indexOf(n) < 0 && function (t) {
      o.d(e, t, function () {
        return i[t];
      });
    }(n);
    e["default"] = s.a;
  },
  29: function _(t, e, o) {
    "use strict";

    (function (t, i) {
      var s = o(4);
      Object.defineProperty(e, "__esModule", {
        value: !0
      }), e.default = void 0;
      var n = s(o(13)),
        a = (s(o(30)), s(o(31))),
        r = s(o(225)),
        c = o(226),
        u = (o(227), {
          globalData: {
            baseApi: "https://pysq.shipook.com/v2base",
            appApi: "https://pysq.shipook.com/v2app",
            app_url: {},
            base_url: {
              getsmscode: "/common/getsmscode",
              login4wechat: "/thirdlogin/login4wechat",
              login4zjtd: "/thirdlogin/login4zjtd",
              login4baidu: "/thirdlogin/login4baidu",
              userlogin: "/user/userlogin",
              qryuserallinfo: "/user/qryuserallinfo",
              cashorder: "/business/cashorder",
              openvip: "/business/openvip",
              bootup: "/common/bootup",
              updatedeviceinfo: "/common/updatedeviceinfo",
              getbusupgradeinfo: "/busupgrade/getbusupgradeinfo",
              qryuserjbviplist: "/business/qryuserjbviplist"
            },
            tab_work: 0,
            qd: "",
            ver: "010009",
            sec: "48a0088cb506e6b7",
            aaa: "",
            bbb: "",
            deviceId: "",
            wxappid: "",
            userinfo: null,
            crgid: "",
            parentid: "",
            deviceMac: "",
            oaid: "",
            ss: "",
            showPay: !0,
            freetype: null,
            vipList: [],
            svip_char: {},
            ios_status: 1,
            tts_text: "",
            ishidetype: "",
            heimingdan0: "",
            heimingdan1: "",
            heimingdan2: "",
            systemInfo: null,
            timeInfo: 0
          },
          onLaunch: function onLaunch() {
            var e = this;
            this.$store.commit("setAppConfig", r.default), 1154 === t.getLaunchOptionsSync().scene && (i.setStorageSync("ispyq", !0), i.switchTab({
              url: "/pages/make/make?pyq=1"
            }));
            var o = t.getUpdateManager();
            o.onCheckForUpdate(function (t) {
              if (!t.hasUpdate) return !1;
              o.onUpdateReady(function () {
                o.applyUpdate();
              });
            }), i.setInnerAudioOption({
              obeyMuteSwitch: !1
            }), i.getSystemInfo({
              complete: function complete(t) {
                i.setStorageSync("device", t), e.globalData.systemInfo = t;
              }
            }), this.globalData.aaa = this.globalData.sec.split("").reverse().join(""), this.globalData.bbb = this.globalData.sec.substr(1) + this.globalData.sec.substr(0, 1), this.setQd(r.default.qd), this.getPhoneId(), this.start_Up();
          },
          onShow: function onShow() {
            (i.getStorageSync("sid") || i.getStorageSync("uid")) && this.getUserInfo(function (t) {});
          },
          onHide: function onHide() {},
          methods: {
            commonencry: function commonencry() {
              return JSON.stringify(a.default.getEncryption());
            },
            findpyblack: function findpyblack() {
              var t = this,
                e = t.globalData.appApi + "/peiyin/findpyblack";
              a.default.postRequest({}, e, function (e) {
                if (e.model) for (var o = e.model.split(","), i = 0; i < o.length; i++) "0" == o[i] ? (t.globalData.heimingdan0 = !0, t.$store ? t.$store.commit("setheimingdan0", t.globalData.heimingdan0) : t.$vm.$store.commit("setheimingdan0", t.globalData.heimingdan0)) : "1" == o[i] ? t.globalData.heimingdan1 = !0 : "2" == o[i] && (t.globalData.heimingdan2 = !0);
              });
            },
            examineText: function examineText(t, e) {
              var o = this;
              return new Promise(function (s, n) {
                var r = o.globalData.appApi + "/security/green/text";
                a.default.postRequest({
                  text: t
                }, r, function (t) {
                  console.log("文本检查结果", t), "0" !== t.rc && s(!0);
                  var o = {
                    10001: " 广告",
                    20001: "时政",
                    20002: "色情",
                    20003: "辱骂",
                    20006: "违法犯罪",
                    20008: "欺诈",
                    20012: "低俗",
                    20013: "版权",
                    21e3: "其他"
                  };
                  o[t.model.label] ? (i.showModal({
                    title: "提示",
                    content: "文本内容包含".concat(o[t.model.label] ? o[t.model.label] : "", "相关违规文字信息，请修改后重新操作"),
                    cancelText: "联系客服",
                    success: function success(t) {
                      t.confirm ? e && e() : t.cancel && i.navigateTo({
                        url: "/pages/wode/kefu/kefu"
                      });
                    }
                  }), s(!1)) : s(!0);
                });
              });
            },
            examineImg: function examineImg(t, e) {
              var o = this;
              return new Promise(function (s, n) {
                var r = o.globalData.appApi + "/peiyin/wxurllink/examinewximg",
                  c = {
                    url: t
                  };
                a.default.postRequest(c, r, function (t) {
                  "0" !== t.rc && s(!0), console.log("图片检查结果", t);
                  var o = JSON.parse(t.model),
                    n = o.errcode;
                  0 !== n && i.showModal({
                    title: "提示",
                    content: "该图片存在敏感信息，暂无法使用，如有疑问，请联系客服处理",
                    cancelText: "联系客服",
                    success: function success(t) {
                      t.confirm ? e && e() : t.cancel && i.switchTab({
                        url: "/pages/mine/mine"
                      });
                    }
                  }), s(0 === n);
                });
              });
            },
            isShowPay: function isShowPay() {
              var t = i.getStorageSync("device").platform;
              return "ios" !== t && "devtools" != t;
            },
            downMp4ForAlbum: function downMp4ForAlbum(t) {
              console.log("导出MP4", t), i.downloadFile({
                url: t,
                success: function success(t) {
                  console.log("res", t), 200 === t.statusCode && (i.hideLoading(), i.saveVideoToPhotosAlbum({
                    filePath: t.tempFilePath,
                    success: function success() {
                      i.showModal({
                        title: "导出成功",
                        content: "前往相册查看"
                      });
                    }
                  }));
                }
              });
            },
            qryApiLimit: function qryApiLimit(t) {
              var e = this;
              return new Promise(function (o, i) {
                var s = {
                    apiType: t,
                    isVip: e.globalData.userinfo.userrich.isvalidvip
                  },
                  n = e.globalData.appApi + "/peiyin/qryapilimitapp";
                console.log("json", s), console.log("url", n), a.default.postRequest(s, n, function (t) {
                  console.log("api剩余次数", t), o(t);
                });
              });
            },
            updateApiLimit: function updateApiLimit(t) {
              var e = {
                  apiType: t,
                  isVip: this.globalData.userinfo.userrich.isvalidvip
                },
                o = this.globalData.appApi + "/peiyin/uptapilimitapp";
              a.default.postRequest(e, o, function (t) {
                console.log("api更新次数", t);
              });
            },
            setOssPath: function setOssPath(t, e, o) {
              i.uploadFile({
                url: this.globalData.appApi + "/peiyin/music/univerupload",
                filePath: t,
                name: "file",
                formData: {
                  isrestrict: "0",
                  catalogue: e,
                  osstype: "1",
                  comparam: getApp().commonencry()
                },
                success: function success(t) {
                  console.log("上传本地文件到oss", t), o(JSON.parse(t.data).model);
                },
                fail: function fail(t) {
                  i.showToast({
                    title: "图片上传失败！",
                    icon: "none"
                  }), o("fail");
                }
              });
            },
            generatePoster: function generatePoster(t) {
              var e = {
                req: JSON.stringify({
                  qd: this.globalData.qd,
                  ver: this.globalData.ver,
                  sceneStr: this.globalData.userinfo.userinfo.id,
                  page: "pages/make/make"
                })
              };
              console.log("生成分享二维码", e);
              var o = this.globalData.appApi + "/wxgetqrcode";
              i.request({
                url: o,
                method: "POST",
                header: {
                  "content-type": "application/x-www-form-urlencoded",
                  cookie: "SESSION=" + (i.getStorageSync("sid") ? i.getStorageSync("sid") : "")
                },
                data: e,
                success: function success(e) {
                  t(e);
                }
              });
            },
            getShare: function getShare(t) {
              var e = this;
              (t.parentid || t.scene) && setTimeout(function () {
                var o = t.parentid;
                if (t.scene && (o = decodeURIComponent(t.scene)), o) {
                  e.globalData.parentid = o;
                  var s = {
                      parentid: o
                    },
                    n = getApp().globalData.baseApi + "/user/bindparent";
                  a.default.postRequest(s, n, function (t) {
                    console.log("分享绑定", t), i.showToast({
                      title: "绑定上级成功",
                      icon: "none",
                      duration: 2e3
                    }), getApp().getUserInfo(function (t) {});
                  }, function (t) {
                    if (console.log("绑定失败aaaa", t), "1501" == t.rc) i.showToast({
                      title: "您已绑定过上级，不可再次绑定",
                      icon: "none",
                      duration: 2e3
                    });else {
                      var e = t.rd;
                      i.showToast({
                        title: e,
                        icon: "none",
                        duration: 2e3
                      });
                    }
                  });
                }
              }, 1e3);
            },
            getbdKF: function getbdKF() {
              r.default.kfurl && t.openCustomerServiceChat({
                extInfo: {
                  url: r.default.kfurl
                },
                corpId: r.default.kfcorpId,
                showMessageCard: !0,
                sendMessageTitle: "请稍等，客服马上就到(" + this.globalData.userinfo.userinfo.id + ")",
                sendMessageImg: "https://pysqstoss.shipook.com/imgs/20220117/202306011h.png"
              });
            },
            copyObj: function copyObj(t) {
              var e = null;
              if ("object" == (0, n.default)(t) && null !== t) for (var o in e = t instanceof Array ? [] : {}, t) e[o] = this.copyObj(t[o]);else e = t;
              return e;
            },
            getLocation: function getLocation(t) {
              i.getLocation({
                type: "gcj02",
                success: function success(e) {
                  var o = e.latitude,
                    i = e.longitude;
                  console.log(e);
                  var s = {
                      lng: i,
                      lat: o
                    },
                    n = getApp().globalData.baseApi + "/common/getprovince";
                  a.default.postRequest(s, n, function (e) {
                    console.log("通过经纬度获取地址", e), t(e);
                  });
                },
                fail: function fail(e) {
                  t("fail"), i.showToast({
                    title: "获取位置信息失败！",
                    icon: "none"
                  }), console.log("获取位置失败", e);
                }
              });
            },
            setUserInfo: function setUserInfo(t, e) {
              console.log("用户信息2222", t), r.default.free && (t.model.userrich.isvalidsvip = "1"), i.setStorageSync("uid", t.model.userinfo.uid), i.setStorageSync("did", t.model.userinfo.did), this.$store ? this.$store.commit("setUserMessage", t.model) : this.$vm.$store.commit("setUserMessage", t.model), getApp().globalData.userinfo = t.model, e(t);
            },
            wxLogin: function wxLogin(t) {
              i.login({
                provider: "weixin",
                success: function success(e) {
                  var o = {
                      isbind: "0",
                      code: e.code
                    },
                    s = getApp().globalData.baseApi + getApp().globalData.base_url.login4wechat,
                    n = function n(e) {
                      i.setStorageSync("sid", e.model.userinfo.sid), getApp().setUserInfo(e, t);
                    };
                  a.default.postRequest(o, s, n);
                }
              });
            },
            disposeNewUser: function disposeNewUser(t, e) {
              var o = this,
                s = new Date(t.ctime).getTime(),
                n = new Date().getTime(),
                r = n - s,
                c = 6048e5;
              "用户" === t.nickname && r <= c && i.showModal({
                title: "提示",
                content: "需要获取您的微信昵称与头像用于完善资料显示，是否同意获取？",
                success: function success(t) {
                  t.confirm && i.getUserProfile({
                    desc: "用于完善资料显示",
                    success: function success(t) {
                      var i = {
                          nickname: t.userInfo.nickName,
                          avatar: t.userInfo.avatarUrl
                        },
                        s = o.globalData.baseApi + "/user/updateuserinfo";
                      a.default.postRequest(i, s, function (t) {
                        e && e();
                      });
                    }
                  });
                }
              });
            },
            getUserInfo: function getUserInfo(t) {
              var e = this,
                o = this.globalData.baseApi + this.globalData.base_url.qryuserallinfo;
              a.default.postRequest({}, o, function (o) {
                console.log("获取用户信息", o), e.setUserInfo(o, t);
              });
            },
            getPay: function getPay(t, e, o, s, n, r, c) {
              i.showLoading({
                title: "加载中",
                mask: !0
              });
              var u = this,
                l = 10 * Number(o).toFixed(2),
                h = {
                  crgtype: 2,
                  paytype: t,
                  ordername: e,
                  jb: l,
                  rmb: o,
                  orderid: n,
                  ordertype: s,
                  extdata: r,
                  ish5: 3
                };
              console.log(h);
              var p = this.globalData.baseApi + this.globalData.base_url.cashorder;
              this.globalData.crgid = "";
              var d = function d(e) {
                u.callPay(t, e, c);
              };
              a.default.postRequest(h, p, d);
            },
            getVip: function getVip(t, e, o, s, n, r) {
              i.showLoading({
                title: "加载中",
                mask: !0
              });
              var c = this,
                u = {
                  viptype: t,
                  sviptype: e,
                  paytype: o,
                  time: s,
                  extdata: n,
                  ish5: 3
                };
              console.log("开通会员", u);
              var l = this.globalData.baseApi + this.globalData.base_url.openvip,
                h = function h(t) {
                  c.callPay(o, t, r);
                };
              a.default.postRequest(u, l, h);
            },
            callPay: function callPay(t, e, o) {
              2 == t && e.model.orderparams4webchat ? this.wxPayForMp(e, o) : 1 == t && e.model.orderstr4alipay;
            },
            wxPayForApp: function wxPayForApp(t, e) {
              var o = this;
              i.requestPayment({
                provider: "wxpay",
                orderInfo: t.model.orderparams4webchat,
                success: function success(t) {
                  o.getUserInfo(), i.hideLoading(), e(t);
                },
                fail: function fail(t) {
                  i.hideLoading(), i.showToast({
                    title: "支付失败",
                    icon: "none"
                  });
                }
              });
            },
            wxPayForMp: function wxPayForMp(t, e) {
              var o = this;
              i.requestPayment({
                provider: "wxpay",
                timeStamp: t.model.orderparams4webchat.timestamp,
                nonceStr: t.model.orderparams4webchat.noncestr,
                package: "prepay_id=" + t.model.orderparams4webchat.prepayid,
                signType: "MD5",
                paySign: t.model.orderparams4webchat.sign,
                success: function success(t) {
                  o.getUserInfo(), i.hideLoading(), e(t);
                },
                fail: function fail(t) {
                  i.hideLoading();
                }
              });
            },
            aliPayForApp: function aliPayForApp(t, e) {
              var o = this;
              i.requestPayment({
                provider: "alipay",
                orderInfo: t.model.orderstr4alipay,
                success: function success(t) {
                  o.getUserInfo(), i.hideLoading(), e(t);
                },
                fail: function fail(t) {
                  i.hideLoading(), i.showToast({
                    title: "支付失败",
                    icon: "none"
                  });
                }
              });
            },
            zjPayForMp: function zjPayForMp(t, e) {},
            setQd: function setQd(t) {
              var e = "";
              e = this.globalData.systemInfo ? this.globalData.systemInfo.platform : i.getSystemInfoSync().platform, console.log("bradn", e), this.globalData.qd = "ios" == e || "devtools1" == e ? "2" + t.slice(1) : t, console.log("渠道号", this.globalData.qd);
            },
            start_Up: function start_Up() {
              var t,
                e = this,
                o = new Date().toLocaleDateString();
              t = i.getStorageSync("active") ? i.getStorageSync("active") == o ? "0" : "2" : "1";
              var s = {
                  active: t
                },
                n = e.globalData.baseApi + e.globalData.base_url.bootup;
              a.default.postRequest(s, n, function (t) {
                console.log("合肥阅舟科技-设备启动信息", t), e.globalData.appcfg = t.model.appcfg ? JSON.parse(t.model.appcfg) : {}, e.globalData.freetype = t.model.appcfg ? JSON.parse(t.model.appcfg).freetype : "0", e.globalData.svip_char = e.globalData.appcfg.svip_char, e.globalData.vipList = t.model.jbviplist, e.globalData.zifubao = JSON.parse(t.model.appcfg).zifubao, t.model.appcfg && (JSON.parse(t.model.appcfg).iospay ? e.globalData.iospay = JSON.parse(t.model.appcfg).iospay : e.globalData.iospay = 1, JSON.parse(t.model.appcfg).hideiospay ? e.globalData.hideiospay = JSON.parse(t.model.appcfg).hideiospay : e.globalData.hideiospay = 1), e.hidearea(), e.findpyblack(), i.setStorageSync("active", o);
              });
              var r = e.globalData.baseApi + "/business/qujbl";
              a.default.postRequest({}, r, function (t) {
                console.log("获取配置信息", t), e.globalData.isexamine = "1" === t.model.isexm, e.globalData.iswcp = t.model.iswcp, i.$emit("qryttscfg");
              });
            },
            hidearea: function hidearea() {
              var t = this,
                e = {
                  functype: "0"
                },
                o = t.globalData.baseApi + "/business/qryshieldfunc";
              a.default.postRequest(e, o, function (e) {
                var o;
                console.log("屏蔽地区", e), o = "0" == e.rc && e.model.iospay ? e.model.iospay : "1", t.globalData.ishidetype = o, t.globalData.ios_status = "1" == o ? t.globalData.hideiospay : "0" == o ? t.globalData.iospay : 1;
              });
            },
            getPhoneId: function getPhoneId() {},
            getStorageFun: function getStorageFun(t, e) {
              var o = new Date().toLocaleDateString();
              if (!i.getStorageSync(t)) return i.setStorageSync(t, o), void e();
              i.getStorageSync(t) != o && (i.setStorageSync(t, o), i.removeStorageSync("bgmusic"), e());
            },
            showLoginToast: function showLoginToast() {
              i.showModal({
                title: "登录提示",
                content: "您当前未登录，请先去登录",
                cancelText: "取消",
                confirmText: "登录",
                showCancel: !0,
                success: function success(t) {
                  t.confirm && getApp().relogin();
                }
              });
            },
            relogin: function relogin() {
              var t = this,
                e = function e(_e) {
                  t.$vm.$store.commit("setIsunlogin", !1), t.$vm.$store.commit("setUserMessage", _e.model), i.showToast({
                    title: "登录成功"
                  });
                };
              getApp().wxLogin(function (t) {
                e(t);
              });
            },
            prosssCirculation: function prosssCirculation(t, e) {
              var o = {
                asyncId: t
              };
              getApp().globalData.timeInfo = setInterval(function () {
                var t = getApp().globalData.appApi + "/peiyin/asyncProcess/selectProcess";
                a.default.postRequest(o, t, function (t) {
                  "0" === t.rc ? "2" == t.model.processState ? (getApp().stoptimerinfo(), e && (e({
                    type: "1",
                    result: t.model
                  }), i.hideLoading({}))) : "1" == t.model.processState && (getApp().stoptimerinfo(), e && e({
                    type: "0",
                    result: t.model.failDesc
                  }), i.hideLoading({})) : (getApp().stoptimerinfo(), e && e({
                    type: "0",
                    result: t.rd
                  }), i.hideLoading({}));
                }, function (t) {
                  getApp().stoptimerinfo(), e && e({
                    type: "0",
                    result: "操作失败"
                  }), i.hideLoading({});
                });
              }, 3e3);
            },
            stoptimerinfo: function stoptimerinfo() {
              getApp().globalData.timeInfo && (clearInterval(getApp().globalData.timeInfo), getApp().globalData.timeInfo = 0);
            },
            getProcessId: function getProcessId(t, e, o) {
              (0, c.getProcess)(t, e).then(function (t) {
                if ("0" === t.rc) {
                  var e = t.model;
                  getApp().globalData.timeInfo && getApp().stoptimerinfo(), getApp().prosssCirculation(e, o);
                }
              }).catch(function (t) {
                console.log(t);
              });
            }
          },
          mounted: function mounted() {}
        });
      e.default = u;
    }).call(this, o(1)["default"], o(2)["default"]);
  },
  359: function _(t, e, o) {
    "use strict";

    (function (t, e) {
      var i = o(4);
      o(26);
      i(o(25));
      var s = i(o(360));
      t.__webpack_require_UNI_MP_PLUGIN__ = o, e(s.default);
    }).call(this, o(1)["default"], o(2)["createPage"]);
  },
  360: function _(t, e, o) {
    "use strict";

    o.r(e);
    var i = o(361),
      s = o(363);
    for (var n in s) ["default"].indexOf(n) < 0 && function (t) {
      o.d(e, t, function () {
        return s[t];
      });
    }(n);
    o(370);
    var a,
      r = o(230),
      c = Object(r["default"])(s["default"], i["render"], i["staticRenderFns"], !1, null, null, null, !1, i["components"], a);
    c.options.__file = "pages/make/make.vue", e["default"] = c.exports;
  },
  361: function _(t, e, o) {
    "use strict";

    o.r(e);
    var i = o(362);
    o.d(e, "render", function () {
      return i["render"];
    }), o.d(e, "staticRenderFns", function () {
      return i["staticRenderFns"];
    }), o.d(e, "recyclableRender", function () {
      return i["recyclableRender"];
    }), o.d(e, "components", function () {
      return i["components"];
    });
  },
  362: function _(t, e, o) {
    "use strict";

    var i;
    o.r(e), o.d(e, "render", function () {
      return s;
    }), o.d(e, "staticRenderFns", function () {
      return a;
    }), o.d(e, "recyclableRender", function () {
      return n;
    }), o.d(e, "components", function () {
      return i;
    });
    try {
      i = {
        uPopup: function uPopup() {
          return Promise.all([o.e("common/vendor"), o.e("uni_modules/uview-ui/components/u-popup/u-popup")]).then(o.bind(null, 1093));
        },
        uSwitch: function uSwitch() {
          return Promise.all([o.e("common/vendor"), o.e("uni_modules/uview-ui/components/u-switch/u-switch")]).then(o.bind(null, 1101));
        }
      };
    } catch (r) {
      if (-1 === r.message.indexOf("Cannot find module") || -1 === r.message.indexOf(".vue")) throw r;
      console.error(r.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
    }
    var s = function s() {
        var t = this,
          e = t.$createElement,
          o = (t._self._c, t.anchor.isemotion && t.anchor.emotion ? JSON.parse(t.anchor.emotion).length : null),
          i = t.workmm ? t.text.substr(0, 4) : null;
        t._isMounted || (t.e0 = function (e) {
          t.is_focus = !1;
        }, t.e1 = function (e) {
          t.show_speed = !0;
        }, t.e2 = function (e) {
          t.show_pitch = !0;
        }, t.e3 = function (e) {
          t.show_bg = !0;
        }, t.e4 = function (e) {
          t.isShowListenSetting = !0;
        }, t.e5 = function (e) {
          t.tszftipflag = !1;
        }, t.e6 = function (e) {
          t.sensitive_word_show = !1;
        }, t.e7 = function (e) {
          t.show_nonmember = !1;
        }, t.e8 = function (e) {
          t.show_svippopup = !1;
        }, t.e9 = function (e) {
          t.show_text = !1;
        }, t.e10 = function (e) {
          t.show_extract = !1;
        }, t.e11 = function (e) {
          t.show_prompt = !1;
        }, t.e12 = function (e) {
          t.show_frequency = !1;
        }, t.e13 = function (e) {
          t.is_focus = !1;
        }, t.e14 = function (e) {
          t.show_char = !1;
        }, t.e15 = function (e) {
          t.show_speed = !1;
        }, t.e16 = function (e) {
          t.speed = t.anchor.speed;
        }, t.e17 = function (e) {
          t.show_speed = !1;
        }, t.e18 = function (e) {
          t.show_pitch = !1;
        }, t.e19 = function (e) {
          t.pitch = t.anchor.pitch;
        }, t.e20 = function (e) {
          t.show_pitch = !1;
        }, t.e21 = function (e) {
          t.show_emo = !1;
        }, t.e22 = function (e) {
          t.isShowListenSetting = !1;
        }), t.$mp.data = Object.assign({}, {
          $root: {
            g0: o,
            g1: i
          }
        });
      },
      n = !1,
      a = [];
    s._withStripped = !0;
  },
  363: function _(t, e, o) {
    "use strict";

    o.r(e);
    var i = o(364),
      s = o.n(i);
    for (var n in i) ["default"].indexOf(n) < 0 && function (t) {
      o.d(e, t, function () {
        return i[t];
      });
    }(n);
    e["default"] = s.a;
  },
  364: function _(t, e, o) {
    "use strict";

    (function (t, i) {
      var s = o(4);
      Object.defineProperty(e, "__esModule", {
        value: !0
      }), e.default = void 0;
      var n = s(o(255)),
        a = s(o(257)),
        r = s(o(11)),
        c = o(226),
        u = o(227),
        l = o(365),
        h = o(366),
        p = (s(o(367)), s(o(225))),
        d = s(o(368)),
        f = s(o(369));
      function m(t, e) {
        var o = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
          var i = Object.getOwnPropertySymbols(t);
          e && (i = i.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })), o.push.apply(o, i);
        }
        return o;
      }
      function g(t) {
        for (var e = 1; e < arguments.length; e++) {
          var o = null != arguments[e] ? arguments[e] : {};
          e % 2 ? m(Object(o), !0).forEach(function (e) {
            (0, r.default)(t, e, o[e]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(o)) : m(Object(o)).forEach(function (e) {
            Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(o, e));
          });
        }
        return t;
      }
      var v = function v() {
          o.e("components/make/make_emotion").then(function () {
            return resolve(o(1109));
          }.bind(null, o)).catch(o.oe);
        },
        _ = function _() {
          o.e("components/make/tszf_tip").then(function () {
            return resolve(o(1116));
          }.bind(null, o)).catch(o.oe);
        },
        b = function b() {
          o.e("components/make/maintenance").then(function () {
            return resolve(o(1123));
          }.bind(null, o)).catch(o.oe);
        },
        y = function y() {
          Promise.all([o.e("common/vendor"), o.e("components/make/make_extract")]).then(function () {
            return resolve(o(1130));
          }.bind(null, o)).catch(o.oe);
        },
        w = function w() {
          o.e("components/make/make_text").then(function () {
            return resolve(o(1137));
          }.bind(null, o)).catch(o.oe);
        },
        x = function x() {
          o.e("components/make/make_popup").then(function () {
            return resolve(o(1144));
          }.bind(null, o)).catch(o.oe);
        },
        k = function k() {
          o.e("components/make/make_bgmusic").then(function () {
            return resolve(o(1151));
          }.bind(null, o)).catch(o.oe);
        },
        S = function S() {
          o.e("components/make/sensitive_word_popup").then(function () {
            return resolve(o(1158));
          }.bind(null, o)).catch(o.oe);
        },
        T = function T() {
          o.e("components/make/make_nonmember").then(function () {
            return resolve(o(1165));
          }.bind(null, o)).catch(o.oe);
        },
        D = function D() {
          o.e("components/make/make_svip_popup").then(function () {
            return resolve(o(1172));
          }.bind(null, o)).catch(o.oe);
        },
        A = function A() {
          o.e("components/make/make_prompt").then(function () {
            return resolve(o(1179));
          }.bind(null, o)).catch(o.oe);
        },
        q = function q() {
          o.e("components/make/make_frequency").then(function () {
            return resolve(o(1186));
          }.bind(null, o)).catch(o.oe);
        },
        P = function P() {
          o.e("components/make/keyboard_top").then(function () {
            return resolve(o(1193));
          }.bind(null, o)).catch(o.oe);
        },
        I = function I() {
          o.e("components/make/char_deficiency").then(function () {
            return resolve(o(1200));
          }.bind(null, o)).catch(o.oe);
        },
        j = function j() {
          o.e("components/make/save_workname").then(function () {
            return resolve(o(1207));
          }.bind(null, o)).catch(o.oe);
        },
        $ = {
          components: {
            MakePopup: x,
            MakeBgMusic: k,
            sensitiveWordPopup: S,
            MakeNonmenber: T,
            MakeSvipPopup: D,
            MakePrompt: A,
            MakeFrequency: q,
            KeyboardTop: P,
            CharDeficiency: I,
            MakeText: w,
            MakeExtract: y,
            SaveWorkName: j,
            tip4special: _,
            maintenance: b,
            makeEmotion: v
          },
          computed: g(g({}, (0, u.mapState)(["titleInfo", "anchor", "emotion", "user_message", "app_config", "heimingdan0", "is_unlogin", "showPrivacy_ysxy"])), {}, {
            disposeMakeHeight: function disposeMakeHeight() {
              var e = this.titleInfo.top + this.titleInfo.height;
              if (this.is_focus) {
                var o = t.upx2px(192),
                  i = this.$refs.KeyboardTop.keyHeight;
                return "calc(100vh - ".concat(e + o + i, "px)");
              }
              var s = 96,
                n = 120,
                a = 142,
                r = 148;
              return e += t.upx2px(s + n + a + r), "calc(100vh - ".concat(e, "px)");
            },
            max_length: function max_length() {
              return this.user_message.userrich && "1" === this.user_message.userrich.isvalidsvip ? 8e3 : 5e3;
            }
          }),
          watch: {
            "tts_audio.url": {
              handler: function handler(t, e) {
                "" != t ? this.is_cursor_flag && (this.keytop_palystatus = !0) : this.is_cursor_flag && (this.keytop_palystatus = !1);
              },
              immediate: !0
            },
            show_nonmember: function show_nonmember(t) {
              t && (this.is_focus = !1);
            },
            show_char: function show_char(t) {
              t && (this.is_focus = !1);
            },
            text: function text(t) {
              this.tts_audio.play_state || (this.tts_audio.url = ""), this.tts_audio.url && (this.jsst = !0), this.input_text = t, this.length = t.replace(/\s*|\t|\r|\n/g, "").replace(/\[(\d+\.?\d*)秒]/g, "").replace(/#[a-z]+[1-5]#/g, "").replace(/#none#/g, "").length, getApp().globalData.text1 = t;
            },
            anchor: {
              handler: function handler(e, o) {
                this.tts_audio.play_state || (this.tts_audio.url = ""), this.tts_audio.url && (this.jsst = !0);
                var i = t.getStorageSync(e.zbid);
                i ? (this.volume = i.volume, this.$refs.bgmusic_obj.volume = i.volume, this.speed = i.speed, this.pitch = i.pitch, "1" === this.anchor.isemotion ? (this.emotiondegree = i.emotiondegree, i.emotion && this.$store.commit("setEmotion", i.emotion)) : (this.emotiondegree = 50, this.$store.commit("setEmotion", {}))) : (this.volume = e.vol, this.$refs.bgmusic_obj.volume = e.vol, this.speed = e.speed, this.pitch = e.pitch, "1" !== this.anchor.isemotion && (this.emotiondegree = 50, this.$store.commit("setEmotion", {})));
              },
              deep: !0
            },
            show_pitch: function show_pitch() {
              this.tts_audio.play_state || (this.tts_audio.url = ""), this.tts_audio.url && (this.jsst = !0), this.record_install.pitch = this.pitch;
            },
            show_speed: function show_speed() {
              this.tts_audio.play_state || (this.tts_audio.url = ""), this.tts_audio.url && (this.jsst = !0), this.record_install.speed = this.speed;
            },
            show_emo: function show_emo(t) {
              this.tts_audio.play_state || (this.tts_audio.url = ""), this.tts_audio.url && (this.jsst = !0), t ? (this.record_install.emotiondegree = this.emotiondegree, this.record_install.emotion = this.emotion) : this.list_play.stop();
            }
          },
          data: function data() {
            return {
              languageCode: "",
              dianjishiting: "点击试听",
              isShowListenSetting: !1,
              qytsFlag: !1,
              lyuan: "0",
              jsst: !1,
              tszftipflag: !1,
              ttstime: "",
              audiourl: "",
              workid: "",
              workname: "",
              folderid: "",
              workmm: !1,
              show_extract: !1,
              show_text: !1,
              tts_audio: null,
              list_play: null,
              text: "",
              input_text: "",
              volume: 50,
              speed: 0,
              pitch: 0,
              length: 0,
              emotiondegree: 50,
              show_pitch: !1,
              show_speed: !1,
              show_emo: !1,
              show_bg: !1,
              show_template: !1,
              show_insert: !1,
              show_nonmember: !1,
              show_svippopup: !1,
              show_inventory: !1,
              show_prompt: !1,
              show_frequency: !1,
              show_char: !1,
              cursor: 0,
              is_focus: !1,
              sensitive_word_show: !1,
              sensitive_word_text: "文本内容含有敏感词，请修改后重新合成制作",
              tts_rc: "0",
              record_install: {},
              show_pyq: !1,
              keytop_palystatus: !1,
              is_cursor_flag: !1,
              is_save_flag: !1,
              keyboardHeight: 0,
              keyboardTopHeight: 0,
              bg_name: "背景音",
              timinval: !0,
              timeInfo: 3,
              time: null
            };
          },
          onLoad: function onLoad(e) {
            var o = this;
            t.getSystemInfoSync();
            this.tts_audio = new d.default(), this.list_play = new f.default(), this.$store.commit("setAppConfig", p.default), t.getStorageSync("ispyq") && (this.show_pyq = !0, t.setStorageSync("ispyq", !1)), t.getStorageSync("use_anchor") && this.$store.commit("setAnchor", t.getStorageSync("use_anchor")), t.$on("reeditWork", function (t) {
              o.reeditWork(t);
            }), t.$on("audioStop", function (t) {
              o.listeningTestPopup();
            }), this.text = t.getStorageSync("tts_text") ? t.getStorageSync("tts_text") : "", this.login(e), this.initLayout(), this.getAnchor(), getApp().globalData.tts_text = this.text, t.$on("setText", function (t) {
              o.text = t;
            });
          },
          onShow: function onShow() {
            var e = this;
            getApp().getUserInfo(function (t) {
              e.$store.commit("setUserMessage", t.model);
            }), this.is_unlogin && t.showModal({
              title: "登录提示",
              content: "您当前未登录，请先去登录",
              confirmText: "登录",
              showCancel: !1,
              success: function success(t) {
                t.confirm && getApp().relogin();
              }
            }), setTimeout(function () {
              e.is_focus = !1;
            }, 10), "no" == t.getStorageSync("tool_timinval") && (this.timinval = !1);
          },
          onHide: function onHide() {
            this.show_pitch = !1, this.show_speed = !1, this.show_emo = !1, this.tts_audio.stopAllMusic();
          },
          methods: {
            confirmMakeEmotion: function confirmMakeEmotion(t) {
              this.emotiondegree = t.myEmotiondegree, this.languageCode = t.mylanguageCode, this.show_emo = !1;
            },
            switchChange: function switchChange(t) {
              this.jsst = !0, this.stopPlay();
            },
            closeJump: function closeJump() {
              this.qytsFlag = !1, clearInterval(this.time);
            },
            jumpXz: function jumpXz() {
              var e = this;
              this.$uma_wx.trackEvent("makeJumpWrite");
              var o = this;
              this.qytsFlag = !0, this.timeInfo = 3, this.time = setInterval(function () {
                o.timeInfo = o.timeInfo - 1, o.timeInfo <= 0 && (clearInterval(e.time), o.timinval = !1, t.setStorageSync("tool_timinval", "no"));
              }, 1e3);
            },
            jumpToNavigate: function jumpToNavigate() {
              var e = this;
              this.qytsFlag = !1, t.navigateToMiniProgram({
                appId: e.app_config.jumpid,
                success: function success(t) {
                  console.log(t);
                },
                fail: function fail(t) {
                  console.log(t);
                }
              });
            },
            clickInfo: function clickInfo() {
              this.is_focus = !1, this.show_prompt = !0;
            },
            copyText: function copyText() {
              var e = this;
              t.getClipboardData({
                success: function success(o) {
                  e.text = o.data, t.showToast({
                    title: "复制成功",
                    icon: "none"
                  });
                },
                fail: function fail(e) {
                  t.showToast({
                    title: "复制失败",
                    icon: "none"
                  });
                }
              });
            },
            confirmSaveWorkName: function confirmSaveWorkName(e) {
              var o = this;
              t.showTabBar(), this.workmm = !1, e.wname && (this.workname = e.wname), this.folderid = e.fid, t.showLoading({
                title: "保存中...",
                mask: !0
              }), setTimeout(function () {
                o.saveWork(o.audiourl);
              }, parseInt(.7 * Number(this.ttstime) * 1e3));
            },
            qxSaveWorkName: function qxSaveWorkName() {
              t.showTabBar(), this.workmm = !1;
            },
            gdgn: function gdgn() {
              getApp().globalData.tts_text = this.text, this.is_focus = !1, this.show_text = !0;
            },
            jumpSpecialWord: function jumpSpecialWord() {
              var e = this;
              this.is_focus = !1, this.text ? (this.show_text = !1, getApp().globalData.tts_text = this.text, t.navigateTo({
                url: "/pages2/make/make_special",
                events: {
                  setText: function setText(t) {
                    e.text = t;
                  }
                }
              })) : t.showToast({
                title: "配音文本为空",
                icon: "none"
              });
            },
            jumpImportText: function jumpImportText() {
              var e = this;
              this.show_text = !1, getApp().globalData.tts_text = this.text, this.show_extract = !0, this.is_focus = !1, t.$on("setText", function (t) {
                e.show_extract = !1, e.text = t;
              });
            },
            hideBgMusicConfig: function hideBgMusicConfig(t) {
              this.bg_name = t ? t.substring(0, 4) : "背景音", this.show_bg = !1, this.tts_audio.stopAllMusic();
            },
            qxg: function qxg() {
              var e = this;
              return this.tszftipflag = !1, "" == this.text ? (t.showToast({
                title: "请输入配音文字",
                icon: "none"
              }), !1) : this.anchor.zbid ? (getApp().globalData.tts_text = this.text, void t.navigateTo({
                url: "/pages2/make/make_special",
                events: {
                  setText: function setText(t) {
                    e.text = t;
                  }
                }
              })) : (t.showToast({
                title: "主播信息异常",
                icon: "none"
              }), !1);
            },
            nohecheng: function nohecheng() {
              t.getStorageSync("textfromWenantiqu") === this.text ? this.lyuan = "1" : this.lyuan = "0";
              var e = this.is_save_flag ? this.text : this.disposeWords(this.is_cursor_flag);
              this.requestTts1(this.is_save_flag, this.is_cursor_flag, e);
            },
            requestTts: function requestTts(e) {
              var o = this,
                i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                s = this;
              if (this.text.length > 0) {
                var n = this.text.replace(/\s*|\t|\r|\n/g, "");
                if (0 == n.length) return void t.showModal({
                  title: "提示",
                  content: "无有效字符，请重新输入",
                  cancelText: "取消",
                  confirmText: "清除",
                  showCancel: !0,
                  success: function success(t) {
                    t.confirm ? s.text = "" : t.cancel;
                  }
                });
              }
              if (t.getStorageSync("textfromWenantiqu") === this.text ? this.lyuan = "1" : this.lyuan = "0", this.jsst = !1, this.is_save_flag = e, this.is_cursor_flag = i, this.verifyTtsArg(e, i)) {
                var a = e ? this.text : this.disposeWords(i);
                "试听200字" == this.dianjishiting && a.length > 200 && (a = a.substring(0, 200)), this.tts_audio.url && 0 == this.jsst ? this.requestTts1(e, i, a) : (0, l.specialWord)({
                  str: a
                }).then(function (t) {
                  t.model && t.model.length > 0 ? (o.is_focus = !1, o.tszftipflag = !0) : o.requestTts1(e, i, a);
                });
              }
            },
            requestTts1: function requestTts1(e) {
              var o = this,
                i = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                s = arguments.length > 2 ? arguments[2] : void 0;
              t.showLoading({
                title: "合成中...",
                mask: !0
              }), this.recordAnchor(), "1" !== this.anchor.polyphonic && (s = s.replace(/#[a-z]+[1-5]#/g, "")), "1" !== this.anchor.wordlink && (s = s.replace(/#none#/g, ""));
              var n = {
                text: s,
                zbid: this.anchor.zbid,
                volume: this.volume,
                speed: this.speed,
                pitch: "" !== this.pitch ? this.pitch : this.anchor.pitch
              };
              if ("1" === this.anchor.isemotion) {
                if (this.emotion && this.emotion.code) n.emotion = this.emotion.code;else {
                  var a = JSON.parse(this.anchor.emotion),
                    r = a[0].code;
                  n.emotion = r;
                }
                n.emotiondegree = this.emotiondegree ? this.emotiondegree : "";
              }
              if (!e && !i && this.tts_arg && this.tts_audio.url && JSON.stringify(this.tts_arg) === JSON.stringify(n)) return this.tts_audio.recoverPlay(), void t.hideLoading();
              var c = JSON.stringify(this.tts_arg) === JSON.stringify(n);
              if (this.tts_arg = n, console.log("tts合成参数：", n), this.$uma_wx.trackEvent("getTts"), c && this.tts_res.audiourl) {
                if (e) return void (this.workmm = !0);
                var u = this.$refs.bgmusic_obj,
                  h = u.bgmusic,
                  p = u.continue_time,
                  d = u.bg_volume,
                  f = u.delay_time,
                  m = u.is_reduce;
                h.bgname ? this.tts_audio.playTtsAndBgMusic(this.tts_res.audiourl, this.tts_res.audionum, h.bgmusicurl, p, d, f, m) : this.tts_audio.playTts(this.tts_res.audiourl, this.tts_res.audionum), console.log("音频地址2", this.tts_res.audiourl);
              } else this.tts_res = {}, (0, l.getTts)(n).then(function (t) {
                if (o.audiourl = t.model.audiourl, o.ttstime = t.model.ttstime, o.tts_res = t.model, console.log("调用tts合成接口了"), e) o.workmm = !0;else {
                  var i = o.$refs.bgmusic_obj,
                    s = i.bgmusic,
                    n = i.continue_time,
                    a = i.bg_volume,
                    r = i.delay_time,
                    c = i.is_reduce;
                  s.bgname ? o.tts_audio.playTtsAndBgMusic(t.model.audiourl, t.model.audionum, s.bgmusicurl, n, a, r, c) : o.tts_audio.playTts(t.model.audiourl, t.model.audionum);
                }
              }).catch(function (t) {
                console.log("tts合成异常回调：", t), o.is_cursor_flag && (o.keytop_palystatus = !1), o.disposeTtsState(t);
              });
            },
            saveWork: function saveWork(e) {
              var o = this;
              return (0, a.default)(n.default.mark(function i() {
                var s, a, r, c, u, h, p, d, f;
                return n.default.wrap(function (i) {
                  while (1) switch (i.prev = i.next) {
                    case 0:
                      if (s = o.$refs.bgmusic_obj, a = s.bgmusic, r = s.continue_time, c = s.bg_volume, u = s.delay_time, h = s.is_reduce, !a.bgname) {
                        i.next = 6;
                        break;
                      }
                      return p = {
                        mp3url: e,
                        bgurl: a.bgmusicurl,
                        bgdelaytime: r,
                        textdelaytime: u,
                        bgvolume: c,
                        lowervolume: h ? "1" : "0"
                      }, t.showLoading({
                        title: "背景音合成中...",
                        mask: !0
                      }), i.next = 6, (0, l.ttsMixBgMusicV2)(p).then(function (o) {
                        t.hideLoading(), o.model ? e = o.model.mp3url : (t.showToast({
                          title: "背景音乐合成失败",
                          icon: "none"
                        }), e = "");
                      });
                    case 6:
                      t.showLoading({
                        title: "保存中...",
                        mask: !0
                      }), d = "1" === o.user_message.userrich.isvalidvip || "1" === o.user_message.userrich.isvalidsvip ? "1" : "0", f = {
                        list: [{
                          wktype: "1",
                          wkname: o.workname,
                          musicpath: e,
                          headpath: o.anchor.zbcover,
                          voiceauthor: o.anchor.speakername,
                          speakercode: o.anchor.speakercode,
                          zbid: o.anchor.zbid,
                          speechrate: o.speed,
                          bgname: a.bgname,
                          bgmusic: a.bgmusicurl,
                          voicetext: o.text,
                          textvolume: o.volume,
                          bgvolume: c,
                          textdelaytime: u,
                          bgdelaytime: r,
                          intonation: o.pitch,
                          emotion: o.emotion.code,
                          emotiondegree: o.emotiondegree,
                          exttype: "2" === o.anchor.feature || "3" === o.anchor.feature ? "2" : d,
                          lyuan: o.lyuan
                        }]
                      }, console.log("保存作品信息", f), (0, l.crtWork)(f).then(function (e) {
                        "1" == o.lyuan ? o.$uma_wx.trackEvent("lyuan", "文案提取") : o.$uma_wx.trackEvent("lyuan", "正常文案");
                        var i = e.model[0].wkid;
                        o.workid = e.model[0].wkid, o.folderid && o.yidongzhi(), t.showToast({
                          title: "保存成功"
                        }), t.navigateTo({
                          url: "/pages/work/work_info?wkid=" + i
                        }), t.$emit("updateWork");
                      });
                    case 11:
                    case "end":
                      return i.stop();
                  }
                }, i);
              }))();
            },
            yidongzhi: function yidongzhi() {
              var t = {
                wkids: this.workid,
                folderid: this.folderid
              };
              (0, c.removeFile)(t).then(function (t) {
                t.rc = "0";
              });
            },
            disposeWords: function disposeWords() {
              var t = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
                e = this.text,
                o = "1" === this.user_message.userrich.isvalidsvip,
                i = "1" === this.user_message.userrich.isvalidvip,
                s = "1" === this.anchor.feature,
                n = "2" === this.anchor.feature,
                a = "3" === this.anchor.feature;
              this.text.length, this.text.replace(/\s*|\t|\r|\n/g, "").replace(/\[(\d+\.?\d*)秒]/g, "").replace(/#[a-z]+[1-5]#/g, "").replace(/#none#/g, "").length;
              return !o && s && this.length > 100 ? (e = t ? e.substring(t ? this.cursor : 0, 100) : e.substring(0, 100), this.is_show_vippopup = !0) : o || i || !(this.length > 100) || n || a ? e = e.substring(t ? this.cursor : 0, e.length) : (e = t ? e.substring(t ? this.cursor : 0, 100) : e.substring(0, 100), this.is_show_vippopup = !0), e || (e = this.disposeWords()), e;
            },
            recordAnchor: function recordAnchor() {
              var e = {
                volume: this.volume,
                speed: this.speed,
                pitch: this.pitch,
                zbid: this.anchor.zbid
              };
              "1" === this.anchor.isemotion && (e.emotion = this.emotion, e.emotiondegree = this.emotiondegree ? this.emotiondegree : ""), t.setStorageSync(this.anchor.zbid, e);
            },
            verifyTtsArg: function verifyTtsArg(e) {
              var o = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
              if ("" == this.text) return t.showToast({
                title: "请输入配音文字",
                icon: "none"
              }), !1;
              if (!this.anchor.zbid) return t.showToast({
                title: "主播信息异常",
                icon: "none"
              }), !1;
              if (o) {
                var i = this.text.substring(0, this.cursor).replace(/\s*|\t|\r|\n/g, "").replace(/\[(\d+\.?\d*)秒]/g, "").replace(/#[a-z]+[1-5]#/g, "").replace(/#none#/g, "").length;
                if (i > 100 && "0" === this.user_message.userrich.isvalidsvip && "1" === this.anchor.feature) return this.show_nonmember = !0, !1;
                if (i > 100 && "0" === this.user_message.userrich.isvalidsvip && "0" === this.user_message.userrich.isvalidvip) return this.show_nonmember = !0, !1;
              }
              return this.length > this.max_length && 8e3 === this.max_length ? (t.showModal({
                title: "提示",
                content: "配音文本字数不能超过".concat(this.max_length, "字"),
                success: function success(t) {
                  t.confirm;
                }
              }), !1) : this.length > this.max_length && 5e3 === this.max_length ? (t.showModal({
                title: "提示",
                content: "配音文本字数不能超过".concat(this.max_length, "字，开通超级会员可提升至8000字"),
                confirmText: "开通会员",
                success: function success(e) {
                  e.confirm && t.navigateTo({
                    url: "/pages3/vip?current=1"
                  });
                }
              }), !1) : !e || "1" !== this.anchor.feature || "0" !== this.user_message.userrich.isvalidsvip || (this.show_svippopup = !0, !1);
            },
            disposeTtsState: function disposeTtsState(e) {
              if (this.tts_rc = e.rc, "1904" === e.rc) return this.sensitive_word_show = !0, !1;
              if ("1901" === e.rc) {
                var o = {
                  10001: " 广告",
                  20001: "时政",
                  20002: "色情",
                  20003: "辱骂",
                  20006: "违法犯罪",
                  20008: "欺诈",
                  20012: "低俗",
                  20013: "版权",
                  21e3: "其他"
                };
                return this.sensitive_word_show = !0, this.sensitive_word_text = "文本内容包含".concat(o[e.rd] ? o[e.rd] : "", "相关违规文字信息，请修改后重新操作"), !1;
              }
              return "1701" === e.rc || "1707" === e.rc ? "3" == this.anchor.feature ? (t.showModal({
                title: "提示",
                content: "克隆主播字符剩余不足，是否前往购买？",
                confirmText: "购买字符",
                success: function success(e) {
                  e.confirm && t.navigateTo({
                    url: "/pages4/cloning_char"
                  });
                }
              }), !1) : (this.show_char = !0, !1) : "1705" === e.rc || "1706" === e.rc ? (this.show_frequency = !0, !1) : "1704" !== e.rc || (t.showModal({
                title: "提示",
                content: "文本异常，详情请联系客服",
                confirmText: "联系客服",
                success: function success(e) {
                  e.confirm && t.switchTab({
                    url: "/pages/mine/mine"
                  });
                }
              }), !1);
            },
            listeningTestPopup: function listeningTestPopup() {
              this.is_show_vippopup && (this.is_show_vippopup = !1, this.show_nonmember = !0);
            },
            inputChange: function inputChange(t) {
              this.text = t.detail.value;
            },
            reeditWork: function reeditWork(e) {
              var o = this;
              if (console.log("监听作品重新编辑", e), t.showLoading({
                title: "数据初始化中..."
              }), this.$store.commit("setAnchor", e.zbmsg), this.text = e.voicetext, e.emotion && this.anchor.emotion) {
                this.emotiondegree = Number(e.emotiondegree);
                var i = JSON.parse(this.anchor.emotion).filter(function (t) {
                  return t.code === e.emotion;
                });
                this.$store.commit("setEmotion", i[0]);
              }
              e.bgname && (this.$refs.bgmusic_obj.bgmusic = {
                bgmusicurl: e.bgmusic,
                bgname: e.bgname
              }, this.$refs.bgmusic_obj.bg_volume = Number(e.bgvolume), this.$refs.bgmusic_obj.continue_time = Number(e.bgdelaytime), this.$refs.bgmusic_obj.delay_time = Number(e.textdelaytime)), this.$nextTick(function () {
                o.speed = e.speechrate, o.volume = e.textvolume, o.pitch = e.intonation, t.hideLoading(), o.$uma_wx.trackEvent("copyWork");
              });
            },
            stopPlay: function stopPlay() {
              this.$refs.KeyboardTop.play_state ? (this.tts_audio.stopAllMusic(), this.is_cursor_flag && (this.keytop_palystatus = !1)) : this.tts_audio.pauseAllMusic(), this.jsst && (this.tts_audio.stopAllMusic(), this.is_cursor_flag && (this.keytop_palystatus = !1));
            },
            initLayout: function initLayout() {
              var e = t.getMenuButtonBoundingClientRect();
              this.$store.commit("setTitleInfo", e);
            },
            insertPause: function insertPause(e) {
              if (e > 10) t.showToast({
                title: "停顿最大值不能超过10s",
                icon: "none"
              });else if (e < .1) t.showToast({
                title: "停顿值不能小于等于0",
                icon: "none"
              });else {
                var o = void 0 !== this.cursor ? this.cursor : this.text.length,
                  i = "[" + e + "秒]",
                  s = this.text.substring(0, o),
                  n = this.text.substring(o);
                this.text = s + i + n, this.show_insert = !1;
              }
            },
            insertQuietness: function insertQuietness() {
              var t = this;
              setTimeout(function () {
                var e = t.text,
                  o = t.cursor ? t.cursor : e.length,
                  i = "#none#",
                  s = e.substring(0, o),
                  n = e.substring(o);
                t.text = s + i + n;
              }, 200);
            },
            textBlur: function textBlur(e) {
              this.cursor = e.detail.cursor, t.setStorageSync("tts_text", this.text);
            },
            textFocus: function textFocus(t) {
              this.is_focus = !0, this.$refs.KeyboardTop.tab = 0;
            },
            setTtsArguments: function setTtsArguments(t, e) {
              this[t] = e.detail.value, this.$uma_wx.trackEvent("resultInstall", t);
            },
            clearText: function clearText() {
              var e = this;
              this.text ? t.showModal({
                title: "提示",
                content: "是否清空文本？",
                success: function success(t) {
                  t.confirm && (e.text = "");
                }
              }) : t.showToast({
                title: "文本框内容已为空",
                icon: "none"
              });
            },
            setEmotion: function setEmotion(t) {
              this.stopPlay(), this.list_play.play(t.url), this.$store.commit("setEmotion", t);
            },
            changeAnchor: function changeAnchor() {
              this.is_focus = !1, t.navigateTo({
                url: "/pages/make/anchor"
              });
            },
            getAnchor: function getAnchor() {
              var e = this,
                o = function o(_o) {
                  t.getStorageSync("use_anchor") ? e.$store.commit("setAnchor", t.getStorageSync("use_anchor")) : e.$store.commit("setAnchor", _o);
                };
              (0, h.getdefaultAnchor)({}).then(function (t) {
                o(t.model.defaultTtszhuboList[0]);
              });
            },
            getPrivacySetting: function getPrivacySetting() {
              var t = this;
              i.getPrivacySetting({
                success: function success(e) {
                  e.needAuthorization ? t.$store.commit("setshowPrivacyYsxy", !0) : t.$store.commit("setshowPrivacyYsxy", !1);
                },
                fail: function fail() {},
                complete: function complete() {}
              });
            },
            login: function login(e) {
              var o = this,
                i = function i(t, e) {
                  o.$store.commit("setUserMessage", t.model), getApp().getShare(e), o.$uma_wx.trackEvent("equipment");
                };
              t.getStorageSync("sid") || t.getStorageSync("uid") ? getApp().getUserInfo(function (t) {
                i(t, e);
              }) : getApp().wxLogin(function (t) {
                i(t, e);
              });
            },
            jumpListeningTest: function jumpListeningTest() {
              var e = this,
                o = {
                  text: this.text,
                  zbid: this.anchor.zbid,
                  volume: this.volume,
                  speed: this.speed,
                  pitch: this.pitch,
                  emotion: this.emotion.code ? this.emotion.code : "",
                  emotiondegree: this.emotiondegree ? this.emotiondegree : ""
                };
              t.navigateTo({
                url: "/pages2/make/listening_test",
                events: {
                  setText: function setText(t) {
                    e.text = t;
                  }
                },
                success: function success(t) {
                  t.eventChannel.emit("setTtsObj", o);
                }
              });
            },
            jumpDuoYinZi: function jumpDuoYinZi() {
              var e = this;
              "1" === this.anchor.polyphonic ? (this.is_focus = !1, this.text ? (this.show_text = !1, getApp().globalData.tts_text = this.text, t.navigateTo({
                url: "/pages2/make/duoyinzi",
                events: {
                  setText: function setText(t) {
                    e.text = t;
                  }
                }
              })) : t.showToast({
                title: "配音文本为空",
                icon: "none"
              })) : t.showModal({
                title: "提示",
                content: "该主播不支持发音纠正！"
              });
            },
            jumpSensitiveWord: function jumpSensitiveWord() {
              var e = this;
              this.is_focus = !1, this.text ? (this.show_text = !1, getApp().globalData.tts_text = this.text, t.navigateTo({
                url: "/pages2/make/sensitive_word",
                events: {
                  setText: function setText(t) {
                    e.text = t;
                  }
                }
              })) : t.showToast({
                title: "配音文本为空",
                icon: "none"
              });
            },
            cancelSet: function cancelSet(t) {
              "pitch" === t ? (this.pitch = this.record_install.pitch, this.show_pitch = !1) : "speed" === t ? (this.speed = this.record_install.speed, this.show_speed = !1) : "emotion" === t && (this.emotiondegree = this.record_install.emotiondegree, this.$store.commit("setEmotion", this.record_install.emotion), this.show_emo = !1);
            },
            showEmo: function showEmo() {
              this.anchor.isemotion || this.anchor.langs ? this.show_emo = !0 : t.showToast({
                title: "该主播不支持情绪功能",
                icon: "none"
              });
            },
            clickPyq: function clickPyq() {
              t.showToast({
                title: "请前往小程序使用完整服务",
                icon: "none"
              });
            }
          }
        };
      e.default = $;
    }).call(this, o(2)["default"], o(1)["default"]);
  },
  370: function _(t, e, o) {
    "use strict";

    o.r(e);
    var i = o(371),
      s = o.n(i);
    for (var n in i) ["default"].indexOf(n) < 0 && function (t) {
      o.d(e, t, function () {
        return i[t];
      });
    }(n);
    e["default"] = s.a;
  },
  371: function _(t, e, o) {}
}, [[359, "common/runtime", "common/vendor"]]]);