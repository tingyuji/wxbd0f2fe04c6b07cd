(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["pages/make/anchor"], {
  228: function _(t, e, o) {
    "use strict";

    o.r(e);
    var a = o(229),
      n = o.n(a);
    for (var i in a) ["default"].indexOf(i) < 0 && function (t) {
      o.d(e, t, function () {
        return a[t];
      });
    }(i);
    e["default"] = n.a;
  },
  229: function _(t, e, o) {},
  27: function _(t, e, o) {
    "use strict";

    o.r(e);
    var a = o(28);
    for (var n in a) ["default"].indexOf(n) < 0 && function (t) {
      o.d(e, t, function () {
        return a[t];
      });
    }(n);
    o(228);
    var i,
      s,
      l,
      r,
      c = o(230),
      u = Object(c["default"])(a["default"], i, s, !1, null, null, null, !1, l, r);
    u.options.__file = "App.vue", e["default"] = u.exports;
  },
  28: function _(t, e, o) {
    "use strict";

    o.r(e);
    var a = o(29),
      n = o.n(a);
    for (var i in a) ["default"].indexOf(i) < 0 && function (t) {
      o.d(e, t, function () {
        return a[t];
      });
    }(i);
    e["default"] = n.a;
  },
  29: function _(t, e, o) {
    "use strict";

    (function (t, a) {
      var n = o(4);
      Object.defineProperty(e, "__esModule", {
        value: !0
      }), e.default = void 0;
      var i = n(o(13)),
        s = (n(o(30)), n(o(31))),
        l = n(o(225)),
        r = o(226),
        c = (o(227), {
          globalData: {
            baseApi: "https://pysq.shipook.com/v2base",
            appApi: "https://pysq.shipook.com/v2app",
            app_url: {},
            base_url: {
              getsmscode: "/common/getsmscode",
              login4wechat: "/thirdlogin/login4wechat",
              login4zjtd: "/thirdlogin/login4zjtd",
              login4baidu: "/thirdlogin/login4baidu",
              userlogin: "/user/userlogin",
              qryuserallinfo: "/user/qryuserallinfo",
              cashorder: "/business/cashorder",
              openvip: "/business/openvip",
              bootup: "/common/bootup",
              updatedeviceinfo: "/common/updatedeviceinfo",
              getbusupgradeinfo: "/busupgrade/getbusupgradeinfo",
              qryuserjbviplist: "/business/qryuserjbviplist"
            },
            tab_work: 0,
            qd: "",
            ver: "010009",
            sec: "48a0088cb506e6b7",
            aaa: "",
            bbb: "",
            deviceId: "",
            wxappid: "",
            userinfo: null,
            crgid: "",
            parentid: "",
            deviceMac: "",
            oaid: "",
            ss: "",
            showPay: !0,
            freetype: null,
            vipList: [],
            svip_char: {},
            ios_status: 1,
            tts_text: "",
            ishidetype: "",
            heimingdan0: "",
            heimingdan1: "",
            heimingdan2: "",
            systemInfo: null,
            timeInfo: 0
          },
          onLaunch: function onLaunch() {
            var e = this;
            this.$store.commit("setAppConfig", l.default), 1154 === t.getLaunchOptionsSync().scene && (a.setStorageSync("ispyq", !0), a.switchTab({
              url: "/pages/make/make?pyq=1"
            }));
            var o = t.getUpdateManager();
            o.onCheckForUpdate(function (t) {
              if (!t.hasUpdate) return !1;
              o.onUpdateReady(function () {
                o.applyUpdate();
              });
            }), a.setInnerAudioOption({
              obeyMuteSwitch: !1
            }), a.getSystemInfo({
              complete: function complete(t) {
                a.setStorageSync("device", t), e.globalData.systemInfo = t;
              }
            }), this.globalData.aaa = this.globalData.sec.split("").reverse().join(""), this.globalData.bbb = this.globalData.sec.substr(1) + this.globalData.sec.substr(0, 1), this.setQd(l.default.qd), this.getPhoneId(), this.start_Up();
          },
          onShow: function onShow() {
            (a.getStorageSync("sid") || a.getStorageSync("uid")) && this.getUserInfo(function (t) {});
          },
          onHide: function onHide() {},
          methods: {
            commonencry: function commonencry() {
              return JSON.stringify(s.default.getEncryption());
            },
            findpyblack: function findpyblack() {
              var t = this,
                e = t.globalData.appApi + "/peiyin/findpyblack";
              s.default.postRequest({}, e, function (e) {
                if (e.model) for (var o = e.model.split(","), a = 0; a < o.length; a++) "0" == o[a] ? (t.globalData.heimingdan0 = !0, t.$store ? t.$store.commit("setheimingdan0", t.globalData.heimingdan0) : t.$vm.$store.commit("setheimingdan0", t.globalData.heimingdan0)) : "1" == o[a] ? t.globalData.heimingdan1 = !0 : "2" == o[a] && (t.globalData.heimingdan2 = !0);
              });
            },
            examineText: function examineText(t, e) {
              var o = this;
              return new Promise(function (n, i) {
                var l = o.globalData.appApi + "/security/green/text";
                s.default.postRequest({
                  text: t
                }, l, function (t) {
                  console.log("文本检查结果", t), "0" !== t.rc && n(!0);
                  var o = {
                    10001: " 广告",
                    20001: "时政",
                    20002: "色情",
                    20003: "辱骂",
                    20006: "违法犯罪",
                    20008: "欺诈",
                    20012: "低俗",
                    20013: "版权",
                    21e3: "其他"
                  };
                  o[t.model.label] ? (a.showModal({
                    title: "提示",
                    content: "文本内容包含".concat(o[t.model.label] ? o[t.model.label] : "", "相关违规文字信息，请修改后重新操作"),
                    cancelText: "联系客服",
                    success: function success(t) {
                      t.confirm ? e && e() : t.cancel && a.navigateTo({
                        url: "/pages/wode/kefu/kefu"
                      });
                    }
                  }), n(!1)) : n(!0);
                });
              });
            },
            examineImg: function examineImg(t, e) {
              var o = this;
              return new Promise(function (n, i) {
                var l = o.globalData.appApi + "/peiyin/wxurllink/examinewximg",
                  r = {
                    url: t
                  };
                s.default.postRequest(r, l, function (t) {
                  "0" !== t.rc && n(!0), console.log("图片检查结果", t);
                  var o = JSON.parse(t.model),
                    i = o.errcode;
                  0 !== i && a.showModal({
                    title: "提示",
                    content: "该图片存在敏感信息，暂无法使用，如有疑问，请联系客服处理",
                    cancelText: "联系客服",
                    success: function success(t) {
                      t.confirm ? e && e() : t.cancel && a.switchTab({
                        url: "/pages/mine/mine"
                      });
                    }
                  }), n(0 === i);
                });
              });
            },
            isShowPay: function isShowPay() {
              var t = a.getStorageSync("device").platform;
              return "ios" !== t && "devtools" != t;
            },
            downMp4ForAlbum: function downMp4ForAlbum(t) {
              console.log("导出MP4", t), a.downloadFile({
                url: t,
                success: function success(t) {
                  console.log("res", t), 200 === t.statusCode && (a.hideLoading(), a.saveVideoToPhotosAlbum({
                    filePath: t.tempFilePath,
                    success: function success() {
                      a.showModal({
                        title: "导出成功",
                        content: "前往相册查看"
                      });
                    }
                  }));
                }
              });
            },
            qryApiLimit: function qryApiLimit(t) {
              var e = this;
              return new Promise(function (o, a) {
                var n = {
                    apiType: t,
                    isVip: e.globalData.userinfo.userrich.isvalidvip
                  },
                  i = e.globalData.appApi + "/peiyin/qryapilimitapp";
                console.log("json", n), console.log("url", i), s.default.postRequest(n, i, function (t) {
                  console.log("api剩余次数", t), o(t);
                });
              });
            },
            updateApiLimit: function updateApiLimit(t) {
              var e = {
                  apiType: t,
                  isVip: this.globalData.userinfo.userrich.isvalidvip
                },
                o = this.globalData.appApi + "/peiyin/uptapilimitapp";
              s.default.postRequest(e, o, function (t) {
                console.log("api更新次数", t);
              });
            },
            setOssPath: function setOssPath(t, e, o) {
              a.uploadFile({
                url: this.globalData.appApi + "/peiyin/music/univerupload",
                filePath: t,
                name: "file",
                formData: {
                  isrestrict: "0",
                  catalogue: e,
                  osstype: "1",
                  comparam: getApp().commonencry()
                },
                success: function success(t) {
                  console.log("上传本地文件到oss", t), o(JSON.parse(t.data).model);
                },
                fail: function fail(t) {
                  a.showToast({
                    title: "图片上传失败！",
                    icon: "none"
                  }), o("fail");
                }
              });
            },
            generatePoster: function generatePoster(t) {
              var e = {
                req: JSON.stringify({
                  qd: this.globalData.qd,
                  ver: this.globalData.ver,
                  sceneStr: this.globalData.userinfo.userinfo.id,
                  page: "pages/make/make"
                })
              };
              console.log("生成分享二维码", e);
              var o = this.globalData.appApi + "/wxgetqrcode";
              a.request({
                url: o,
                method: "POST",
                header: {
                  "content-type": "application/x-www-form-urlencoded",
                  cookie: "SESSION=" + (a.getStorageSync("sid") ? a.getStorageSync("sid") : "")
                },
                data: e,
                success: function success(e) {
                  t(e);
                }
              });
            },
            getShare: function getShare(t) {
              var e = this;
              (t.parentid || t.scene) && setTimeout(function () {
                var o = t.parentid;
                if (t.scene && (o = decodeURIComponent(t.scene)), o) {
                  e.globalData.parentid = o;
                  var n = {
                      parentid: o
                    },
                    i = getApp().globalData.baseApi + "/user/bindparent";
                  s.default.postRequest(n, i, function (t) {
                    console.log("分享绑定", t), a.showToast({
                      title: "绑定上级成功",
                      icon: "none",
                      duration: 2e3
                    }), getApp().getUserInfo(function (t) {});
                  }, function (t) {
                    if (console.log("绑定失败aaaa", t), "1501" == t.rc) a.showToast({
                      title: "您已绑定过上级，不可再次绑定",
                      icon: "none",
                      duration: 2e3
                    });else {
                      var e = t.rd;
                      a.showToast({
                        title: e,
                        icon: "none",
                        duration: 2e3
                      });
                    }
                  });
                }
              }, 1e3);
            },
            getbdKF: function getbdKF() {
              l.default.kfurl && t.openCustomerServiceChat({
                extInfo: {
                  url: l.default.kfurl
                },
                corpId: l.default.kfcorpId,
                showMessageCard: !0,
                sendMessageTitle: "请稍等，客服马上就到(" + this.globalData.userinfo.userinfo.id + ")",
                sendMessageImg: "https://pysqstoss.shipook.com/imgs/20220117/202306011h.png"
              });
            },
            copyObj: function copyObj(t) {
              var e = null;
              if ("object" == (0, i.default)(t) && null !== t) for (var o in e = t instanceof Array ? [] : {}, t) e[o] = this.copyObj(t[o]);else e = t;
              return e;
            },
            getLocation: function getLocation(t) {
              a.getLocation({
                type: "gcj02",
                success: function success(e) {
                  var o = e.latitude,
                    a = e.longitude;
                  console.log(e);
                  var n = {
                      lng: a,
                      lat: o
                    },
                    i = getApp().globalData.baseApi + "/common/getprovince";
                  s.default.postRequest(n, i, function (e) {
                    console.log("通过经纬度获取地址", e), t(e);
                  });
                },
                fail: function fail(e) {
                  t("fail"), a.showToast({
                    title: "获取位置信息失败！",
                    icon: "none"
                  }), console.log("获取位置失败", e);
                }
              });
            },
            setUserInfo: function setUserInfo(t, e) {
              console.log("用户信息2222", t), l.default.free && (t.model.userrich.isvalidsvip = "1"), a.setStorageSync("uid", t.model.userinfo.uid), a.setStorageSync("did", t.model.userinfo.did), this.$store ? this.$store.commit("setUserMessage", t.model) : this.$vm.$store.commit("setUserMessage", t.model), getApp().globalData.userinfo = t.model, e(t);
            },
            wxLogin: function wxLogin(t) {
              a.login({
                provider: "weixin",
                success: function success(e) {
                  var o = {
                      isbind: "0",
                      code: e.code
                    },
                    n = getApp().globalData.baseApi + getApp().globalData.base_url.login4wechat,
                    i = function i(e) {
                      a.setStorageSync("sid", e.model.userinfo.sid), getApp().setUserInfo(e, t);
                    };
                  s.default.postRequest(o, n, i);
                }
              });
            },
            disposeNewUser: function disposeNewUser(t, e) {
              var o = this,
                n = new Date(t.ctime).getTime(),
                i = new Date().getTime(),
                l = i - n,
                r = 6048e5;
              "用户" === t.nickname && l <= r && a.showModal({
                title: "提示",
                content: "需要获取您的微信昵称与头像用于完善资料显示，是否同意获取？",
                success: function success(t) {
                  t.confirm && a.getUserProfile({
                    desc: "用于完善资料显示",
                    success: function success(t) {
                      var a = {
                          nickname: t.userInfo.nickName,
                          avatar: t.userInfo.avatarUrl
                        },
                        n = o.globalData.baseApi + "/user/updateuserinfo";
                      s.default.postRequest(a, n, function (t) {
                        e && e();
                      });
                    }
                  });
                }
              });
            },
            getUserInfo: function getUserInfo(t) {
              var e = this,
                o = this.globalData.baseApi + this.globalData.base_url.qryuserallinfo;
              s.default.postRequest({}, o, function (o) {
                console.log("获取用户信息", o), e.setUserInfo(o, t);
              });
            },
            getPay: function getPay(t, e, o, n, i, l, r) {
              a.showLoading({
                title: "加载中",
                mask: !0
              });
              var c = this,
                u = 10 * Number(o).toFixed(2),
                p = {
                  crgtype: 2,
                  paytype: t,
                  ordername: e,
                  jb: u,
                  rmb: o,
                  orderid: i,
                  ordertype: n,
                  extdata: l,
                  ish5: 3
                };
              console.log(p);
              var g = this.globalData.baseApi + this.globalData.base_url.cashorder;
              this.globalData.crgid = "";
              var f = function f(e) {
                c.callPay(t, e, r);
              };
              s.default.postRequest(p, g, f);
            },
            getVip: function getVip(t, e, o, n, i, l) {
              a.showLoading({
                title: "加载中",
                mask: !0
              });
              var r = this,
                c = {
                  viptype: t,
                  sviptype: e,
                  paytype: o,
                  time: n,
                  extdata: i,
                  ish5: 3
                };
              console.log("开通会员", c);
              var u = this.globalData.baseApi + this.globalData.base_url.openvip,
                p = function p(t) {
                  r.callPay(o, t, l);
                };
              s.default.postRequest(c, u, p);
            },
            callPay: function callPay(t, e, o) {
              2 == t && e.model.orderparams4webchat ? this.wxPayForMp(e, o) : 1 == t && e.model.orderstr4alipay;
            },
            wxPayForApp: function wxPayForApp(t, e) {
              var o = this;
              a.requestPayment({
                provider: "wxpay",
                orderInfo: t.model.orderparams4webchat,
                success: function success(t) {
                  o.getUserInfo(), a.hideLoading(), e(t);
                },
                fail: function fail(t) {
                  a.hideLoading(), a.showToast({
                    title: "支付失败",
                    icon: "none"
                  });
                }
              });
            },
            wxPayForMp: function wxPayForMp(t, e) {
              var o = this;
              a.requestPayment({
                provider: "wxpay",
                timeStamp: t.model.orderparams4webchat.timestamp,
                nonceStr: t.model.orderparams4webchat.noncestr,
                package: "prepay_id=" + t.model.orderparams4webchat.prepayid,
                signType: "MD5",
                paySign: t.model.orderparams4webchat.sign,
                success: function success(t) {
                  o.getUserInfo(), a.hideLoading(), e(t);
                },
                fail: function fail(t) {
                  a.hideLoading();
                }
              });
            },
            aliPayForApp: function aliPayForApp(t, e) {
              var o = this;
              a.requestPayment({
                provider: "alipay",
                orderInfo: t.model.orderstr4alipay,
                success: function success(t) {
                  o.getUserInfo(), a.hideLoading(), e(t);
                },
                fail: function fail(t) {
                  a.hideLoading(), a.showToast({
                    title: "支付失败",
                    icon: "none"
                  });
                }
              });
            },
            zjPayForMp: function zjPayForMp(t, e) {},
            setQd: function setQd(t) {
              var e = "";
              e = this.globalData.systemInfo ? this.globalData.systemInfo.platform : a.getSystemInfoSync().platform, console.log("bradn", e), this.globalData.qd = "ios" == e || "devtools1" == e ? "2" + t.slice(1) : t, console.log("渠道号", this.globalData.qd);
            },
            start_Up: function start_Up() {
              var t,
                e = this,
                o = new Date().toLocaleDateString();
              t = a.getStorageSync("active") ? a.getStorageSync("active") == o ? "0" : "2" : "1";
              var n = {
                  active: t
                },
                i = e.globalData.baseApi + e.globalData.base_url.bootup;
              s.default.postRequest(n, i, function (t) {
                console.log("合肥阅舟科技-设备启动信息", t), e.globalData.appcfg = t.model.appcfg ? JSON.parse(t.model.appcfg) : {}, e.globalData.freetype = t.model.appcfg ? JSON.parse(t.model.appcfg).freetype : "0", e.globalData.svip_char = e.globalData.appcfg.svip_char, e.globalData.vipList = t.model.jbviplist, e.globalData.zifubao = JSON.parse(t.model.appcfg).zifubao, t.model.appcfg && (JSON.parse(t.model.appcfg).iospay ? e.globalData.iospay = JSON.parse(t.model.appcfg).iospay : e.globalData.iospay = 1, JSON.parse(t.model.appcfg).hideiospay ? e.globalData.hideiospay = JSON.parse(t.model.appcfg).hideiospay : e.globalData.hideiospay = 1), e.hidearea(), e.findpyblack(), a.setStorageSync("active", o);
              });
              var l = e.globalData.baseApi + "/business/qujbl";
              s.default.postRequest({}, l, function (t) {
                console.log("获取配置信息", t), e.globalData.isexamine = "1" === t.model.isexm, e.globalData.iswcp = t.model.iswcp, a.$emit("qryttscfg");
              });
            },
            hidearea: function hidearea() {
              var t = this,
                e = {
                  functype: "0"
                },
                o = t.globalData.baseApi + "/business/qryshieldfunc";
              s.default.postRequest(e, o, function (e) {
                var o;
                console.log("屏蔽地区", e), o = "0" == e.rc && e.model.iospay ? e.model.iospay : "1", t.globalData.ishidetype = o, t.globalData.ios_status = "1" == o ? t.globalData.hideiospay : "0" == o ? t.globalData.iospay : 1;
              });
            },
            getPhoneId: function getPhoneId() {},
            getStorageFun: function getStorageFun(t, e) {
              var o = new Date().toLocaleDateString();
              if (!a.getStorageSync(t)) return a.setStorageSync(t, o), void e();
              a.getStorageSync(t) != o && (a.setStorageSync(t, o), a.removeStorageSync("bgmusic"), e());
            },
            showLoginToast: function showLoginToast() {
              a.showModal({
                title: "登录提示",
                content: "您当前未登录，请先去登录",
                cancelText: "取消",
                confirmText: "登录",
                showCancel: !0,
                success: function success(t) {
                  t.confirm && getApp().relogin();
                }
              });
            },
            relogin: function relogin() {
              var t = this,
                e = function e(_e) {
                  t.$vm.$store.commit("setIsunlogin", !1), t.$vm.$store.commit("setUserMessage", _e.model), a.showToast({
                    title: "登录成功"
                  });
                };
              getApp().wxLogin(function (t) {
                e(t);
              });
            },
            prosssCirculation: function prosssCirculation(t, e) {
              var o = {
                asyncId: t
              };
              getApp().globalData.timeInfo = setInterval(function () {
                var t = getApp().globalData.appApi + "/peiyin/asyncProcess/selectProcess";
                s.default.postRequest(o, t, function (t) {
                  "0" === t.rc ? "2" == t.model.processState ? (getApp().stoptimerinfo(), e && (e({
                    type: "1",
                    result: t.model
                  }), a.hideLoading({}))) : "1" == t.model.processState && (getApp().stoptimerinfo(), e && e({
                    type: "0",
                    result: t.model.failDesc
                  }), a.hideLoading({})) : (getApp().stoptimerinfo(), e && e({
                    type: "0",
                    result: t.rd
                  }), a.hideLoading({}));
                }, function (t) {
                  getApp().stoptimerinfo(), e && e({
                    type: "0",
                    result: "操作失败"
                  }), a.hideLoading({});
                });
              }, 3e3);
            },
            stoptimerinfo: function stoptimerinfo() {
              getApp().globalData.timeInfo && (clearInterval(getApp().globalData.timeInfo), getApp().globalData.timeInfo = 0);
            },
            getProcessId: function getProcessId(t, e, o) {
              (0, r.getProcess)(t, e).then(function (t) {
                if ("0" === t.rc) {
                  var e = t.model;
                  getApp().globalData.timeInfo && getApp().stoptimerinfo(), getApp().prosssCirculation(e, o);
                }
              }).catch(function (t) {
                console.log(t);
              });
            }
          },
          mounted: function mounted() {}
        });
      e.default = c;
    }).call(this, o(1)["default"], o(2)["default"]);
  },
  389: function _(t, e, o) {
    "use strict";

    (function (t, e) {
      var a = o(4);
      o(26);
      a(o(25));
      var n = a(o(390));
      t.__webpack_require_UNI_MP_PLUGIN__ = o, e(n.default);
    }).call(this, o(1)["default"], o(2)["createPage"]);
  },
  390: function _(t, e, o) {
    "use strict";

    o.r(e);
    var a = o(391),
      n = o(393);
    for (var i in n) ["default"].indexOf(i) < 0 && function (t) {
      o.d(e, t, function () {
        return n[t];
      });
    }(i);
    o(396);
    var s,
      l = o(230),
      r = Object(l["default"])(n["default"], a["render"], a["staticRenderFns"], !1, null, null, null, !1, a["components"], s);
    r.options.__file = "pages/make/anchor.vue", e["default"] = r.exports;
  },
  391: function _(t, e, o) {
    "use strict";

    o.r(e);
    var a = o(392);
    o.d(e, "render", function () {
      return a["render"];
    }), o.d(e, "staticRenderFns", function () {
      return a["staticRenderFns"];
    }), o.d(e, "recyclableRender", function () {
      return a["recyclableRender"];
    }), o.d(e, "components", function () {
      return a["components"];
    });
  },
  392: function _(t, e, o) {
    "use strict";

    var a;
    o.r(e), o.d(e, "render", function () {
      return n;
    }), o.d(e, "staticRenderFns", function () {
      return s;
    }), o.d(e, "recyclableRender", function () {
      return i;
    }), o.d(e, "components", function () {
      return a;
    });
    try {
      a = {
        uLoadmore: function uLoadmore() {
          return Promise.all([o.e("common/vendor"), o.e("uni_modules/uview-ui/components/u-loadmore/u-loadmore")]).then(o.bind(null, 1222));
        }
      };
    } catch (l) {
      if (-1 === l.message.indexOf("Cannot find module") || -1 === l.message.indexOf(".vue")) throw l;
      console.error(l.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
    }
    var n = function n() {
        var t = this,
          e = t.$createElement,
          o = (t._self._c, t.collectionList.length),
          a = t.list.length,
          n = a ? t.__map(t.list, function (e, o) {
            var a = t.__get_orig(e),
              n = t.myKey(e),
              i = t.shoucangbiaozhi(e.zbid);
            return {
              $orig: a,
              m0: n,
              m1: i
            };
          }) : null,
          i = a ? t.list.length : null,
          s = 0 == t.list.length && -3 == t.tab;
        t.$mp.data = Object.assign({}, {
          $root: {
            g0: o,
            g1: a,
            l0: n,
            g2: i,
            g3: s
          }
        });
      },
      i = !1,
      s = [];
    n._withStripped = !0;
  },
  393: function _(t, e, o) {
    "use strict";

    o.r(e);
    var a = o(394),
      n = o.n(a);
    for (var i in a) ["default"].indexOf(i) < 0 && function (t) {
      o.d(e, t, function () {
        return a[t];
      });
    }(i);
    e["default"] = n.a;
  },
  394: function _(t, e, o) {
    "use strict";

    (function (t) {
      var a = o(4);
      Object.defineProperty(e, "__esModule", {
        value: !0
      }), e.default = void 0;
      var n = a(o(255)),
        i = a(o(18)),
        s = a(o(257)),
        l = a(o(11)),
        r = o(227),
        c = o(366),
        u = o(395),
        p = a(o(369));
      function g(t, e) {
        var o = Object.keys(t);
        if (Object.getOwnPropertySymbols) {
          var a = Object.getOwnPropertySymbols(t);
          e && (a = a.filter(function (e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
          })), o.push.apply(o, a);
        }
        return o;
      }
      function f(t) {
        for (var e = 1; e < arguments.length; e++) {
          var o = null != arguments[e] ? arguments[e] : {};
          e % 2 ? g(Object(o), !0).forEach(function (e) {
            (0, l.default)(t, e, o[e]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(o)) : g(Object(o)).forEach(function (e) {
            Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(o, e));
          });
        }
        return t;
      }
      var d = function d() {
          o.e("components/make/anchorLi").then(function () {
            return resolve(o(1230));
          }.bind(null, o)).catch(o.oe);
        },
        h = {
          components: {
            anchorLi: d
          },
          data: function data() {
            return {
              mypageZb: "",
              list_play: new p.default(),
              tab: 0,
              list: [],
              tab_list: [],
              scroll_top: 0,
              page: 0,
              rows: 20,
              lastPage: !1,
              anchorLiIndex: "",
              collectionList: [],
              collection_zbid: [],
              scrolly: !0,
              triggered: !1,
              cloningZbList: [],
              scrollLeft: 0,
              moveParams: {
                scrollLeft: 0,
                screenHalfWidth: null
              },
              tabLiIndex: "",
              cloningList: [{
                title: "精品定制",
                icon: "/static/images/make/cl_jpdz.svg"
              }, {
                title: "高度还原",
                icon: "/static/images/make/cl_gdhy.svg"
              }, {
                title: "稳定配音",
                icon: "/static/images/make/cl_wdpy.svg"
              }, {
                title: "极速克隆",
                icon: "/static/images/make/cl_jskl.svg"
              }]
            };
          },
          filters: {
            subFristTitle: function subFristTitle(t) {
              if (!t.feature || "2" === t.feature && "0" === t.issvipzb) return "普通";
              if ("1" === t.feature || "2" === t.feature && "1" === t.issvipzb) {
                if (t.emotion) {
                  var e = JSON.parse(t.emotion).length;
                  return "超级·" + e + "情绪";
                }
                return "超级";
              }
            }
          },
          computed: f({}, (0, r.mapState)(["app_config", "anchor"])),
          onLoad: function onLoad() {
            this.beforeCollect(), this.getZbType("once");
          },
          onHide: function onHide() {
            this.list_play.stop();
          },
          onUnload: function onUnload() {
            this.list_play.stop();
          },
          onShow: function onShow() {
            this.collectancorList();
          },
          created: function created() {
            var e = this;
            t.getSystemInfo({
              success: function success(t) {
                e.moveParams.screenHalfWidth = t.screenWidth / 2;
              }
            });
          },
          methods: {
            gotoCloning: function gotoCloning() {
              t.navigateTo({
                url: "/pages4/soundCloning"
              });
            },
            qryTtsTrain: function qryTtsTrain(t) {
              var e = this;
              (0, u.qryttstrain)().then(function (o) {
                e.cloningZbList = [], o.model && o.model.length && o.model.forEach(function (t) {
                  "4" != t.resstatus && "5" != t.resstatus || e.cloningZbList.push(t);
                }), e.list = getApp().copyObj(e.cloningZbList), "cloningOnce" == t && e.$nextTick(function () {
                  var t = e.anchor.zbid;
                  t && (e.anchorLiIndex = "anchorLi" + t, console.log("定位主播", e.anchorLiIndex), t = null);
                });
              });
            },
            useAnchor: function useAnchor(t) {
              this.list_play.stop(), this.selectAnchor(t.zbdetail, t.myEmotion);
            },
            playEmotion: function playEmotion(t) {
              this.list_play.play(t);
            },
            stopEmotion: function stopEmotion() {
              this.list_play.stop();
            },
            myKey: function myKey(t) {
              var e = t.zbid + this.tab;
              return e;
            },
            submit: function submit() {
              t.navigateTo({
                url: "/pages2/make/submit_zb"
              });
            },
            jumppage: function jumppage() {
              t.navigateTo({
                url: "/pages2/make/search"
              });
            },
            beforeCollect: function beforeCollect() {
              var e = this,
                o = t.getStorageSync("collectanchor-yz");
              o && o.length > 0 ? (this.collectionList = o, this.collectionList.forEach(function (t) {
                e.collection_zbid.push(t.zbid);
              }), -1 == this.tab && (this.list = this.collectionList)) : this.collectancorList();
            },
            shoucangbiaozhi: function shoucangbiaozhi(t) {
              return !this.collection_zbid.includes(t);
            },
            collectAnchor: function collectAnchor(e) {
              var o = this;
              (0, c.zbcollect)({
                zbid: e.zbid
              }).then(function () {
                var e = (0, s.default)(n.default.mark(function e(a) {
                  var i, s;
                  return n.default.wrap(function (e) {
                    while (1) switch (e.prev = e.next) {
                      case 0:
                        if (i = a.rc, "0" != i) {
                          e.next = 18;
                          break;
                        }
                        if (s = a.model, "0" != s) {
                          e.next = 9;
                          break;
                        }
                        return e.next = 6, o.collectancorList();
                      case 6:
                        t.showToast({
                          title: "收藏成功"
                        }), e.next = 18;
                        break;
                      case 9:
                        if ("1" != s) {
                          e.next = 17;
                          break;
                        }
                        return e.next = 12, o.collectancorList();
                      case 12:
                        t.showToast({
                          title: "取消收藏成功"
                        }), -1 == o.tab && (o.list = o.collectionList), 0 == o.collection_zbid.length && o.setTab(0), e.next = 18;
                        break;
                      case 17:
                        t.showToast({
                          title: "收藏失败"
                        });
                      case 18:
                      case "end":
                        return e.stop();
                    }
                  }, e);
                }));
                return function (t) {
                  return e.apply(this, arguments);
                };
              }());
            },
            collectancorList: function collectancorList() {
              var e = this;
              return (0, s.default)(n.default.mark(function o() {
                return n.default.wrap(function (o) {
                  while (1) switch (o.prev = o.next) {
                    case 0:
                      return o.next = 2, (0, c.zbcollectlist)({}).then(function (o) {
                        var a = o.rc;
                        if ("0" == a) {
                          var n = o.model;
                          t.setStorageSync("collectanchor-yz", n), e.collectionList = n, e.collection_zbid = [], e.collectionList.forEach(function (t) {
                            e.collection_zbid.push(t.zbid);
                          }), -1 == e.tab && (e.list = e.collectionList);
                        }
                      });
                    case 2:
                    case "end":
                      return o.stop();
                  }
                }, o);
              }))();
            },
            selectAnchor: function selectAnchor(e) {
              var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
              if (console.log("选择最后的主播", e), getApp().globalData.record_info = {
                tab: this.tab,
                scroll: this.record_scroll
              }, "dialogue" === getApp().globalData.selectAnchorType) return getApp().globalData.selectAnchorType = "", void this.setDialogue(e, o);
              if ("edit_dialogue" === getApp().globalData.selectAnchorType) return getApp().globalData.selectAnchorType = "", void this.setMsg(e, o);
              if (o) this.$store.commit("setEmotion", o);else if (!o && e.emotion) {
                var a = JSON.parse(e.emotion),
                  n = a[0];
                this.$store.commit("setEmotion", n);
              }
              this.tab_list[this.tab] && this.tab_list[this.tab].cattype ? e.tabcattype = this.tab_list[this.tab].cattype : -1 == this.tab ? e.tabcattype = "-1" : -3 == this.tab && (e.tabcattype = "-3"), this.$store.commit("setAnchor", e), t.switchTab({
                url: "/pages/make/make"
              }), t.setStorageSync("use_anchor", e);
              var i = t.getStorageSync(e.zbid);
              i.zbid == e.zbid && (i.emotion = o, t.setStorageSync(e.zbid, i));
            },
            setDialogue: function setDialogue(e) {
              var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
              o ? t.$emit("setAnchor", {
                anchor: e,
                emotion: o
              }) : t.$emit("setAnchor", {
                anchor: e,
                emotion: e.emotion ? JSON.parse(e.emotion)[0] : ""
              }), t.navigateBack();
            },
            setMsg: function setMsg(e) {
              var o = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : null;
              o ? t.$emit("setMsgAnchor", {
                anchor: e,
                emotion: o
              }) : t.$emit("setMsgAnchor", {
                anchor: e,
                emotion: e.emotion ? JSON.parse(e.emotion)[0] : ""
              }), t.navigateBack();
            },
            huitan: function huitan() {
              var e = this;
              this.triggered = !0, setTimeout(function () {
                e.triggered = !1;
              }, 100), t.showToast({
                title: "已到达顶部",
                icon: "none"
              });
            },
            loadAnchor: function loadAnchor(t, e) {
              var o = this,
                a = this;
              if (-1 == a.tab || -3 == a.tab) return this.triggered = !0, void setTimeout(function () {
                o.triggered = !1;
              }, 100);
              if ("top" == t) {
                if (0 == a.tab_list[a.tab].pageflag.lastpage) return void a.huitan();
                a.scrolly = !1, a.triggered = !0, a.getAnchor(a.tab, !1, !0);
              } else if ("bottom" == t) {
                if (-1 == a.tab_list[a.tab].pageflag.nextpage) return;
                a.getAnchor(a.tab, !0, !1);
              }
            },
            setTab: function setTab(e) {
              var o = this,
                a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "no",
                n = this;
              -1 == e ? this.$uma_wx.trackEvent("zbCategory", "收藏") : -3 == e ? this.$uma_wx.trackEvent("zbCategory", "克隆") : this.$uma_wx.trackEvent("zbCategory", this.tab_list[e].catname), this.tab = e, -1 == e ? (this.list = getApp().copyObj(this.collectionList), "collectOnce" == a && this.$nextTick(function () {
                var t = o.anchor.zbid;
                t && (o.anchorLiIndex = "anchorLi" + t, console.log("定位主播", o.anchorLiIndex), t = null);
              })) : -3 == e ? this.qryTtsTrain(a) : this.getAnchor(e, !1, !1);
              var i = "#ele" + e;
              t.createSelectorQuery().in(this).select(i).boundingClientRect(function (t) {
                if (t) {
                  var e = t.left - n.moveParams.screenHalfWidth + t.width / 2;
                  n.scrollLeft = n.moveParams.scrollLeft + e;
                }
              }).exec();
            },
            scrollMove: function scrollMove(t) {
              this.moveParams.scrollLeft = t.detail.scrollLeft;
            },
            getZbType: function getZbType(t) {
              var e = this;
              (0, c.qryzbtype)({}).then(function (o) {
                if (e.tab_list = o.model, e.tab_list.forEach(function (t) {
                  t.pageflag = {
                    lastpage: 0,
                    nextpage: 1
                  }, t.zblist = [];
                }), "once" == t) {
                  if ("-1" == e.anchor.tabcattype) return void e.setTab(-1, "collectOnce");
                  if ("-3" == e.anchor.tabcattype) return void e.setTab(-3, "cloningOnce");
                  e.getAnchor("shouye", !1, !1);
                }
              });
            },
            getAnchor: function getAnchor(e, o, a) {
              var n = this,
                s = this,
                l = this.tab_list[this.tab].cattype,
                r = {
                  rows: 20,
                  cattype: l
                };
              "shouye" != e ? r.page = o ? s.tab_list[e].pageflag.nextpage : a ? s.tab_list[e].pageflag.lastpage : 1 : "dialogue" === getApp().globalData.selectAnchorType ? r.page = 1 : (s.anchor && s.anchor.tabcattype && (r.cattype = s.anchor.tabcattype), r.page = 1, s.anchor && s.anchor.zbid && (r.zbid = s.anchor.zbid)), (0, c.qrymakeanchor)(r).then(function (l) {
                var r, c;
                if (l.model.cattype) {
                  var u = s.tab_list.findIndex(function (t) {
                    return t.cattype == l.model.cattype;
                  });
                  s.tab = u;
                }
                if (o) s.tab_list[s.tab].pageflag.nextpage = l.model.page.lastPage ? -1 : s.tab_list[s.tab].pageflag.nextpage + 1, (c = s.tab_list[s.tab].zblist).push.apply(c, (0, i.default)(l.model.page.list));else if (a) {
                  var p;
                  s.tab_list[s.tab].pageflag.lastpage = s.tab_list[s.tab].pageflag.lastpage - 1, (p = s.tab_list[s.tab].zblist).unshift.apply(p, (0, i.default)(l.model.page.list)), s.scrolly = !0, r = s.tab_list[s.tab].zblist[19].zbid;
                } else {
                  var g;
                  s.tab_list[s.tab].zblist = [], s.tab_list[s.tab].pageflag.lastpage = l.model.page.firstPage ? 0 : l.model.page.curpage - 1, s.tab_list[s.tab].pageflag.nextpage = l.model.page.lastPage ? -1 : l.model.page.curpage + 1, "shouye" == e && "dialogue" != getApp().globalData.selectAnchorType && (r = s.anchor.zbid), (g = s.tab_list[s.tab].zblist).push.apply(g, (0, i.default)(l.model.page.list));
                }
                s.triggered = !1, s.list = s.tab_list[s.tab].zblist, n.$nextTick(function () {
                  t.hideLoading(), r && (s.anchorLiIndex = "anchorLi" + r, s.tabLiIndex = "ele" + s.tab, r = null);
                });
              });
            }
          }
        };
      e.default = h;
    }).call(this, o(2)["default"]);
  },
  396: function _(t, e, o) {
    "use strict";

    o.r(e);
    var a = o(397),
      n = o.n(a);
    for (var i in a) ["default"].indexOf(i) < 0 && function (t) {
      o.d(e, t, function () {
        return a[t];
      });
    }(i);
    e["default"] = n.a;
  },
  397: function _(t, e, o) {}
}, [[389, "common/runtime", "common/vendor"]]]);