(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["components/make/keyboard_top"], {
  1193: function _(t, e, n) {
    "use strict";

    n.r(e);
    var i = n(1194),
      o = n(1196);
    for (var r in o) ["default"].indexOf(r) < 0 && function (t) {
      n.d(e, t, function () {
        return o[t];
      });
    }(r);
    n(1198);
    var u,
      s = n(230),
      a = Object(s["default"])(o["default"], i["render"], i["staticRenderFns"], !1, null, null, null, !1, i["components"], u);
    a.options.__file = "components/make/keyboard_top.vue", e["default"] = a.exports;
  },
  1194: function _(t, e, n) {
    "use strict";

    n.r(e);
    var i = n(1195);
    n.d(e, "render", function () {
      return i["render"];
    }), n.d(e, "staticRenderFns", function () {
      return i["staticRenderFns"];
    }), n.d(e, "recyclableRender", function () {
      return i["recyclableRender"];
    }), n.d(e, "components", function () {
      return i["components"];
    });
  },
  1195: function _(t, e, n) {
    "use strict";

    var i;
    n.r(e), n.d(e, "render", function () {
      return o;
    }), n.d(e, "staticRenderFns", function () {
      return u;
    }), n.d(e, "recyclableRender", function () {
      return r;
    }), n.d(e, "components", function () {
      return i;
    });
    var o = function o() {
        var t = this,
          e = t.$createElement;
        t._self._c;
        t._isMounted || (t.e0 = function (e) {
          t.tab = 1;
        }, t.e1 = function (e) {
          t.tab = 2;
        });
      },
      r = !1,
      u = [];
    o._withStripped = !0;
  },
  1196: function _(t, e, n) {
    "use strict";

    n.r(e);
    var i = n(1197),
      o = n.n(i);
    for (var r in i) ["default"].indexOf(r) < 0 && function (t) {
      n.d(e, t, function () {
        return i[t];
      });
    }(r);
    e["default"] = o.a;
  },
  1197: function _(t, e, n) {
    "use strict";

    (function (t) {
      Object.defineProperty(e, "__esModule", {
        value: !0
      }), e.default = void 0;
      var n = {
        data: function data() {
          return {
            keyHeight: 300,
            tab: 0,
            pause: .5
          };
        },
        mounted: function mounted() {
          var e = t.getStorageSync("device");
          "windows" !== e.platform && (console.log("this.keyboardHeight()"), this.keyboardHeight());
        },
        watch: {
          tab: function tab(t) {
            0 !== t && this.stopTts();
          },
          play_state: function play_state(t) {
            console.log("play_state", t);
          }
        },
        props: {
          nonmember: {
            type: Boolean,
            default: !1
          },
          is_continuous: {
            type: Boolean,
            default: !1
          },
          play_state: {
            type: Boolean,
            default: !1
          }
        },
        methods: {
          stopTts: function stopTts() {
            this.$parent.tts_audio.stopAllMusic();
          },
          playTts: function playTts() {
            var e = this;
            this.$parent.text ? (this.tab = 0, this.nonmember && (this.$parent.keytop_palystatus = !0), setTimeout(function () {
              e.$parent.requestTts(!1, !0);
            }, 200)) : t.showToast({
              title: "配音文本为空",
              icon: "none"
            });
          },
          insertPause: function insertPause() {
            var t = this;
            this.tab = 1, setTimeout(function () {
              t.$emit("insertPause", t.pause);
            }, 200);
          },
          insertContinuous: function insertContinuous() {
            this.$emit("insertContinuous");
          },
          setPauseNumber: function setPauseNumber(t) {
            this.pause = t.detail.value.toFixed(1);
          },
          keyboardHeight: function keyboardHeight() {
            var e = this;
            console.log("keyboardHeight"), t.onKeyboardHeightChange(function (n) {
              var i = t.getSystemInfoSync(),
                o = i.screenHeight - i.windowHeight,
                r = n.height - o;
              e.diffHeight = r > 0 ? r : 0, 0 !== e.diffHeight && (e.keyHeight = e.diffHeight + t.upx2px(104), e.is_height = !0);
            });
          },
          hide: function hide() {
            this.$parent.is_focus = !1, this.$emit("hide");
          }
        }
      };
      e.default = n;
    }).call(this, n(2)["default"]);
  },
  1198: function _(t, e, n) {
    "use strict";

    n.r(e);
    var i = n(1199),
      o = n.n(i);
    for (var r in i) ["default"].indexOf(r) < 0 && function (t) {
      n.d(e, t, function () {
        return i[t];
      });
    }(r);
    e["default"] = o.a;
  },
  1199: function _(t, e, n) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['components/make/keyboard_top-create-component', {
  'components/make/keyboard_top-create-component': function componentsMakeKeyboard_topCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1193));
  }
}, [['components/make/keyboard_top-create-component']]]);