(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["components/make/make_text"], {
  1130: function _(e, t, n) {
    "use strict";

    n.r(t);
    var o = n(1131),
      i = n(1133);
    for (var a in i) ["default"].indexOf(a) < 0 && function (e) {
      n.d(t, e, function () {
        return i[e];
      });
    }(a);
    n(1135);
    var r,
      c = n(230),
      u = Object(c["default"])(i["default"], o["render"], o["staticRenderFns"], !1, null, null, null, !1, o["components"], r);
    u.options.__file = "components/make/make_extract.vue", t["default"] = u.exports;
  },
  1131: function _(e, t, n) {
    "use strict";

    n.r(t);
    var o = n(1132);
    n.d(t, "render", function () {
      return o["render"];
    }), n.d(t, "staticRenderFns", function () {
      return o["staticRenderFns"];
    }), n.d(t, "recyclableRender", function () {
      return o["recyclableRender"];
    }), n.d(t, "components", function () {
      return o["components"];
    });
  },
  1132: function _(e, t, n) {
    "use strict";

    var o;
    n.r(t), n.d(t, "render", function () {
      return i;
    }), n.d(t, "staticRenderFns", function () {
      return r;
    }), n.d(t, "recyclableRender", function () {
      return a;
    }), n.d(t, "components", function () {
      return o;
    });
    try {
      o = {
        uPopup: function uPopup() {
          return Promise.all([n.e("common/vendor"), n.e("uni_modules/uview-ui/components/u-popup/u-popup")]).then(n.bind(null, 1093));
        }
      };
    } catch (c) {
      if (-1 === c.message.indexOf("Cannot find module") || -1 === c.message.indexOf(".vue")) throw c;
      console.error(c.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
    }
    var i = function i() {
        var e = this,
          t = e.$createElement;
        e._self._c;
        e._isMounted || (e.e0 = function (t) {
          e.showpop = !1;
        }, e.e1 = function (t) {
          e.showpop = !1;
        });
      },
      a = !1,
      r = [];
    i._withStripped = !0;
  },
  1133: function _(e, t, n) {
    "use strict";

    n.r(t);
    var o = n(1134),
      i = n.n(o);
    for (var a in o) ["default"].indexOf(a) < 0 && function (e) {
      n.d(t, e, function () {
        return o[e];
      });
    }(a);
    t["default"] = i.a;
  },
  1134: function _(e, t, n) {
    "use strict";

    (function (e, o) {
      var i = n(4);
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var a = i(n(255)),
        r = i(n(257)),
        c = i(n(11)),
        u = n(365),
        s = n(227);
      function p(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var o = Object.getOwnPropertySymbols(e);
          t && (o = o.filter(function (t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
          })), n.push.apply(n, o);
        }
        return n;
      }
      function l(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2 ? p(Object(n), !0).forEach(function (t) {
            (0, c.default)(e, t, n[t]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : p(Object(n)).forEach(function (t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
          });
        }
        return e;
      }
      var d = {
        props: {
          show: {
            type: Boolean,
            default: !0
          },
          jumpType: {
            type: Number,
            default: 0
          }
        },
        computed: l({}, (0, s.mapState)(["user_message", "app_config", "showPrivacy_ysxy"])),
        data: function data() {
          return {
            showpop: !1,
            content: "",
            video_url: "",
            audio_url: "",
            id: "",
            timeInfo: null
          };
        },
        methods: {
          choosetuwen: function choosetuwen(t) {
            var n;
            1 == t ? (n = "/pages2/make/image_text?type=1&jumpType=" + this.jumpType, this.$uma_wx.trackEvent("image-text", "提取视频中音频文案")) : 2 == t && (n = "/pages2/make/image_text?type=2&jumpType=" + this.jumpType, this.$uma_wx.trackEvent("image-text", "提取视频中图片文案")), e.navigateTo({
              url: n
            }), this.showpop = !1, this.$emit("hide");
          },
          imageTextLink: function imageTextLink() {
            this.$uma_wx.trackEvent("importDocument", "图文视频链接"), this.showpop = !0;
          },
          hide: function hide() {
            this.showpop ? this.showpop = !1 : this.$emit("hide");
          },
          shortVideoLink: function shortVideoLink() {
            this.$uma_wx.trackEvent("importDocument", "短视频链接提取"), e.navigateTo({
              url: "/pages2/make/short_video_link?jumpType=" + this.jumpType
            });
          },
          choiceFile: function choiceFile(t) {
            var n = this;
            e.showActionSheet({
              itemList: ["本地文件", "聊天文件"],
              success: function success(e) {
                0 == e.tapIndex ? 1 == t ? n.selectVideo() : 2 == t && n.selectAudio() : 1 == e.tapIndex && n.chooseMessageFile(t);
              },
              fail: function fail(e) {}
            });
          },
          chooseMessageFile: function chooseMessageFile(e) {
            var t = this,
              n = "file",
              i = [];
            i = 1 == e ? ["mp4"] : ["mp3"], o.chooseMessageFile({
              count: 1,
              extension: i,
              type: n,
              success: function success(n) {
                1 == e ? t.uploadVideo(n.tempFiles[0].path, "mp4") : t.uploadVideo(n.tempFiles[0].path, "mp3");
              }
            });
          },
          selectAudio: function selectAudio() {
            var t = this;
            this.$uma_wx.trackEvent("importDocument", "音频提取"), e.navigateTo({
              url: "/pages2/make/up_diybg?type=extract",
              events: {
                diyExtract: function diyExtract(n) {
                  t.$store.commit("setUploadFile", n.model), t.audio_url = n.model.bgmusicurl;
                  n.model.bgmusicurl, n.model.bgtimelen, n.model.bgsize, n.model.bgname;
                  e.showLoading({
                    title: "上传中..."
                  }), t.getVideoText(t.audio_url, "mp3");
                }
              }
            });
          },
          selectVideo: function selectVideo() {
            var t = this;
            this.$uma_wx.trackEvent("importDocument", "视频提取"), e.chooseVideo({
              compressed: !0,
              sourceType: ["album", "camera"],
              success: function success(n) {
                n.duration > 7200 || n.size > 536870912 ? e.showModal({
                  title: "视频太大，上传失败",
                  icon: "none"
                }) : (e.showLoading({
                  title: "上传视频中..."
                }), e.uploadFile({
                  filePath: n.tempFilePath,
                  name: "file",
                  header: {
                    "Content-Type": "multipart/form-data"
                  },
                  formData: {
                    isrestrict: "0",
                    catalogue: "0",
                    comparam: getApp().commonencry()
                  },
                  url: getApp().globalData.appApi + "/peiyin/music/univerupload",
                  success: function success(e) {
                    console.log("上传视频", e);
                    var n = JSON.parse(e.data);
                    t.video_url = n.model.bgmusicurl, t.getVideoText(t.video_url, "mp4");
                  },
                  fail: function fail(t) {
                    e.hideLoading(), e.showModal({
                      title: "视频上传失败，请稍后重试",
                      showCancel: !1
                    });
                  }
                }));
              }
            });
          },
          uploadVideo: function uploadVideo(t, n) {
            var o = this;
            e.showLoading({
              title: "上传中..."
            }), e.uploadFile({
              filePath: t,
              name: "file",
              header: {
                "Content-Type": "multipart/form-data"
              },
              formData: {
                catalogue: "0",
                isrestrict: "0",
                comparam: getApp().commonencry()
              },
              url: getApp().globalData.appApi + "/peiyin/music/univerupload",
              success: function success(e) {
                var t = JSON.parse(e.data);
                o.video_url = t.model.bgmusicurl, o.getVideoText(o.video_url, n);
              },
              fail: function fail() {
                e.hideLoading(), e.showModal({
                  title: "上传失败，请稍后重试",
                  showCancel: !1
                });
              }
            });
          },
          getVideoText: function getVideoText(t, n) {
            var o = this,
              i = {
                ossUrl: t,
                format: n
              };
            e.showLoading({
              title: "提取中...",
              mask: !0
            }), console.log("提取音视频文案", i);
            var c = getApp().globalData.appApi + "/peiyin/ttsAudio2Text";
            this.$http.postRequest(i, c, function () {
              var e = (0, r.default)(a.default.mark(function e(t) {
                return a.default.wrap(function (e) {
                  while (1) switch (e.prev = e.next) {
                    case 0:
                      "0" === t.rc && (o.id = t.model), !0, o.timeInfo = setInterval(function () {
                        o.getAsyncProcess(n), "" !== o.content && (o.content = "", !1);
                      }, 3e3);
                    case 3:
                    case "end":
                      return e.stop();
                  }
                }, e);
              }));
              return function (t) {
                return e.apply(this, arguments);
              };
            }());
          },
          getAsyncProcess: function getAsyncProcess(t) {
            var n,
              o = this;
            n = "mp3" === t ? "getAudioText" : "getVideoText";
            var i = {
                asyncId: this.id
              },
              a = getApp().globalData.appApi + "/peiyin/asyncProcess/selectProcess";
            this.$http.postRequest(i, a, function (t) {
              if ("0" === t.rc) if ("2" == t.model.processState) e.hideLoading({}), o.content = t.model.processText, clearInterval(o.timeInfo), e.navigateTo({
                url: "/pages2/make/import_text?jumpType=" + o.jumpType,
                success: function success(e) {
                  e.eventChannel.emit("acceptDataFromOpenerPage", {
                    content: t.model.processText,
                    type: n
                  });
                }
              });else if ("1" == t.model.processState) {
                e.hideLoading({}), clearInterval(o.timeInfo);
                var i = t.model.failDesc;
                e.showToast({
                  title: i,
                  icon: "none"
                });
              }
            });
          },
          selectSrt: function selectSrt() {
            var t = this;
            e.chooseMessageFile({
              count: 1,
              type: "file",
              extension: ["srt"],
              success: function success(n) {
                e.showLoading({
                  title: "提取中..."
                }), e.uploadFile({
                  url: getApp().globalData.appApi + "/peiyin/music/univerupload",
                  filePath: n.tempFiles[0].path,
                  name: "file",
                  formData: {
                    catalogue: "0",
                    isrestrict: "0",
                    comparam: getApp().commonencry()
                  },
                  success: function () {
                    var n = (0, r.default)(a.default.mark(function n(o) {
                      var i, r, c;
                      return a.default.wrap(function (n) {
                        while (1) switch (n.prev = n.next) {
                          case 0:
                            if (i = JSON.parse(o.data), r = i.model.bgmusicurl, c = {
                              url: r
                            }, c.url) {
                              n.next = 6;
                              break;
                            }
                            return e.showToast({
                              title: "选取文件失败",
                              icon: "none"
                            }), n.abrupt("return");
                          case 6:
                            (0, u.requestSrt)(c).then(function (n) {
                              var o = n.model;
                              t.content = o, e.navigateTo({
                                url: "/pages2/make/import_text?type='getSrt'&jumpType=".concat(t.jumpType),
                                success: function success(e) {
                                  e.eventChannel.emit("acceptDataFromOpenerPage", {
                                    content: o,
                                    type: tp
                                  });
                                }
                              });
                            });
                          case 7:
                          case "end":
                            return n.stop();
                        }
                      }, n);
                    }));
                    function o(e) {
                      return n.apply(this, arguments);
                    }
                    return o;
                  }(),
                  fail: function fail(t) {
                    e.hideLoading("上传失败，请稍后重试");
                  }
                });
              }
            });
          },
          readTxt: function readTxt() {
            var t = this,
              n = this;
            this.$uma_wx.trackEvent("importDocument", "txt/word提取"), o.chooseMessageFile({
              count: 1,
              type: "file",
              extension: ["txt", "doc", "docx"],
              success: function success(o) {
                if (o.tempFiles[0].size > 51200) e.showToast({
                  title: "提取txt文本不能大于50k",
                  icon: "none",
                  duration: 2500
                });else {
                  e.showLoading({
                    title: "提取中..."
                  });
                  var i = o.tempFiles[0].path,
                    a = getApp().globalData.appApi + "/peiyin/file/getTextFromTextFileV2";
                  e.uploadFile({
                    url: a,
                    filePath: i,
                    name: "file",
                    success: function success(o) {
                      var i = JSON.parse(o.data);
                      "0" === i.rc ? (t.content = i.model, e.hideLoading(), e.navigateTo({
                        url: "/pages2/make/import_text?type=readTxt&jumpType=".concat(t.jumpType),
                        success: function success(e) {
                          e.eventChannel.emit("acceptDataFromOpenerPage", {
                            content: n.content
                          });
                        }
                      })) : e.showToast({
                        title: "提取失败",
                        icon: "none"
                      });
                    }
                  });
                }
              }
            });
          },
          photoAlbum: function photoAlbum() {
            var t = this;
            this.$uma_wx.trackEvent("importDocument", "图片提取"), e.chooseImage({
              count: 1,
              sizeType: ["original", "compressed"],
              success: function success(e) {
                console.log("图片提取", e);
                var n = e.tempFilePaths[0];
                t.getOcr(n);
              }
            });
          },
          getOcr: function getOcr(t) {
            var n = this,
              o = this;
            e.showLoading({
              title: "提取中..."
            }), e.uploadFile({
              url: getApp().globalData.appApi + "/live/follow/extraimage",
              filePath: t,
              name: "file",
              formData: {
                comparam: getApp().commonencry()
              },
              success: function success(t) {
                var i = JSON.parse(t.data).model,
                  a = {
                    image: i,
                    type: 0
                  };
                (0, u.requestOcr)(a).then(function (t) {
                  var i = t.model.common.reduce(function (e, t) {
                    return e += t.text + "\n", e;
                  }, "");
                  n.content = i, e.navigateTo({
                    url: "/pages2/make/import_text?type=getOcr&jumpType=".concat(n.jumpType),
                    success: function success(e) {
                      e.eventChannel.emit("acceptDataFromOpenerPage", {
                        content: o.content
                      });
                    }
                  });
                });
              }
            });
          }
        }
      };
      t.default = d;
    }).call(this, n(2)["default"], n(1)["default"]);
  },
  1135: function _(e, t, n) {
    "use strict";

    n.r(t);
    var o = n(1136),
      i = n.n(o);
    for (var a in o) ["default"].indexOf(a) < 0 && function (e) {
      n.d(t, e, function () {
        return o[e];
      });
    }(a);
    t["default"] = i.a;
  },
  1136: function _(e, t, n) {},
  1137: function _(e, t, n) {
    "use strict";

    n.r(t);
    var o = n(1138),
      i = n(1140);
    for (var a in i) ["default"].indexOf(a) < 0 && function (e) {
      n.d(t, e, function () {
        return i[e];
      });
    }(a);
    n(1142);
    var r,
      c = n(230),
      u = Object(c["default"])(i["default"], o["render"], o["staticRenderFns"], !1, null, null, null, !1, o["components"], r);
    u.options.__file = "components/make/make_text.vue", t["default"] = u.exports;
  },
  1138: function _(e, t, n) {
    "use strict";

    n.r(t);
    var o = n(1139);
    n.d(t, "render", function () {
      return o["render"];
    }), n.d(t, "staticRenderFns", function () {
      return o["staticRenderFns"];
    }), n.d(t, "recyclableRender", function () {
      return o["recyclableRender"];
    }), n.d(t, "components", function () {
      return o["components"];
    });
  },
  1139: function _(e, t, n) {
    "use strict";

    var o;
    n.r(t), n.d(t, "render", function () {
      return i;
    }), n.d(t, "staticRenderFns", function () {
      return r;
    }), n.d(t, "recyclableRender", function () {
      return a;
    }), n.d(t, "components", function () {
      return o;
    });
    var i = function i() {
        var e = this,
          t = e.$createElement;
        e._self._c;
      },
      a = !1,
      r = [];
    i._withStripped = !0;
  },
  1140: function _(e, t, n) {
    "use strict";

    n.r(t);
    var o = n(1141),
      i = n.n(o);
    for (var a in o) ["default"].indexOf(a) < 0 && function (e) {
      n.d(t, e, function () {
        return o[e];
      });
    }(a);
    t["default"] = i.a;
  },
  1141: function _(e, t, n) {
    "use strict";

    var o = n(4);
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = void 0;
    o(n(1130));
    var i = {
      props: {
        show: {
          type: Boolean,
          default: !0
        },
        show_text: {
          type: Boolean,
          default: !0
        }
      },
      methods: {
        data: function data() {
          return {};
        },
        hide: function hide() {
          this.$emit("hide");
        },
        jumpExtract: function jumpExtract() {
          this.$emit("jumpExtract");
        },
        JumpPronounce: function JumpPronounce() {
          this.$emit("JumpPronounce");
        },
        jumpSpecial: function jumpSpecial() {
          this.$emit("jumpSpecial");
        },
        JumpSensitive: function JumpSensitive() {
          this.$emit("JumpSensitive");
        }
      }
    };
    t.default = i;
  },
  1142: function _(e, t, n) {
    "use strict";

    n.r(t);
    var o = n(1143),
      i = n.n(o);
    for (var a in o) ["default"].indexOf(a) < 0 && function (e) {
      n.d(t, e, function () {
        return o[e];
      });
    }(a);
    t["default"] = i.a;
  },
  1143: function _(e, t, n) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['components/make/make_text-create-component', {
  'components/make/make_text-create-component': function componentsMakeMake_textCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1137));
  }
}, [['components/make/make_text-create-component']]]);