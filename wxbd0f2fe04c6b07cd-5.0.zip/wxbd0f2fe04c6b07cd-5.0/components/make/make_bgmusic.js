(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["components/make/make_bgmusic"], {
  1151: function _(e, t, n) {
    "use strict";

    n.r(t);
    var i = n(1152),
      u = n(1154);
    for (var o in u) ["default"].indexOf(o) < 0 && function (e) {
      n.d(t, e, function () {
        return u[e];
      });
    }(o);
    n(1156);
    var c,
      r = n(230),
      s = Object(r["default"])(u["default"], i["render"], i["staticRenderFns"], !1, null, null, null, !1, i["components"], c);
    s.options.__file = "components/make/make_bgmusic.vue", t["default"] = s.exports;
  },
  1152: function _(e, t, n) {
    "use strict";

    n.r(t);
    var i = n(1153);
    n.d(t, "render", function () {
      return i["render"];
    }), n.d(t, "staticRenderFns", function () {
      return i["staticRenderFns"];
    }), n.d(t, "recyclableRender", function () {
      return i["recyclableRender"];
    }), n.d(t, "components", function () {
      return i["components"];
    });
  },
  1153: function _(e, t, n) {
    "use strict";

    var i;
    n.r(t), n.d(t, "render", function () {
      return u;
    }), n.d(t, "staticRenderFns", function () {
      return c;
    }), n.d(t, "recyclableRender", function () {
      return o;
    }), n.d(t, "components", function () {
      return i;
    });
    var u = function u() {
        var e = this,
          t = e.$createElement;
        e._self._c;
      },
      o = !1,
      c = [];
    u._withStripped = !0;
  },
  1154: function _(e, t, n) {
    "use strict";

    n.r(t);
    var i = n(1155),
      u = n.n(i);
    for (var o in i) ["default"].indexOf(o) < 0 && function (e) {
      n.d(t, e, function () {
        return i[e];
      });
    }(o);
    t["default"] = u.a;
  },
  1155: function _(e, t, n) {
    "use strict";

    (function (e) {
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var n = {
        props: {
          show: {
            type: Boolean,
            default: !0
          }
        },
        data: function data() {
          return {
            volume: 50,
            bgmusic: {},
            bg_volume: 50,
            is_loop: !1,
            interval_time: 0,
            continue_time: 0,
            delay_time: 0,
            is_reduce: !1
          };
        },
        watch: {
          show: function show() {
            this.record = {
              volume: this.volume,
              bgmusic: this.bgmusic,
              bg_volume: this.bg_volume,
              is_loop: this.is_loop,
              interval_time: this.interval_time,
              continue_time: this.continue_time,
              delay_time: this.delay_time,
              is_reduce: this.is_reduce
            }, console.log(11111, this.record);
          }
        },
        methods: {
          cancel: function cancel() {
            var e = this,
              t = Object.keys(this.record);
            t.forEach(function (t) {
              e[t] = e.record[t];
            }), this.$emit("hide");
          },
          setAnchorVolume: function setAnchorVolume(e) {
            this.volume = e.detail.value, this.$parent.volume = e.detail.value;
          },
          setBgVolume: function setBgVolume(e) {
            this.bg_volume = e.detail.value;
          },
          changeReduce: function changeReduce(e) {
            this.is_reduce = e.detail.value;
          },
          initBgMusic: function initBgMusic() {
            var t = this;
            e.showModal({
              title: "提示",
              content: "是否恢复默认设置？",
              success: function success(e) {
                e.confirm && (t.bg_volume = 50, t.is_loop = !1, t.interval_time = 0, t.continue_time = 0, t.delay_time = 0, t.is_reduce = !1, t.volume = t.$parent.anchor.vol);
              }
            });
          },
          setBgArgument: function setBgArgument(e, t) {
            if (this.bgmusic.bgid) if (e) this[t] += 1;else {
              if (this[t] <= 0) return;
              this[t] -= 1;
            }
          },
          removeBgMusic: function removeBgMusic() {
            var t = this;
            e.showModal({
              title: "提示",
              content: "是否移除背景音乐？",
              success: function success(e) {
                e.confirm && (t.bgmusic = {});
              }
            });
          },
          selectBgmusic: function selectBgmusic() {
            var t = this;
            e.navigateTo({
              url: "/pages2/make/bgmusic",
              events: {
                setBgMusic: function setBgMusic(e) {
                  t.bgmusic = e;
                }
              }
            });
          },
          hide: function hide() {
            this.$uma_wx.trackEvent("chooseBg"), this.$emit("hide", this.bgmusic.bgname);
          }
        }
      };
      t.default = n;
    }).call(this, n(2)["default"]);
  },
  1156: function _(e, t, n) {
    "use strict";

    n.r(t);
    var i = n(1157),
      u = n.n(i);
    for (var o in i) ["default"].indexOf(o) < 0 && function (e) {
      n.d(t, e, function () {
        return i[e];
      });
    }(o);
    t["default"] = u.a;
  },
  1157: function _(e, t, n) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['components/make/make_bgmusic-create-component', {
  'components/make/make_bgmusic-create-component': function componentsMakeMake_bgmusicCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1151));
  }
}, [['components/make/make_bgmusic-create-component']]]);