(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["components/make/save_workname"], {
  1207: function _(e, n, t) {
    "use strict";

    t.r(n);
    var r = t(1208),
      o = t(1210);
    for (var i in o) ["default"].indexOf(i) < 0 && function (e) {
      t.d(n, e, function () {
        return o[e];
      });
    }(i);
    t(1212);
    var c,
      u = t(230),
      f = Object(u["default"])(o["default"], r["render"], r["staticRenderFns"], !1, null, null, null, !1, r["components"], c);
    f.options.__file = "components/make/save_workname.vue", n["default"] = f.exports;
  },
  1208: function _(e, n, t) {
    "use strict";

    t.r(n);
    var r = t(1209);
    t.d(n, "render", function () {
      return r["render"];
    }), t.d(n, "staticRenderFns", function () {
      return r["staticRenderFns"];
    }), t.d(n, "recyclableRender", function () {
      return r["recyclableRender"];
    }), t.d(n, "components", function () {
      return r["components"];
    });
  },
  1209: function _(e, n, t) {
    "use strict";

    var r;
    t.r(n), t.d(n, "render", function () {
      return o;
    }), t.d(n, "staticRenderFns", function () {
      return c;
    }), t.d(n, "recyclableRender", function () {
      return i;
    }), t.d(n, "components", function () {
      return r;
    });
    try {
      r = {
        uIcon: function uIcon() {
          return Promise.all([t.e("common/vendor"), t.e("uni_modules/uview-ui/components/u-icon/u-icon")]).then(t.bind(null, 1431));
        }
      };
    } catch (u) {
      if (-1 === u.message.indexOf("Cannot find module") || -1 === u.message.indexOf(".vue")) throw u;
      console.error(u.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
    }
    var o = function o() {
        var e = this,
          n = e.$createElement;
        e._self._c;
        e._isMounted || (e.e0 = function (n) {
          e.fileFlag = !0;
        }, e.e1 = function (n) {
          e.fileFlag = !0;
        });
      },
      i = !1,
      c = [];
    o._withStripped = !0;
  },
  1210: function _(e, n, t) {
    "use strict";

    t.r(n);
    var r = t(1211),
      o = t.n(r);
    for (var i in r) ["default"].indexOf(i) < 0 && function (e) {
      t.d(n, e, function () {
        return r[e];
      });
    }(i);
    n["default"] = o.a;
  },
  1211: function _(e, n, t) {
    "use strict";

    (function (e) {
      var r = t(4);
      Object.defineProperty(n, "__esModule", {
        value: !0
      }), n.default = void 0;
      var o = r(t(11)),
        i = t(227),
        c = t(226);
      function u(e, n) {
        var t = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(e);
          n && (r = r.filter(function (n) {
            return Object.getOwnPropertyDescriptor(e, n).enumerable;
          })), t.push.apply(t, r);
        }
        return t;
      }
      function f(e) {
        for (var n = 1; n < arguments.length; n++) {
          var t = null != arguments[n] ? arguments[n] : {};
          n % 2 ? u(Object(t), !0).forEach(function (n) {
            (0, o.default)(e, n, t[n]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : u(Object(t)).forEach(function (n) {
            Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n));
          });
        }
        return e;
      }
      var a = {
        computed: f({}, (0, i.mapState)(["app_config"])),
        data: function data() {
          return {
            fileFlag: !1,
            height: "",
            fileList: [],
            work_name: "",
            fid: "",
            fname: "默认",
            upflag: !1
          };
        },
        props: {
          work_wname: {
            type: String,
            default: ""
          }
        },
        mounted: function mounted() {
          this.getFileList(), this.work_name = this.work_wname;
        },
        methods: {
          upfocus: function upfocus() {
            this.upflag = !0;
          },
          choseflie: function choseflie(e) {
            this.fid = e.folderid, this.fname = e.foldername, this.fileFlag = !1;
          },
          getFileList: function getFileList() {
            var e = this,
              n = {
                type: 0
              };
            (0, c.getFiles)(n).then(function (n) {
              var t = {
                folderid: "",
                foldername: "我的作品"
              };
              e.fileList.push(t);
              for (var r = 0; r < n.model.length; r++) e.fileList.push(n.model[r]);
              e.fileList.length > 4 && (e.height = "320rpx");
            });
          },
          clear: function clear() {
            this.work_name = "";
          },
          confirm: function confirm() {
            if (this.work_name.length > 30) e.showToast({
              title: "作品名称太长",
              icon: "none"
            });else {
              var n = {
                wname: this.work_name,
                fid: this.fid
              };
              this.$emit("confirm", n);
            }
          },
          hide: function hide() {
            this.$emit("hide");
          }
        }
      };
      n.default = a;
    }).call(this, t(2)["default"]);
  },
  1212: function _(e, n, t) {
    "use strict";

    t.r(n);
    var r = t(1213),
      o = t.n(r);
    for (var i in r) ["default"].indexOf(i) < 0 && function (e) {
      t.d(n, e, function () {
        return r[e];
      });
    }(i);
    n["default"] = o.a;
  },
  1213: function _(e, n, t) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['components/make/save_workname-create-component', {
  'components/make/save_workname-create-component': function componentsMakeSave_worknameCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1207));
  }
}, [['components/make/save_workname-create-component']]]);