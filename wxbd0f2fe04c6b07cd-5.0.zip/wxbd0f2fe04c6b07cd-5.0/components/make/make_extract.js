(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["components/make/make_extract"], {
  1130: function _(e, t, o) {
    "use strict";

    o.r(t);
    var a = o(1131),
      n = o(1133);
    for (var i in n) ["default"].indexOf(i) < 0 && function (e) {
      o.d(t, e, function () {
        return n[e];
      });
    }(i);
    o(1135);
    var s,
      r = o(230),
      c = Object(r["default"])(n["default"], a["render"], a["staticRenderFns"], !1, null, null, null, !1, a["components"], s);
    c.options.__file = "components/make/make_extract.vue", t["default"] = c.exports;
  },
  1131: function _(e, t, o) {
    "use strict";

    o.r(t);
    var a = o(1132);
    o.d(t, "render", function () {
      return a["render"];
    }), o.d(t, "staticRenderFns", function () {
      return a["staticRenderFns"];
    }), o.d(t, "recyclableRender", function () {
      return a["recyclableRender"];
    }), o.d(t, "components", function () {
      return a["components"];
    });
  },
  1132: function _(e, t, o) {
    "use strict";

    var a;
    o.r(t), o.d(t, "render", function () {
      return n;
    }), o.d(t, "staticRenderFns", function () {
      return s;
    }), o.d(t, "recyclableRender", function () {
      return i;
    }), o.d(t, "components", function () {
      return a;
    });
    try {
      a = {
        uPopup: function uPopup() {
          return Promise.all([o.e("common/vendor"), o.e("uni_modules/uview-ui/components/u-popup/u-popup")]).then(o.bind(null, 1093));
        }
      };
    } catch (r) {
      if (-1 === r.message.indexOf("Cannot find module") || -1 === r.message.indexOf(".vue")) throw r;
      console.error(r.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
    }
    var n = function n() {
        var e = this,
          t = e.$createElement;
        e._self._c;
        e._isMounted || (e.e0 = function (t) {
          e.showpop = !1;
        }, e.e1 = function (t) {
          e.showpop = !1;
        });
      },
      i = !1,
      s = [];
    n._withStripped = !0;
  },
  1133: function _(e, t, o) {
    "use strict";

    o.r(t);
    var a = o(1134),
      n = o.n(a);
    for (var i in a) ["default"].indexOf(i) < 0 && function (e) {
      o.d(t, e, function () {
        return a[e];
      });
    }(i);
    t["default"] = n.a;
  },
  1134: function _(e, t, o) {
    "use strict";

    (function (e, a) {
      var n = o(4);
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var i = n(o(255)),
        s = n(o(257)),
        r = n(o(11)),
        c = o(365),
        l = o(227);
      function u(e, t) {
        var o = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var a = Object.getOwnPropertySymbols(e);
          t && (a = a.filter(function (t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
          })), o.push.apply(o, a);
        }
        return o;
      }
      function p(e) {
        for (var t = 1; t < arguments.length; t++) {
          var o = null != arguments[t] ? arguments[t] : {};
          t % 2 ? u(Object(o), !0).forEach(function (t) {
            (0, r.default)(e, t, o[t]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : u(Object(o)).forEach(function (t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t));
          });
        }
        return e;
      }
      var d = {
        props: {
          show: {
            type: Boolean,
            default: !0
          },
          jumpType: {
            type: Number,
            default: 0
          }
        },
        computed: p({}, (0, l.mapState)(["user_message", "app_config", "showPrivacy_ysxy"])),
        data: function data() {
          return {
            showpop: !1,
            content: "",
            video_url: "",
            audio_url: "",
            id: "",
            timeInfo: null
          };
        },
        methods: {
          choosetuwen: function choosetuwen(t) {
            var o;
            1 == t ? (o = "/pages2/make/image_text?type=1&jumpType=" + this.jumpType, this.$uma_wx.trackEvent("image-text", "提取视频中音频文案")) : 2 == t && (o = "/pages2/make/image_text?type=2&jumpType=" + this.jumpType, this.$uma_wx.trackEvent("image-text", "提取视频中图片文案")), e.navigateTo({
              url: o
            }), this.showpop = !1, this.$emit("hide");
          },
          imageTextLink: function imageTextLink() {
            this.$uma_wx.trackEvent("importDocument", "图文视频链接"), this.showpop = !0;
          },
          hide: function hide() {
            this.showpop ? this.showpop = !1 : this.$emit("hide");
          },
          shortVideoLink: function shortVideoLink() {
            this.$uma_wx.trackEvent("importDocument", "短视频链接提取"), e.navigateTo({
              url: "/pages2/make/short_video_link?jumpType=" + this.jumpType
            });
          },
          choiceFile: function choiceFile(t) {
            var o = this;
            e.showActionSheet({
              itemList: ["本地文件", "聊天文件"],
              success: function success(e) {
                0 == e.tapIndex ? 1 == t ? o.selectVideo() : 2 == t && o.selectAudio() : 1 == e.tapIndex && o.chooseMessageFile(t);
              },
              fail: function fail(e) {}
            });
          },
          chooseMessageFile: function chooseMessageFile(e) {
            var t = this,
              o = "file",
              n = [];
            n = 1 == e ? ["mp4"] : ["mp3"], a.chooseMessageFile({
              count: 1,
              extension: n,
              type: o,
              success: function success(o) {
                1 == e ? t.uploadVideo(o.tempFiles[0].path, "mp4") : t.uploadVideo(o.tempFiles[0].path, "mp3");
              }
            });
          },
          selectAudio: function selectAudio() {
            var t = this;
            this.$uma_wx.trackEvent("importDocument", "音频提取"), e.navigateTo({
              url: "/pages2/make/up_diybg?type=extract",
              events: {
                diyExtract: function diyExtract(o) {
                  t.$store.commit("setUploadFile", o.model), t.audio_url = o.model.bgmusicurl;
                  o.model.bgmusicurl, o.model.bgtimelen, o.model.bgsize, o.model.bgname;
                  e.showLoading({
                    title: "上传中..."
                  }), t.getVideoText(t.audio_url, "mp3");
                }
              }
            });
          },
          selectVideo: function selectVideo() {
            var t = this;
            this.$uma_wx.trackEvent("importDocument", "视频提取"), e.chooseVideo({
              compressed: !0,
              sourceType: ["album", "camera"],
              success: function success(o) {
                o.duration > 7200 || o.size > 536870912 ? e.showModal({
                  title: "视频太大，上传失败",
                  icon: "none"
                }) : (e.showLoading({
                  title: "上传视频中..."
                }), e.uploadFile({
                  filePath: o.tempFilePath,
                  name: "file",
                  header: {
                    "Content-Type": "multipart/form-data"
                  },
                  formData: {
                    isrestrict: "0",
                    catalogue: "0",
                    comparam: getApp().commonencry()
                  },
                  url: getApp().globalData.appApi + "/peiyin/music/univerupload",
                  success: function success(e) {
                    console.log("上传视频", e);
                    var o = JSON.parse(e.data);
                    t.video_url = o.model.bgmusicurl, t.getVideoText(t.video_url, "mp4");
                  },
                  fail: function fail(t) {
                    e.hideLoading(), e.showModal({
                      title: "视频上传失败，请稍后重试",
                      showCancel: !1
                    });
                  }
                }));
              }
            });
          },
          uploadVideo: function uploadVideo(t, o) {
            var a = this;
            e.showLoading({
              title: "上传中..."
            }), e.uploadFile({
              filePath: t,
              name: "file",
              header: {
                "Content-Type": "multipart/form-data"
              },
              formData: {
                catalogue: "0",
                isrestrict: "0",
                comparam: getApp().commonencry()
              },
              url: getApp().globalData.appApi + "/peiyin/music/univerupload",
              success: function success(e) {
                var t = JSON.parse(e.data);
                a.video_url = t.model.bgmusicurl, a.getVideoText(a.video_url, o);
              },
              fail: function fail() {
                e.hideLoading(), e.showModal({
                  title: "上传失败，请稍后重试",
                  showCancel: !1
                });
              }
            });
          },
          getVideoText: function getVideoText(t, o) {
            var a = this,
              n = {
                ossUrl: t,
                format: o
              };
            e.showLoading({
              title: "提取中...",
              mask: !0
            }), console.log("提取音视频文案", n);
            var r = getApp().globalData.appApi + "/peiyin/ttsAudio2Text";
            this.$http.postRequest(n, r, function () {
              var e = (0, s.default)(i.default.mark(function e(t) {
                return i.default.wrap(function (e) {
                  while (1) switch (e.prev = e.next) {
                    case 0:
                      "0" === t.rc && (a.id = t.model), !0, a.timeInfo = setInterval(function () {
                        a.getAsyncProcess(o), "" !== a.content && (a.content = "", !1);
                      }, 3e3);
                    case 3:
                    case "end":
                      return e.stop();
                  }
                }, e);
              }));
              return function (t) {
                return e.apply(this, arguments);
              };
            }());
          },
          getAsyncProcess: function getAsyncProcess(t) {
            var o,
              a = this;
            o = "mp3" === t ? "getAudioText" : "getVideoText";
            var n = {
                asyncId: this.id
              },
              i = getApp().globalData.appApi + "/peiyin/asyncProcess/selectProcess";
            this.$http.postRequest(n, i, function (t) {
              if ("0" === t.rc) if ("2" == t.model.processState) e.hideLoading({}), a.content = t.model.processText, clearInterval(a.timeInfo), e.navigateTo({
                url: "/pages2/make/import_text?jumpType=" + a.jumpType,
                success: function success(e) {
                  e.eventChannel.emit("acceptDataFromOpenerPage", {
                    content: t.model.processText,
                    type: o
                  });
                }
              });else if ("1" == t.model.processState) {
                e.hideLoading({}), clearInterval(a.timeInfo);
                var n = t.model.failDesc;
                e.showToast({
                  title: n,
                  icon: "none"
                });
              }
            });
          },
          selectSrt: function selectSrt() {
            var t = this;
            e.chooseMessageFile({
              count: 1,
              type: "file",
              extension: ["srt"],
              success: function success(o) {
                e.showLoading({
                  title: "提取中..."
                }), e.uploadFile({
                  url: getApp().globalData.appApi + "/peiyin/music/univerupload",
                  filePath: o.tempFiles[0].path,
                  name: "file",
                  formData: {
                    catalogue: "0",
                    isrestrict: "0",
                    comparam: getApp().commonencry()
                  },
                  success: function () {
                    var o = (0, s.default)(i.default.mark(function o(a) {
                      var n, s, r;
                      return i.default.wrap(function (o) {
                        while (1) switch (o.prev = o.next) {
                          case 0:
                            if (n = JSON.parse(a.data), s = n.model.bgmusicurl, r = {
                              url: s
                            }, r.url) {
                              o.next = 6;
                              break;
                            }
                            return e.showToast({
                              title: "选取文件失败",
                              icon: "none"
                            }), o.abrupt("return");
                          case 6:
                            (0, c.requestSrt)(r).then(function (o) {
                              var a = o.model;
                              t.content = a, e.navigateTo({
                                url: "/pages2/make/import_text?type='getSrt'&jumpType=".concat(t.jumpType),
                                success: function success(e) {
                                  e.eventChannel.emit("acceptDataFromOpenerPage", {
                                    content: a,
                                    type: tp
                                  });
                                }
                              });
                            });
                          case 7:
                          case "end":
                            return o.stop();
                        }
                      }, o);
                    }));
                    function a(e) {
                      return o.apply(this, arguments);
                    }
                    return a;
                  }(),
                  fail: function fail(t) {
                    e.hideLoading("上传失败，请稍后重试");
                  }
                });
              }
            });
          },
          readTxt: function readTxt() {
            var t = this,
              o = this;
            this.$uma_wx.trackEvent("importDocument", "txt/word提取"), a.chooseMessageFile({
              count: 1,
              type: "file",
              extension: ["txt", "doc", "docx"],
              success: function success(a) {
                if (a.tempFiles[0].size > 51200) e.showToast({
                  title: "提取txt文本不能大于50k",
                  icon: "none",
                  duration: 2500
                });else {
                  e.showLoading({
                    title: "提取中..."
                  });
                  var n = a.tempFiles[0].path,
                    i = getApp().globalData.appApi + "/peiyin/file/getTextFromTextFileV2";
                  e.uploadFile({
                    url: i,
                    filePath: n,
                    name: "file",
                    success: function success(a) {
                      var n = JSON.parse(a.data);
                      "0" === n.rc ? (t.content = n.model, e.hideLoading(), e.navigateTo({
                        url: "/pages2/make/import_text?type=readTxt&jumpType=".concat(t.jumpType),
                        success: function success(e) {
                          e.eventChannel.emit("acceptDataFromOpenerPage", {
                            content: o.content
                          });
                        }
                      })) : e.showToast({
                        title: "提取失败",
                        icon: "none"
                      });
                    }
                  });
                }
              }
            });
          },
          photoAlbum: function photoAlbum() {
            var t = this;
            this.$uma_wx.trackEvent("importDocument", "图片提取"), e.chooseImage({
              count: 1,
              sizeType: ["original", "compressed"],
              success: function success(e) {
                console.log("图片提取", e);
                var o = e.tempFilePaths[0];
                t.getOcr(o);
              }
            });
          },
          getOcr: function getOcr(t) {
            var o = this,
              a = this;
            e.showLoading({
              title: "提取中..."
            }), e.uploadFile({
              url: getApp().globalData.appApi + "/live/follow/extraimage",
              filePath: t,
              name: "file",
              formData: {
                comparam: getApp().commonencry()
              },
              success: function success(t) {
                var n = JSON.parse(t.data).model,
                  i = {
                    image: n,
                    type: 0
                  };
                (0, c.requestOcr)(i).then(function (t) {
                  var n = t.model.common.reduce(function (e, t) {
                    return e += t.text + "\n", e;
                  }, "");
                  o.content = n, e.navigateTo({
                    url: "/pages2/make/import_text?type=getOcr&jumpType=".concat(o.jumpType),
                    success: function success(e) {
                      e.eventChannel.emit("acceptDataFromOpenerPage", {
                        content: a.content
                      });
                    }
                  });
                });
              }
            });
          }
        }
      };
      t.default = d;
    }).call(this, o(2)["default"], o(1)["default"]);
  },
  1135: function _(e, t, o) {
    "use strict";

    o.r(t);
    var a = o(1136),
      n = o.n(a);
    for (var i in a) ["default"].indexOf(i) < 0 && function (e) {
      o.d(t, e, function () {
        return a[e];
      });
    }(i);
    t["default"] = n.a;
  },
  1136: function _(e, t, o) {},
  228: function _(e, t, o) {
    "use strict";

    o.r(t);
    var a = o(229),
      n = o.n(a);
    for (var i in a) ["default"].indexOf(i) < 0 && function (e) {
      o.d(t, e, function () {
        return a[e];
      });
    }(i);
    t["default"] = n.a;
  },
  229: function _(e, t, o) {},
  27: function _(e, t, o) {
    "use strict";

    o.r(t);
    var a = o(28);
    for (var n in a) ["default"].indexOf(n) < 0 && function (e) {
      o.d(t, e, function () {
        return a[e];
      });
    }(n);
    o(228);
    var i,
      s,
      r,
      c,
      l = o(230),
      u = Object(l["default"])(a["default"], i, s, !1, null, null, null, !1, r, c);
    u.options.__file = "App.vue", t["default"] = u.exports;
  },
  28: function _(e, t, o) {
    "use strict";

    o.r(t);
    var a = o(29),
      n = o.n(a);
    for (var i in a) ["default"].indexOf(i) < 0 && function (e) {
      o.d(t, e, function () {
        return a[e];
      });
    }(i);
    t["default"] = n.a;
  },
  29: function _(e, t, o) {
    "use strict";

    (function (e, a) {
      var n = o(4);
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var i = n(o(13)),
        s = (n(o(30)), n(o(31))),
        r = n(o(225)),
        c = o(226),
        l = (o(227), {
          globalData: {
            baseApi: "https://pysq.shipook.com/v2base",
            appApi: "https://pysq.shipook.com/v2app",
            app_url: {},
            base_url: {
              getsmscode: "/common/getsmscode",
              login4wechat: "/thirdlogin/login4wechat",
              login4zjtd: "/thirdlogin/login4zjtd",
              login4baidu: "/thirdlogin/login4baidu",
              userlogin: "/user/userlogin",
              qryuserallinfo: "/user/qryuserallinfo",
              cashorder: "/business/cashorder",
              openvip: "/business/openvip",
              bootup: "/common/bootup",
              updatedeviceinfo: "/common/updatedeviceinfo",
              getbusupgradeinfo: "/busupgrade/getbusupgradeinfo",
              qryuserjbviplist: "/business/qryuserjbviplist"
            },
            tab_work: 0,
            qd: "",
            ver: "010009",
            sec: "48a0088cb506e6b7",
            aaa: "",
            bbb: "",
            deviceId: "",
            wxappid: "",
            userinfo: null,
            crgid: "",
            parentid: "",
            deviceMac: "",
            oaid: "",
            ss: "",
            showPay: !0,
            freetype: null,
            vipList: [],
            svip_char: {},
            ios_status: 1,
            tts_text: "",
            ishidetype: "",
            heimingdan0: "",
            heimingdan1: "",
            heimingdan2: "",
            systemInfo: null,
            timeInfo: 0
          },
          onLaunch: function onLaunch() {
            var t = this;
            this.$store.commit("setAppConfig", r.default), 1154 === e.getLaunchOptionsSync().scene && (a.setStorageSync("ispyq", !0), a.switchTab({
              url: "/pages/make/make?pyq=1"
            }));
            var o = e.getUpdateManager();
            o.onCheckForUpdate(function (e) {
              if (!e.hasUpdate) return !1;
              o.onUpdateReady(function () {
                o.applyUpdate();
              });
            }), a.setInnerAudioOption({
              obeyMuteSwitch: !1
            }), a.getSystemInfo({
              complete: function complete(e) {
                a.setStorageSync("device", e), t.globalData.systemInfo = e;
              }
            }), this.globalData.aaa = this.globalData.sec.split("").reverse().join(""), this.globalData.bbb = this.globalData.sec.substr(1) + this.globalData.sec.substr(0, 1), this.setQd(r.default.qd), this.getPhoneId(), this.start_Up();
          },
          onShow: function onShow() {
            (a.getStorageSync("sid") || a.getStorageSync("uid")) && this.getUserInfo(function (e) {});
          },
          onHide: function onHide() {},
          methods: {
            commonencry: function commonencry() {
              return JSON.stringify(s.default.getEncryption());
            },
            findpyblack: function findpyblack() {
              var e = this,
                t = e.globalData.appApi + "/peiyin/findpyblack";
              s.default.postRequest({}, t, function (t) {
                if (t.model) for (var o = t.model.split(","), a = 0; a < o.length; a++) "0" == o[a] ? (e.globalData.heimingdan0 = !0, e.$store ? e.$store.commit("setheimingdan0", e.globalData.heimingdan0) : e.$vm.$store.commit("setheimingdan0", e.globalData.heimingdan0)) : "1" == o[a] ? e.globalData.heimingdan1 = !0 : "2" == o[a] && (e.globalData.heimingdan2 = !0);
              });
            },
            examineText: function examineText(e, t) {
              var o = this;
              return new Promise(function (n, i) {
                var r = o.globalData.appApi + "/security/green/text";
                s.default.postRequest({
                  text: e
                }, r, function (e) {
                  console.log("文本检查结果", e), "0" !== e.rc && n(!0);
                  var o = {
                    10001: " 广告",
                    20001: "时政",
                    20002: "色情",
                    20003: "辱骂",
                    20006: "违法犯罪",
                    20008: "欺诈",
                    20012: "低俗",
                    20013: "版权",
                    21e3: "其他"
                  };
                  o[e.model.label] ? (a.showModal({
                    title: "提示",
                    content: "文本内容包含".concat(o[e.model.label] ? o[e.model.label] : "", "相关违规文字信息，请修改后重新操作"),
                    cancelText: "联系客服",
                    success: function success(e) {
                      e.confirm ? t && t() : e.cancel && a.navigateTo({
                        url: "/pages/wode/kefu/kefu"
                      });
                    }
                  }), n(!1)) : n(!0);
                });
              });
            },
            examineImg: function examineImg(e, t) {
              var o = this;
              return new Promise(function (n, i) {
                var r = o.globalData.appApi + "/peiyin/wxurllink/examinewximg",
                  c = {
                    url: e
                  };
                s.default.postRequest(c, r, function (e) {
                  "0" !== e.rc && n(!0), console.log("图片检查结果", e);
                  var o = JSON.parse(e.model),
                    i = o.errcode;
                  0 !== i && a.showModal({
                    title: "提示",
                    content: "该图片存在敏感信息，暂无法使用，如有疑问，请联系客服处理",
                    cancelText: "联系客服",
                    success: function success(e) {
                      e.confirm ? t && t() : e.cancel && a.switchTab({
                        url: "/pages/mine/mine"
                      });
                    }
                  }), n(0 === i);
                });
              });
            },
            isShowPay: function isShowPay() {
              var e = a.getStorageSync("device").platform;
              return "ios" !== e && "devtools" != e;
            },
            downMp4ForAlbum: function downMp4ForAlbum(e) {
              console.log("导出MP4", e), a.downloadFile({
                url: e,
                success: function success(e) {
                  console.log("res", e), 200 === e.statusCode && (a.hideLoading(), a.saveVideoToPhotosAlbum({
                    filePath: e.tempFilePath,
                    success: function success() {
                      a.showModal({
                        title: "导出成功",
                        content: "前往相册查看"
                      });
                    }
                  }));
                }
              });
            },
            qryApiLimit: function qryApiLimit(e) {
              var t = this;
              return new Promise(function (o, a) {
                var n = {
                    apiType: e,
                    isVip: t.globalData.userinfo.userrich.isvalidvip
                  },
                  i = t.globalData.appApi + "/peiyin/qryapilimitapp";
                console.log("json", n), console.log("url", i), s.default.postRequest(n, i, function (e) {
                  console.log("api剩余次数", e), o(e);
                });
              });
            },
            updateApiLimit: function updateApiLimit(e) {
              var t = {
                  apiType: e,
                  isVip: this.globalData.userinfo.userrich.isvalidvip
                },
                o = this.globalData.appApi + "/peiyin/uptapilimitapp";
              s.default.postRequest(t, o, function (e) {
                console.log("api更新次数", e);
              });
            },
            setOssPath: function setOssPath(e, t, o) {
              a.uploadFile({
                url: this.globalData.appApi + "/peiyin/music/univerupload",
                filePath: e,
                name: "file",
                formData: {
                  isrestrict: "0",
                  catalogue: t,
                  osstype: "1",
                  comparam: getApp().commonencry()
                },
                success: function success(e) {
                  console.log("上传本地文件到oss", e), o(JSON.parse(e.data).model);
                },
                fail: function fail(e) {
                  a.showToast({
                    title: "图片上传失败！",
                    icon: "none"
                  }), o("fail");
                }
              });
            },
            generatePoster: function generatePoster(e) {
              var t = {
                req: JSON.stringify({
                  qd: this.globalData.qd,
                  ver: this.globalData.ver,
                  sceneStr: this.globalData.userinfo.userinfo.id,
                  page: "pages/make/make"
                })
              };
              console.log("生成分享二维码", t);
              var o = this.globalData.appApi + "/wxgetqrcode";
              a.request({
                url: o,
                method: "POST",
                header: {
                  "content-type": "application/x-www-form-urlencoded",
                  cookie: "SESSION=" + (a.getStorageSync("sid") ? a.getStorageSync("sid") : "")
                },
                data: t,
                success: function success(t) {
                  e(t);
                }
              });
            },
            getShare: function getShare(e) {
              var t = this;
              (e.parentid || e.scene) && setTimeout(function () {
                var o = e.parentid;
                if (e.scene && (o = decodeURIComponent(e.scene)), o) {
                  t.globalData.parentid = o;
                  var n = {
                      parentid: o
                    },
                    i = getApp().globalData.baseApi + "/user/bindparent";
                  s.default.postRequest(n, i, function (e) {
                    console.log("分享绑定", e), a.showToast({
                      title: "绑定上级成功",
                      icon: "none",
                      duration: 2e3
                    }), getApp().getUserInfo(function (e) {});
                  }, function (e) {
                    if (console.log("绑定失败aaaa", e), "1501" == e.rc) a.showToast({
                      title: "您已绑定过上级，不可再次绑定",
                      icon: "none",
                      duration: 2e3
                    });else {
                      var t = e.rd;
                      a.showToast({
                        title: t,
                        icon: "none",
                        duration: 2e3
                      });
                    }
                  });
                }
              }, 1e3);
            },
            getbdKF: function getbdKF() {
              r.default.kfurl && e.openCustomerServiceChat({
                extInfo: {
                  url: r.default.kfurl
                },
                corpId: r.default.kfcorpId,
                showMessageCard: !0,
                sendMessageTitle: "请稍等，客服马上就到(" + this.globalData.userinfo.userinfo.id + ")",
                sendMessageImg: "https://pysqstoss.shipook.com/imgs/20220117/202306011h.png"
              });
            },
            copyObj: function copyObj(e) {
              var t = null;
              if ("object" == (0, i.default)(e) && null !== e) for (var o in t = e instanceof Array ? [] : {}, e) t[o] = this.copyObj(e[o]);else t = e;
              return t;
            },
            getLocation: function getLocation(e) {
              a.getLocation({
                type: "gcj02",
                success: function success(t) {
                  var o = t.latitude,
                    a = t.longitude;
                  console.log(t);
                  var n = {
                      lng: a,
                      lat: o
                    },
                    i = getApp().globalData.baseApi + "/common/getprovince";
                  s.default.postRequest(n, i, function (t) {
                    console.log("通过经纬度获取地址", t), e(t);
                  });
                },
                fail: function fail(t) {
                  e("fail"), a.showToast({
                    title: "获取位置信息失败！",
                    icon: "none"
                  }), console.log("获取位置失败", t);
                }
              });
            },
            setUserInfo: function setUserInfo(e, t) {
              console.log("用户信息2222", e), r.default.free && (e.model.userrich.isvalidsvip = "1"), a.setStorageSync("uid", e.model.userinfo.uid), a.setStorageSync("did", e.model.userinfo.did), this.$store ? this.$store.commit("setUserMessage", e.model) : this.$vm.$store.commit("setUserMessage", e.model), getApp().globalData.userinfo = e.model, t(e);
            },
            wxLogin: function wxLogin(e) {
              a.login({
                provider: "weixin",
                success: function success(t) {
                  var o = {
                      isbind: "0",
                      code: t.code
                    },
                    n = getApp().globalData.baseApi + getApp().globalData.base_url.login4wechat,
                    i = function i(t) {
                      a.setStorageSync("sid", t.model.userinfo.sid), getApp().setUserInfo(t, e);
                    };
                  s.default.postRequest(o, n, i);
                }
              });
            },
            disposeNewUser: function disposeNewUser(e, t) {
              var o = this,
                n = new Date(e.ctime).getTime(),
                i = new Date().getTime(),
                r = i - n,
                c = 6048e5;
              "用户" === e.nickname && r <= c && a.showModal({
                title: "提示",
                content: "需要获取您的微信昵称与头像用于完善资料显示，是否同意获取？",
                success: function success(e) {
                  e.confirm && a.getUserProfile({
                    desc: "用于完善资料显示",
                    success: function success(e) {
                      var a = {
                          nickname: e.userInfo.nickName,
                          avatar: e.userInfo.avatarUrl
                        },
                        n = o.globalData.baseApi + "/user/updateuserinfo";
                      s.default.postRequest(a, n, function (e) {
                        t && t();
                      });
                    }
                  });
                }
              });
            },
            getUserInfo: function getUserInfo(e) {
              var t = this,
                o = this.globalData.baseApi + this.globalData.base_url.qryuserallinfo;
              s.default.postRequest({}, o, function (o) {
                console.log("获取用户信息", o), t.setUserInfo(o, e);
              });
            },
            getPay: function getPay(e, t, o, n, i, r, c) {
              a.showLoading({
                title: "加载中",
                mask: !0
              });
              var l = this,
                u = 10 * Number(o).toFixed(2),
                p = {
                  crgtype: 2,
                  paytype: e,
                  ordername: t,
                  jb: u,
                  rmb: o,
                  orderid: i,
                  ordertype: n,
                  extdata: r,
                  ish5: 3
                };
              console.log(p);
              var d = this.globalData.baseApi + this.globalData.base_url.cashorder;
              this.globalData.crgid = "";
              var f = function f(t) {
                l.callPay(e, t, c);
              };
              s.default.postRequest(p, d, f);
            },
            getVip: function getVip(e, t, o, n, i, r) {
              a.showLoading({
                title: "加载中",
                mask: !0
              });
              var c = this,
                l = {
                  viptype: e,
                  sviptype: t,
                  paytype: o,
                  time: n,
                  extdata: i,
                  ish5: 3
                };
              console.log("开通会员", l);
              var u = this.globalData.baseApi + this.globalData.base_url.openvip,
                p = function p(e) {
                  c.callPay(o, e, r);
                };
              s.default.postRequest(l, u, p);
            },
            callPay: function callPay(e, t, o) {
              2 == e && t.model.orderparams4webchat ? this.wxPayForMp(t, o) : 1 == e && t.model.orderstr4alipay;
            },
            wxPayForApp: function wxPayForApp(e, t) {
              var o = this;
              a.requestPayment({
                provider: "wxpay",
                orderInfo: e.model.orderparams4webchat,
                success: function success(e) {
                  o.getUserInfo(), a.hideLoading(), t(e);
                },
                fail: function fail(e) {
                  a.hideLoading(), a.showToast({
                    title: "支付失败",
                    icon: "none"
                  });
                }
              });
            },
            wxPayForMp: function wxPayForMp(e, t) {
              var o = this;
              a.requestPayment({
                provider: "wxpay",
                timeStamp: e.model.orderparams4webchat.timestamp,
                nonceStr: e.model.orderparams4webchat.noncestr,
                package: "prepay_id=" + e.model.orderparams4webchat.prepayid,
                signType: "MD5",
                paySign: e.model.orderparams4webchat.sign,
                success: function success(e) {
                  o.getUserInfo(), a.hideLoading(), t(e);
                },
                fail: function fail(e) {
                  a.hideLoading();
                }
              });
            },
            aliPayForApp: function aliPayForApp(e, t) {
              var o = this;
              a.requestPayment({
                provider: "alipay",
                orderInfo: e.model.orderstr4alipay,
                success: function success(e) {
                  o.getUserInfo(), a.hideLoading(), t(e);
                },
                fail: function fail(e) {
                  a.hideLoading(), a.showToast({
                    title: "支付失败",
                    icon: "none"
                  });
                }
              });
            },
            zjPayForMp: function zjPayForMp(e, t) {},
            setQd: function setQd(e) {
              var t = "";
              t = this.globalData.systemInfo ? this.globalData.systemInfo.platform : a.getSystemInfoSync().platform, console.log("bradn", t), this.globalData.qd = "ios" == t || "devtools1" == t ? "2" + e.slice(1) : e, console.log("渠道号", this.globalData.qd);
            },
            start_Up: function start_Up() {
              var e,
                t = this,
                o = new Date().toLocaleDateString();
              e = a.getStorageSync("active") ? a.getStorageSync("active") == o ? "0" : "2" : "1";
              var n = {
                  active: e
                },
                i = t.globalData.baseApi + t.globalData.base_url.bootup;
              s.default.postRequest(n, i, function (e) {
                console.log("合肥阅舟科技-设备启动信息", e), t.globalData.appcfg = e.model.appcfg ? JSON.parse(e.model.appcfg) : {}, t.globalData.freetype = e.model.appcfg ? JSON.parse(e.model.appcfg).freetype : "0", t.globalData.svip_char = t.globalData.appcfg.svip_char, t.globalData.vipList = e.model.jbviplist, t.globalData.zifubao = JSON.parse(e.model.appcfg).zifubao, e.model.appcfg && (JSON.parse(e.model.appcfg).iospay ? t.globalData.iospay = JSON.parse(e.model.appcfg).iospay : t.globalData.iospay = 1, JSON.parse(e.model.appcfg).hideiospay ? t.globalData.hideiospay = JSON.parse(e.model.appcfg).hideiospay : t.globalData.hideiospay = 1), t.hidearea(), t.findpyblack(), a.setStorageSync("active", o);
              });
              var r = t.globalData.baseApi + "/business/qujbl";
              s.default.postRequest({}, r, function (e) {
                console.log("获取配置信息", e), t.globalData.isexamine = "1" === e.model.isexm, t.globalData.iswcp = e.model.iswcp, a.$emit("qryttscfg");
              });
            },
            hidearea: function hidearea() {
              var e = this,
                t = {
                  functype: "0"
                },
                o = e.globalData.baseApi + "/business/qryshieldfunc";
              s.default.postRequest(t, o, function (t) {
                var o;
                console.log("屏蔽地区", t), o = "0" == t.rc && t.model.iospay ? t.model.iospay : "1", e.globalData.ishidetype = o, e.globalData.ios_status = "1" == o ? e.globalData.hideiospay : "0" == o ? e.globalData.iospay : 1;
              });
            },
            getPhoneId: function getPhoneId() {},
            getStorageFun: function getStorageFun(e, t) {
              var o = new Date().toLocaleDateString();
              if (!a.getStorageSync(e)) return a.setStorageSync(e, o), void t();
              a.getStorageSync(e) != o && (a.setStorageSync(e, o), a.removeStorageSync("bgmusic"), t());
            },
            showLoginToast: function showLoginToast() {
              a.showModal({
                title: "登录提示",
                content: "您当前未登录，请先去登录",
                cancelText: "取消",
                confirmText: "登录",
                showCancel: !0,
                success: function success(e) {
                  e.confirm && getApp().relogin();
                }
              });
            },
            relogin: function relogin() {
              var e = this,
                t = function t(_t) {
                  e.$vm.$store.commit("setIsunlogin", !1), e.$vm.$store.commit("setUserMessage", _t.model), a.showToast({
                    title: "登录成功"
                  });
                };
              getApp().wxLogin(function (e) {
                t(e);
              });
            },
            prosssCirculation: function prosssCirculation(e, t) {
              var o = {
                asyncId: e
              };
              getApp().globalData.timeInfo = setInterval(function () {
                var e = getApp().globalData.appApi + "/peiyin/asyncProcess/selectProcess";
                s.default.postRequest(o, e, function (e) {
                  "0" === e.rc ? "2" == e.model.processState ? (getApp().stoptimerinfo(), t && (t({
                    type: "1",
                    result: e.model
                  }), a.hideLoading({}))) : "1" == e.model.processState && (getApp().stoptimerinfo(), t && t({
                    type: "0",
                    result: e.model.failDesc
                  }), a.hideLoading({})) : (getApp().stoptimerinfo(), t && t({
                    type: "0",
                    result: e.rd
                  }), a.hideLoading({}));
                }, function (e) {
                  getApp().stoptimerinfo(), t && t({
                    type: "0",
                    result: "操作失败"
                  }), a.hideLoading({});
                });
              }, 3e3);
            },
            stoptimerinfo: function stoptimerinfo() {
              getApp().globalData.timeInfo && (clearInterval(getApp().globalData.timeInfo), getApp().globalData.timeInfo = 0);
            },
            getProcessId: function getProcessId(e, t, o) {
              (0, c.getProcess)(e, t).then(function (e) {
                if ("0" === e.rc) {
                  var t = e.model;
                  getApp().globalData.timeInfo && getApp().stoptimerinfo(), getApp().prosssCirculation(t, o);
                }
              }).catch(function (e) {
                console.log(e);
              });
            }
          },
          mounted: function mounted() {}
        });
      t.default = l;
    }).call(this, o(1)["default"], o(2)["default"]);
  }
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['components/make/make_extract-create-component', {
  'components/make/make_extract-create-component': function componentsMakeMake_extractCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1130));
  }
}, [['components/make/make_extract-create-component']]]);