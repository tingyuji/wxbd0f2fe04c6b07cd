(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["components/make/make_nonmember1"], {
  1315: function _(e, n, t) {
    "use strict";

    t.r(n);
    var o = t(1316),
      r = t(1318);
    for (var s in r) ["default"].indexOf(s) < 0 && function (e) {
      t.d(n, e, function () {
        return r[e];
      });
    }(s);
    t(1320);
    var i,
      u = t(230),
      c = Object(u["default"])(r["default"], o["render"], o["staticRenderFns"], !1, null, null, null, !1, o["components"], i);
    c.options.__file = "components/make/make_nonmember1.vue", n["default"] = c.exports;
  },
  1316: function _(e, n, t) {
    "use strict";

    t.r(n);
    var o = t(1317);
    t.d(n, "render", function () {
      return o["render"];
    }), t.d(n, "staticRenderFns", function () {
      return o["staticRenderFns"];
    }), t.d(n, "recyclableRender", function () {
      return o["recyclableRender"];
    }), t.d(n, "components", function () {
      return o["components"];
    });
  },
  1317: function _(e, n, t) {
    "use strict";

    var o;
    t.r(n), t.d(n, "render", function () {
      return r;
    }), t.d(n, "staticRenderFns", function () {
      return i;
    }), t.d(n, "recyclableRender", function () {
      return s;
    }), t.d(n, "components", function () {
      return o;
    });
    try {
      o = {
        uPopup: function uPopup() {
          return Promise.all([t.e("common/vendor"), t.e("uni_modules/uview-ui/components/u-popup/u-popup")]).then(t.bind(null, 1093));
        }
      };
    } catch (u) {
      if (-1 === u.message.indexOf("Cannot find module") || -1 === u.message.indexOf(".vue")) throw u;
      console.error(u.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
    }
    var r = function r() {
        var e = this,
          n = e.$createElement,
          t = (e._self._c, e.getSrcimage());
        e.$mp.data = Object.assign({}, {
          $root: {
            m0: t
          }
        });
      },
      s = !1,
      i = [];
    r._withStripped = !0;
  },
  1318: function _(e, n, t) {
    "use strict";

    t.r(n);
    var o = t(1319),
      r = t.n(o);
    for (var s in o) ["default"].indexOf(s) < 0 && function (e) {
      t.d(n, e, function () {
        return o[e];
      });
    }(s);
    n["default"] = r.a;
  },
  1319: function _(e, n, t) {
    "use strict";

    (function (e) {
      Object.defineProperty(n, "__esModule", {
        value: !0
      }), n.default = void 0;
      var t = {
        props: {
          is_gold: {
            type: Boolean,
            default: !1
          },
          type: {
            type: String,
            default: "1"
          },
          title: {
            type: String,
            default: "请开通会员后使用"
          },
          subtitle: {
            type: String,
            default: "开通会员享受免费制作导出"
          },
          show: {
            type: Boolean,
            default: !1
          }
        },
        methods: {
          getSrcimage: function getSrcimage() {
            switch (this.type) {
              case "1":
                return "https://pysqstoss.shipook.com/static/minisource/10767/make_nonmember.png";
              case "2":
                return "https://pysqstoss.shipook.com/static/minisource/10767/make_nonmember1.png";
              case "3":
                return "https://pysqstoss.shipook.com/static/minisource/10767/make_nonmemberp.png";
              default:
                return "https://pysqstoss.shipook.com/static/minisource/10767/make_nonmember2.png";
            }
          },
          jumpVip: function jumpVip() {
            this.$emit("hide"), e.navigateTo({
              url: "/pages3/vip?current=" + (this.is_gold ? "1" : "0")
            });
          },
          hide: function hide() {
            this.$emit("hide");
          }
        }
      };
      n.default = t;
    }).call(this, t(2)["default"]);
  },
  1320: function _(e, n, t) {
    "use strict";

    t.r(n);
    var o = t(1321),
      r = t.n(o);
    for (var s in o) ["default"].indexOf(s) < 0 && function (e) {
      t.d(n, e, function () {
        return o[e];
      });
    }(s);
    n["default"] = r.a;
  },
  1321: function _(e, n, t) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['components/make/make_nonmember1-create-component', {
  'components/make/make_nonmember1-create-component': function componentsMakeMake_nonmember1CreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1315));
  }
}, [['components/make/make_nonmember1-create-component']]]);