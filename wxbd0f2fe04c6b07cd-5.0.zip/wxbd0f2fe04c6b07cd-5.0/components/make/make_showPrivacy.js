(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["components/make/make_showPrivacy"], {
  1086: function _(e, t, n) {
    "use strict";

    n.r(t);
    var r = n(1087),
      o = n(1089);
    for (var c in o) ["default"].indexOf(c) < 0 && function (e) {
      n.d(t, e, function () {
        return o[e];
      });
    }(c);
    n(1091);
    var i,
      u = n(230),
      a = Object(u["default"])(o["default"], r["render"], r["staticRenderFns"], !1, null, null, null, !1, r["components"], i);
    a.options.__file = "components/make/make_showPrivacy.vue", t["default"] = a.exports;
  },
  1087: function _(e, t, n) {
    "use strict";

    n.r(t);
    var r = n(1088);
    n.d(t, "render", function () {
      return r["render"];
    }), n.d(t, "staticRenderFns", function () {
      return r["staticRenderFns"];
    }), n.d(t, "recyclableRender", function () {
      return r["recyclableRender"];
    }), n.d(t, "components", function () {
      return r["components"];
    });
  },
  1088: function _(e, t, n) {
    "use strict";

    var r;
    n.r(t), n.d(t, "render", function () {
      return o;
    }), n.d(t, "staticRenderFns", function () {
      return i;
    }), n.d(t, "recyclableRender", function () {
      return c;
    }), n.d(t, "components", function () {
      return r;
    });
    var o = function o() {
        var e = this,
          t = e.$createElement;
        e._self._c;
      },
      c = !1,
      i = [];
    o._withStripped = !0;
  },
  1089: function _(e, t, n) {
    "use strict";

    n.r(t);
    var r = n(1090),
      o = n.n(r);
    for (var c in r) ["default"].indexOf(c) < 0 && function (e) {
      n.d(t, e, function () {
        return r[e];
      });
    }(c);
    t["default"] = o.a;
  },
  1090: function _(e, t, n) {
    "use strict";

    (function (e, r) {
      var o = n(4);
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var c = o(n(11)),
        i = n(227);
      function u(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(e);
          t && (r = r.filter(function (t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
          })), n.push.apply(n, r);
        }
        return n;
      }
      function a(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2 ? u(Object(n), !0).forEach(function (t) {
            (0, c.default)(e, t, n[t]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : u(Object(n)).forEach(function (t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
          });
        }
        return e;
      }
      var s = {
        name: "makeShowPrivacy",
        computed: a({}, (0, i.mapState)(["showPrivacy_ysxy"])),
        data: function data() {
          return {};
        },
        mounted: function mounted() {
          e.hideTabBar(), e.hideLoading();
        },
        destroyed: function destroyed() {
          e.showTabBar();
        },
        methods: {
          noagree: function noagree() {
            this.$store.commit("setshowPrivacyYsxy", !1);
          },
          jumpAgreement: function jumpAgreement() {
            e.navigateTo({
              url: "/pages/webview/webview?url=https://pysq.stoss.shipook.com/static/html/yhxy_mini.html"
            });
          },
          handleOpenPrivacyContract: function handleOpenPrivacyContract() {
            r.openPrivacyContract({
              success: function success() {},
              fail: function fail() {
                e.showToast({
                  title: "打开《隐私协议》失败",
                  icon: "none"
                });
              }
            });
          },
          handleAgreePrivacyAuthorization: function handleAgreePrivacyAuthorization() {
            this.$store.commit("setshowPrivacyYsxy", !1);
          }
        }
      };
      t.default = s;
    }).call(this, n(2)["default"], n(1)["default"]);
  },
  1091: function _(e, t, n) {
    "use strict";

    n.r(t);
    var r = n(1092),
      o = n.n(r);
    for (var c in r) ["default"].indexOf(c) < 0 && function (e) {
      n.d(t, e, function () {
        return r[e];
      });
    }(c);
    t["default"] = o.a;
  },
  1092: function _(e, t, n) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['components/make/make_showPrivacy-create-component', {
  'components/make/make_showPrivacy-create-component': function componentsMakeMake_showPrivacyCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1086));
  }
}, [['components/make/make_showPrivacy-create-component']]]);