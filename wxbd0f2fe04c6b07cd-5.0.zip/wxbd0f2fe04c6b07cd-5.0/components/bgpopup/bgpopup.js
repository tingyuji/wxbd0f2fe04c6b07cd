(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["components/bgpopup/bgpopup"], {
  1440: function _(n, e, t) {
    "use strict";

    t.r(e);
    var r = t(1441),
      u = t(1443);
    for (var o in u) ["default"].indexOf(o) < 0 && function (n) {
      t.d(e, n, function () {
        return u[n];
      });
    }(o);
    t(1445);
    var c,
      i = t(230),
      d = Object(i["default"])(u["default"], r["render"], r["staticRenderFns"], !1, null, null, null, !1, r["components"], c);
    d.options.__file = "components/bgpopup/bgpopup.vue", e["default"] = d.exports;
  },
  1441: function _(n, e, t) {
    "use strict";

    t.r(e);
    var r = t(1442);
    t.d(e, "render", function () {
      return r["render"];
    }), t.d(e, "staticRenderFns", function () {
      return r["staticRenderFns"];
    }), t.d(e, "recyclableRender", function () {
      return r["recyclableRender"];
    }), t.d(e, "components", function () {
      return r["components"];
    });
  },
  1442: function _(n, e, t) {
    "use strict";

    var r;
    t.r(e), t.d(e, "render", function () {
      return u;
    }), t.d(e, "staticRenderFns", function () {
      return c;
    }), t.d(e, "recyclableRender", function () {
      return o;
    }), t.d(e, "components", function () {
      return r;
    });
    var u = function u() {
        var n = this,
          e = n.$createElement;
        n._self._c;
      },
      o = !1,
      c = [];
    u._withStripped = !0;
  },
  1443: function _(n, e, t) {
    "use strict";

    t.r(e);
    var r = t(1444),
      u = t.n(r);
    for (var o in r) ["default"].indexOf(o) < 0 && function (n) {
      t.d(e, n, function () {
        return r[n];
      });
    }(o);
    e["default"] = u.a;
  },
  1444: function _(n, e, t) {
    "use strict";

    (function (n) {
      Object.defineProperty(e, "__esModule", {
        value: !0
      }), e.default = void 0;
      var t = {
        methods: {
          readContent: function readContent() {
            n.setStorageSync("isread_bgtext", !0), this.$emit("read");
          }
        }
      };
      e.default = t;
    }).call(this, t(2)["default"]);
  },
  1445: function _(n, e, t) {
    "use strict";

    t.r(e);
    var r = t(1446),
      u = t.n(r);
    for (var o in r) ["default"].indexOf(o) < 0 && function (n) {
      t.d(e, n, function () {
        return r[n];
      });
    }(o);
    e["default"] = u.a;
  },
  1446: function _(n, e, t) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['components/bgpopup/bgpopup-create-component', {
  'components/bgpopup/bgpopup-create-component': function componentsBgpopupBgpopupCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1440));
  }
}, [['components/bgpopup/bgpopup-create-component']]]);