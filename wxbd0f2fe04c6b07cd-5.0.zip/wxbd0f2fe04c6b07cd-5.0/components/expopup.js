(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["components/expopup"], {
  1394: function _(e, t, n) {
    "use strict";

    n.r(t);
    var o = n(1395),
      r = n(1397);
    for (var i in r) ["default"].indexOf(i) < 0 && function (e) {
      n.d(t, e, function () {
        return r[e];
      });
    }(i);
    n(1399);
    var c,
      s = n(230),
      u = Object(s["default"])(r["default"], o["render"], o["staticRenderFns"], !1, null, null, null, !1, o["components"], c);
    u.options.__file = "components/expopup.vue", t["default"] = u.exports;
  },
  1395: function _(e, t, n) {
    "use strict";

    n.r(t);
    var o = n(1396);
    n.d(t, "render", function () {
      return o["render"];
    }), n.d(t, "staticRenderFns", function () {
      return o["staticRenderFns"];
    }), n.d(t, "recyclableRender", function () {
      return o["recyclableRender"];
    }), n.d(t, "components", function () {
      return o["components"];
    });
  },
  1396: function _(e, t, n) {
    "use strict";

    var o;
    n.r(t), n.d(t, "render", function () {
      return r;
    }), n.d(t, "staticRenderFns", function () {
      return c;
    }), n.d(t, "recyclableRender", function () {
      return i;
    }), n.d(t, "components", function () {
      return o;
    });
    try {
      o = {
        uIcon: function uIcon() {
          return Promise.all([n.e("common/vendor"), n.e("uni_modules/uview-ui/components/u-icon/u-icon")]).then(n.bind(null, 1431));
        }
      };
    } catch (s) {
      if (-1 === s.message.indexOf("Cannot find module") || -1 === s.message.indexOf(".vue")) throw s;
      console.error(s.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
    }
    var r = function r() {
        var e = this,
          t = e.$createElement;
        e._self._c;
      },
      i = !1,
      c = [];
    r._withStripped = !0;
  },
  1397: function _(e, t, n) {
    "use strict";

    n.r(t);
    var o = n(1398),
      r = n.n(o);
    for (var i in o) ["default"].indexOf(i) < 0 && function (e) {
      n.d(t, e, function () {
        return o[e];
      });
    }(i);
    t["default"] = r.a;
  },
  1398: function _(e, t, n) {
    "use strict";

    (function (e) {
      var o = n(4);
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var r = o(n(11)),
        i = n(227);
      function c(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var o = Object.getOwnPropertySymbols(e);
          t && (o = o.filter(function (t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
          })), n.push.apply(n, o);
        }
        return n;
      }
      function s(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2 ? c(Object(n), !0).forEach(function (t) {
            (0, r.default)(e, t, n[t]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach(function (t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
          });
        }
        return e;
      }
      var u = {
        computed: s({}, (0, i.mapState)(["showPrivacy_ysxy"])),
        props: {
          show_derive: {
            type: Boolean,
            default: !1
          },
          url: {
            type: String,
            default: ""
          },
          only_mp3: {
            type: Boolean,
            default: !1
          }
        },
        data: function data() {
          return {
            showMp3: !1,
            isexamine: !0
          };
        },
        watch: {
          show_derive: function show_derive(e) {
            console.log(this.show_derive, "---show_derive-");
          },
          only_mp3: {
            handler: function handler(e, t) {
              this.showMp3 = e, console.log("only_mp3", e, "oldVal", t);
            },
            deep: !0,
            immediate: !0
          }
        },
        mounted: function mounted() {
          this.isexamine = !getApp().globalData.isexamine;
        },
        methods: (0, r.default)({
          deriveWork: function deriveWork(e) {
            this.$parent.deriveWork(e);
          },
          closePopup: function closePopup() {
            this.$emit("close", !1);
          }
        }, "deriveWork", function (t) {
          var n = this;
          if (this.closePopup(), 0 == t) {
            e.showLoading({
              title: "加载中",
              mask: !0
            });
            var o = {
                mp3url: this.url
              },
              r = getApp().globalData.appApi + "/peiyin/ttschangemp4app",
              i = function i(t) {
                console.log(t), null != t.model ? getApp().downMp4ForAlbum(t.model.mp4url) : e.showToast({
                  title: "导出失败",
                  icon: "none"
                });
              };
            n.$http.postRequest(o, r, i);
          } else 1 == t ? e.setClipboardData({
            data: this.url,
            success: function success() {
              e.showModal({
                title: "复制链接成功",
                content: "复制成功，您可以在浏览器中粘贴该链接打开或者分享发送给好友",
                success: function success(e) {
                  e.confirm;
                }
              });
            }
          }) : 2 == t && e.downloadFile({
            url: this.url,
            success: function success(t) {
              200 === t.statusCode && e.saveFile({
                tempFilePath: t.tempFilePath,
                success: function success(t) {
                  var n = plus.io.convertLocalFileSystemURL(t.savedFilePath);
                  testModule.shareFilePath(n, function (t) {
                    e.showToast({
                      title: "导出 " + t,
                      icon: "none"
                    });
                  });
                }
              });
            }
          });
          this.$emit("change", !1);
        })
      };
      t.default = u;
    }).call(this, n(2)["default"]);
  },
  1399: function _(e, t, n) {
    "use strict";

    n.r(t);
    var o = n(1400),
      r = n.n(o);
    for (var i in o) ["default"].indexOf(i) < 0 && function (e) {
      n.d(t, e, function () {
        return o[e];
      });
    }(i);
    t["default"] = r.a;
  },
  1400: function _(e, t, n) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['components/expopup-create-component', {
  'components/expopup-create-component': function componentsExpopupCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1394));
  }
}, [['components/expopup-create-component']]]);