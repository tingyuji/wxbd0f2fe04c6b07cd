(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["components/work/file_item"], {
  1259: function _(e, t, n) {
    "use strict";

    n.r(t);
    var r = n(1260),
      i = n(1262);
    for (var u in i) ["default"].indexOf(u) < 0 && function (e) {
      n.d(t, e, function () {
        return i[e];
      });
    }(u);
    n(1264);
    var o,
      c = n(230),
      a = Object(c["default"])(i["default"], r["render"], r["staticRenderFns"], !1, null, null, null, !1, r["components"], o);
    a.options.__file = "components/work/file_item.vue", t["default"] = a.exports;
  },
  1260: function _(e, t, n) {
    "use strict";

    n.r(t);
    var r = n(1261);
    n.d(t, "render", function () {
      return r["render"];
    }), n.d(t, "staticRenderFns", function () {
      return r["staticRenderFns"];
    }), n.d(t, "recyclableRender", function () {
      return r["recyclableRender"];
    }), n.d(t, "components", function () {
      return r["components"];
    });
  },
  1261: function _(e, t, n) {
    "use strict";

    var r;
    n.r(t), n.d(t, "render", function () {
      return i;
    }), n.d(t, "staticRenderFns", function () {
      return o;
    }), n.d(t, "recyclableRender", function () {
      return u;
    }), n.d(t, "components", function () {
      return r;
    });
    var i = function i() {
        var e = this,
          t = e.$createElement;
        e._self._c;
      },
      u = !1,
      o = [];
    i._withStripped = !0;
  },
  1262: function _(e, t, n) {
    "use strict";

    n.r(t);
    var r = n(1263),
      i = n.n(r);
    for (var u in r) ["default"].indexOf(u) < 0 && function (e) {
      n.d(t, e, function () {
        return r[e];
      });
    }(u);
    t["default"] = i.a;
  },
  1263: function _(e, t, n) {
    "use strict";

    (function (e) {
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var n = {
        props: {
          batch_state: {
            type: Boolean,
            default: !1
          },
          item: {
            type: Object,
            default: {}
          },
          index: {
            type: Number,
            default: -1
          },
          parent_tab: {
            type: Number,
            default: 1
          }
        },
        methods: {
          openFileMore: function openFileMore() {
            this.batch_state || this.$emit("getFileMore", this.item);
          },
          jumpFileInfo: function jumpFileInfo() {
            if (!this.batch_state) {
              console.log(22222, this.item);
              var t = this;
              e.navigateTo({
                url: "/pages2/work/folder?id=" + this.item.folderid,
                success: function success(e) {
                  e.eventChannel.emit("acceptDataFromOpenerPage", t.item);
                }
              });
            }
          }
        }
      };
      t.default = n;
    }).call(this, n(2)["default"]);
  },
  1264: function _(e, t, n) {
    "use strict";

    n.r(t);
    var r = n(1265),
      i = n.n(r);
    for (var u in r) ["default"].indexOf(u) < 0 && function (e) {
      n.d(t, e, function () {
        return r[e];
      });
    }(u);
    t["default"] = i.a;
  },
  1265: function _(e, t, n) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['components/work/file_item-create-component', {
  'components/work/file_item-create-component': function componentsWorkFile_itemCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1259));
  }
}, [['components/work/file_item-create-component']]]);