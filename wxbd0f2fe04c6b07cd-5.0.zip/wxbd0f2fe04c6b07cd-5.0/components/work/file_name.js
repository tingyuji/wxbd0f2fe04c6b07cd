(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["components/work/file_name"], {
  1266: function _(n, e, t) {
    "use strict";

    t.r(e);
    var r = t(1267),
      u = t(1269);
    for (var o in u) ["default"].indexOf(o) < 0 && function (n) {
      t.d(e, n, function () {
        return u[n];
      });
    }(o);
    t(1271);
    var i,
      c = t(230),
      f = Object(c["default"])(u["default"], r["render"], r["staticRenderFns"], !1, null, null, null, !1, r["components"], i);
    f.options.__file = "components/work/file_name.vue", e["default"] = f.exports;
  },
  1267: function _(n, e, t) {
    "use strict";

    t.r(e);
    var r = t(1268);
    t.d(e, "render", function () {
      return r["render"];
    }), t.d(e, "staticRenderFns", function () {
      return r["staticRenderFns"];
    }), t.d(e, "recyclableRender", function () {
      return r["recyclableRender"];
    }), t.d(e, "components", function () {
      return r["components"];
    });
  },
  1268: function _(n, e, t) {
    "use strict";

    var r;
    t.r(e), t.d(e, "render", function () {
      return u;
    }), t.d(e, "staticRenderFns", function () {
      return i;
    }), t.d(e, "recyclableRender", function () {
      return o;
    }), t.d(e, "components", function () {
      return r;
    });
    var u = function u() {
        var n = this,
          e = n.$createElement;
        n._self._c;
      },
      o = !1,
      i = [];
    u._withStripped = !0;
  },
  1269: function _(n, e, t) {
    "use strict";

    t.r(e);
    var r = t(1270),
      u = t.n(r);
    for (var o in r) ["default"].indexOf(o) < 0 && function (n) {
      t.d(e, n, function () {
        return r[n];
      });
    }(o);
    e["default"] = u.a;
  },
  1270: function _(n, e, t) {
    "use strict";

    Object.defineProperty(e, "__esModule", {
      value: !0
    }), e.default = void 0;
    var r = {
      props: {
        mytype: {
          type: Number,
          default: 1
        }
      },
      mounted: function mounted() {
        console.log(99999, this.mytype);
      },
      methods: {
        rename: function rename() {
          this.$emit("rename");
        },
        remove: function remove() {
          this.$emit("remove");
        },
        hide: function hide() {
          this.$emit("hide");
        }
      }
    };
    e.default = r;
  },
  1271: function _(n, e, t) {
    "use strict";

    t.r(e);
    var r = t(1272),
      u = t.n(r);
    for (var o in r) ["default"].indexOf(o) < 0 && function (n) {
      t.d(e, n, function () {
        return r[n];
      });
    }(o);
    e["default"] = u.a;
  },
  1272: function _(n, e, t) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['components/work/file_name-create-component', {
  'components/work/file_name-create-component': function componentsWorkFile_nameCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1266));
  }
}, [['components/work/file_name-create-component']]]);