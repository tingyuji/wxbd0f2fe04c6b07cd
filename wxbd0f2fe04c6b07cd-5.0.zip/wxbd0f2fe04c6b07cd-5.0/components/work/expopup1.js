(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["components/work/expopup1"], {
  1301: function _(e, t, n) {
    "use strict";

    n.r(t);
    var i = n(1302),
      o = n(1304);
    for (var s in o) ["default"].indexOf(s) < 0 && function (e) {
      n.d(t, e, function () {
        return o[e];
      });
    }(s);
    n(1306);
    var r,
      a = n(230),
      c = Object(a["default"])(o["default"], i["render"], i["staticRenderFns"], !1, null, null, null, !1, i["components"], r);
    c.options.__file = "components/work/expopup1.vue", t["default"] = c.exports;
  },
  1302: function _(e, t, n) {
    "use strict";

    n.r(t);
    var i = n(1303);
    n.d(t, "render", function () {
      return i["render"];
    }), n.d(t, "staticRenderFns", function () {
      return i["staticRenderFns"];
    }), n.d(t, "recyclableRender", function () {
      return i["recyclableRender"];
    }), n.d(t, "components", function () {
      return i["components"];
    });
  },
  1303: function _(e, t, n) {
    "use strict";

    var i;
    n.r(t), n.d(t, "render", function () {
      return o;
    }), n.d(t, "staticRenderFns", function () {
      return r;
    }), n.d(t, "recyclableRender", function () {
      return s;
    }), n.d(t, "components", function () {
      return i;
    });
    var o = function o() {
        var e = this,
          t = e.$createElement,
          n = (e._self._c, 0 != e.tab ? e._f("format")(e.isfinish) : null);
        e._isMounted || (e.e0 = function (t) {
          e.tab = 0;
        }, e.e1 = function (t) {
          e.tab = 1;
        }, e.e2 = function (t) {
          e.tab = 2;
        }, e.e3 = function (t) {
          e.tab = 3;
        }), e.$mp.data = Object.assign({}, {
          $root: {
            f0: n
          }
        });
      },
      s = !1,
      r = [];
    o._withStripped = !0;
  },
  1304: function _(e, t, n) {
    "use strict";

    n.r(t);
    var i = n(1305),
      o = n.n(i);
    for (var s in i) ["default"].indexOf(s) < 0 && function (e) {
      n.d(t, e, function () {
        return i[e];
      });
    }(s);
    t["default"] = o.a;
  },
  1305: function _(e, t, n) {
    "use strict";

    (function (e, i) {
      var o = n(4);
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var s = o(n(255)),
        r = o(n(257)),
        a = o(n(11)),
        c = n(227),
        l = n(226);
      n(238);
      function u(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var i = Object.getOwnPropertySymbols(e);
          t && (i = i.filter(function (t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
          })), n.push.apply(n, i);
        }
        return n;
      }
      function f(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2 ? u(Object(n), !0).forEach(function (t) {
            (0, a.default)(e, t, n[t]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : u(Object(n)).forEach(function (t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
          });
        }
        return e;
      }
      var h = {
        computed: f({}, (0, c.mapState)(["select_work", "user_message", "app_config", "showPrivacy_ysxy"])),
        data: function data() {
          return {
            is_showpay: !0,
            tab: 0,
            link: "",
            show_copy_err: !1,
            timeNum: 1,
            ycwxflag: !1,
            asyncId: null,
            isfinish: "-1"
          };
        },
        mounted: function mounted() {
          var t = this;
          getApp().getUserInfo(function (n) {
            t.$store.commit("setUserMessage", n.model), e.hideLoading();
          }), this.is_showpay = getApp().isShowPay();
          var n = e.getSystemInfoSync().platform;
          "windows" != n && "mac" != n || (this.ycwxflag = !0, console.log("ycwxflag", this.ycwxflag));
        },
        unmounted: function unmounted() {
          e.hideLoading();
        },
        beforeDestroy: function beforeDestroy() {
          clearInterval(this.timerInfo), clearInterval(this.timerInfo2);
        },
        filters: {
          format: function format(e) {
            var t;
            return t = "0" == e ? "合成中" : "1" == e ? "合成失败" : "2" == e ? "已合成" : "未合成", t;
          }
        },
        methods: {
          swiperchange: function swiperchange(e) {
            var t = this;
            if (this.tab = e.detail.current, 0 != this.tab) {
              clearInterval(t.timerInfo2);
              var n,
                i = "1" === this.user_message.userrich.isvalidvip,
                o = "1" === this.user_message.userrich.isvalidsvip,
                s = "2" === this.select_work.exttype;
              if (i || o || s) 1 == this.tab ? n = {
                asyncType: "0",
                wkid: this.select_work.wkid
              } : 2 == this.tab ? n = {
                asyncType: "5",
                wkid: this.select_work.wkid
              } : 3 == this.tab && (n = {
                asyncType: "4",
                wkid: this.select_work.wkid
              }), (0, l.selectWkProcess)(n).then(function (e) {
                e.model ? e.model && e.model.asyncId && ("0" == e.model.processState ? (t.isfinish = "0", t.timer2 = !0, t.timerInfo2 = setInterval(function () {
                  t.asyncProcess2(e.model.asyncId).then(function (e) {
                    t.timer2 || clearInterval(t.timerInfo2);
                  });
                }, 3e3)) : "2" == e.model.processState ? t.isfinish = "2" : "1" == e.model.processState && (t.isfinish = "1")) : t.isfinish = "-1";
              });
            }
          },
          asyncProcess2: function asyncProcess2(e) {
            var t = this;
            return new Promise(function (n) {
              (0, l.selectProcess)({
                asyncId: e
              }).then(function (e) {
                n(e), "0" == e.model.processState ? t.isfinish = "0" : "1" == e.model.processState ? (t.timer2 = !1, t.isfinish = "1") : "2" == e.model.processState && (t.timer2 = !1, t.isfinish = "2");
              }).catch(function (e) {
                console.log("res2");
              });
            });
          },
          asyncProcess: function asyncProcess(e) {
            var t = this;
            return new Promise(function (n) {
              (0, l.selectProcess)({
                asyncId: t.asyncId
              }).then(function (i) {
                n(i), console.log("查询异步任务", i), "0" === i.rc && i.model[e] && (t.timer = !1);
              }).catch(function (e) {
                console.log("res2");
              });
            });
          },
          shareWx: function shareWx() {
            this.is_share = !0, 1 === this.tab ? (this.downloadMp4(), this.$uma_wx.trackEvent("extendWork", "导出MP4(不带字幕)-分享到微信")) : 2 === this.tab ? (this.showMp4GreenCurtain(), this.$uma_wx.trackEvent("extendWork", "导出MP4(带字幕)-分享到微信")) : 0 === this.tab ? (this.downloadMp3(), this.$uma_wx.trackEvent("extendWork", "导出MP3-分享到微信")) : 3 === this.tab && (this.getSrtFile(), this.$uma_wx.trackEvent("extendWork", "导出srt-分享到微信"));
          },
          shareFileMessage: function shareFileMessage(t, n) {
            var o = this;
            i.downloadFile({
              url: t,
              success: function success(t) {
                e.hideLoading(), 3 == n ? i.shareFileMessage({
                  filePath: t.tempFilePath,
                  fileName: o.select_work.wkname + new Date().getTime() + ".srt",
                  success: function success(e) {
                    console.log("分享成功", e);
                  },
                  fail: function fail(e) {
                    console.log("分享失败", e);
                  }
                }) : i.shareFileMessage({
                  filePath: t.tempFilePath,
                  fileName: o.select_work.wkname + new Date().getTime() + ".mp3",
                  success: function success(e) {
                    console.log("分享成功", e);
                  },
                  fail: function fail(e) {
                    console.log("分享失败", e);
                  }
                });
              }
            }), this.is_share = !1;
          },
          shareVideoMessage: function shareVideoMessage(t) {
            var n = this;
            return (0, r.default)(s.default.mark(function o() {
              return s.default.wrap(function (o) {
                while (1) switch (o.prev = o.next) {
                  case 0:
                    i.downloadFile({
                      url: t,
                      success: function success(t) {
                        e.hideLoading(), e.showModal({
                          title: "生成完成,开始分享",
                          success: function success(e) {
                            1 == e.confirm && i.shareVideoMessage({
                              videoPath: t.tempFilePath,
                              success: function success(e) {
                                console.log("分享成功", e);
                              },
                              fail: function fail(e) {
                                console.log("分享失败", e);
                              }
                            });
                          }
                        });
                      }
                    }), n.is_share = !1;
                  case 2:
                  case "end":
                    return o.stop();
                }
              }, o);
            }))();
          },
          copyLink: function copyLink() {
            0 === this.tab ? (this.copyPath(), this.$uma_wx.trackEvent("extendWork", "导出MP3-复制链接")) : 3 === this.tab ? (this.getSrtFile(), this.$uma_wx.trackEvent("extendWork", "导出srt-复制链接")) : 1 === this.tab ? (this.downloadMp4(!0), this.$uma_wx.trackEvent("extendWork", "下载mp4-复制链接")) : 2 === this.tab && (this.showMp4GreenCurtain(!0), this.$uma_wx.trackEvent("extendWork", "下载mp4带字幕-复制链接"));
          },
          downloadToPhone: function downloadToPhone() {
            1 === this.tab ? (this.downloadMp4(), this.$uma_wx.trackEvent("extendWork", "导出MP4(不带字幕)-下载到本地手机")) : 2 === this.tab ? (this.showMp4GreenCurtain(), this.$uma_wx.trackEvent("extendWork", "导出MP4(带字幕)-下载到本地手机")) : 0 === this.tab && (this.downloadMp3(), this.$uma_wx.trackEvent("extendWork", "导出MP3-下载到本地手机"));
          },
          downloadToAlbum: function downloadToAlbum() {
            1 === this.tab ? (this.downloadMp4(), this.$uma_wx.trackEvent("extendWork", "导出MP4(不带字幕)-下载到相册")) : 2 === this.tab && (this.showMp4GreenCurtain(), this.$uma_wx.trackEvent("extendWork", "导出MP4(带字幕)-下载到相册"));
          },
          hide: function hide() {
            this.$emit("hide");
          },
          importWork: function importWork() {
            var e = "1" === this.user_message.userrich.isvalidvip,
              t = "1" === this.user_message.userrich.isvalidsvip,
              n = "2" === this.select_work.exttype;
            return t || "1" !== this.select_work.feature ? !!(e || t || n) || (this.hide(), this.$emit("showVipTip", {
              is_gold: "0"
            }), !1) : (this.hide(), this.$emit("showVipTip", {
              is_gold: "1"
            }), !1);
          },
          getSrtFile: function getSrtFile() {
            var t = this;
            if (this.importWork()) {
              "2" == this.isfinish ? e.showLoading({
                title: "作品下载中...",
                mask: !0
              }) : this.$parent.show_export2 = !0;
              var n = {
                ossUrl: this.select_work.musicpath,
                format: "mp3",
                wkid: this.select_work.wkid
              };
              console.log("getSrtFile", n), (0, l.audioToSrt)(n).then(function () {
                var n = (0, r.default)(s.default.mark(function n(i) {
                  return s.default.wrap(function (n) {
                    while (1) switch (n.prev = n.next) {
                      case 0:
                        t.asyncId = i.model, t.timer = !0, t.timerInfo = setInterval(function () {
                          t.asyncProcess("fileUrl").then(function (n) {
                            if (t.timer || (t.timeNum = 1, clearInterval(t.timerInfo), t.$parent.show_export2 = !1), n.model.fileUrl) {
                              if (e.hideLoading(), t.is_share) return 3 == t.tab ? void e.showModal({
                                title: "字幕生成成功,是否分享到微信",
                                success: function success(e) {
                                  1 == e.confirm && t.shareFileMessage(n.model.fileUrl, 3);
                                }
                              }) : void t.shareFileMessage(n.model.fileUrl, null);
                              e.showModal({
                                title: "复制该链接粘贴至浏览器下载",
                                content: n.model.fileUrl,
                                confirmText: "复制链接",
                                success: function success(i) {
                                  i.confirm && e.setClipboardData({
                                    data: n.model.fileUrl,
                                    success: function success() {
                                      console.log("success");
                                    },
                                    fail: function fail(e) {
                                      console.log("err", e), t.link = n.model.fileUrl, t.show_copy_err = !0;
                                    }
                                  });
                                }
                              });
                            }
                          });
                        }, 3e3);
                      case 3:
                      case "end":
                        return n.stop();
                    }
                  }, n);
                }));
                return function (e) {
                  return n.apply(this, arguments);
                };
              }());
            }
          },
          jumpCourseForMp3: function jumpCourseForMp3() {
            e.navigateTo({
              url: "/pages/webview/webview?url=https://pysq.stoss.shipook.com/sharepage/export/v1/index.html"
            });
          },
          downloadMp3: function downloadMp3() {
            if (this.importWork()) {
              var e = this.select_work.wkname.replace(/[\'\"\\\/\b\f\n\r\t\?\&]/g, "");
              this.is_share ? this.shareFileMessage(this.select_work.musicpath, null) : this.getMp3ByWxApi(this.select_work.musicpath, this.app_config.name + e + "-" + Date.parse(new Date()) / 1e3 + ".mp3");
            }
          },
          copyPath: function copyPath() {
            var t = this;
            this.importWork() && e.setClipboardData({
              data: this.select_work.musicpath,
              success: function success(t) {
                e.hideToast({}), e.showModal({
                  title: "复制链接成功",
                  showCancel: !1,
                  content: "复制成功，您可以在浏览器中粘贴该链接下载"
                });
              },
              fail: function fail(e) {
                console.log("err", e), t.link = t.select_work.musicpath, t.show_copy_err = !0;
              }
            });
          },
          downloadMp42: function downloadMp42() {
            var t = this,
              n = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            if (this.importWork()) {
              var i = {
                mp3url: this.select_work.musicpath,
                greenVideo: "1"
              };
              (0, l.ttsChangeMp4)(i).then(function (i) {
                if (!t.is_share) return 1 == n ? (e.hideLoading(), void e.showModal({
                  title: "复制该链接粘贴至浏览器下载",
                  content: i.model.mp4url,
                  confirmText: "复制链接",
                  success: function success(n) {
                    n.confirm && e.setClipboardData({
                      data: i.model.mp4url,
                      success: function success() {
                        console.log("success");
                      },
                      fail: function fail(e) {
                        console.log("err", e), t.link = i.model.mp4url, t.show_copy_err = !0;
                      }
                    });
                  }
                })) : void t.getMp4ByWxApi(i.model.mp4url);
                t.shareVideoMessage(i.model.mp4url);
              });
            }
          },
          downloadMp4: function downloadMp4() {
            var t = this,
              n = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            if (this.importWork()) {
              "2" == this.isfinish ? e.showLoading({
                title: "作品下载中...",
                mask: !0
              }) : this.$parent.show_export2 = !0;
              var i = {
                mp3url: this.select_work.musicpath,
                greenVideo: "1",
                wkid: this.select_work.wkid
              };
              console.log("showMp4GreenCurtain", i), (0, l.ttschangemp4appv2)(i).then(function () {
                var i = (0, r.default)(s.default.mark(function i(o) {
                  return s.default.wrap(function (i) {
                    while (1) switch (i.prev = i.next) {
                      case 0:
                        if (console.log("下载MP4到相册（不带文字）", o), o.model) {
                          i.next = 5;
                          break;
                        }
                        return e.hideLoading(), e.showToast({
                          title: "下载失败",
                          icon: "none"
                        }), i.abrupt("return");
                      case 5:
                        t.asyncId = o.model, t.timer = !0, t.timerInfo = setInterval(function () {
                          t.asyncProcess("fileUrl").then(function (i) {
                            if (t.timer || (t.timeNum = 1, clearInterval(t.timerInfo), t.$parent.show_export2 = !1), i.model.fileUrl) {
                              if (e.hideLoading(), t.is_share) return void t.shareVideoMessage(i.model.fileUrl);
                              if (1 == n) return void e.showModal({
                                title: "复制该链接粘贴至浏览器下载",
                                content: i.model.fileUrl,
                                confirmText: "复制链接",
                                success: function success(n) {
                                  n.confirm && e.setClipboardData({
                                    data: i.model.fileUrl,
                                    success: function success() {
                                      console.log("success");
                                    },
                                    fail: function fail(e) {
                                      console.log("err", e), t.link = i.model.fileUrl, t.show_copy_err = !0;
                                    }
                                  });
                                }
                              });
                              t.getMp4ByWxApi(i.model.fileUrl);
                            }
                          });
                        }, 3e3);
                      case 8:
                      case "end":
                        return i.stop();
                    }
                  }, i);
                }));
                return function (e) {
                  return i.apply(this, arguments);
                };
              }());
            }
          },
          showMp4GreenCurtain: function showMp4GreenCurtain() {
            var t = this,
              n = arguments.length > 0 && void 0 !== arguments[0] && arguments[0];
            if (this.importWork()) {
              "2" == this.isfinish ? e.showLoading({
                title: "作品下载中...",
                mask: !0
              }) : this.$parent.show_export2 = !0;
              var i = {
                ossUrl: this.select_work.musicpath,
                wkid: this.select_work.wkid
              };
              console.log("showMp4GreenCurtain", i), (0, l.ttsChangeMp4V2)(i).then(function () {
                var i = (0, r.default)(s.default.mark(function i(o) {
                  return s.default.wrap(function (i) {
                    while (1) switch (i.prev = i.next) {
                      case 0:
                        if (console.log("下载MP4到相册（绿幕带文字）", o), o.model) {
                          i.next = 5;
                          break;
                        }
                        return e.hideLoading(), e.showToast({
                          title: "下载失败",
                          icon: "none"
                        }), i.abrupt("return");
                      case 5:
                        t.asyncId = o.model, t.timer = !0, t.timerInfo = setInterval(function () {
                          t.asyncProcess("resultUrl").then(function (i) {
                            if (t.timer || (t.timeNum = 1, clearInterval(t.timerInfo), t.$parent.show_export2 = !1), i.model.resultUrl) {
                              if (e.hideLoading(), t.is_share) return void t.shareVideoMessage(i.model.resultUrl);
                              if (1 == n) return void e.showModal({
                                title: "复制该链接粘贴至浏览器下载",
                                content: i.model.resultUrl,
                                confirmText: "复制链接",
                                success: function success(n) {
                                  n.confirm && e.setClipboardData({
                                    data: i.model.resultUrl,
                                    success: function success() {
                                      console.log("success");
                                    },
                                    fail: function fail(e) {
                                      console.log("err", e), t.link = i.model.resultUrl, t.show_copy_err = !0;
                                    }
                                  });
                                }
                              });
                              t.getMp4ByWxApi(i.model.resultUrl);
                            }
                          });
                        }, 3e3);
                      case 8:
                      case "end":
                        return i.stop();
                    }
                  }, i);
                }));
                return function (e) {
                  return i.apply(this, arguments);
                };
              }());
            }
          },
          getMp4ByWxApi: function getMp4ByWxApi(t) {
            var n = e.getStorageSync("device");
            "windows" != n.platform ? (e.showLoading({
              title: "下载中...",
              mask: !0
            }), e.downloadFile({
              url: t,
              success: function success(t) {
                var n = t.tempFilePath;
                e.saveVideoToPhotosAlbum({
                  filePath: n,
                  success: function success(t) {
                    e.hideLoading({}), e.showToast({
                      title: "成功保存至相册"
                    });
                  },
                  fail: function fail(t) {
                    e.hideLoading({}), e.getSetting({
                      success: function success(t) {
                        t.authSetting["scope.writePhotosAlbum"] ? e.showToast({
                          title: "您取消了保存",
                          icon: "none"
                        }) : e.showModal({
                          title: "音频下载失败",
                          content: "您拒绝了微信授权访问相册，所以未能成功下载保存到您的相册，请在接下来的设置页面开启【保存到相册】选项再试一次~",
                          showCancel: !1,
                          confirmText: "知道了",
                          confirmColor: "#1482ff",
                          success: function success(t) {
                            t.confirm && e.openSetting();
                          }
                        });
                      }
                    });
                  }
                });
              }
            })) : this.getMp4ByWindows(t);
          },
          getMp3ByWxApi: function getMp3ByWxApi(t, n) {
            var i = this;
            e.getStorageSync("device") || e.getSystemInfo({
              complete: function complete(t) {
                e.setStorageSync("device", t);
              }
            });
            var o = e.getStorageSync("device");
            e.showLoading({
              title: "下载中...",
              mask: !0
            }), e.downloadFile({
              url: t,
              header: {
                "content-type": "application/json"
              },
              filePath: "wxfile://usr/" + n,
              success: function success(t) {
                "windows" != o.platform ? (e.hideLoading({}), e.showModal({
                  title: "音频下载成功",
                  content: "文件位置：内部存储->tencent->MicroMsg->wxanewfiles，在此目录搜索【".concat(i.app_config.name, "】；如果找不到，请在手机【内部存储】或【文件管理】中，使用搜索（或深度搜索）关键词【").concat(i.app_config.name, "】即可找到音频文件。（不同品牌手机略有差别）"),
                  showCancel: !1,
                  confirmText: "知道了",
                  confirmColor: "#1482ff"
                })) : e.saveFileToDisk ? e.saveFileToDisk({
                  filePath: "wxfile://usr/" + n,
                  success: function success() {
                    e.showToast({
                      title: "保存成功"
                    });
                  },
                  fail: function fail() {
                    e.showToast({
                      title: "取消保存...",
                      icon: "none"
                    });
                  }
                }) : (e.hideLoading({}), e.showModal({
                  title: "提示",
                  content: "当前微信版本过低，无法使用该功能，请在微信界面点击左下角【 ☰-设置-关于微信-检查更新 】升级到最新微信版本后重试。"
                }));
              },
              fail: function fail(t) {
                e.showToast({
                  icon: "none",
                  title: "文件下载失败"
                });
              }
            });
          },
          getMp4ByWindows: function getMp4ByWindows(t) {
            e.showLoading({
              title: "下载中..."
            }), e.downloadFile({
              url: t,
              success: function success(t) {
                e.saveFileToDisk ? e.saveFileToDisk({
                  filePath: t.tempFilePath,
                  success: function success() {
                    e.showToast({
                      title: "保存成功"
                    });
                  },
                  fail: function fail(t) {
                    console.log("保存失败", t), e.showToast({
                      title: "取消保存...",
                      icon: "none"
                    });
                  }
                }) : (e.hideLoading({}), e.showModal({
                  title: "提示",
                  content: "当前微信版本过低，无法使用该功能，请在微信界面点击左下角【 ☰-设置-关于微信-检查更新 】升级到最新微信版本后重试。"
                }));
              },
              fail: function fail(e) {
                console.log("导出失败", e);
              }
            });
          }
        }
      };
      t.default = h;
    }).call(this, n(2)["default"], n(1)["default"]);
  },
  1306: function _(e, t, n) {
    "use strict";

    n.r(t);
    var i = n(1307),
      o = n.n(i);
    for (var s in i) ["default"].indexOf(s) < 0 && function (e) {
      n.d(t, e, function () {
        return i[e];
      });
    }(s);
    t["default"] = o.a;
  },
  1307: function _(e, t, n) {}
}]);;(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['components/work/expopup1-create-component', {
  'components/work/expopup1-create-component': function componentsWorkExpopup1CreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1301));
  }
}, [['components/work/expopup1-create-component']]]);