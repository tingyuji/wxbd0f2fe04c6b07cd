(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["common/main"], {
  0: function _(e, t, o) {
    "use strict";

    (function (e, t) {
      var a = o(4),
        n = a(o(11));
      o(26);
      var i = a(o(25)),
        s = a(o(27)),
        l = a(o(31)),
        r = a(o(231)),
        c = a(o(236)),
        p = a(o(237)),
        u = a(o(225)),
        d = a(o(358));
      function f(e, t) {
        var o = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var a = Object.getOwnPropertySymbols(e);
          t && (a = a.filter(function (t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
          })), o.push.apply(o, a);
        }
        return o;
      }
      function g(e) {
        for (var t = 1; t < arguments.length; t++) {
          var o = null != arguments[t] ? arguments[t] : {};
          t % 2 ? f(Object(o), !0).forEach(function (t) {
            (0, n.default)(e, t, o[t]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(o)) : f(Object(o)).forEach(function (t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(o, t));
          });
        }
        return e;
      }
      e.__webpack_require_UNI_MP_PLUGIN__ = o;
      var m = function m() {
        o.e("components/make/make_showPrivacy").then(function () {
          return resolve(o(1086));
        }.bind(null, o)).catch(o.oe);
      };
      i.default.config.productionTip = !1, s.default.mpType = "app";
      var b = e.getAccountInfoSync();
      "release" === b.miniProgram.envVersion && (console.log = function () {}), i.default.prototype.$log = function (e, t) {
        console.log("[".concat(t || new Date().getTime(), "] -- "), e);
      }, i.default.component("makeShowPrivacy", m), i.default.prototype.$http = l.default, i.default.mixin(c.default), i.default.use(p.default), d.default.init({
        appKey: u.default.um_key ? u.default.um_key : "",
        autoGetOpenid: !1,
        useOpenid: !1,
        debug: !1,
        uploadUserInfo: !0
      }), d.default.install = function (e) {
        e.prototype.$uma_wx = d.default;
      }, i.default.use(d.default);
      var h = new i.default(g({
        store: r.default
      }, s.default));
      t(h).$mount();
    }).call(this, o(1)["default"], o(2)["createApp"]);
  },
  228: function _(e, t, o) {
    "use strict";

    o.r(t);
    var a = o(229),
      n = o.n(a);
    for (var i in a) ["default"].indexOf(i) < 0 && function (e) {
      o.d(t, e, function () {
        return a[e];
      });
    }(i);
    t["default"] = n.a;
  },
  229: function _(e, t, o) {},
  27: function _(e, t, o) {
    "use strict";

    o.r(t);
    var a = o(28);
    for (var n in a) ["default"].indexOf(n) < 0 && function (e) {
      o.d(t, e, function () {
        return a[e];
      });
    }(n);
    o(228);
    var i,
      s,
      l,
      r,
      c = o(230),
      p = Object(c["default"])(a["default"], i, s, !1, null, null, null, !1, l, r);
    p.options.__file = "App.vue", t["default"] = p.exports;
  },
  28: function _(e, t, o) {
    "use strict";

    o.r(t);
    var a = o(29),
      n = o.n(a);
    for (var i in a) ["default"].indexOf(i) < 0 && function (e) {
      o.d(t, e, function () {
        return a[e];
      });
    }(i);
    t["default"] = n.a;
  },
  29: function _(e, t, o) {
    "use strict";

    (function (e, a) {
      var n = o(4);
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var i = n(o(13)),
        s = (n(o(30)), n(o(31))),
        l = n(o(225)),
        r = o(226),
        c = (o(227), {
          globalData: {
            baseApi: "https://pysq.shipook.com/v2base",
            appApi: "https://pysq.shipook.com/v2app",
            app_url: {},
            base_url: {
              getsmscode: "/common/getsmscode",
              login4wechat: "/thirdlogin/login4wechat",
              login4zjtd: "/thirdlogin/login4zjtd",
              login4baidu: "/thirdlogin/login4baidu",
              userlogin: "/user/userlogin",
              qryuserallinfo: "/user/qryuserallinfo",
              cashorder: "/business/cashorder",
              openvip: "/business/openvip",
              bootup: "/common/bootup",
              updatedeviceinfo: "/common/updatedeviceinfo",
              getbusupgradeinfo: "/busupgrade/getbusupgradeinfo",
              qryuserjbviplist: "/business/qryuserjbviplist"
            },
            tab_work: 0,
            qd: "",
            ver: "010009",
            sec: "48a0088cb506e6b7",
            aaa: "",
            bbb: "",
            deviceId: "",
            wxappid: "",
            userinfo: null,
            crgid: "",
            parentid: "",
            deviceMac: "",
            oaid: "",
            ss: "",
            showPay: !0,
            freetype: null,
            vipList: [],
            svip_char: {},
            ios_status: 1,
            tts_text: "",
            ishidetype: "",
            heimingdan0: "",
            heimingdan1: "",
            heimingdan2: "",
            systemInfo: null,
            timeInfo: 0
          },
          onLaunch: function onLaunch() {
            var t = this;
            this.$store.commit("setAppConfig", l.default), 1154 === e.getLaunchOptionsSync().scene && (a.setStorageSync("ispyq", !0), a.switchTab({
              url: "/pages/make/make?pyq=1"
            }));
            var o = e.getUpdateManager();
            o.onCheckForUpdate(function (e) {
              if (!e.hasUpdate) return !1;
              o.onUpdateReady(function () {
                o.applyUpdate();
              });
            }), a.setInnerAudioOption({
              obeyMuteSwitch: !1
            }), a.getSystemInfo({
              complete: function complete(e) {
                a.setStorageSync("device", e), t.globalData.systemInfo = e;
              }
            }), this.globalData.aaa = this.globalData.sec.split("").reverse().join(""), this.globalData.bbb = this.globalData.sec.substr(1) + this.globalData.sec.substr(0, 1), this.setQd(l.default.qd), this.getPhoneId(), this.start_Up();
          },
          onShow: function onShow() {
            (a.getStorageSync("sid") || a.getStorageSync("uid")) && this.getUserInfo(function (e) {});
          },
          onHide: function onHide() {},
          methods: {
            commonencry: function commonencry() {
              return JSON.stringify(s.default.getEncryption());
            },
            findpyblack: function findpyblack() {
              var e = this,
                t = e.globalData.appApi + "/peiyin/findpyblack";
              s.default.postRequest({}, t, function (t) {
                if (t.model) for (var o = t.model.split(","), a = 0; a < o.length; a++) "0" == o[a] ? (e.globalData.heimingdan0 = !0, e.$store ? e.$store.commit("setheimingdan0", e.globalData.heimingdan0) : e.$vm.$store.commit("setheimingdan0", e.globalData.heimingdan0)) : "1" == o[a] ? e.globalData.heimingdan1 = !0 : "2" == o[a] && (e.globalData.heimingdan2 = !0);
              });
            },
            examineText: function examineText(e, t) {
              var o = this;
              return new Promise(function (n, i) {
                var l = o.globalData.appApi + "/security/green/text";
                s.default.postRequest({
                  text: e
                }, l, function (e) {
                  console.log("文本检查结果", e), "0" !== e.rc && n(!0);
                  var o = {
                    10001: " 广告",
                    20001: "时政",
                    20002: "色情",
                    20003: "辱骂",
                    20006: "违法犯罪",
                    20008: "欺诈",
                    20012: "低俗",
                    20013: "版权",
                    21e3: "其他"
                  };
                  o[e.model.label] ? (a.showModal({
                    title: "提示",
                    content: "文本内容包含".concat(o[e.model.label] ? o[e.model.label] : "", "相关违规文字信息，请修改后重新操作"),
                    cancelText: "联系客服",
                    success: function success(e) {
                      e.confirm ? t && t() : e.cancel && a.navigateTo({
                        url: "/pages/wode/kefu/kefu"
                      });
                    }
                  }), n(!1)) : n(!0);
                });
              });
            },
            examineImg: function examineImg(e, t) {
              var o = this;
              return new Promise(function (n, i) {
                var l = o.globalData.appApi + "/peiyin/wxurllink/examinewximg",
                  r = {
                    url: e
                  };
                s.default.postRequest(r, l, function (e) {
                  "0" !== e.rc && n(!0), console.log("图片检查结果", e);
                  var o = JSON.parse(e.model),
                    i = o.errcode;
                  0 !== i && a.showModal({
                    title: "提示",
                    content: "该图片存在敏感信息，暂无法使用，如有疑问，请联系客服处理",
                    cancelText: "联系客服",
                    success: function success(e) {
                      e.confirm ? t && t() : e.cancel && a.switchTab({
                        url: "/pages/mine/mine"
                      });
                    }
                  }), n(0 === i);
                });
              });
            },
            isShowPay: function isShowPay() {
              var e = a.getStorageSync("device").platform;
              return "ios" !== e && "devtools" != e;
            },
            downMp4ForAlbum: function downMp4ForAlbum(e) {
              console.log("导出MP4", e), a.downloadFile({
                url: e,
                success: function success(e) {
                  console.log("res", e), 200 === e.statusCode && (a.hideLoading(), a.saveVideoToPhotosAlbum({
                    filePath: e.tempFilePath,
                    success: function success() {
                      a.showModal({
                        title: "导出成功",
                        content: "前往相册查看"
                      });
                    }
                  }));
                }
              });
            },
            qryApiLimit: function qryApiLimit(e) {
              var t = this;
              return new Promise(function (o, a) {
                var n = {
                    apiType: e,
                    isVip: t.globalData.userinfo.userrich.isvalidvip
                  },
                  i = t.globalData.appApi + "/peiyin/qryapilimitapp";
                console.log("json", n), console.log("url", i), s.default.postRequest(n, i, function (e) {
                  console.log("api剩余次数", e), o(e);
                });
              });
            },
            updateApiLimit: function updateApiLimit(e) {
              var t = {
                  apiType: e,
                  isVip: this.globalData.userinfo.userrich.isvalidvip
                },
                o = this.globalData.appApi + "/peiyin/uptapilimitapp";
              s.default.postRequest(t, o, function (e) {
                console.log("api更新次数", e);
              });
            },
            setOssPath: function setOssPath(e, t, o) {
              a.uploadFile({
                url: this.globalData.appApi + "/peiyin/music/univerupload",
                filePath: e,
                name: "file",
                formData: {
                  isrestrict: "0",
                  catalogue: t,
                  osstype: "1",
                  comparam: getApp().commonencry()
                },
                success: function success(e) {
                  console.log("上传本地文件到oss", e), o(JSON.parse(e.data).model);
                },
                fail: function fail(e) {
                  a.showToast({
                    title: "图片上传失败！",
                    icon: "none"
                  }), o("fail");
                }
              });
            },
            generatePoster: function generatePoster(e) {
              var t = {
                req: JSON.stringify({
                  qd: this.globalData.qd,
                  ver: this.globalData.ver,
                  sceneStr: this.globalData.userinfo.userinfo.id,
                  page: "pages/make/make"
                })
              };
              console.log("生成分享二维码", t);
              var o = this.globalData.appApi + "/wxgetqrcode";
              a.request({
                url: o,
                method: "POST",
                header: {
                  "content-type": "application/x-www-form-urlencoded",
                  cookie: "SESSION=" + (a.getStorageSync("sid") ? a.getStorageSync("sid") : "")
                },
                data: t,
                success: function success(t) {
                  e(t);
                }
              });
            },
            getShare: function getShare(e) {
              var t = this;
              (e.parentid || e.scene) && setTimeout(function () {
                var o = e.parentid;
                if (e.scene && (o = decodeURIComponent(e.scene)), o) {
                  t.globalData.parentid = o;
                  var n = {
                      parentid: o
                    },
                    i = getApp().globalData.baseApi + "/user/bindparent";
                  s.default.postRequest(n, i, function (e) {
                    console.log("分享绑定", e), a.showToast({
                      title: "绑定上级成功",
                      icon: "none",
                      duration: 2e3
                    }), getApp().getUserInfo(function (e) {});
                  }, function (e) {
                    if (console.log("绑定失败aaaa", e), "1501" == e.rc) a.showToast({
                      title: "您已绑定过上级，不可再次绑定",
                      icon: "none",
                      duration: 2e3
                    });else {
                      var t = e.rd;
                      a.showToast({
                        title: t,
                        icon: "none",
                        duration: 2e3
                      });
                    }
                  });
                }
              }, 1e3);
            },
            getbdKF: function getbdKF() {
              l.default.kfurl && e.openCustomerServiceChat({
                extInfo: {
                  url: l.default.kfurl
                },
                corpId: l.default.kfcorpId,
                showMessageCard: !0,
                sendMessageTitle: "请稍等，客服马上就到(" + this.globalData.userinfo.userinfo.id + ")",
                sendMessageImg: "https://pysqstoss.shipook.com/imgs/20220117/202306011h.png"
              });
            },
            copyObj: function copyObj(e) {
              var t = null;
              if ("object" == (0, i.default)(e) && null !== e) for (var o in t = e instanceof Array ? [] : {}, e) t[o] = this.copyObj(e[o]);else t = e;
              return t;
            },
            getLocation: function getLocation(e) {
              a.getLocation({
                type: "gcj02",
                success: function success(t) {
                  var o = t.latitude,
                    a = t.longitude;
                  console.log(t);
                  var n = {
                      lng: a,
                      lat: o
                    },
                    i = getApp().globalData.baseApi + "/common/getprovince";
                  s.default.postRequest(n, i, function (t) {
                    console.log("通过经纬度获取地址", t), e(t);
                  });
                },
                fail: function fail(t) {
                  e("fail"), a.showToast({
                    title: "获取位置信息失败！",
                    icon: "none"
                  }), console.log("获取位置失败", t);
                }
              });
            },
            setUserInfo: function setUserInfo(e, t) {
              console.log("用户信息2222", e), l.default.free && (e.model.userrich.isvalidsvip = "1"), a.setStorageSync("uid", e.model.userinfo.uid), a.setStorageSync("did", e.model.userinfo.did), this.$store ? this.$store.commit("setUserMessage", e.model) : this.$vm.$store.commit("setUserMessage", e.model), getApp().globalData.userinfo = e.model, t(e);
            },
            wxLogin: function wxLogin(e) {
              a.login({
                provider: "weixin",
                success: function success(t) {
                  var o = {
                      isbind: "0",
                      code: t.code
                    },
                    n = getApp().globalData.baseApi + getApp().globalData.base_url.login4wechat,
                    i = function i(t) {
                      a.setStorageSync("sid", t.model.userinfo.sid), getApp().setUserInfo(t, e);
                    };
                  s.default.postRequest(o, n, i);
                }
              });
            },
            disposeNewUser: function disposeNewUser(e, t) {
              var o = this,
                n = new Date(e.ctime).getTime(),
                i = new Date().getTime(),
                l = i - n,
                r = 6048e5;
              "用户" === e.nickname && l <= r && a.showModal({
                title: "提示",
                content: "需要获取您的微信昵称与头像用于完善资料显示，是否同意获取？",
                success: function success(e) {
                  e.confirm && a.getUserProfile({
                    desc: "用于完善资料显示",
                    success: function success(e) {
                      var a = {
                          nickname: e.userInfo.nickName,
                          avatar: e.userInfo.avatarUrl
                        },
                        n = o.globalData.baseApi + "/user/updateuserinfo";
                      s.default.postRequest(a, n, function (e) {
                        t && t();
                      });
                    }
                  });
                }
              });
            },
            getUserInfo: function getUserInfo(e) {
              var t = this,
                o = this.globalData.baseApi + this.globalData.base_url.qryuserallinfo;
              s.default.postRequest({}, o, function (o) {
                console.log("获取用户信息", o), t.setUserInfo(o, e);
              });
            },
            getPay: function getPay(e, t, o, n, i, l, r) {
              a.showLoading({
                title: "加载中",
                mask: !0
              });
              var c = this,
                p = 10 * Number(o).toFixed(2),
                u = {
                  crgtype: 2,
                  paytype: e,
                  ordername: t,
                  jb: p,
                  rmb: o,
                  orderid: i,
                  ordertype: n,
                  extdata: l,
                  ish5: 3
                };
              console.log(u);
              var d = this.globalData.baseApi + this.globalData.base_url.cashorder;
              this.globalData.crgid = "";
              var f = function f(t) {
                c.callPay(e, t, r);
              };
              s.default.postRequest(u, d, f);
            },
            getVip: function getVip(e, t, o, n, i, l) {
              a.showLoading({
                title: "加载中",
                mask: !0
              });
              var r = this,
                c = {
                  viptype: e,
                  sviptype: t,
                  paytype: o,
                  time: n,
                  extdata: i,
                  ish5: 3
                };
              console.log("开通会员", c);
              var p = this.globalData.baseApi + this.globalData.base_url.openvip,
                u = function u(e) {
                  r.callPay(o, e, l);
                };
              s.default.postRequest(c, p, u);
            },
            callPay: function callPay(e, t, o) {
              2 == e && t.model.orderparams4webchat ? this.wxPayForMp(t, o) : 1 == e && t.model.orderstr4alipay;
            },
            wxPayForApp: function wxPayForApp(e, t) {
              var o = this;
              a.requestPayment({
                provider: "wxpay",
                orderInfo: e.model.orderparams4webchat,
                success: function success(e) {
                  o.getUserInfo(), a.hideLoading(), t(e);
                },
                fail: function fail(e) {
                  a.hideLoading(), a.showToast({
                    title: "支付失败",
                    icon: "none"
                  });
                }
              });
            },
            wxPayForMp: function wxPayForMp(e, t) {
              var o = this;
              a.requestPayment({
                provider: "wxpay",
                timeStamp: e.model.orderparams4webchat.timestamp,
                nonceStr: e.model.orderparams4webchat.noncestr,
                package: "prepay_id=" + e.model.orderparams4webchat.prepayid,
                signType: "MD5",
                paySign: e.model.orderparams4webchat.sign,
                success: function success(e) {
                  o.getUserInfo(), a.hideLoading(), t(e);
                },
                fail: function fail(e) {
                  a.hideLoading();
                }
              });
            },
            aliPayForApp: function aliPayForApp(e, t) {
              var o = this;
              a.requestPayment({
                provider: "alipay",
                orderInfo: e.model.orderstr4alipay,
                success: function success(e) {
                  o.getUserInfo(), a.hideLoading(), t(e);
                },
                fail: function fail(e) {
                  a.hideLoading(), a.showToast({
                    title: "支付失败",
                    icon: "none"
                  });
                }
              });
            },
            zjPayForMp: function zjPayForMp(e, t) {},
            setQd: function setQd(e) {
              var t = "";
              t = this.globalData.systemInfo ? this.globalData.systemInfo.platform : a.getSystemInfoSync().platform, console.log("bradn", t), this.globalData.qd = "ios" == t || "devtools1" == t ? "2" + e.slice(1) : e, console.log("渠道号", this.globalData.qd);
            },
            start_Up: function start_Up() {
              var e,
                t = this,
                o = new Date().toLocaleDateString();
              e = a.getStorageSync("active") ? a.getStorageSync("active") == o ? "0" : "2" : "1";
              var n = {
                  active: e
                },
                i = t.globalData.baseApi + t.globalData.base_url.bootup;
              s.default.postRequest(n, i, function (e) {
                console.log("合肥阅舟科技-设备启动信息", e), t.globalData.appcfg = e.model.appcfg ? JSON.parse(e.model.appcfg) : {}, t.globalData.freetype = e.model.appcfg ? JSON.parse(e.model.appcfg).freetype : "0", t.globalData.svip_char = t.globalData.appcfg.svip_char, t.globalData.vipList = e.model.jbviplist, t.globalData.zifubao = JSON.parse(e.model.appcfg).zifubao, e.model.appcfg && (JSON.parse(e.model.appcfg).iospay ? t.globalData.iospay = JSON.parse(e.model.appcfg).iospay : t.globalData.iospay = 1, JSON.parse(e.model.appcfg).hideiospay ? t.globalData.hideiospay = JSON.parse(e.model.appcfg).hideiospay : t.globalData.hideiospay = 1), t.hidearea(), t.findpyblack(), a.setStorageSync("active", o);
              });
              var l = t.globalData.baseApi + "/business/qujbl";
              s.default.postRequest({}, l, function (e) {
                console.log("获取配置信息", e), t.globalData.isexamine = "1" === e.model.isexm, t.globalData.iswcp = e.model.iswcp, a.$emit("qryttscfg");
              });
            },
            hidearea: function hidearea() {
              var e = this,
                t = {
                  functype: "0"
                },
                o = e.globalData.baseApi + "/business/qryshieldfunc";
              s.default.postRequest(t, o, function (t) {
                var o;
                console.log("屏蔽地区", t), o = "0" == t.rc && t.model.iospay ? t.model.iospay : "1", e.globalData.ishidetype = o, e.globalData.ios_status = "1" == o ? e.globalData.hideiospay : "0" == o ? e.globalData.iospay : 1;
              });
            },
            getPhoneId: function getPhoneId() {},
            getStorageFun: function getStorageFun(e, t) {
              var o = new Date().toLocaleDateString();
              if (!a.getStorageSync(e)) return a.setStorageSync(e, o), void t();
              a.getStorageSync(e) != o && (a.setStorageSync(e, o), a.removeStorageSync("bgmusic"), t());
            },
            showLoginToast: function showLoginToast() {
              a.showModal({
                title: "登录提示",
                content: "您当前未登录，请先去登录",
                cancelText: "取消",
                confirmText: "登录",
                showCancel: !0,
                success: function success(e) {
                  e.confirm && getApp().relogin();
                }
              });
            },
            relogin: function relogin() {
              var e = this,
                t = function t(_t) {
                  e.$vm.$store.commit("setIsunlogin", !1), e.$vm.$store.commit("setUserMessage", _t.model), a.showToast({
                    title: "登录成功"
                  });
                };
              getApp().wxLogin(function (e) {
                t(e);
              });
            },
            prosssCirculation: function prosssCirculation(e, t) {
              var o = {
                asyncId: e
              };
              getApp().globalData.timeInfo = setInterval(function () {
                var e = getApp().globalData.appApi + "/peiyin/asyncProcess/selectProcess";
                s.default.postRequest(o, e, function (e) {
                  "0" === e.rc ? "2" == e.model.processState ? (getApp().stoptimerinfo(), t && (t({
                    type: "1",
                    result: e.model
                  }), a.hideLoading({}))) : "1" == e.model.processState && (getApp().stoptimerinfo(), t && t({
                    type: "0",
                    result: e.model.failDesc
                  }), a.hideLoading({})) : (getApp().stoptimerinfo(), t && t({
                    type: "0",
                    result: e.rd
                  }), a.hideLoading({}));
                }, function (e) {
                  getApp().stoptimerinfo(), t && t({
                    type: "0",
                    result: "操作失败"
                  }), a.hideLoading({});
                });
              }, 3e3);
            },
            stoptimerinfo: function stoptimerinfo() {
              getApp().globalData.timeInfo && (clearInterval(getApp().globalData.timeInfo), getApp().globalData.timeInfo = 0);
            },
            getProcessId: function getProcessId(e, t, o) {
              (0, r.getProcess)(e, t).then(function (e) {
                if ("0" === e.rc) {
                  var t = e.model;
                  getApp().globalData.timeInfo && getApp().stoptimerinfo(), getApp().prosssCirculation(t, o);
                }
              }).catch(function (e) {
                console.log(e);
              });
            }
          },
          mounted: function mounted() {}
        });
      t.default = c;
    }).call(this, o(1)["default"], o(2)["default"]);
  }
}, [[0, "common/runtime", "common/vendor"]]]);