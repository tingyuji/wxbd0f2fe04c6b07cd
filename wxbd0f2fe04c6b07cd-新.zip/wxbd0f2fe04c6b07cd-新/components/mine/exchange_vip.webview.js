$gwx_XC_24=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_24 || [];
function gz$gwx_XC_24_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_24_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_24_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_24_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[4],[[5],[[5],[1,'exchange_bg']],[[2,'?:'],[[7],[3,'show']],[1,'exchange_show'],[1,'']]]])
Z([3,'__e'])
Z([3,'bg_con'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'hide']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[4],[[5],[[5],[1,'exchange_con']],[[2,'?:'],[[7],[3,'show']],[1,'exchange_con_show'],[1,'']]]])
Z([3,'exchange_tit'])
Z([3,'exchange_t1'])
Z([3,'我的卡密'])
Z([3,'exchange_t2'])
Z([3,'兑换会员'])
Z(z[1])
Z([3,'exchange_close'])
Z(z[3])
Z([3,'../../static/images/mine/close.png'])
Z(z[1])
Z([[4],[[5],[[4],[[5],[[5],[1,'input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'cdkey']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([3,'请输入卡密兑换'])
Z([3,'text'])
Z([[7],[3,'cdkey']])
Z([3,'exchange_tips'])
Z([3,'兑换规则'])
Z([3,'exchange_txt'])
Z([3,'1、兑换码不可重复使用'])
Z(z[21])
Z([3,'2、兑换码仅限兑换会员，不可兑换现金，请妥善保管'])
Z(z[21])
Z([3,'3、兑换会员2-3分钟到账，如遇到未到账的情况请联系客服'])
Z(z[1])
Z([3,'exchange_footer'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'activateCdKey']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'兑换'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_24_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_24_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_24=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_24=true;
var x=['./components/mine/exchange_vip.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_24_1()
var oJU=_n('view')
_rz(z,oJU,'class',0,e,s,gg)
var xKU=_mz(z,'view',['bindtap',1,'class',1,'data-event-opts',2],[],e,s,gg)
_(oJU,xKU)
var oLU=_n('view')
_rz(z,oLU,'class',4,e,s,gg)
var fMU=_n('view')
_rz(z,fMU,'class',5,e,s,gg)
var cNU=_n('text')
_rz(z,cNU,'class',6,e,s,gg)
var hOU=_oz(z,7,e,s,gg)
_(cNU,hOU)
_(fMU,cNU)
var oPU=_n('text')
_rz(z,oPU,'class',8,e,s,gg)
var cQU=_oz(z,9,e,s,gg)
_(oPU,cQU)
_(fMU,oPU)
var oRU=_mz(z,'image',['mode',-1,'bindtap',10,'class',1,'data-event-opts',2,'src',3],[],e,s,gg)
_(fMU,oRU)
_(oLU,fMU)
var lSU=_mz(z,'input',['bindinput',14,'data-event-opts',1,'placeholder',2,'type',3,'value',4],[],e,s,gg)
_(oLU,lSU)
var aTU=_n('view')
_rz(z,aTU,'class',19,e,s,gg)
var tUU=_oz(z,20,e,s,gg)
_(aTU,tUU)
_(oLU,aTU)
var eVU=_n('view')
_rz(z,eVU,'class',21,e,s,gg)
var bWU=_oz(z,22,e,s,gg)
_(eVU,bWU)
_(oLU,eVU)
var oXU=_n('view')
_rz(z,oXU,'class',23,e,s,gg)
var xYU=_oz(z,24,e,s,gg)
_(oXU,xYU)
_(oLU,oXU)
var oZU=_n('view')
_rz(z,oZU,'class',25,e,s,gg)
var f1U=_oz(z,26,e,s,gg)
_(oZU,f1U)
_(oLU,oZU)
var c2U=_mz(z,'view',['bindtap',27,'class',1,'data-event-opts',2],[],e,s,gg)
var h3U=_oz(z,30,e,s,gg)
_(c2U,h3U)
_(oLU,c2U)
_(oJU,oLU)
_(r,oJU)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_24";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_24();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/mine/exchange_vip.wxml'] = [$gwx_XC_24, './components/mine/exchange_vip.wxml'];else __wxAppCode__['components/mine/exchange_vip.wxml'] = $gwx_XC_24( './components/mine/exchange_vip.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/mine/exchange_vip.wxss'] = setCssToHead([".",[1],"exchange_show{opacity:1!important;z-index:2222!important}\n.",[1],"exchange_bg{background:rgba(0,0,0,.5);height:100%;left:0;opacity:0;position:fixed;top:0;transition:all .25s;width:100%;z-index:-1}\n.",[1],"exchange_bg .",[1],"exchange_con_show{-webkit-transform:translateY(0)!important;transform:translateY(0)!important}\n.",[1],"exchange_bg .",[1],"exchange_con{background:#fff;border-radius:",[0,30]," ",[0,30]," ",[0,0]," ",[0,0],";bottom:0;left:0;padding:",[0,38]," ",[0,30],";position:absolute;-webkit-transform:translateY(100%);transform:translateY(100%);transition:all .25s;width:100%;z-index:2}\n.",[1],"exchange_bg .",[1],"exchange_con .",[1],"exchange_t2{font-size:",[0,36],";font-weight:700;left:50%;position:absolute;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}\n.",[1],"exchange_bg .",[1],"exchange_con .",[1],"exchange_tit{height:",[0,50],";line-height:",[0,50],";position:relative}\n.",[1],"exchange_bg .",[1],"exchange_con .",[1],"exchange_t1{color:#ff932f;float:left;font-weight:700}\n.",[1],"exchange_bg .",[1],"exchange_con .",[1],"flex_t1{color:#ff932f;font-size:",[0,28],";font-weight:500}\n.",[1],"exchange_bg .",[1],"exchange_con .",[1],"flex_t2{font-size:",[0,36],";font-weight:500}\n.",[1],"exchange_bg .",[1],"exchange_con .",[1],"exchange_close{height:",[0,32],";position:absolute;right:",[0,0],";top:50%;-webkit-transform:translateY(-50%);transform:translateY(-50%);width:",[0,32],"}\n.",[1],"exchange_bg .",[1],"exchange_con wx-input{background:#f5f6f7;border-radius:",[0,20],";box-sizing:border-box;height:",[0,93],";margin-top:",[0,48],";padding:0 ",[0,30],";width:100%}\n.",[1],"exchange_bg .",[1],"exchange_con .",[1],"exchange_tips{color:#666;font-size:",[0,24],";font-weight:500;margin-top:",[0,40],"}\n.",[1],"exchange_bg .",[1],"exchange_con .",[1],"exchange_txt{color:#999;font-size:",[0,22],";font-weight:400;margin-top:",[0,6],"}\n.",[1],"exchange_bg .",[1],"exchange_con .",[1],"exchange_footer{background:linear-gradient(90deg,#ffa001,#ff7e05);border-radius:",[0,50],";color:#fff;font-size:",[0,36],";font-weight:500;height:",[0,96],";line-height:",[0,96],";margin-top:",[0,30],";text-align:center;width:",[0,690],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/mine/exchange_vip.wxss:1:1226)",{path:"./components/mine/exchange_vip.wxss"});
}