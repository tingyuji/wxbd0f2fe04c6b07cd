$gwx_XC_18=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_18 || [];
function gz$gwx_XC_18_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'make_showPrivacy_bg'])
Z([3,'make_showPrivacy'])
Z([3,'showPrivacy_con'])
Z([3,'showPrivacy_con_title'])
Z([3,'用户隐私协议'])
Z([3,'showPrivacy_con_hz'])
Z([3,'感谢您使用本小程序！我们非常重视您的隐私和个人信息保护。在您使用前，请认真阅读'])
Z([3,'__e'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[1,'jumpAgreement']]]]]]]]])
Z([3,'《用户协议》'])
Z([3,'和'])
Z(z[7])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[1,'handleOpenPrivacyContract']]]]]]]]])
Z([3,'《隐私协议》'])
Z([3,'。我们将严格按照前述政策，为您提供更好的服务。如您同意该隐私政策，请点击\x22同意并继续”开始使用我们的产品及服务。'])
Z([3,'showPrivacy_btns'])
Z([3,'showPrivacy_btns_btn1 flex_cen'])
Z([3,'同意并继续'])
Z(z[7])
Z([3,'bg_con'])
Z([[4],[[5],[[4],[[5],[[5],[1,'agreeprivacyauthorization']],[[4],[[5],[[4],[[5],[1,'handleAgreePrivacyAuthorization']]]]]]]]])
Z([3,'agree-btn'])
Z([3,'agreePrivacyAuthorization'])
Z([3,'opacity:0;'])
Z(z[7])
Z([3,'showPrivacy_btns_btn2 flex_cen'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[1,'noagree']]]]]]]]])
Z([3,'不同意'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_18_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_18_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_18=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_18=true;
var x=['./components/make/make_showPrivacy.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_18_1()
var eZQ=_n('view')
_rz(z,eZQ,'class',0,e,s,gg)
var b1Q=_n('view')
_rz(z,b1Q,'class',1,e,s,gg)
var o2Q=_n('view')
_rz(z,o2Q,'class',2,e,s,gg)
var x3Q=_n('view')
_rz(z,x3Q,'class',3,e,s,gg)
var o4Q=_oz(z,4,e,s,gg)
_(x3Q,o4Q)
_(o2Q,x3Q)
var f5Q=_n('view')
_rz(z,f5Q,'class',5,e,s,gg)
var c6Q=_oz(z,6,e,s,gg)
_(f5Q,c6Q)
var h7Q=_mz(z,'text',['bindtap',7,'data-event-opts',1],[],e,s,gg)
var o8Q=_oz(z,9,e,s,gg)
_(h7Q,o8Q)
_(f5Q,h7Q)
var c9Q=_oz(z,10,e,s,gg)
_(f5Q,c9Q)
var o0Q=_mz(z,'text',['bindtap',11,'data-event-opts',1],[],e,s,gg)
var lAR=_oz(z,13,e,s,gg)
_(o0Q,lAR)
_(f5Q,o0Q)
var aBR=_oz(z,14,e,s,gg)
_(f5Q,aBR)
_(o2Q,f5Q)
_(b1Q,o2Q)
var tCR=_n('view')
_rz(z,tCR,'class',15,e,s,gg)
var eDR=_n('view')
_rz(z,eDR,'class',16,e,s,gg)
var bER=_oz(z,17,e,s,gg)
_(eDR,bER)
var oFR=_mz(z,'button',['bindagreeprivacyauthorization',18,'class',1,'data-event-opts',2,'id',3,'openType',4,'style',5],[],e,s,gg)
_(eDR,oFR)
_(tCR,eDR)
var xGR=_mz(z,'view',['bindtap',24,'class',1,'data-event-opts',2],[],e,s,gg)
var oHR=_oz(z,27,e,s,gg)
_(xGR,oHR)
_(tCR,xGR)
_(b1Q,tCR)
_(eZQ,b1Q)
_(r,eZQ)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_18";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_18();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/make/make_showPrivacy.wxml'] = [$gwx_XC_18, './components/make/make_showPrivacy.wxml'];else __wxAppCode__['components/make/make_showPrivacy.wxml'] = $gwx_XC_18( './components/make/make_showPrivacy.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/make/make_showPrivacy.wxss'] = setCssToHead([".",[1],"make_showPrivacy_bg{background-color:rgba(0,0,0,.5);height:100%;left:0;position:fixed;top:0;width:100%;z-index:999999!important}\n.",[1],"make_showPrivacy{background-color:#fff;border-radius:",[0,30]," ",[0,30]," 0 0;bottom:0;left:0;position:fixed}\n.",[1],"make_showPrivacy,.",[1],"make_showPrivacy .",[1],"showPrivacy_con{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column}\n.",[1],"make_showPrivacy .",[1],"showPrivacy_con{-webkit-align-items:center;align-items:center;-webkit-align-self:stretch;align-self:stretch;gap:",[0,35],";padding:",[0,48]," ",[0,40],"}\n.",[1],"make_showPrivacy .",[1],"showPrivacy_con .",[1],"showPrivacy_con_title{color:#323233;font-size:",[0,36],";font-weight:700}\n.",[1],"make_showPrivacy .",[1],"showPrivacy_con .",[1],"showPrivacy_con_hz{-webkit-align-self:stretch;align-self:stretch;color:#646566;font-size:",[0,28],"}\n.",[1],"make_showPrivacy .",[1],"showPrivacy_con .",[1],"showPrivacy_con_hz wx-text{color:#576b95;font-size:",[0,28],"}\n.",[1],"showPrivacy_btns{-webkit-align-items:center;align-items:center;-webkit-align-self:stretch;align-self:stretch;background-color:#fff;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;gap:",[0,30],";-webkit-justify-content:center;justify-content:center;padding:",[0,30]," ",[0,128]," ",[0,40],"}\n.",[1],"showPrivacy_btns .",[1],"showPrivacy_btns_btn1{background:#ff932f;border-radius:",[0,90],";color:#fff;font-size:",[0,32],";font-weight:700;padding:",[0,26]," ",[0,160],";position:relative}\n.",[1],"showPrivacy_btns .",[1],"showPrivacy_btns_btn2{border-radius:",[0,90],";color:#646566;font-size:",[0,32],";padding:",[0,12]," ",[0,128],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/make/make_showPrivacy.wxss:1:817)",{path:"./components/make/make_showPrivacy.wxss"});
}