$gwx_XC_22=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_22 || [];
function gz$gwx_XC_22_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_22_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_22_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_22_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'sensitive_word_popup'])
Z([3,'__e'])
Z([3,'sensitive_word_bgcon'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'hide']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[2,'=='],[[7],[3,'rc']],[1,1901]])
Z([3,'sensitive_word_cen'])
Z([3,'sensitive_word_tit'])
Z([3,'合成失败'])
Z([3,'sensitive_word_text1'])
Z([a,[[7],[3,'popup_text']]])
Z([3,'sensitive_word_flow'])
Z([3,'https://pysq.stoss.shipook.com/static/imgs/mini/sensitive_word_popup2.png'])
Z(z[1])
Z([3,'flex_cen sensitive_word_know'])
Z(z[3])
Z([3,'知道了'])
Z([[2,'=='],[[7],[3,'rc']],[1,1904]])
Z([3,'sensitive_con'])
Z([3,'sensitive_tit'])
Z(z[7])
Z(z[1])
Z([3,'sensitive_off'])
Z(z[3])
Z([3,'/static/images/make/sensitive_off.png'])
Z([3,'sensitive_text'])
Z([3,'文本内容可能存在敏感词，需要联系客服进一步检测文本内容！否则后果自负！'])
Z([3,'sensitive_cen'])
Z([3,'sensitive_cen_tit'])
Z([3,'敏感词：'])
Z([3,'sensitive_cen_text'])
Z([3,'可能检测出敏感词'])
Z(z[24])
Z([3,'若文本无法合成，可根据提示修改相应的文本信息（使用拼音、谐音字代替或直接删除可能涉及违规的词汇）'])
Z(z[1])
Z([3,'sensitive_btn'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'jumpKF']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'联系客服'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_22_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_22_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_22=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_22=true;
var x=['./components/make/sensitive_word_popup.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_22_1()
var bCT=_n('view')
_rz(z,bCT,'class',0,e,s,gg)
var oFT=_mz(z,'view',['bindtap',1,'class',1,'data-event-opts',2],[],e,s,gg)
_(bCT,oFT)
var oDT=_v()
_(bCT,oDT)
if(_oz(z,4,e,s,gg)){oDT.wxVkey=1
var fGT=_n('view')
_rz(z,fGT,'class',5,e,s,gg)
var cHT=_n('view')
_rz(z,cHT,'class',6,e,s,gg)
var hIT=_oz(z,7,e,s,gg)
_(cHT,hIT)
_(fGT,cHT)
var oJT=_n('view')
_rz(z,oJT,'class',8,e,s,gg)
var cKT=_oz(z,9,e,s,gg)
_(oJT,cKT)
_(fGT,oJT)
var oLT=_mz(z,'image',['class',10,'src',1],[],e,s,gg)
_(fGT,oLT)
var lMT=_mz(z,'view',['bindtap',12,'class',1,'data-event-opts',2],[],e,s,gg)
var aNT=_oz(z,15,e,s,gg)
_(lMT,aNT)
_(fGT,lMT)
_(oDT,fGT)
}
var xET=_v()
_(bCT,xET)
if(_oz(z,16,e,s,gg)){xET.wxVkey=1
var tOT=_n('view')
_rz(z,tOT,'class',17,e,s,gg)
var ePT=_n('view')
_rz(z,ePT,'class',18,e,s,gg)
var bQT=_n('text')
var oRT=_oz(z,19,e,s,gg)
_(bQT,oRT)
_(ePT,bQT)
var xST=_mz(z,'image',['bindtap',20,'class',1,'data-event-opts',2,'src',3],[],e,s,gg)
_(ePT,xST)
_(tOT,ePT)
var oTT=_n('view')
_rz(z,oTT,'class',24,e,s,gg)
var fUT=_oz(z,25,e,s,gg)
_(oTT,fUT)
_(tOT,oTT)
var cVT=_n('view')
_rz(z,cVT,'class',26,e,s,gg)
var hWT=_n('view')
_rz(z,hWT,'class',27,e,s,gg)
var oXT=_oz(z,28,e,s,gg)
_(hWT,oXT)
_(cVT,hWT)
var cYT=_n('view')
_rz(z,cYT,'class',29,e,s,gg)
var oZT=_oz(z,30,e,s,gg)
_(cYT,oZT)
_(cVT,cYT)
_(tOT,cVT)
var l1T=_n('view')
_rz(z,l1T,'class',31,e,s,gg)
var a2T=_oz(z,32,e,s,gg)
_(l1T,a2T)
_(tOT,l1T)
var t3T=_mz(z,'view',['bindtap',33,'class',1,'data-event-opts',2],[],e,s,gg)
var e4T=_oz(z,36,e,s,gg)
_(t3T,e4T)
_(tOT,t3T)
_(xET,tOT)
}
oDT.wxXCkey=1
xET.wxXCkey=1
_(r,bCT)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_22";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_22();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/make/sensitive_word_popup.wxml'] = [$gwx_XC_22, './components/make/sensitive_word_popup.wxml'];else __wxAppCode__['components/make/sensitive_word_popup.wxml'] = $gwx_XC_22( './components/make/sensitive_word_popup.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/make/sensitive_word_popup.wxss'] = setCssToHead([".",[1],"sensitive_con{background-color:#fff;border-radius:",[0,30],";left:50%;padding:",[0,30]," ",[0,33],";position:absolute;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);width:",[0,622],";z-index:2}\n.",[1],"sensitive_tit{margin-bottom:",[0,16],";position:relative;text-align:center}\n.",[1],"sensitive_tit wx-text{font-size:",[0,32],";font-weight:700}\n.",[1],"sensitive_text{color:#666}\n.",[1],"sensitive_cen{background-color:#f7f7f7;border-radius:",[0,20],";height:",[0,286],";margin:",[0,24]," 0;padding:",[0,24],";width:100%}\n.",[1],"sensitive_btn{-webkit-align-items:center;align-items:center;border:",[0,2]," solid #ff932f;border-radius:",[0,16],";color:#ff932f;display:-webkit-flex;display:flex;font-weight:700;height:",[0,78],";-webkit-justify-content:center;justify-content:center;margin-top:",[0,24],";width:100%}\n.",[1],"sensitive_cen_tit{color:#999;font-size:",[0,24],"}\n.",[1],"sensitive_cen_text{-webkit-align-items:center;align-items:center;color:#999;display:-webkit-flex;display:flex;font-size:",[0,32],";font-weight:700;height:",[0,192],";-webkit-justify-content:center;justify-content:center;width:100%}\n.",[1],"sensitive_off{height:",[0,40],";position:absolute;right:0;top:50%;-webkit-transform:translateY(-50%);transform:translateY(-50%);width:",[0,40],"}\n.",[1],"sensitive_word_popup{background-color:rgba(0,0,0,.5);height:100%;position:fixed;width:100%;z-index:99999}\n.",[1],"sensitive_word_bgcon{height:100%;left:0;position:absolute;top:0;width:100%;z-index:1}\n.",[1],"sensitive_word_cen{background-color:#fff;border-radius:",[0,40],";left:50%;padding:",[0,36]," ",[0,30],";position:absolute;text-align:center;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);width:",[0,622],";z-index:2}\n.",[1],"sensitive_word_tit{font-size:",[0,32],";font-weight:700;margin-bottom:",[0,12],";text-align:center}\n.",[1],"sensitive_word_text1{color:#999}\n.",[1],"sensitive_word_flow{height:",[0,480],";margin-top:",[0,36],";width:",[0,562],"}\n.",[1],"sensitive_word_btn{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-justify-content:space-between;justify-content:space-between;margin-top:",[0,24],"}\n.",[1],"sensitive_word_btn1{background-color:#f6f6f6;color:#999;width:",[0,208],"}\n.",[1],"sensitive_word_btn1,.",[1],"sensitive_word_btn2{-webkit-align-items:center;align-items:center;border-radius:",[0,16],";display:-webkit-flex;display:flex;font-weight:700;height:",[0,80],";-webkit-justify-content:center;justify-content:center}\n.",[1],"sensitive_word_btn2{width:",[0,330],"}\n.",[1],"sensitive_word_btn2,.",[1],"sensitive_word_know{background:#fff3d8 linear-gradient(90deg,#ffa001,#ff7e05);color:#fff}\n.",[1],"sensitive_word_know{border-radius:",[0,16],";font-weight:700;height:",[0,80],";margin-top:",[0,24],";width:100%}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/make/sensitive_word_popup.wxss:1:292)",{path:"./components/make/sensitive_word_popup.wxss"});
}