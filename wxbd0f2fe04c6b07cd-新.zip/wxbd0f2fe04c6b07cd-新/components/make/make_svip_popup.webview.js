$gwx_XC_19=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_19 || [];
function gz$gwx_XC_19_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_19_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'make_nonmember'])
Z([3,'__e'])
Z([3,'bg_con'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'hide']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'make_nonmember_con'])
Z([3,'make_nonmember_bg'])
Z([3,'https://pysqstoss.shipook.com/imgs/20220117/20233272h.png'])
Z(z[1])
Z([3,'flex_cen make_nonmember_btn'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'jumpVip']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'去开通'])
Z(z[1])
Z([3,'flex_cen make_nonmember_btn2'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'jumAnchor']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'暂不开通，更换主播'])
Z([3,'/static/images/make/svippopupjump.png'])
Z(z[1])
Z([3,'off_popup'])
Z(z[3])
Z([3,'https://pysqstoss.shipook.com/static/minisource/10767/off_popup.png'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_19_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_19_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_19=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_19=true;
var x=['./components/make/make_svip_popup.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_19_1()
var cJR=_n('view')
_rz(z,cJR,'class',0,e,s,gg)
var hKR=_mz(z,'view',['bindtap',1,'class',1,'data-event-opts',2],[],e,s,gg)
_(cJR,hKR)
var oLR=_n('view')
_rz(z,oLR,'class',4,e,s,gg)
var cMR=_mz(z,'image',['class',5,'src',1],[],e,s,gg)
_(oLR,cMR)
var oNR=_mz(z,'view',['bindtap',7,'class',1,'data-event-opts',2],[],e,s,gg)
var lOR=_oz(z,10,e,s,gg)
_(oNR,lOR)
_(oLR,oNR)
var aPR=_mz(z,'view',['bindtap',11,'class',1,'data-event-opts',2],[],e,s,gg)
var tQR=_n('text')
var eRR=_oz(z,14,e,s,gg)
_(tQR,eRR)
_(aPR,tQR)
var bSR=_n('image')
_rz(z,bSR,'src',15,e,s,gg)
_(aPR,bSR)
_(oLR,aPR)
var oTR=_mz(z,'image',['bindtap',16,'class',1,'data-event-opts',2,'src',3],[],e,s,gg)
_(oLR,oTR)
_(cJR,oLR)
_(r,cJR)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_19";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_19();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/make/make_svip_popup.wxml'] = [$gwx_XC_19, './components/make/make_svip_popup.wxml'];else __wxAppCode__['components/make/make_svip_popup.wxml'] = $gwx_XC_19( './components/make/make_svip_popup.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/make/make_svip_popup.wxss'] = setCssToHead([".",[1],"make_nonmember{background-color:rgba(0,0,0,.5);height:100%;left:0;position:fixed;top:0;width:100%;z-index:9999}\n.",[1],"make_nonmember .",[1],"make_nonmember_con{height:",[0,628],";left:50%;position:absolute;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);width:",[0,574],";z-index:2}\n.",[1],"make_nonmember .",[1],"make_nonmember_con .",[1],"make_nonmember_bg{height:100%;width:100%}\n.",[1],"make_nonmember .",[1],"make_nonmember_con .",[1],"off_popup{bottom:",[0,-128],";height:",[0,64],";left:50%;position:absolute;-webkit-transform:translateX(-50%);transform:translateX(-50%);width:",[0,64],"}\n.",[1],"make_nonmember .",[1],"make_nonmember_con .",[1],"make_nonmember_btn{background:#fa3f6d linear-gradient(90deg,#ffa001,#ff7e05);border-radius:",[0,50],";bottom:",[0,115],";color:#fff;font-size:",[0,32],";font-weight:700;height:",[0,94],";left:50%;position:absolute;-webkit-transform:translateX(-50%);transform:translateX(-50%);width:",[0,428],"}\n.",[1],"make_nonmember .",[1],"make_nonmember_con .",[1],"make_nonmember_btn2{bottom:",[0,24],";height:",[0,76],";left:50%;position:absolute;-webkit-transform:translateX(-50%);transform:translateX(-50%);width:",[0,358],"}\n.",[1],"make_nonmember .",[1],"make_nonmember_con .",[1],"make_nonmember_btn2 wx-text{color:#999}\n.",[1],"make_nonmember .",[1],"make_nonmember_con .",[1],"make_nonmember_btn2 wx-image{height:",[0,16],";margin-left:",[0,16],";width:",[0,16],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/make/make_svip_popup.wxss:1:1166)",{path:"./components/make/make_svip_popup.wxss"});
}