$gwx_XC_5=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_5 || [];
function gz$gwx_XC_5_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'keyboard_con'])
Z([[2,'+'],[[2,'+'],[1,'height:'],[[2,'+'],[[7],[3,'keyHeight']],[1,'px']]],[1,';']])
Z([[7],[3,'is_continuous']])
Z([3,'keyboard_main'])
Z([[2,'==='],[[7],[3,'tab']],[1,0]])
Z([[2,'==='],[[7],[3,'tab']],[1,1]])
Z([[2,'==='],[[7],[3,'tab']],[1,2]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_5=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_5=true;
var x=['./components/make/keyboard_top.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_5_1()
var lQB=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var aRB=_v()
_(lQB,aRB)
if(_oz(z,2,e,s,gg)){aRB.wxVkey=1
}
var tSB=_n('view')
_rz(z,tSB,'class',3,e,s,gg)
var eTB=_v()
_(tSB,eTB)
if(_oz(z,4,e,s,gg)){eTB.wxVkey=1
}
var bUB=_v()
_(tSB,bUB)
if(_oz(z,5,e,s,gg)){bUB.wxVkey=1
}
var oVB=_v()
_(tSB,oVB)
if(_oz(z,6,e,s,gg)){oVB.wxVkey=1
}
eTB.wxXCkey=1
bUB.wxXCkey=1
oVB.wxXCkey=1
_(lQB,tSB)
aRB.wxXCkey=1
_(r,lQB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_5";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_5();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/make/keyboard_top.wxml'] = [$gwx_XC_5, './components/make/keyboard_top.wxml'];else __wxAppCode__['components/make/keyboard_top.wxml'] = $gwx_XC_5( './components/make/keyboard_top.wxml' );
	;__wxRoute = "components/make/keyboard_top";__wxRouteBegin = true;__wxAppCurrentFile__="components/make/keyboard_top.js";define("components/make/keyboard_top.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["components/make/keyboard_top"], {
  1193: function _(t, e, n) {
    "use strict";

    n.r(e);
    var i = n(1194),
      o = n(1196);
    for (var r in o) ["default"].indexOf(r) < 0 && function (t) {
      n.d(e, t, function () {
        return o[t];
      });
    }(r);
    n(1198);
    var u,
      s = n(230),
      a = Object(s["default"])(o["default"], i["render"], i["staticRenderFns"], !1, null, null, null, !1, i["components"], u);
    a.options.__file = "components/make/keyboard_top.vue", e["default"] = a.exports;
  },
  1194: function _(t, e, n) {
    "use strict";

    n.r(e);
    var i = n(1195);
    n.d(e, "render", function () {
      return i["render"];
    }), n.d(e, "staticRenderFns", function () {
      return i["staticRenderFns"];
    }), n.d(e, "recyclableRender", function () {
      return i["recyclableRender"];
    }), n.d(e, "components", function () {
      return i["components"];
    });
  },
  1195: function _(t, e, n) {
    "use strict";

    var i;
    n.r(e), n.d(e, "render", function () {
      return o;
    }), n.d(e, "staticRenderFns", function () {
      return u;
    }), n.d(e, "recyclableRender", function () {
      return r;
    }), n.d(e, "components", function () {
      return i;
    });
    var o = function o() {
        var t = this,
          e = t.$createElement;
        t._self._c;
        t._isMounted || (t.e0 = function (e) {
          t.tab = 1;
        }, t.e1 = function (e) {
          t.tab = 2;
        });
      },
      r = !1,
      u = [];
    o._withStripped = !0;
  },
  1196: function _(t, e, n) {
    "use strict";

    n.r(e);
    var i = n(1197),
      o = n.n(i);
    for (var r in i) ["default"].indexOf(r) < 0 && function (t) {
      n.d(e, t, function () {
        return i[t];
      });
    }(r);
    e["default"] = o.a;
  },
  1197: function _(t, e, n) {
    "use strict";

    (function (t) {
      Object.defineProperty(e, "__esModule", {
        value: !0
      }), e.default = void 0;
      var n = {
        data: function data() {
          return {
            keyHeight: 300,
            tab: 0,
            pause: .5
          };
        },
        mounted: function mounted() {
          var e = t.getStorageSync("device");
          "windows" !== e.platform && (console.log("this.keyboardHeight()"), this.keyboardHeight());
        },
        watch: {
          tab: function tab(t) {
            0 !== t && this.stopTts();
          },
          play_state: function play_state(t) {
            console.log("play_state", t);
          }
        },
        props: {
          nonmember: {
            type: Boolean,
            default: !1
          },
          is_continuous: {
            type: Boolean,
            default: !1
          },
          play_state: {
            type: Boolean,
            default: !1
          }
        },
        methods: {
          stopTts: function stopTts() {
            this.$parent.tts_audio.stopAllMusic();
          },
          playTts: function playTts() {
            var e = this;
            this.$parent.text ? (this.tab = 0, this.nonmember && (this.$parent.keytop_palystatus = !0), setTimeout(function () {
              e.$parent.requestTts(!1, !0);
            }, 200)) : t.showToast({
              title: "配音文本为空",
              icon: "none"
            });
          },
          insertPause: function insertPause() {
            var t = this;
            this.tab = 1, setTimeout(function () {
              t.$emit("insertPause", t.pause);
            }, 200);
          },
          insertContinuous: function insertContinuous() {
            this.$emit("insertContinuous");
          },
          setPauseNumber: function setPauseNumber(t) {
            this.pause = t.detail.value.toFixed(1);
          },
          keyboardHeight: function keyboardHeight() {
            var e = this;
            console.log("keyboardHeight"), t.onKeyboardHeightChange(function (n) {
              var i = t.getSystemInfoSync(),
                o = i.screenHeight - i.windowHeight,
                r = n.height - o;
              e.diffHeight = r > 0 ? r : 0, 0 !== e.diffHeight && (e.keyHeight = e.diffHeight + t.upx2px(104), e.is_height = !0);
            });
          },
          hide: function hide() {
            this.$parent.is_focus = !1, this.$emit("hide");
          }
        }
      };
      e.default = n;
    }).call(this, n(2)["default"]);
  },
  1198: function _(t, e, n) {
    "use strict";

    n.r(e);
    var i = n(1199),
      o = n.n(i);
    for (var r in i) ["default"].indexOf(r) < 0 && function (t) {
      n.d(e, t, function () {
        return i[t];
      });
    }(r);
    e["default"] = o.a;
  },
  1199: function _(t, e, n) {}
}]);
//# sourceMappingURL=../../../.sourcemap/mp-weixin/components/make/keyboard_top.js.map
;
(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['components/make/keyboard_top-create-component', {
  'components/make/keyboard_top-create-component': function componentsMakeKeyboard_topCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1193));
  }
}, [['components/make/keyboard_top-create-component']]]);
},{isPage:false,isComponent:true,currentFile:'components/make/keyboard_top.js'});require("components/make/keyboard_top.js");