$gwx_XC_3=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_3 || [];
function gz$gwx_XC_3_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_3_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'make_nonmember'])
Z([3,'__e'])
Z([3,'bg_con'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'hide']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[2,'==='],[[7],[3,'is_svip']],[1,'1']])
Z([3,'make_nonmember_con'])
Z([3,'make_nonmember_bg'])
Z([3,'https://pysqstoss.shipook.com/imgs/20220117/20233271h.png'])
Z([3,'\x3e'])
Z(z[1])
Z([3,'flex_cen make_nonmember_btn'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'jumpChar']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'去购买字符'])
Z(z[1])
Z([3,'off_popup'])
Z(z[3])
Z([3,'https://pysqstoss.shipook.com/static/minisource/10767/off_popup.png'])
Z(z[5])
Z(z[6])
Z([3,'https://pysq.stoss.shipook.com/static/imgs/peiyinyav2/nochar2.png'])
Z(z[1])
Z(z[10])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'jumpVip']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'去开通'])
Z(z[1])
Z(z[14])
Z(z[3])
Z(z[16])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_3_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_3_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_3=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_3=true;
var x=['./components/make/char_deficiency.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_3_1()
var x9D=_n('view')
_rz(z,x9D,'class',0,e,s,gg)
var fAE=_mz(z,'view',['bindtap',1,'class',1,'data-event-opts',2],[],e,s,gg)
_(x9D,fAE)
var o0D=_v()
_(x9D,o0D)
if(_oz(z,4,e,s,gg)){o0D.wxVkey=1
var cBE=_n('view')
_rz(z,cBE,'class',5,e,s,gg)
var hCE=_mz(z,'image',['class',6,'src',1],[],e,s,gg)
_(cBE,hCE)
var oDE=_oz(z,8,e,s,gg)
_(cBE,oDE)
var cEE=_mz(z,'view',['bindtap',9,'class',1,'data-event-opts',2],[],e,s,gg)
var oFE=_oz(z,12,e,s,gg)
_(cEE,oFE)
_(cBE,cEE)
var lGE=_mz(z,'image',['bindtap',13,'class',1,'data-event-opts',2,'src',3],[],e,s,gg)
_(cBE,lGE)
_(o0D,cBE)
}
else{o0D.wxVkey=2
var aHE=_n('view')
_rz(z,aHE,'class',17,e,s,gg)
var tIE=_mz(z,'image',['class',18,'src',1],[],e,s,gg)
_(aHE,tIE)
var eJE=_mz(z,'view',['bindtap',20,'class',1,'data-event-opts',2],[],e,s,gg)
var bKE=_oz(z,23,e,s,gg)
_(eJE,bKE)
_(aHE,eJE)
var oLE=_mz(z,'image',['bindtap',24,'class',1,'data-event-opts',2,'src',3],[],e,s,gg)
_(aHE,oLE)
_(o0D,aHE)
}
o0D.wxXCkey=1
_(r,x9D)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_3";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_3();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/make/char_deficiency.wxml'] = [$gwx_XC_3, './components/make/char_deficiency.wxml'];else __wxAppCode__['components/make/char_deficiency.wxml'] = $gwx_XC_3( './components/make/char_deficiency.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/make/char_deficiency.wxss'] = setCssToHead([".",[1],"make_nonmember{background-color:rgba(0,0,0,.5);height:100%;left:0;position:fixed;top:0;width:100%;z-index:9999}\n.",[1],"make_nonmember .",[1],"make_nonmember_con{height:",[0,628],";left:50%;position:absolute;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);width:",[0,574],";z-index:2}\n.",[1],"make_nonmember .",[1],"make_nonmember_con .",[1],"make_nonmember_bg{height:100%;width:100%}\n.",[1],"make_nonmember .",[1],"make_nonmember_con .",[1],"off_popup{bottom:",[0,-128],";height:",[0,64],";left:50%;position:absolute;-webkit-transform:translateX(-50%);transform:translateX(-50%);width:",[0,64],"}\n.",[1],"make_nonmember .",[1],"make_nonmember_con .",[1],"make_nonmember_btn{background:#fa3f6d linear-gradient(90deg,#ffa001,#ff7e05);border-radius:",[0,50],";bottom:",[0,48],";color:#fff;font-size:",[0,32],";font-weight:700;height:",[0,94],";left:50%;position:absolute;-webkit-transform:translateX(-50%);transform:translateX(-50%);width:",[0,428],"}\n",],undefined,{path:"./components/make/char_deficiency.wxss"});
}