$gwx_XC_4=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_4 || [];
function gz$gwx_XC_4_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__l'])
Z([3,'__e'])
Z([3,'true'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^close']],[[4],[[5],[[4],[[5],[1,'hide']]]]]]]]])
Z([3,'bottom'])
Z([1,16])
Z([1,true])
Z([3,'412aa17c-1'])
Z([[4],[[5],[1,'default']]])
Z([3,'upopup'])
Z([3,'upopup_top'])
Z([3,'image1'])
Z([[6],[[7],[3,'chooseZb']],[3,'zbcover']])
Z([3,'upopup_top_right'])
Z([a,[[6],[[7],[3,'chooseZb']],[3,'speakername']]])
Z([3,'rightchar'])
Z([a,[[2,'+'],[[2,'?:'],[[2,'=='],[[6],[[7],[3,'chooseZb']],[3,'gender']],[1,'male']],[1,'男生'],[1,'女生']],[1,'']]])
Z([3,'rightchar _span'])
Z([3,'margin:0 4rpx;'])
Z([3,'·'])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'chooseZb']],[3,'usecase']]],[1,'']]])
Z(z[15])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'$root']],[3,'m0']]],[1,'']]])
Z([3,'upopup_con'])
Z([[2,'!='],[[7],[3,'from']],[1,'anchor']])
Z([3,'con_voice'])
Z([3,'_span'])
Z([3,'声音'])
Z([3,'bft'])
Z([3,'../../static/images/make/bofangtiao.svg'])
Z(z[1])
Z([3,'voice_btn'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[1,'playAudio']]]]]]]]])
Z([[2,'!'],[[6],[[7],[3,'list_play']],[3,'audiourl']]])
Z([3,'/static/images/make/cl_play.svg'])
Z([3,'/static/images/make/cl_stop.svg'])
Z([3,'con_priceblock'])
Z([[2,'=='],[[6],[[7],[3,'chooseZb']],[3,'resstatus']],[1,'5']])
Z([3,'outtime'])
Z([3,'../../static/images/make/gantanhaoorange.svg'])
Z([a,[[2,'+'],[[2,'+'],[1,'主播已过期，'],[[6],[[7],[3,'$root']],[3,'m1']]],[1,'前不续费则回收主播']]])
Z([3,'con_priceblock_title'])
Z([3,'续费价格'])
Z([3,'con_priceList'])
Z([3,'index'])
Z([3,'item'])
Z([[6],[[7],[3,'$root']],[3,'l0']])
Z(z[44])
Z(z[1])
Z([[4],[[5],[[5],[1,'price_li']],[[2,'?:'],[[2,'==='],[[6],[[7],[3,'zf_select']],[3,'termday']],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'termday']]],[1,'price_li_act'],[1,'']]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e0']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[8],'item',[[6],[[7],[3,'item']],[3,'$orig']]])
Z(z[26])
Z([a,[[6],[[7],[3,'item']],[3,'m2']]])
Z([3,'price'])
Z([3,'￥'])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'rmb']]],[1,'']]])
Z([3,'fgx'])
Z([3,'desp'])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[6],[[7],[3,'item']],[3,'$orig']],[3,'zfnumstring']]],[1,'']]])
Z([3,'con_tip'])
Z([3,'温馨提示'])
Z(z[26])
Z([3,'1.定制声音不捆绑会员，可独立享用配音生成；'])
Z(z[26])
Z([3,'2.定制声音不享有会员功能特权，与超级主播字符不互通；'])
Z(z[26])
Z([3,'3.声音一经续费成功，不支持退换；'])
Z(z[26])
Z([3,'4.有其他问题联系客服。'])
Z([3,'upopup_btn flex_cen'])
Z(z[1])
Z([3,'btn flex_cen'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'goPay']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'立即续费'])
Z([[2,'+'],[[2,'+'],[[2,'+'],[1,'width:'],[1,'100%']],[1,';']],[[2,'+'],[[2,'+'],[1,'height:'],[[2,'+'],[[7],[3,'bottomSafeHeight']],[1,'px']]],[1,';']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_4_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_4_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_4=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_4=true;
var x=['./components/make/cloningPay.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_4_1()
var oNE=_mz(z,'u-popup',['bind:__l',0,'bind:close',1,'closeable',1,'data-event-opts',2,'mode',3,'round',4,'show',5,'vueId',6,'vueSlots',7],[],e,s,gg)
var fOE=_n('view')
_rz(z,fOE,'class',9,e,s,gg)
var cPE=_n('view')
_rz(z,cPE,'class',10,e,s,gg)
var hQE=_mz(z,'image',['class',11,'src',1],[],e,s,gg)
_(cPE,hQE)
var oRE=_n('view')
_rz(z,oRE,'class',13,e,s,gg)
var cSE=_n('text')
var oTE=_oz(z,14,e,s,gg)
_(cSE,oTE)
_(oRE,cSE)
var lUE=_n('view')
_rz(z,lUE,'class',15,e,s,gg)
var aVE=_oz(z,16,e,s,gg)
_(lUE,aVE)
var tWE=_mz(z,'label',['class',17,'style',1],[],e,s,gg)
var eXE=_oz(z,19,e,s,gg)
_(tWE,eXE)
_(lUE,tWE)
var bYE=_oz(z,20,e,s,gg)
_(lUE,bYE)
_(oRE,lUE)
var oZE=_n('view')
_rz(z,oZE,'class',21,e,s,gg)
var x1E=_oz(z,22,e,s,gg)
_(oZE,x1E)
_(oRE,oZE)
_(cPE,oRE)
_(fOE,cPE)
var o2E=_n('view')
_rz(z,o2E,'class',23,e,s,gg)
var f3E=_v()
_(o2E,f3E)
if(_oz(z,24,e,s,gg)){f3E.wxVkey=1
var c4E=_n('view')
_rz(z,c4E,'class',25,e,s,gg)
var h5E=_n('label')
_rz(z,h5E,'class',26,e,s,gg)
var o6E=_oz(z,27,e,s,gg)
_(h5E,o6E)
_(c4E,h5E)
var c7E=_mz(z,'image',['class',28,'src',1],[],e,s,gg)
_(c4E,c7E)
var o8E=_mz(z,'view',['bindtap',30,'class',1,'data-event-opts',2],[],e,s,gg)
var l9E=_v()
_(o8E,l9E)
if(_oz(z,33,e,s,gg)){l9E.wxVkey=1
var a0E=_n('image')
_rz(z,a0E,'src',34,e,s,gg)
_(l9E,a0E)
}
else{l9E.wxVkey=2
var tAF=_n('image')
_rz(z,tAF,'src',35,e,s,gg)
_(l9E,tAF)
}
l9E.wxXCkey=1
_(c4E,o8E)
_(f3E,c4E)
}
var eBF=_n('view')
_rz(z,eBF,'class',36,e,s,gg)
var bCF=_v()
_(eBF,bCF)
if(_oz(z,37,e,s,gg)){bCF.wxVkey=1
var oDF=_n('view')
_rz(z,oDF,'class',38,e,s,gg)
var xEF=_n('image')
_rz(z,xEF,'src',39,e,s,gg)
_(oDF,xEF)
var oFF=_oz(z,40,e,s,gg)
_(oDF,oFF)
_(bCF,oDF)
}
var fGF=_n('view')
_rz(z,fGF,'class',41,e,s,gg)
var cHF=_oz(z,42,e,s,gg)
_(fGF,cHF)
_(eBF,fGF)
var hIF=_n('view')
_rz(z,hIF,'class',43,e,s,gg)
var oJF=_v()
_(hIF,oJF)
var cKF=function(lMF,oLF,aNF,gg){
var ePF=_mz(z,'view',['bindtap',48,'class',1,'data-event-opts',2,'data-event-params',3],[],lMF,oLF,gg)
var bQF=_n('label')
_rz(z,bQF,'class',52,lMF,oLF,gg)
var oRF=_oz(z,53,lMF,oLF,gg)
_(bQF,oRF)
_(ePF,bQF)
var xSF=_n('view')
_rz(z,xSF,'class',54,lMF,oLF,gg)
var oTF=_n('text')
var fUF=_oz(z,55,lMF,oLF,gg)
_(oTF,fUF)
_(xSF,oTF)
var cVF=_oz(z,56,lMF,oLF,gg)
_(xSF,cVF)
_(ePF,xSF)
var hWF=_n('view')
_rz(z,hWF,'class',57,lMF,oLF,gg)
_(ePF,hWF)
var oXF=_n('view')
_rz(z,oXF,'class',58,lMF,oLF,gg)
var cYF=_oz(z,59,lMF,oLF,gg)
_(oXF,cYF)
_(ePF,oXF)
_(aNF,ePF)
return aNF
}
oJF.wxXCkey=2
_2z(z,46,cKF,e,s,gg,oJF,'item','index','index')
_(eBF,hIF)
bCF.wxXCkey=1
_(o2E,eBF)
var oZF=_n('view')
_rz(z,oZF,'class',60,e,s,gg)
var l1F=_n('text')
var a2F=_oz(z,61,e,s,gg)
_(l1F,a2F)
_(oZF,l1F)
var t3F=_n('label')
_rz(z,t3F,'class',62,e,s,gg)
var e4F=_oz(z,63,e,s,gg)
_(t3F,e4F)
_(oZF,t3F)
var b5F=_n('label')
_rz(z,b5F,'class',64,e,s,gg)
var o6F=_oz(z,65,e,s,gg)
_(b5F,o6F)
_(oZF,b5F)
var x7F=_n('label')
_rz(z,x7F,'class',66,e,s,gg)
var o8F=_oz(z,67,e,s,gg)
_(x7F,o8F)
_(oZF,x7F)
var f9F=_n('label')
_rz(z,f9F,'class',68,e,s,gg)
var c0F=_oz(z,69,e,s,gg)
_(f9F,c0F)
_(oZF,f9F)
_(o2E,oZF)
f3E.wxXCkey=1
_(fOE,o2E)
var hAG=_n('view')
_rz(z,hAG,'class',70,e,s,gg)
var oBG=_mz(z,'view',['bindtap',71,'class',1,'data-event-opts',2],[],e,s,gg)
var cCG=_oz(z,74,e,s,gg)
_(oBG,cCG)
_(hAG,oBG)
var oDG=_n('view')
_rz(z,oDG,'style',75,e,s,gg)
_(hAG,oDG)
_(fOE,hAG)
_(oNE,fOE)
_(r,oNE)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_4";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_4();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/make/cloningPay.wxml'] = [$gwx_XC_4, './components/make/cloningPay.wxml'];else __wxAppCode__['components/make/cloningPay.wxml'] = $gwx_XC_4( './components/make/cloningPay.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/make/cloningPay.wxss'] = setCssToHead([".",[1],"upopup{background:#f7f8fa;border-radius:",[0,32]," ",[0,32]," ",[0,0]," ",[0,0],";display:-webkit-flex;display:flex;max-height:",[0,1020],";overflow-y:scroll}\n.",[1],"upopup,.",[1],"upopup .",[1],"upopup_btn{-webkit-flex-direction:column;flex-direction:column;width:100vw}\n.",[1],"upopup .",[1],"upopup_btn{background-color:#fff;border-top:",[0,1]," solid #ebedf0;bottom:0;left:0;padding:",[0,24]," ",[0,32],";position:fixed}\n.",[1],"upopup .",[1],"upopup_btn .",[1],"btn{background:#ffe411;border-radius:",[0,2024],";color:#262626;font-size:",[0,32],";font-weight:500;padding:",[0,24]," ",[0,30],";width:100%}\n.",[1],"upopup .",[1],"upopup_con{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;gap:",[0,24],";padding:",[0,24],";width:100%}\n.",[1],"upopup .",[1],"upopup_con .",[1],"outtime{-webkit-align-items:center;align-items:center;background:#fef7ea;border-radius:",[0,16],";color:#ff9e2f;display:-webkit-flex;display:flex;font-size:",[0,26],";font-weight:500;gap:",[0,10],";padding:",[0,16],"}\n.",[1],"upopup .",[1],"upopup_con .",[1],"outtime wx-image{height:",[0,32],";width:",[0,32],"}\n.",[1],"upopup .",[1],"upopup_con .",[1],"con_tip{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;gap:",[0,4],";margin-bottom:",[0,208],";width:100%}\n.",[1],"upopup .",[1],"upopup_con .",[1],"con_tip wx-text{color:#525252;font-size:",[0,26],"}\n.",[1],"upopup .",[1],"upopup_con .",[1],"con_tip .",[1],"_span{color:#737373;font-size:",[0,24],";line-height:160%;text-align:justify}\n.",[1],"upopup .",[1],"upopup_con .",[1],"con_priceblock{background:#fff;border-radius:",[0,24],";display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;gap:",[0,24],";padding:",[0,32],"}\n.",[1],"upopup .",[1],"upopup_con .",[1],"con_priceblock .",[1],"con_priceList{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;gap:",[0,24],";width:100%}\n.",[1],"upopup .",[1],"upopup_con .",[1],"con_priceblock .",[1],"con_priceList .",[1],"price_li_act{background:#fffce6!important;border:",[0,4]," solid #ffe411!important}\n.",[1],"upopup .",[1],"upopup_con .",[1],"con_priceblock .",[1],"con_priceList .",[1],"price_li{-webkit-align-items:center;align-items:center;background:#f0f3f5;border:",[0,4]," solid #f0f3f5;border-radius:",[0,24],";display:-webkit-flex;display:flex;-webkit-flex:1 0 0;flex:1 0 0;-webkit-flex-direction:column;flex-direction:column;gap:",[0,16],";-webkit-justify-content:center;justify-content:center;padding:",[0,32]," ",[0,32]," ",[0,24],"}\n.",[1],"upopup .",[1],"upopup_con .",[1],"con_priceblock .",[1],"con_priceList .",[1],"price_li .",[1],"_span{color:#262626;font-size:",[0,28],";font-weight:500}\n.",[1],"upopup .",[1],"upopup_con .",[1],"con_priceblock .",[1],"con_priceList .",[1],"price_li .",[1],"price{-webkit-align-items:baseline;align-items:baseline;color:#262626;display:-webkit-flex;display:flex;font-size:",[0,48],";font-weight:590;gap:",[0,4],";-webkit-justify-content:center;justify-content:center;text-align:justify}\n.",[1],"upopup .",[1],"upopup_con .",[1],"con_priceblock .",[1],"con_priceList .",[1],"price_li .",[1],"price wx-text{color:#262626;font-size:",[0,32],";font-weight:590;text-align:justify}\n.",[1],"upopup .",[1],"upopup_con .",[1],"con_priceblock .",[1],"con_priceList .",[1],"price_li .",[1],"fgx{background:rgba(0,0,0,.04);height:",[0,1],";width:100%}\n.",[1],"upopup .",[1],"upopup_con .",[1],"con_priceblock .",[1],"con_priceList .",[1],"price_li .",[1],"desp{color:#525252;font-size:",[0,24],";text-align:center}\n.",[1],"upopup .",[1],"upopup_con .",[1],"con_priceblock .",[1],"con_priceblock_title{color:#262626;font-size:",[0,28],";font-weight:500}\n.",[1],"upopup .",[1],"upopup_con .",[1],"con_voice{-webkit-align-items:center;align-items:center;background:#fff;border-radius:",[0,999],";display:-webkit-flex;display:flex;gap:",[0,24],";padding:",[0,12]," ",[0,12]," ",[0,12]," ",[0,32],";width:100%}\n.",[1],"upopup .",[1],"upopup_con .",[1],"con_voice .",[1],"_span{color:#262626;font-size:",[0,28],";font-weight:500}\n.",[1],"upopup .",[1],"upopup_con .",[1],"con_voice .",[1],"bft{-webkit-flex:1 0 0;flex:1 0 0;height:",[0,22],"}\n.",[1],"upopup .",[1],"upopup_con .",[1],"con_voice .",[1],"voice_btn{-webkit-align-items:center;align-items:center;background:#f0f3f5;border-radius:50%;display:-webkit-flex;display:flex;padding:",[0,12],"}\n.",[1],"upopup .",[1],"upopup_con .",[1],"con_voice .",[1],"voice_btn wx-image{height:",[0,48],";width:",[0,48],"}\n.",[1],"upopup .",[1],"upopup_top{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;gap:",[0,24],";padding:",[0,40]," ",[0,32]," ",[0,12],";width:100%}\n.",[1],"upopup .",[1],"upopup_top wx-image{border-radius:",[0,128],";-webkit-flex-shrink:0;flex-shrink:0;height:",[0,128],";width:",[0,128],"}\n.",[1],"upopup .",[1],"upopup_top .",[1],"upopup_top_right{display:-webkit-flex;display:flex;-webkit-flex:1 0 0;flex:1 0 0;-webkit-flex-direction:column;flex-direction:column;gap:",[0,4],"}\n.",[1],"upopup .",[1],"upopup_top .",[1],"upopup_top_right wx-text{color:#333;font-size:",[0,38],";font-weight:500;text-align:justify}\n.",[1],"upopup .",[1],"upopup_top .",[1],"upopup_top_right .",[1],"rightchar{color:#999;font-size:",[0,24],";text-align:justify}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/make/cloningPay.wxss:1:4011)",{path:"./components/make/cloningPay.wxss"});
}