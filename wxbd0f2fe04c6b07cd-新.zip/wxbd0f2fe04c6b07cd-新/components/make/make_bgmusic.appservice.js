$gwx_XC_7=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_7 || [];
function gz$gwx_XC_7_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_7_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_7_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_7_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_7=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_7=true;
var x=['./components/make/make_bgmusic.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_7_1()
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_7";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_7();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/make/make_bgmusic.wxml'] = [$gwx_XC_7, './components/make/make_bgmusic.wxml'];else __wxAppCode__['components/make/make_bgmusic.wxml'] = $gwx_XC_7( './components/make/make_bgmusic.wxml' );
	;__wxRoute = "components/make/make_bgmusic";__wxRouteBegin = true;__wxAppCurrentFile__="components/make/make_bgmusic.js";define("components/make/make_bgmusic.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["components/make/make_bgmusic"], {
  1151: function _(e, t, n) {
    "use strict";

    n.r(t);
    var i = n(1152),
      u = n(1154);
    for (var o in u) ["default"].indexOf(o) < 0 && function (e) {
      n.d(t, e, function () {
        return u[e];
      });
    }(o);
    n(1156);
    var c,
      r = n(230),
      s = Object(r["default"])(u["default"], i["render"], i["staticRenderFns"], !1, null, null, null, !1, i["components"], c);
    s.options.__file = "components/make/make_bgmusic.vue", t["default"] = s.exports;
  },
  1152: function _(e, t, n) {
    "use strict";

    n.r(t);
    var i = n(1153);
    n.d(t, "render", function () {
      return i["render"];
    }), n.d(t, "staticRenderFns", function () {
      return i["staticRenderFns"];
    }), n.d(t, "recyclableRender", function () {
      return i["recyclableRender"];
    }), n.d(t, "components", function () {
      return i["components"];
    });
  },
  1153: function _(e, t, n) {
    "use strict";

    var i;
    n.r(t), n.d(t, "render", function () {
      return u;
    }), n.d(t, "staticRenderFns", function () {
      return c;
    }), n.d(t, "recyclableRender", function () {
      return o;
    }), n.d(t, "components", function () {
      return i;
    });
    var u = function u() {
        var e = this,
          t = e.$createElement;
        e._self._c;
      },
      o = !1,
      c = [];
    u._withStripped = !0;
  },
  1154: function _(e, t, n) {
    "use strict";

    n.r(t);
    var i = n(1155),
      u = n.n(i);
    for (var o in i) ["default"].indexOf(o) < 0 && function (e) {
      n.d(t, e, function () {
        return i[e];
      });
    }(o);
    t["default"] = u.a;
  },
  1155: function _(e, t, n) {
    "use strict";

    (function (e) {
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var n = {
        props: {
          show: {
            type: Boolean,
            default: !0
          }
        },
        data: function data() {
          return {
            volume: 50,
            bgmusic: {},
            bg_volume: 50,
            is_loop: !1,
            interval_time: 0,
            continue_time: 0,
            delay_time: 0,
            is_reduce: !1
          };
        },
        watch: {
          show: function show() {
            this.record = {
              volume: this.volume,
              bgmusic: this.bgmusic,
              bg_volume: this.bg_volume,
              is_loop: this.is_loop,
              interval_time: this.interval_time,
              continue_time: this.continue_time,
              delay_time: this.delay_time,
              is_reduce: this.is_reduce
            }, console.log(11111, this.record);
          }
        },
        methods: {
          cancel: function cancel() {
            var e = this,
              t = Object.keys(this.record);
            t.forEach(function (t) {
              e[t] = e.record[t];
            }), this.$emit("hide");
          },
          setAnchorVolume: function setAnchorVolume(e) {
            this.volume = e.detail.value, this.$parent.volume = e.detail.value;
          },
          setBgVolume: function setBgVolume(e) {
            this.bg_volume = e.detail.value;
          },
          changeReduce: function changeReduce(e) {
            this.is_reduce = e.detail.value;
          },
          initBgMusic: function initBgMusic() {
            var t = this;
            e.showModal({
              title: "提示",
              content: "是否恢复默认设置？",
              success: function success(e) {
                e.confirm && (t.bg_volume = 50, t.is_loop = !1, t.interval_time = 0, t.continue_time = 0, t.delay_time = 0, t.is_reduce = !1, t.volume = t.$parent.anchor.vol);
              }
            });
          },
          setBgArgument: function setBgArgument(e, t) {
            if (this.bgmusic.bgid) if (e) this[t] += 1;else {
              if (this[t] <= 0) return;
              this[t] -= 1;
            }
          },
          removeBgMusic: function removeBgMusic() {
            var t = this;
            e.showModal({
              title: "提示",
              content: "是否移除背景音乐？",
              success: function success(e) {
                e.confirm && (t.bgmusic = {});
              }
            });
          },
          selectBgmusic: function selectBgmusic() {
            var t = this;
            e.navigateTo({
              url: "/pages2/make/bgmusic",
              events: {
                setBgMusic: function setBgMusic(e) {
                  t.bgmusic = e;
                }
              }
            });
          },
          hide: function hide() {
            this.$uma_wx.trackEvent("chooseBg"), this.$emit("hide", this.bgmusic.bgname);
          }
        }
      };
      t.default = n;
    }).call(this, n(2)["default"]);
  },
  1156: function _(e, t, n) {
    "use strict";

    n.r(t);
    var i = n(1157),
      u = n.n(i);
    for (var o in i) ["default"].indexOf(o) < 0 && function (e) {
      n.d(t, e, function () {
        return i[e];
      });
    }(o);
    t["default"] = u.a;
  },
  1157: function _(e, t, n) {}
}]);
//# sourceMappingURL=../../../.sourcemap/mp-weixin/components/make/make_bgmusic.js.map
;
(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['components/make/make_bgmusic-create-component', {
  'components/make/make_bgmusic-create-component': function componentsMakeMake_bgmusicCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1151));
  }
}, [['components/make/make_bgmusic-create-component']]]);
},{isPage:false,isComponent:true,currentFile:'components/make/make_bgmusic.js'});require("components/make/make_bgmusic.js");