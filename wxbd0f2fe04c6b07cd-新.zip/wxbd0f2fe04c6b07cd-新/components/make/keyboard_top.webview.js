$gwx_XC_5=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_5 || [];
function gz$gwx_XC_5_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'keyboard_top'])
Z([3,'keyboard_con'])
Z([[2,'+'],[[2,'+'],[1,'height:'],[[2,'+'],[[7],[3,'keyHeight']],[1,'px']]],[1,';']])
Z([3,'flex_bet keyboard_tab'])
Z([3,'flex_ali'])
Z([[2,'!'],[[7],[3,'play_state']]])
Z([3,'__e'])
Z([3,'keyboard_tab_li'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'playTts']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'/static/images/make/keyboard/guangbiaoshiting.png'])
Z([3,'光标试听'])
Z(z[6])
Z([3,'keyboard_tab_li keyboard_tab_stop'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'stopTts']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'/static/images/make/keyboard/ting.png'])
Z([3,'暂停播放'])
Z(z[6])
Z([[4],[[5],[[5],[1,'keyboard_tab_li']],[[2,'?:'],[[2,'==='],[[7],[3,'tab']],[1,1]],[1,'keyboard_tab_stop'],[1,'']]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e0']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[2,'==='],[[7],[3,'tab']],[1,1]])
Z([3,'/static/images/make/keyboard/charutingdun1.png'])
Z([3,'/static/images/make/keyboard/charutingdun.png'])
Z([3,'插入停顿'])
Z([[7],[3,'is_continuous']])
Z(z[6])
Z([[4],[[5],[[5],[1,'keyboard_tab_li']],[[2,'?:'],[[2,'==='],[[7],[3,'tab']],[1,2]],[1,'keyboard_tab_stop'],[1,'']]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e1']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[2,'==='],[[7],[3,'tab']],[1,2]])
Z([3,'/static/images/make/keyboard/lianxu1.png'])
Z([3,'/static/images/make/keyboard/lianxu.png'])
Z([3,'连读'])
Z(z[4])
Z([3,'insert_pause_btn_wm flex_cen'])
Z(z[6])
Z([3,'insert_pause_btn flex_cen'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'insertPause']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([a,[[2,'+'],[[2,'+'],[1,'停顿'],[[7],[3,'pause']]],[1,'s']]])
Z(z[6])
Z([3,'show_keyboard'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'hide']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'/static/images/make/keyboard/jianpan.png'])
Z([3,'top_line'])
Z([3,'keyboard_main'])
Z([[2,'==='],[[7],[3,'tab']],[1,0]])
Z([3,'keyboard_play'])
Z([3,'keyboard_play_t1'])
Z([3,'当前试听'])
Z([3,'keyboard_play_t2'])
Z([3,'光标处为试听开始位置，点击光标试听按钮播放'])
Z(z[19])
Z(z[44])
Z(z[45])
Z(z[22])
Z(z[47])
Z([3,'光标处点击，插入左右词间的停顿时长'])
Z([3,'keyboard_pause_num'])
Z([3,'插入'])
Z([a,[[7],[3,'pause']]])
Z([3,'秒'])
Z([3,'width:600rpx;margin-left:45rpx;'])
Z([3,'#FF932F'])
Z([3,'#EBEDF0'])
Z(z[6])
Z(z[6])
Z([3,'18'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'changing']],[[4],[[5],[[4],[[5],[[5],[1,'setPauseNumber']],[[4],[[5],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'change']],[[4],[[5],[[4],[[5],[[5],[1,'setPauseNumber']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'10'])
Z([3,'0.1'])
Z(z[67])
Z([[7],[3,'pause']])
Z(z[6])
Z([3,'pause_btn'])
Z(z[35])
Z(z[22])
Z(z[27])
Z(z[44])
Z(z[45])
Z(z[30])
Z(z[47])
Z([3,'设置光标处的声音连续'])
Z(z[6])
Z(z[71])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'insertContinuous']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'插入连续'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_5_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_5_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_5=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_5=true;
var x=['./components/make/keyboard_top.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_5_1()
var aFG=_n('view')
_rz(z,aFG,'class',0,e,s,gg)
var tGG=_mz(z,'view',['class',1,'style',1],[],e,s,gg)
var eHG=_n('view')
_rz(z,eHG,'class',3,e,s,gg)
var bIG=_n('view')
_rz(z,bIG,'class',4,e,s,gg)
var oJG=_v()
_(bIG,oJG)
if(_oz(z,5,e,s,gg)){oJG.wxVkey=1
var oLG=_mz(z,'view',['bindtap',6,'class',1,'data-event-opts',2],[],e,s,gg)
var fMG=_n('image')
_rz(z,fMG,'src',9,e,s,gg)
_(oLG,fMG)
var cNG=_n('text')
var hOG=_oz(z,10,e,s,gg)
_(cNG,hOG)
_(oLG,cNG)
_(oJG,oLG)
}
else{oJG.wxVkey=2
var oPG=_mz(z,'view',['bindtap',11,'class',1,'data-event-opts',2],[],e,s,gg)
var cQG=_n('image')
_rz(z,cQG,'src',14,e,s,gg)
_(oPG,cQG)
var oRG=_n('text')
var lSG=_oz(z,15,e,s,gg)
_(oRG,lSG)
_(oPG,oRG)
_(oJG,oPG)
}
var aTG=_mz(z,'view',['bindtap',16,'class',1,'data-event-opts',2],[],e,s,gg)
var tUG=_v()
_(aTG,tUG)
if(_oz(z,19,e,s,gg)){tUG.wxVkey=1
var eVG=_n('image')
_rz(z,eVG,'src',20,e,s,gg)
_(tUG,eVG)
}
else{tUG.wxVkey=2
var bWG=_n('image')
_rz(z,bWG,'src',21,e,s,gg)
_(tUG,bWG)
}
var oXG=_n('text')
var xYG=_oz(z,22,e,s,gg)
_(oXG,xYG)
_(aTG,oXG)
tUG.wxXCkey=1
_(bIG,aTG)
var xKG=_v()
_(bIG,xKG)
if(_oz(z,23,e,s,gg)){xKG.wxVkey=1
var oZG=_mz(z,'view',['bindtap',24,'class',1,'data-event-opts',2],[],e,s,gg)
var f1G=_v()
_(oZG,f1G)
if(_oz(z,27,e,s,gg)){f1G.wxVkey=1
var c2G=_n('image')
_rz(z,c2G,'src',28,e,s,gg)
_(f1G,c2G)
}
else{f1G.wxVkey=2
var h3G=_n('image')
_rz(z,h3G,'src',29,e,s,gg)
_(f1G,h3G)
}
var o4G=_n('text')
var c5G=_oz(z,30,e,s,gg)
_(o4G,c5G)
_(oZG,o4G)
f1G.wxXCkey=1
_(xKG,oZG)
}
oJG.wxXCkey=1
xKG.wxXCkey=1
_(eHG,bIG)
var o6G=_n('view')
_rz(z,o6G,'class',31,e,s,gg)
var l7G=_n('view')
_rz(z,l7G,'class',32,e,s,gg)
var a8G=_mz(z,'view',['bindtap',33,'class',1,'data-event-opts',2],[],e,s,gg)
var t9G=_oz(z,36,e,s,gg)
_(a8G,t9G)
_(l7G,a8G)
_(o6G,l7G)
var e0G=_mz(z,'view',['bindtap',37,'class',1,'data-event-opts',2],[],e,s,gg)
var bAH=_n('image')
_rz(z,bAH,'src',40,e,s,gg)
_(e0G,bAH)
_(o6G,e0G)
_(eHG,o6G)
_(tGG,eHG)
var oBH=_n('view')
_rz(z,oBH,'class',41,e,s,gg)
_(tGG,oBH)
var xCH=_n('view')
_rz(z,xCH,'class',42,e,s,gg)
var oDH=_v()
_(xCH,oDH)
if(_oz(z,43,e,s,gg)){oDH.wxVkey=1
var hGH=_n('view')
_rz(z,hGH,'class',44,e,s,gg)
var oHH=_n('view')
var cIH=_n('view')
_rz(z,cIH,'class',45,e,s,gg)
var oJH=_oz(z,46,e,s,gg)
_(cIH,oJH)
_(oHH,cIH)
var lKH=_n('view')
_rz(z,lKH,'class',47,e,s,gg)
var aLH=_oz(z,48,e,s,gg)
_(lKH,aLH)
_(oHH,lKH)
_(hGH,oHH)
_(oDH,hGH)
}
var fEH=_v()
_(xCH,fEH)
if(_oz(z,49,e,s,gg)){fEH.wxVkey=1
var tMH=_n('view')
_rz(z,tMH,'class',50,e,s,gg)
var eNH=_n('view')
var bOH=_n('view')
_rz(z,bOH,'class',51,e,s,gg)
var oPH=_oz(z,52,e,s,gg)
_(bOH,oPH)
_(eNH,bOH)
var xQH=_n('view')
_rz(z,xQH,'class',53,e,s,gg)
var oRH=_oz(z,54,e,s,gg)
_(xQH,oRH)
_(eNH,xQH)
_(tMH,eNH)
var fSH=_n('view')
var cTH=_n('view')
_rz(z,cTH,'class',55,e,s,gg)
var hUH=_oz(z,56,e,s,gg)
_(cTH,hUH)
var oVH=_n('text')
var cWH=_oz(z,57,e,s,gg)
_(oVH,cWH)
_(cTH,oVH)
var oXH=_oz(z,58,e,s,gg)
_(cTH,oXH)
_(fSH,cTH)
var lYH=_n('view')
_rz(z,lYH,'style',59,e,s,gg)
var aZH=_mz(z,'slider',['activeColor',60,'backgroundColor',1,'bindchange',2,'bindchanging',3,'blockSize',4,'data-event-opts',5,'max',6,'min',7,'step',8,'value',9],[],e,s,gg)
_(lYH,aZH)
_(fSH,lYH)
_(tMH,fSH)
var t1H=_mz(z,'view',['bindtap',70,'class',1,'data-event-opts',2],[],e,s,gg)
var e2H=_oz(z,73,e,s,gg)
_(t1H,e2H)
_(tMH,t1H)
_(fEH,tMH)
}
var cFH=_v()
_(xCH,cFH)
if(_oz(z,74,e,s,gg)){cFH.wxVkey=1
var b3H=_n('view')
_rz(z,b3H,'class',75,e,s,gg)
var o4H=_n('view')
var x5H=_n('view')
_rz(z,x5H,'class',76,e,s,gg)
var o6H=_oz(z,77,e,s,gg)
_(x5H,o6H)
_(o4H,x5H)
var f7H=_n('view')
_rz(z,f7H,'class',78,e,s,gg)
var c8H=_oz(z,79,e,s,gg)
_(f7H,c8H)
_(o4H,f7H)
_(b3H,o4H)
var h9H=_mz(z,'view',['bindtap',80,'class',1,'data-event-opts',2],[],e,s,gg)
var o0H=_oz(z,83,e,s,gg)
_(h9H,o0H)
_(b3H,h9H)
_(cFH,b3H)
}
oDH.wxXCkey=1
fEH.wxXCkey=1
cFH.wxXCkey=1
_(tGG,xCH)
_(aFG,tGG)
_(r,aFG)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_5";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_5();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/make/keyboard_top.wxml'] = [$gwx_XC_5, './components/make/keyboard_top.wxml'];else __wxAppCode__['components/make/keyboard_top.wxml'] = $gwx_XC_5( './components/make/keyboard_top.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/make/keyboard_top.wxss'] = setCssToHead([".",[1],"keyboard_con{background-color:#dcdcdc;bottom:0;left:0;position:fixed;width:100%;z-index:99999}\n.",[1],"keyboard_con .",[1],"keyboard_main{background-color:#fff;height:calc(100% - ",[0,104],");width:100%}\n.",[1],"keyboard_con .",[1],"keyboard_main .",[1],"keyboard_play{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:100%;-webkit-justify-content:space-between;justify-content:space-between;padding:",[0,30],"}\n.",[1],"keyboard_con .",[1],"keyboard_main .",[1],"keyboard_play .",[1],"keyboard_play_t1{font-weight:700}\n.",[1],"keyboard_con .",[1],"keyboard_main .",[1],"keyboard_play .",[1],"keyboard_play_t2{color:#666;font-size:",[0,24],";margin-top:",[0,6],"}\n.",[1],"keyboard_con .",[1],"keyboard_main .",[1],"keyboard_play .",[1],"keyboard_pause_num{margin-bottom:",[0,62],";text-align:center}\n.",[1],"keyboard_con .",[1],"keyboard_main .",[1],"keyboard_play .",[1],"keyboard_pause_num wx-text{color:#ff932f;font-size:",[0,44],";font-weight:700;margin:0 ",[0,8],"}\n.",[1],"keyboard_con .",[1],"keyboard_main .",[1],"keyboard_play .",[1],"pause_btn{-webkit-align-items:center;align-items:center;background-color:#ff932f;border-radius:",[0,16],";color:#fff;display:-webkit-flex;display:flex;font-weight:700;height:",[0,82],";-webkit-justify-content:center;justify-content:center;margin:0 auto ",[0,30],";width:",[0,558],"}\n.",[1],"keyboard_con .",[1],"keyboard_tab{background-color:#fff;height:",[0,104],";position:relative}\n.",[1],"keyboard_con .",[1],"keyboard_tab .",[1],"keyboard_tab_stop wx-text{color:#ff932f!important}\n.",[1],"keyboard_con .",[1],"keyboard_tab .",[1],"keyboard_tab_li{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:calc(100% - ",[0,16],");-webkit-justify-content:center;justify-content:center;margin-right:",[0,12],";margin-top:",[0,8],";width:",[0,118],"}\n.",[1],"keyboard_con .",[1],"keyboard_tab .",[1],"keyboard_tab_li:last-of-type{margin-right:0}\n.",[1],"keyboard_con .",[1],"keyboard_tab .",[1],"keyboard_tab_li wx-image{height:",[0,44],";width:",[0,44],"}\n.",[1],"keyboard_con .",[1],"keyboard_tab .",[1],"keyboard_tab_li wx-text{color:#666;font-size:",[0,22],";margin-top:",[0,2],"}\n.",[1],"keyboard_con .",[1],"keyboard_tab .",[1],"show_keyboard{-webkit-align-self:stretch;align-self:stretch;gap:",[0,10],";padding:",[0,0]," ",[0,30],"}\n.",[1],"keyboard_con .",[1],"keyboard_tab .",[1],"show_keyboard wx-image{height:",[0,48],";width:",[0,48],"}\n.",[1],"top_line{background-color:#f9fafc;height:",[0,2],";width:100%}\n.",[1],"insert_pause_btn_wm{-webkit-align-self:stretch;align-self:stretch;gap:",[0,10],";padding:",[0,0]," ",[0,8],"}\n.",[1],"insert_pause_btn{background:#f7f8fa;border:",[0,2]," solid #ebedf0;border-radius:",[0,16],";color:#333;font-size:",[0,24],";gap:",[0,10],";padding:",[0,12]," ",[0,23],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/make/keyboard_top.wxss:1:1996)",{path:"./components/make/keyboard_top.wxss"});
}