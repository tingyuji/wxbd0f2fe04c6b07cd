$gwx_XC_21=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_21 || [];
function gz$gwx_XC_21_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_21_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_21_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_21_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'workname'])
Z([[2,'?:'],[[7],[3,'upflag']],[1,'top: 40%;'],[1,'top: 50%;']])
Z([3,'__e'])
Z([3,'flex_cen'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'clear']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'width:40rpx;height:40rpx;'])
Z([3,'__l'])
Z([3,'close'])
Z([3,'16'])
Z([3,'50e55ace-1'])
Z([3,'save'])
Z([[7],[3,'fileFlag']])
Z([[2,'!'],[[6],[[7],[3,'app_config']],[3,'nozdy']]])
Z(z[12])
Z(z[12])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_21_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_21_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_21=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_21=true;
var x=['./components/make/save_workname.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_21_1()
var eRD=_mz(z,'view',['class',0,'style',1],[],e,s,gg)
var bSD=_mz(z,'view',['bindtap',2,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var oTD=_mz(z,'u-icon',['bind:__l',6,'name',1,'size',2,'vueId',3],[],e,s,gg)
_(bSD,oTD)
_(eRD,bSD)
var xUD=_n('view')
_rz(z,xUD,'class',10,e,s,gg)
var oVD=_v()
_(xUD,oVD)
if(_oz(z,11,e,s,gg)){oVD.wxVkey=1
}
var fWD=_v()
_(xUD,fWD)
if(_oz(z,12,e,s,gg)){fWD.wxVkey=1
}
var cXD=_v()
_(xUD,cXD)
if(_oz(z,13,e,s,gg)){cXD.wxVkey=1
}
var hYD=_v()
_(xUD,hYD)
if(_oz(z,14,e,s,gg)){hYD.wxVkey=1
}
oVD.wxXCkey=1
fWD.wxXCkey=1
cXD.wxXCkey=1
hYD.wxXCkey=1
_(eRD,xUD)
_(r,eRD)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_21";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_21();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/make/save_workname.wxml'] = [$gwx_XC_21, './components/make/save_workname.wxml'];else __wxAppCode__['components/make/save_workname.wxml'] = $gwx_XC_21( './components/make/save_workname.wxml' );
	;__wxRoute = "components/make/save_workname";__wxRouteBegin = true;__wxAppCurrentFile__="components/make/save_workname.js";define("components/make/save_workname.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["components/make/save_workname"], {
  1207: function _(e, n, t) {
    "use strict";

    t.r(n);
    var r = t(1208),
      o = t(1210);
    for (var i in o) ["default"].indexOf(i) < 0 && function (e) {
      t.d(n, e, function () {
        return o[e];
      });
    }(i);
    t(1212);
    var c,
      u = t(230),
      f = Object(u["default"])(o["default"], r["render"], r["staticRenderFns"], !1, null, null, null, !1, r["components"], c);
    f.options.__file = "components/make/save_workname.vue", n["default"] = f.exports;
  },
  1208: function _(e, n, t) {
    "use strict";

    t.r(n);
    var r = t(1209);
    t.d(n, "render", function () {
      return r["render"];
    }), t.d(n, "staticRenderFns", function () {
      return r["staticRenderFns"];
    }), t.d(n, "recyclableRender", function () {
      return r["recyclableRender"];
    }), t.d(n, "components", function () {
      return r["components"];
    });
  },
  1209: function _(e, n, t) {
    "use strict";

    var r;
    t.r(n), t.d(n, "render", function () {
      return o;
    }), t.d(n, "staticRenderFns", function () {
      return c;
    }), t.d(n, "recyclableRender", function () {
      return i;
    }), t.d(n, "components", function () {
      return r;
    });
    try {
      r = {
        uIcon: function uIcon() {
          return Promise.all([t.e("common/vendor"), t.e("uni_modules/uview-ui/components/u-icon/u-icon")]).then(t.bind(null, 1431));
        }
      };
    } catch (u) {
      if (-1 === u.message.indexOf("Cannot find module") || -1 === u.message.indexOf(".vue")) throw u;
      console.error(u.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
    }
    var o = function o() {
        var e = this,
          n = e.$createElement;
        e._self._c;
        e._isMounted || (e.e0 = function (n) {
          e.fileFlag = !0;
        }, e.e1 = function (n) {
          e.fileFlag = !0;
        });
      },
      i = !1,
      c = [];
    o._withStripped = !0;
  },
  1210: function _(e, n, t) {
    "use strict";

    t.r(n);
    var r = t(1211),
      o = t.n(r);
    for (var i in r) ["default"].indexOf(i) < 0 && function (e) {
      t.d(n, e, function () {
        return r[e];
      });
    }(i);
    n["default"] = o.a;
  },
  1211: function _(e, n, t) {
    "use strict";

    (function (e) {
      var r = t(4);
      Object.defineProperty(n, "__esModule", {
        value: !0
      }), n.default = void 0;
      var o = r(t(11)),
        i = t(227),
        c = t(226);
      function u(e, n) {
        var t = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var r = Object.getOwnPropertySymbols(e);
          n && (r = r.filter(function (n) {
            return Object.getOwnPropertyDescriptor(e, n).enumerable;
          })), t.push.apply(t, r);
        }
        return t;
      }
      function f(e) {
        for (var n = 1; n < arguments.length; n++) {
          var t = null != arguments[n] ? arguments[n] : {};
          n % 2 ? u(Object(t), !0).forEach(function (n) {
            (0, o.default)(e, n, t[n]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : u(Object(t)).forEach(function (n) {
            Object.defineProperty(e, n, Object.getOwnPropertyDescriptor(t, n));
          });
        }
        return e;
      }
      var a = {
        computed: f({}, (0, i.mapState)(["app_config"])),
        data: function data() {
          return {
            fileFlag: !1,
            height: "",
            fileList: [],
            work_name: "",
            fid: "",
            fname: "默认",
            upflag: !1
          };
        },
        props: {
          work_wname: {
            type: String,
            default: ""
          }
        },
        mounted: function mounted() {
          this.getFileList(), this.work_name = this.work_wname;
        },
        methods: {
          upfocus: function upfocus() {
            this.upflag = !0;
          },
          choseflie: function choseflie(e) {
            this.fid = e.folderid, this.fname = e.foldername, this.fileFlag = !1;
          },
          getFileList: function getFileList() {
            var e = this,
              n = {
                type: 0
              };
            (0, c.getFiles)(n).then(function (n) {
              var t = {
                folderid: "",
                foldername: "我的作品"
              };
              e.fileList.push(t);
              for (var r = 0; r < n.model.length; r++) e.fileList.push(n.model[r]);
              e.fileList.length > 4 && (e.height = "320rpx");
            });
          },
          clear: function clear() {
            this.work_name = "";
          },
          confirm: function confirm() {
            if (this.work_name.length > 30) e.showToast({
              title: "作品名称太长",
              icon: "none"
            });else {
              var n = {
                wname: this.work_name,
                fid: this.fid
              };
              this.$emit("confirm", n);
            }
          },
          hide: function hide() {
            this.$emit("hide");
          }
        }
      };
      n.default = a;
    }).call(this, t(2)["default"]);
  },
  1212: function _(e, n, t) {
    "use strict";

    t.r(n);
    var r = t(1213),
      o = t.n(r);
    for (var i in r) ["default"].indexOf(i) < 0 && function (e) {
      t.d(n, e, function () {
        return r[e];
      });
    }(i);
    n["default"] = o.a;
  },
  1213: function _(e, n, t) {}
}]);
//# sourceMappingURL=../../../.sourcemap/mp-weixin/components/make/save_workname.js.map
;
(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['components/make/save_workname-create-component', {
  'components/make/save_workname-create-component': function componentsMakeSave_worknameCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1207));
  }
}, [['components/make/save_workname-create-component']]]);
},{isPage:false,isComponent:true,currentFile:'components/make/save_workname.js'});require("components/make/save_workname.js");