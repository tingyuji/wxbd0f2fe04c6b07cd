$gwx_XC_1=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_1 || [];
function gz$gwx_XC_1_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show_derive']])
Z([3,'expopup'])
Z([3,'z-index:999;'])
Z([3,'__e'])
Z([3,'expopup_mb'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'closePopup']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'expopup_con'])
Z([3,'flex_bet'])
Z([3,'font-weight:bold;font-size:32rpx;'])
Z([3,'导出为'])
Z([3,'__l'])
Z(z[3])
Z([3,'#000'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'closePopup']]]]]]]]])
Z([3,'arrow-right'])
Z([3,'32rpx'])
Z([3,'transform:rotate(90deg);'])
Z([3,'0054f250-1'])
Z([[2,'&&'],[[2,'!'],[[7],[3,'showMp3']]],[[7],[3,'isexamine']]])
Z(z[3])
Z([3,'derive_works'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'deriveWork']],[[4],[[5],[1,0]]]]]]]]]]])
Z([3,'background-color:rgba(247,82,82,0.1);'])
Z(z[7])
Z([3,'width:30%;'])
Z([3,'https://pysqstoss.shipook.com/static/minisource/10767/video.png'])
Z([3,'导出MP4'])
Z(z[3])
Z(z[20])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'deriveWork']],[[4],[[5],[1,1]]]]]]]]]]])
Z([3,'background-color:rgba(93,175,213,0.1);'])
Z(z[7])
Z([3,'width:29%;'])
Z([3,'https://pysqstoss.shipook.com/static/minisource/10767/link.png'])
Z([3,'链接下载'])
Z([[7],[3,'showPrivacy_ysxy']])
Z(z[10])
Z([3,'0054f250-2'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_1=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_1=true;
var x=['./components/expopup.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_1_1()
var lY=_v()
_(r,lY)
if(_oz(z,0,e,s,gg)){lY.wxVkey=1
var aZ=_mz(z,'view',['class',1,'style',1],[],e,s,gg)
var e2=_mz(z,'view',['bindtap',3,'class',1,'data-event-opts',2],[],e,s,gg)
_(aZ,e2)
var b3=_n('view')
_rz(z,b3,'class',6,e,s,gg)
var o4=_n('view')
_rz(z,o4,'class',7,e,s,gg)
var x5=_n('view')
_rz(z,x5,'style',8,e,s,gg)
var o6=_oz(z,9,e,s,gg)
_(x5,o6)
_(o4,x5)
var f7=_mz(z,'u-icon',['bind:__l',10,'bind:click',1,'color',2,'data-event-opts',3,'name',4,'size',5,'style',6,'vueId',7],[],e,s,gg)
_(o4,f7)
_(b3,o4)
var c8=_n('view')
var h9=_v()
_(c8,h9)
if(_oz(z,18,e,s,gg)){h9.wxVkey=1
var o0=_mz(z,'view',['bindtap',19,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var cAB=_mz(z,'view',['class',23,'style',1],[],e,s,gg)
var oBB=_n('image')
_rz(z,oBB,'src',25,e,s,gg)
_(cAB,oBB)
var lCB=_n('text')
var aDB=_oz(z,26,e,s,gg)
_(lCB,aDB)
_(cAB,lCB)
_(o0,cAB)
_(h9,o0)
}
var tEB=_mz(z,'view',['bindtap',27,'class',1,'data-event-opts',2,'style',3],[],e,s,gg)
var eFB=_mz(z,'view',['class',31,'style',1],[],e,s,gg)
var bGB=_n('image')
_rz(z,bGB,'src',33,e,s,gg)
_(eFB,bGB)
var oHB=_n('text')
var xIB=_oz(z,34,e,s,gg)
_(oHB,xIB)
_(eFB,oHB)
_(tEB,eFB)
_(c8,tEB)
h9.wxXCkey=1
_(b3,c8)
_(aZ,b3)
var t1=_v()
_(aZ,t1)
if(_oz(z,35,e,s,gg)){t1.wxVkey=1
var oJB=_mz(z,'make-show-privacy',['bind:__l',36,'vueId',1],[],e,s,gg)
_(t1,oJB)
}
t1.wxXCkey=1
t1.wxXCkey=3
_(lY,aZ)
}
lY.wxXCkey=1
lY.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_1";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_1();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/expopup.wxml'] = [$gwx_XC_1, './components/expopup.wxml'];else __wxAppCode__['components/expopup.wxml'] = $gwx_XC_1( './components/expopup.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/expopup.wxss'] = setCssToHead([".",[1],"expopup{background-color:rgba(0,0,0,.4);height:100%;left:0;position:fixed;top:0;width:100%;z-index:99999}\n.",[1],"expopup_con{background-color:#fff;border-radius:",[0,40]," ",[0,40]," 0 0;bottom:0;padding:",[0,32],"}\n.",[1],"expopup_con,.",[1],"expopup_mb{left:0;position:absolute;width:100%}\n.",[1],"expopup_mb{height:100%;top:0;z-index:-1}\n.",[1],"flex_bet{-webkit-justify-content:space-between;justify-content:space-between}\n.",[1],"derive_works,.",[1],"flex_bet{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex}\n.",[1],"derive_works{border-radius:",[0,24],";height:",[0,112],";-webkit-justify-content:space-around;justify-content:space-around;margin-bottom:",[0,20],";margin-top:",[0,32],";width:100%}\n.",[1],"derive_works wx-image{height:",[0,52],";width:",[0,52],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/expopup.wxss:1:655)",{path:"./components/expopup.wxss"});
}