$gwx_XC_1=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_1 || [];
function gz$gwx_XC_1_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show_derive']])
Z([3,'expopup'])
Z([3,'z-index:999;'])
Z([3,'expopup_con'])
Z([3,'__l'])
Z([3,'__e'])
Z([3,'#000'])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'closePopup']]]]]]]]])
Z([3,'arrow-right'])
Z([3,'32rpx'])
Z([3,'transform:rotate(90deg);'])
Z([3,'0054f250-1'])
Z([[2,'&&'],[[2,'!'],[[7],[3,'showMp3']]],[[7],[3,'isexamine']]])
Z([[7],[3,'showPrivacy_ysxy']])
Z(z[4])
Z([3,'0054f250-2'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_1_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_1_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_1=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_1=true;
var x=['./components/expopup.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_1_1()
var xC=_v()
_(r,xC)
if(_oz(z,0,e,s,gg)){xC.wxVkey=1
var oD=_mz(z,'view',['class',1,'style',1],[],e,s,gg)
var cF=_n('view')
_rz(z,cF,'class',3,e,s,gg)
var oH=_mz(z,'u-icon',['bind:__l',4,'bind:click',1,'color',2,'data-event-opts',3,'name',4,'size',5,'style',6,'vueId',7],[],e,s,gg)
_(cF,oH)
var hG=_v()
_(cF,hG)
if(_oz(z,12,e,s,gg)){hG.wxVkey=1
}
hG.wxXCkey=1
_(oD,cF)
var fE=_v()
_(oD,fE)
if(_oz(z,13,e,s,gg)){fE.wxVkey=1
var cI=_mz(z,'make-show-privacy',['bind:__l',14,'vueId',1],[],e,s,gg)
_(fE,cI)
}
fE.wxXCkey=1
fE.wxXCkey=3
_(xC,oD)
}
xC.wxXCkey=1
xC.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_1";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_1();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/expopup.wxml'] = [$gwx_XC_1, './components/expopup.wxml'];else __wxAppCode__['components/expopup.wxml'] = $gwx_XC_1( './components/expopup.wxml' );
	;__wxRoute = "components/expopup";__wxRouteBegin = true;__wxAppCurrentFile__="components/expopup.js";define("components/expopup.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["components/expopup"], {
  1394: function _(e, t, n) {
    "use strict";

    n.r(t);
    var o = n(1395),
      r = n(1397);
    for (var i in r) ["default"].indexOf(i) < 0 && function (e) {
      n.d(t, e, function () {
        return r[e];
      });
    }(i);
    n(1399);
    var c,
      s = n(230),
      u = Object(s["default"])(r["default"], o["render"], o["staticRenderFns"], !1, null, null, null, !1, o["components"], c);
    u.options.__file = "components/expopup.vue", t["default"] = u.exports;
  },
  1395: function _(e, t, n) {
    "use strict";

    n.r(t);
    var o = n(1396);
    n.d(t, "render", function () {
      return o["render"];
    }), n.d(t, "staticRenderFns", function () {
      return o["staticRenderFns"];
    }), n.d(t, "recyclableRender", function () {
      return o["recyclableRender"];
    }), n.d(t, "components", function () {
      return o["components"];
    });
  },
  1396: function _(e, t, n) {
    "use strict";

    var o;
    n.r(t), n.d(t, "render", function () {
      return r;
    }), n.d(t, "staticRenderFns", function () {
      return c;
    }), n.d(t, "recyclableRender", function () {
      return i;
    }), n.d(t, "components", function () {
      return o;
    });
    try {
      o = {
        uIcon: function uIcon() {
          return Promise.all([n.e("common/vendor"), n.e("uni_modules/uview-ui/components/u-icon/u-icon")]).then(n.bind(null, 1431));
        }
      };
    } catch (s) {
      if (-1 === s.message.indexOf("Cannot find module") || -1 === s.message.indexOf(".vue")) throw s;
      console.error(s.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
    }
    var r = function r() {
        var e = this,
          t = e.$createElement;
        e._self._c;
      },
      i = !1,
      c = [];
    r._withStripped = !0;
  },
  1397: function _(e, t, n) {
    "use strict";

    n.r(t);
    var o = n(1398),
      r = n.n(o);
    for (var i in o) ["default"].indexOf(i) < 0 && function (e) {
      n.d(t, e, function () {
        return o[e];
      });
    }(i);
    t["default"] = r.a;
  },
  1398: function _(e, t, n) {
    "use strict";

    (function (e) {
      var o = n(4);
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var r = o(n(11)),
        i = n(227);
      function c(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
          var o = Object.getOwnPropertySymbols(e);
          t && (o = o.filter(function (t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
          })), n.push.apply(n, o);
        }
        return n;
      }
      function s(e) {
        for (var t = 1; t < arguments.length; t++) {
          var n = null != arguments[t] ? arguments[t] : {};
          t % 2 ? c(Object(n), !0).forEach(function (t) {
            (0, r.default)(e, t, n[t]);
          }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : c(Object(n)).forEach(function (t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t));
          });
        }
        return e;
      }
      var u = {
        computed: s({}, (0, i.mapState)(["showPrivacy_ysxy"])),
        props: {
          show_derive: {
            type: Boolean,
            default: !1
          },
          url: {
            type: String,
            default: ""
          },
          only_mp3: {
            type: Boolean,
            default: !1
          }
        },
        data: function data() {
          return {
            showMp3: !1,
            isexamine: !0
          };
        },
        watch: {
          show_derive: function show_derive(e) {
            console.log(this.show_derive, "---show_derive-");
          },
          only_mp3: {
            handler: function handler(e, t) {
              this.showMp3 = e, console.log("only_mp3", e, "oldVal", t);
            },
            deep: !0,
            immediate: !0
          }
        },
        mounted: function mounted() {
          this.isexamine = !getApp().globalData.isexamine;
        },
        methods: (0, r.default)({
          deriveWork: function deriveWork(e) {
            this.$parent.deriveWork(e);
          },
          closePopup: function closePopup() {
            this.$emit("close", !1);
          }
        }, "deriveWork", function (t) {
          var n = this;
          if (this.closePopup(), 0 == t) {
            e.showLoading({
              title: "加载中",
              mask: !0
            });
            var o = {
                mp3url: this.url
              },
              r = getApp().globalData.appApi + "/peiyin/ttschangemp4app",
              i = function i(t) {
                console.log(t), null != t.model ? getApp().downMp4ForAlbum(t.model.mp4url) : e.showToast({
                  title: "导出失败",
                  icon: "none"
                });
              };
            n.$http.postRequest(o, r, i);
          } else 1 == t ? e.setClipboardData({
            data: this.url,
            success: function success() {
              e.showModal({
                title: "复制链接成功",
                content: "复制成功，您可以在浏览器中粘贴该链接打开或者分享发送给好友",
                success: function success(e) {
                  e.confirm;
                }
              });
            }
          }) : 2 == t && e.downloadFile({
            url: this.url,
            success: function success(t) {
              200 === t.statusCode && e.saveFile({
                tempFilePath: t.tempFilePath,
                success: function success(t) {
                  var n = plus.io.convertLocalFileSystemURL(t.savedFilePath);
                  testModule.shareFilePath(n, function (t) {
                    e.showToast({
                      title: "导出 " + t,
                      icon: "none"
                    });
                  });
                }
              });
            }
          });
          this.$emit("change", !1);
        })
      };
      t.default = u;
    }).call(this, n(2)["default"]);
  },
  1399: function _(e, t, n) {
    "use strict";

    n.r(t);
    var o = n(1400),
      r = n.n(o);
    for (var i in o) ["default"].indexOf(i) < 0 && function (e) {
      n.d(t, e, function () {
        return o[e];
      });
    }(i);
    t["default"] = r.a;
  },
  1400: function _(e, t, n) {}
}]);
//# sourceMappingURL=../../.sourcemap/mp-weixin/components/expopup.js.map
;
(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['components/expopup-create-component', {
  'components/expopup-create-component': function componentsExpopupCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1394));
  }
}, [['components/expopup-create-component']]]);
},{isPage:false,isComponent:true,currentFile:'components/expopup.js'});require("components/expopup.js");