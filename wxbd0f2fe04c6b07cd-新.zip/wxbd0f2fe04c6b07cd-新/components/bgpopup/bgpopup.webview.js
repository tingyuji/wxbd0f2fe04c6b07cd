$gwx_XC_0=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_0 || [];
function gz$gwx_XC_0_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'bgpopup_main'])
Z([3,'bgpopup_con'])
Z([3,'text-align:center;font-size:32rpx;margin-bottom:20rpx;'])
Z([3,'背景音使用声明'])
Z([3,'您对背景音乐功能的使用即表示您完全接受本协议下的全部条款:'])
Z([3,'1.背景音乐中所有作品内容，包括但不限于歌词、歌曲、音频(一下简称作品)均为用户自行上传及制作，用户在上传及制作作品时，如需获得该作品内容权利或任何第三方的事先授权或批准的，应事先获得该等授权或批准；一旦用户上传及制作作品，将被视为用户已事先获得该等授权或。'])
Z([3,'2.您于背景音乐中上传并制作的作品中所含有的知识产权归您所有。您同意授予背景音乐为提供本服务、填充背景音背景音社区内容、娱乐和宣传推广本服务之目的的所必须的免费、非独占、不可撤销的可在全国范围内使用您上传作品的权利。'])
Z([3,'3.您一旦在上传及分享背景音乐到本软件时，将视为用户已事先获得相关授权或批准，并且可共享展示给其他用户。'])
Z([3,'4.如用户发布侵害他人合法权利的作品内容，背景音乐有权立即采取适当措施。包括但不限于：删除侵权作品，对违规用户进行删除、禁言和永久封禁等。'])
Z([3,'5.如您认为背景音乐用户上传内容侵权了您的相关权益，请联系客服，一经核实我们将根据相关法律规定采取措施删除相关内容。'])
Z([3,'6.您的背景音乐作品可被其他用户选择制作配音作品。'])
Z([3,'7.其他未尽事宜，请参见“用户服务协议”。'])
Z([3,'__e'])
Z([3,'bgpopup_btn'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'readContent']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'我已阅读，并遵守声明内容'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_0_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_0_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_0=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_0=true;
var x=['./components/bgpopup/bgpopup.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_0_1()
var oB=_n('view')
_rz(z,oB,'class',0,e,s,gg)
var xC=_n('view')
_rz(z,xC,'class',1,e,s,gg)
var oD=_n('view')
_rz(z,oD,'style',2,e,s,gg)
var fE=_oz(z,3,e,s,gg)
_(oD,fE)
_(xC,oD)
var cF=_n('view')
var hG=_oz(z,4,e,s,gg)
_(cF,hG)
_(xC,cF)
var oH=_n('view')
var cI=_oz(z,5,e,s,gg)
_(oH,cI)
_(xC,oH)
var oJ=_n('view')
var lK=_oz(z,6,e,s,gg)
_(oJ,lK)
_(xC,oJ)
var aL=_n('view')
var tM=_oz(z,7,e,s,gg)
_(aL,tM)
_(xC,aL)
var eN=_n('view')
var bO=_oz(z,8,e,s,gg)
_(eN,bO)
_(xC,eN)
var oP=_n('view')
var xQ=_oz(z,9,e,s,gg)
_(oP,xQ)
_(xC,oP)
var oR=_n('view')
var fS=_oz(z,10,e,s,gg)
_(oR,fS)
_(xC,oR)
var cT=_n('view')
var hU=_oz(z,11,e,s,gg)
_(cT,hU)
_(xC,cT)
var oV=_mz(z,'view',['bindtap',12,'class',1,'data-event-opts',2],[],e,s,gg)
var cW=_oz(z,15,e,s,gg)
_(oV,cW)
_(xC,oV)
_(oB,xC)
_(r,oB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_0";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_0();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/bgpopup/bgpopup.wxml'] = [$gwx_XC_0, './components/bgpopup/bgpopup.wxml'];else __wxAppCode__['components/bgpopup/bgpopup.wxml'] = $gwx_XC_0( './components/bgpopup/bgpopup.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/bgpopup/bgpopup.wxss'] = setCssToHead([".",[1],"bgpopup_main{-webkit-align-items:center;align-items:center;background-color:rgba(0,0,0,.4);display:-webkit-flex;display:flex;height:100%;-webkit-justify-content:space-around;justify-content:space-around;left:0;position:fixed;top:0;width:100%;z-index:99999}\n.",[1],"bgpopup_con{background-color:#fff;border-radius:",[0,20],";box-sizing:border-box;padding:",[0,32],";width:92%}\n.",[1],"bgpopup_con wx-view{font-size:",[0,24],";margin:",[0,6]," 0}\n.",[1],"bgpopup_btn{color:#ffc22d;font-size:",[0,32],"!important;padding-top:",[0,40],";text-align:center}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/bgpopup/bgpopup.wxss:1:372)",{path:"./components/bgpopup/bgpopup.wxss"});
}