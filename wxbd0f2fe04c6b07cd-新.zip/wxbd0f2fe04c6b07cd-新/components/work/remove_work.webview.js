$gwx_XC_32=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_32 || [];
function gz$gwx_XC_32_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_32_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_32_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_32_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'remove_work'])
Z([3,'remove'])
Z([3,'remove_tit'])
Z([3,'__e'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'hide']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'../../static/images/work/close.png'])
Z([3,'移动至'])
Z(z[3])
Z([3,'wuwjj flex_bet'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[1,'gwjj']]]]]]]]])
Z([3,'wu_left'])
Z([3,'wu_tit'])
Z([3,'我的配音'])
Z([3,'choose'])
Z([[2,'&&'],[[7],[3,'choseFileFlag']],[[2,'!'],[[7],[3,'folderid']]]])
Z([3,'../../static/images/work/select_on.png'])
Z([[2,'!'],[[7],[3,'choseFileFlag']]])
Z([3,'../../static/images/work/select_off.png'])
Z([3,'wjj'])
Z([3,'wjj_tit'])
Z([3,'文件夹'])
Z([3,'true'])
Z([3,'width:100%;height:506rpx;'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'fileList']])
Z(z[23])
Z(z[3])
Z([3,'wjj_list'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'chooseFile']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'fileList']],[1,'']],[[7],[3,'index']]],[1,'folderid']]]]]]]]]]]]]]])
Z([3,'wjj_image'])
Z([3,'https://pysqstoss.shipook.com/static/minisource/10767/files.png'])
Z([3,'wjj_con flex_bet'])
Z([3,'con_desp'])
Z([3,'text1'])
Z([a,[[6],[[7],[3,'item']],[3,'foldername']]])
Z([3,'text2'])
Z([a,[[2,'+'],[[6],[[7],[3,'item']],[3,'wknum']],[1,'个文件']]])
Z([[2,'=='],[[6],[[7],[3,'item']],[3,'folderid']],[[7],[3,'folderid']]])
Z(z[15])
Z([[2,'!='],[[6],[[7],[3,'item']],[3,'folderid']],[[7],[3,'folderid']]])
Z(z[17])
Z([3,'btns'])
Z(z[3])
Z([3,'btn1 flex_cen'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'build']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'新建文件夹'])
Z(z[3])
Z([3,'btn2 flex_cen'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[1,'cofirmChooseFile']]]]]]]]])
Z([3,'确定'])
Z([[7],[3,'buidFileFlag']])
Z([3,'__l'])
Z(z[3])
Z(z[3])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^hide']],[[4],[[5],[[4],[[5],[1,'qxbuild']]]]]]]],[[4],[[5],[[5],[1,'^confirm']],[[4],[[5],[[4],[[5],[1,'confirmFileName']]]]]]]]])
Z([3,'1b59fffd-1'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_32_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_32_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_32=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_32=true;
var x=['./components/work/remove_work.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_32_1()
var hA2=_n('view')
_rz(z,hA2,'class',0,e,s,gg)
var cC2=_n('view')
_rz(z,cC2,'class',1,e,s,gg)
var oD2=_n('view')
_rz(z,oD2,'class',2,e,s,gg)
var lE2=_mz(z,'image',['bindtap',3,'data-event-opts',1,'src',2],[],e,s,gg)
_(oD2,lE2)
var aF2=_n('text')
var tG2=_oz(z,6,e,s,gg)
_(aF2,tG2)
_(oD2,aF2)
_(cC2,oD2)
var eH2=_mz(z,'view',['bindtap',7,'class',1,'data-event-opts',2],[],e,s,gg)
var bI2=_n('view')
_rz(z,bI2,'class',10,e,s,gg)
var oJ2=_n('view')
_rz(z,oJ2,'class',11,e,s,gg)
var xK2=_oz(z,12,e,s,gg)
_(oJ2,xK2)
_(bI2,oJ2)
_(eH2,bI2)
var oL2=_n('view')
_rz(z,oL2,'class',13,e,s,gg)
var fM2=_v()
_(oL2,fM2)
if(_oz(z,14,e,s,gg)){fM2.wxVkey=1
var hO2=_n('image')
_rz(z,hO2,'src',15,e,s,gg)
_(fM2,hO2)
}
var cN2=_v()
_(oL2,cN2)
if(_oz(z,16,e,s,gg)){cN2.wxVkey=1
var oP2=_n('image')
_rz(z,oP2,'src',17,e,s,gg)
_(cN2,oP2)
}
fM2.wxXCkey=1
cN2.wxXCkey=1
_(eH2,oL2)
_(cC2,eH2)
var cQ2=_n('view')
_rz(z,cQ2,'class',18,e,s,gg)
var oR2=_n('view')
_rz(z,oR2,'class',19,e,s,gg)
var lS2=_oz(z,20,e,s,gg)
_(oR2,lS2)
_(cQ2,oR2)
_(cC2,cQ2)
var aT2=_mz(z,'scroll-view',['scrollY',21,'style',1],[],e,s,gg)
var tU2=_v()
_(aT2,tU2)
var eV2=function(oX2,bW2,xY2,gg){
var f12=_mz(z,'view',['bindtap',27,'class',1,'data-event-opts',2],[],oX2,bW2,gg)
var c22=_mz(z,'image',['class',30,'src',1],[],oX2,bW2,gg)
_(f12,c22)
var h32=_n('view')
_rz(z,h32,'class',32,oX2,bW2,gg)
var o62=_n('view')
_rz(z,o62,'class',33,oX2,bW2,gg)
var l72=_n('text')
_rz(z,l72,'class',34,oX2,bW2,gg)
var a82=_oz(z,35,oX2,bW2,gg)
_(l72,a82)
_(o62,l72)
var t92=_n('text')
_rz(z,t92,'class',36,oX2,bW2,gg)
var e02=_oz(z,37,oX2,bW2,gg)
_(t92,e02)
_(o62,t92)
_(h32,o62)
var o42=_v()
_(h32,o42)
if(_oz(z,38,oX2,bW2,gg)){o42.wxVkey=1
var bA3=_n('image')
_rz(z,bA3,'src',39,oX2,bW2,gg)
_(o42,bA3)
}
var c52=_v()
_(h32,c52)
if(_oz(z,40,oX2,bW2,gg)){c52.wxVkey=1
var oB3=_n('image')
_rz(z,oB3,'src',41,oX2,bW2,gg)
_(c52,oB3)
}
o42.wxXCkey=1
c52.wxXCkey=1
_(f12,h32)
_(xY2,f12)
return xY2
}
tU2.wxXCkey=2
_2z(z,25,eV2,e,s,gg,tU2,'item','index','index')
_(cC2,aT2)
var xC3=_n('view')
_rz(z,xC3,'class',42,e,s,gg)
var oD3=_mz(z,'view',['bindtap',43,'class',1,'data-event-opts',2],[],e,s,gg)
var fE3=_oz(z,46,e,s,gg)
_(oD3,fE3)
_(xC3,oD3)
var cF3=_mz(z,'view',['bindtap',47,'class',1,'data-event-opts',2],[],e,s,gg)
var hG3=_oz(z,50,e,s,gg)
_(cF3,hG3)
_(xC3,cF3)
_(cC2,xC3)
_(hA2,cC2)
var oB2=_v()
_(hA2,oB2)
if(_oz(z,51,e,s,gg)){oB2.wxVkey=1
var oH3=_mz(z,'new-folder',['bind:__l',52,'bind:confirm',1,'bind:hide',2,'data-event-opts',3,'vueId',4],[],e,s,gg)
_(oB2,oH3)
}
oB2.wxXCkey=1
oB2.wxXCkey=3
_(r,hA2)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_32";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_32();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/work/remove_work.wxml'] = [$gwx_XC_32, './components/work/remove_work.wxml'];else __wxAppCode__['components/work/remove_work.wxml'] = $gwx_XC_32( './components/work/remove_work.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/work/remove_work.wxss'] = setCssToHead([".",[1],"remove_work{background:rgba(0,0,0,.5);height:100%;z-index:99999}\n.",[1],"remove_work,.",[1],"remove_work .",[1],"remove{bottom:0;left:0;position:fixed;width:100%}\n.",[1],"remove_work .",[1],"remove{background-color:#fff;border-radius:",[0,30]," ",[0,30]," ",[0,0]," ",[0,0],";height:",[0,1147],";padding:",[0,30],"}\n.",[1],"remove_work .",[1],"remove .",[1],"remove_tit{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;height:",[0,108],";width:100%}\n.",[1],"remove_work .",[1],"remove .",[1],"remove_tit wx-image{height:",[0,48],";width:",[0,48],"}\n.",[1],"remove_work .",[1],"remove .",[1],"remove_tit wx-text{color:#333;font-size:",[0,32],";font-weight:700;margin-left:",[0,249],"}\n.",[1],"remove_work .",[1],"remove .",[1],"wuwjj{background:#f7f8fa;border:",[0,2]," solid #ebedf0;border-radius:",[0,30],";height:",[0,137],";margin-top:",[0,16],";padding:",[0,30],";width:100%}\n.",[1],"remove_work .",[1],"remove .",[1],"wuwjj .",[1],"wu_left{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column}\n.",[1],"remove_work .",[1],"remove .",[1],"wuwjj .",[1],"wu_left .",[1],"wu_tit{color:#333;font-size:",[0,28],";font-weight:700}\n.",[1],"remove_work .",[1],"remove .",[1],"wuwjj .",[1],"wu_left .",[1],"wu_count{color:#999;font-size:",[0,24],";margin-top:",[0,4],"}\n.",[1],"remove_work .",[1],"remove .",[1],"wuwjj .",[1],"choose wx-image{height:",[0,36],";width:",[0,36],"}\n.",[1],"remove_work .",[1],"remove .",[1],"wjj{margin-top:",[0,47],";width:100%}\n.",[1],"remove_work .",[1],"remove .",[1],"wjj .",[1],"wjj_tit{color:#333;font-size:",[0,32],";font-weight:700;height:",[0,45],";width:100%}\n.",[1],"remove_work .",[1],"remove .",[1],"wjj_list{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;height:",[0,144],";width:100%}\n.",[1],"remove_work .",[1],"remove .",[1],"wjj_list .",[1],"wjj_image{height:",[0,96],";width:",[0,96],"}\n.",[1],"remove_work .",[1],"remove .",[1],"wjj_list .",[1],"wjj_con{margin-left:",[0,24],";width:calc(100% - ",[0,120],")}\n.",[1],"remove_work .",[1],"remove .",[1],"wjj_list .",[1],"wjj_con wx-image{height:",[0,36],";width:",[0,36],"}\n.",[1],"remove_work .",[1],"remove .",[1],"wjj_list .",[1],"wjj_con .",[1],"con_desp{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column}\n.",[1],"remove_work .",[1],"remove .",[1],"wjj_list .",[1],"wjj_con .",[1],"con_desp .",[1],"text1{color:#333;font-size:",[0,28],";font-weight:700}\n.",[1],"remove_work .",[1],"remove .",[1],"wjj_list .",[1],"wjj_con .",[1],"con_desp .",[1],"text2{color:#999;font-size:",[0,24],";margin-top:",[0,4],"}\n.",[1],"remove_work .",[1],"remove .",[1],"btns{display:-webkit-flex;display:flex;height:",[0,147],";margin-top:",[0,74],";padding:",[0,30]," ",[0,10],";width:100%}\n.",[1],"remove_work .",[1],"remove .",[1],"btns .",[1],"btn1{background:#fff;border:",[0,2]," solid #ebedf0;border-radius:",[0,20],";color:#333;font-size:",[0,28],";font-weight:700;height:",[0,87],";width:",[0,320],"}\n.",[1],"remove_work .",[1],"remove .",[1],"btns .",[1],"btn2{background:linear-gradient(90deg,#ffa001,#ff7e05);border-radius:",[0,20],";color:#fff;font-size:",[0,28],";font-weight:700;height:",[0,87],";margin-left:",[0,30],";width:",[0,320],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/work/remove_work.wxss:1:1552)",{path:"./components/work/remove_work.wxss"});
}