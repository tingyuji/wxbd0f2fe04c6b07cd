$gwx_XC_28=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_28 || [];
function gz$gwx_XC_28_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_28_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'flex_bet'])
Z([[7],[3,'batch_state']])
Z([3,'file_select'])
Z([3,'__e'])
Z([[4],[[5],[[5],[[5],[1,'file_item']],[1,'flex_cen']],[[2,'?:'],[[7],[3,'batch_state']],[1,'file_item_bathch'],[1,'']]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'jumpFileInfo']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'file_item_left'])
Z([[4],[[5],[[2,'?:'],[[7],[3,'batch_state']],[1,'work_item_bathch'],[1,'']]]])
Z([3,'https://pysqstoss.shipook.com/static/minisource/10767/files.png'])
Z([[4],[[5],[[2,'?:'],[[7],[3,'batch_state']],[1,'file_tit work_item_bathch'],[1,'file_tit']]]])
Z([3,'tit1'])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'item']],[3,'foldername']]],[1,'']]])
Z([3,'tit2'])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'item']],[3,'wknum']]],[1,'个文件']]])
Z(z[3])
Z([[4],[[5],[[2,'?:'],[[7],[3,'batch_state']],[1,'file_item_right work_item_bathch'],[1,'file_item_right']]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'openFileMore']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'/static/images/make/diandiandian.png'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_28_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_28_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_28=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_28=true;
var x=['./components/work/file_item.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_28_1()
var fOZ=_n('view')
_rz(z,fOZ,'class',0,e,s,gg)
var cPZ=_v()
_(fOZ,cPZ)
if(_oz(z,1,e,s,gg)){cPZ.wxVkey=1
var hQZ=_n('view')
_rz(z,hQZ,'class',2,e,s,gg)
_(cPZ,hQZ)
}
var oRZ=_mz(z,'view',['bindtap',3,'class',1,'data-event-opts',2],[],e,s,gg)
var cSZ=_n('view')
_rz(z,cSZ,'class',6,e,s,gg)
var oTZ=_mz(z,'image',['class',7,'src',1],[],e,s,gg)
_(cSZ,oTZ)
var lUZ=_n('view')
_rz(z,lUZ,'class',9,e,s,gg)
var aVZ=_n('view')
_rz(z,aVZ,'class',10,e,s,gg)
var tWZ=_oz(z,11,e,s,gg)
_(aVZ,tWZ)
_(lUZ,aVZ)
var eXZ=_n('view')
_rz(z,eXZ,'class',12,e,s,gg)
var bYZ=_oz(z,13,e,s,gg)
_(eXZ,bYZ)
_(lUZ,eXZ)
_(cSZ,lUZ)
_(oRZ,cSZ)
var oZZ=_mz(z,'image',['catchtap',14,'class',1,'data-event-opts',2,'src',3],[],e,s,gg)
_(oRZ,oZZ)
_(fOZ,oRZ)
cPZ.wxXCkey=1
_(r,fOZ)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_28";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_28();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/work/file_item.wxml'] = [$gwx_XC_28, './components/work/file_item.wxml'];else __wxAppCode__['components/work/file_item.wxml'] = $gwx_XC_28( './components/work/file_item.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/work/file_item.wxss'] = setCssToHead([".",[1],"file_item_bathch{width:calc(100% - ",[0,70],")!important}\n.",[1],"work_item_bathch{opacity:.3}\n.",[1],"file_select{-webkit-flex-shrink:0;flex-shrink:0;height:",[0,40],";margin-right:",[0,30],";width:",[0,40],"}\n.",[1],"file_item{background-color:#fff;border-radius:",[0,20],";height:",[0,144],";margin-bottom:",[0,24],";padding:",[0,24]," ",[0,30],";width:100%}\n.",[1],"file_item .",[1],"file_item_left{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;width:",[0,552],"}\n.",[1],"file_item .",[1],"file_item_left wx-image{height:",[0,96],";margin-right:",[0,24],";width:",[0,96],"}\n.",[1],"file_item .",[1],"file_item_left .",[1],"file_tit{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column}\n.",[1],"file_item .",[1],"file_item_left .",[1],"file_tit .",[1],"tit1{ont-size:",[0,32],";color:#333;width:",[0,432],"}\n.",[1],"file_item .",[1],"file_item_left .",[1],"file_tit .",[1],"tit2{color:#999;font-size:",[0,24],";width:",[0,432],"}\n.",[1],"file_item .",[1],"file_item_right{height:",[0,38],";margin-left:",[0,30],";width:",[0,48],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/work/file_item.wxss:1:441)",{path:"./components/work/file_item.wxss"});
}