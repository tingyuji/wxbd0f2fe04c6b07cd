$gwx_XC_26=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_26 || [];
function gz$gwx_XC_26_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_26_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'expopup'])
Z([3,'__e'])
Z([3,'bg_con'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'hide']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[7],[3,'show_copy_err']])
Z([3,'err_con'])
Z([3,'flex_cen'])
Z([3,'margin:32rpx 0;'])
Z([3,'复制失败，请长按下方输入框中并手动复制内容'])
Z(z[1])
Z([[4],[[5],[[4],[[5],[[5],[1,'input']],[[4],[[5],[[4],[[5],[[5],[1,'__set_model']],[[4],[[5],[[5],[[5],[[5],[1,'']],[1,'link']],[1,'$event']],[[4],[[5]]]]]]]]]]]]])
Z([[7],[3,'link']])
Z([3,'expopup_con'])
Z([3,'expopup_tit'])
Z([3,'配音下载'])
Z([3,'expopup_tab'])
Z(z[1])
Z([[4],[[5],[[5],[1,'expopup_tab_li']],[[2,'?:'],[[2,'==='],[[7],[3,'tab']],[1,0]],[1,'expopup_tab_act'],[1,'']]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e0']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'MP3'])
Z(z[1])
Z([[4],[[5],[[5],[1,'expopup_tab_li']],[[2,'?:'],[[2,'==='],[[7],[3,'tab']],[1,1]],[1,'expopup_tab_act'],[1,'']]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e1']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'MP4'])
Z(z[1])
Z([[4],[[5],[[5],[1,'expopup_tab_li']],[[2,'?:'],[[2,'==='],[[7],[3,'tab']],[1,2]],[1,'expopup_tab_act'],[1,'']]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e2']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'MP4(字幕)'])
Z(z[1])
Z([[4],[[5],[[5],[1,'expopup_tab_li']],[[2,'?:'],[[2,'==='],[[7],[3,'tab']],[1,3]],[1,'expopup_tab_act'],[1,'']]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e3']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'SRT'])
Z(z[1])
Z([3,'true'])
Z([3,'swiper'])
Z([[7],[3,'tab']])
Z([[4],[[5],[[4],[[5],[[5],[1,'change']],[[4],[[5],[[4],[[5],[[5],[1,'swiperchange']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'index'])
Z([3,'item'])
Z([1,4])
Z(z[37])
Z([3,'expopup_main'])
Z([3,'width:100%;display:flex;'])
Z([[2,'&&'],[[2,'=='],[[7],[3,'ycwxflag']],[1,false]],[[2,'!'],[[6],[[7],[3,'app_config']],[3,'nozdy']]]])
Z(z[1])
Z([3,'expopup_main_li'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'shareWx']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'https://pysqstoss.shipook.com/static/minisource/10767/weixin.png'])
Z([3,'微信'])
Z([[2,'||'],[[2,'==='],[[7],[3,'tab']],[1,1]],[[2,'==='],[[7],[3,'tab']],[1,2]]])
Z(z[1])
Z(z[45])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'downloadToAlbum']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'https://pysqstoss.shipook.com/static/minisource/10767/xiangce.png'])
Z([3,'相册'])
Z(z[1])
Z(z[45])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'copyLink']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'https://pysqstoss.shipook.com/static/minisource/10767/fuzhilianjie.png'])
Z([3,'链接下载'])
Z([3,'expopup_tip flex_cen'])
Z([[2,'||'],[[2,'=='],[[7],[3,'tab']],[1,2]],[[2,'=='],[[7],[3,'tab']],[1,3]]])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[2,'?:'],[[2,'=='],[[7],[3,'tab']],[1,2]],[1,'视频字幕功能，不能确保百分百准确无误'],[1,'字幕功能，不能确保百分百准确无误']]],[1,'']]])
Z([[2,'!='],[[7],[3,'tab']],[1,0]])
Z([[2,'+'],[[2,'+'],[1,'color:'],[[2,'?:'],[[2,'=='],[[7],[3,'isfinish']],[1,'2']],[1,'#FF932F'],[1,'']]],[1,';']])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'$root']],[3,'f0']]],[1,'']]])
Z([[7],[3,'showPrivacy_ysxy']])
Z([3,'__l'])
Z([3,'0cedc1db-1'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_26_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_26_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_26=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_26=true;
var x=['./components/work/expopup1.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_26_1()
var eZX=_n('view')
_rz(z,eZX,'class',0,e,s,gg)
var x3X=_mz(z,'view',['bindtap',1,'class',1,'data-event-opts',2],[],e,s,gg)
_(eZX,x3X)
var b1X=_v()
_(eZX,b1X)
if(_oz(z,4,e,s,gg)){b1X.wxVkey=1
var o4X=_n('view')
_rz(z,o4X,'class',5,e,s,gg)
var f5X=_mz(z,'view',['class',6,'style',1],[],e,s,gg)
var c6X=_oz(z,8,e,s,gg)
_(f5X,c6X)
_(o4X,f5X)
var h7X=_mz(z,'textarea',['bindinput',9,'data-event-opts',1,'value',2],[],e,s,gg)
_(o4X,h7X)
_(b1X,o4X)
}
var o8X=_n('view')
_rz(z,o8X,'class',12,e,s,gg)
var c9X=_n('view')
_rz(z,c9X,'class',13,e,s,gg)
var o0X=_oz(z,14,e,s,gg)
_(c9X,o0X)
_(o8X,c9X)
var lAY=_n('view')
_rz(z,lAY,'class',15,e,s,gg)
var aBY=_mz(z,'view',['bindtap',16,'class',1,'data-event-opts',2],[],e,s,gg)
var tCY=_oz(z,19,e,s,gg)
_(aBY,tCY)
_(lAY,aBY)
var eDY=_mz(z,'view',['bindtap',20,'class',1,'data-event-opts',2],[],e,s,gg)
var bEY=_oz(z,23,e,s,gg)
_(eDY,bEY)
_(lAY,eDY)
var oFY=_mz(z,'view',['bindtap',24,'class',1,'data-event-opts',2],[],e,s,gg)
var xGY=_oz(z,27,e,s,gg)
_(oFY,xGY)
_(lAY,oFY)
var oHY=_mz(z,'view',['bindtap',28,'class',1,'data-event-opts',2],[],e,s,gg)
var fIY=_oz(z,31,e,s,gg)
_(oHY,fIY)
_(lAY,oHY)
_(o8X,lAY)
var cJY=_mz(z,'swiper',['bindchange',32,'circular',1,'class',2,'current',3,'data-event-opts',4],[],e,s,gg)
var hKY=_v()
_(cJY,hKY)
var oLY=function(oNY,cMY,lOY,gg){
var tQY=_n('swiper-item')
_rz(z,tQY,'class',41,oNY,cMY,gg)
var eRY=_n('view')
_rz(z,eRY,'style',42,oNY,cMY,gg)
var bSY=_v()
_(eRY,bSY)
if(_oz(z,43,oNY,cMY,gg)){bSY.wxVkey=1
var xUY=_mz(z,'view',['bindtap',44,'class',1,'data-event-opts',2],[],oNY,cMY,gg)
var oVY=_n('image')
_rz(z,oVY,'src',47,oNY,cMY,gg)
_(xUY,oVY)
var fWY=_n('text')
var cXY=_oz(z,48,oNY,cMY,gg)
_(fWY,cXY)
_(xUY,fWY)
_(bSY,xUY)
}
var oTY=_v()
_(eRY,oTY)
if(_oz(z,49,oNY,cMY,gg)){oTY.wxVkey=1
var hYY=_mz(z,'view',['bindtap',50,'class',1,'data-event-opts',2],[],oNY,cMY,gg)
var oZY=_n('image')
_rz(z,oZY,'src',53,oNY,cMY,gg)
_(hYY,oZY)
var c1Y=_n('text')
var o2Y=_oz(z,54,oNY,cMY,gg)
_(c1Y,o2Y)
_(hYY,c1Y)
_(oTY,hYY)
}
var l3Y=_mz(z,'view',['bindtap',55,'class',1,'data-event-opts',2],[],oNY,cMY,gg)
var a4Y=_n('image')
_rz(z,a4Y,'src',58,oNY,cMY,gg)
_(l3Y,a4Y)
var t5Y=_n('text')
var e6Y=_oz(z,59,oNY,cMY,gg)
_(t5Y,e6Y)
_(l3Y,t5Y)
_(eRY,l3Y)
bSY.wxXCkey=1
oTY.wxXCkey=1
_(tQY,eRY)
var b7Y=_n('view')
_rz(z,b7Y,'class',60,oNY,cMY,gg)
var o8Y=_v()
_(b7Y,o8Y)
if(_oz(z,61,oNY,cMY,gg)){o8Y.wxVkey=1
var o0Y=_n('view')
var fAZ=_oz(z,62,oNY,cMY,gg)
_(o0Y,fAZ)
_(o8Y,o0Y)
}
var x9Y=_v()
_(b7Y,x9Y)
if(_oz(z,63,oNY,cMY,gg)){x9Y.wxVkey=1
var cBZ=_n('text')
_rz(z,cBZ,'style',64,oNY,cMY,gg)
var hCZ=_oz(z,65,oNY,cMY,gg)
_(cBZ,hCZ)
_(x9Y,cBZ)
}
o8Y.wxXCkey=1
x9Y.wxXCkey=1
_(tQY,b7Y)
_(lOY,tQY)
return lOY
}
hKY.wxXCkey=2
_2z(z,39,oLY,e,s,gg,hKY,'item','index','index')
_(o8X,cJY)
_(eZX,o8X)
var o2X=_v()
_(eZX,o2X)
if(_oz(z,66,e,s,gg)){o2X.wxVkey=1
var oDZ=_mz(z,'make-show-privacy',['bind:__l',67,'vueId',1],[],e,s,gg)
_(o2X,oDZ)
}
b1X.wxXCkey=1
o2X.wxXCkey=1
o2X.wxXCkey=3
_(r,eZX)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_26";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_26();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/work/expopup1.wxml'] = [$gwx_XC_26, './components/work/expopup1.wxml'];else __wxAppCode__['components/work/expopup1.wxml'] = $gwx_XC_26( './components/work/expopup1.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/work/expopup1.wxss'] = setCssToHead([".",[1],"expopup_tip{display:-webkit-flex;display:flex;gap:",[0,16],";margin-left:",[0,-55],";margin-top:",[0,56],";width:100%}\n.",[1],"expopup_tip wx-text,.",[1],"expopup_tip wx-view{color:#666;font-size:",[0,24],"}\n.",[1],"expopup_tip wx-text{text-align:center}\n.",[1],"err_con{background-color:#fff;border-radius:",[0,30],";height:",[0,300],";left:50%;padding:",[0,30],";position:absolute;top:",[0,240],";-webkit-transform:translateX(-50%);transform:translateX(-50%);width:90%;z-index:2}\n.",[1],"expopup{background-color:rgba(0,0,0,.5);height:100%;left:0;position:fixed;top:0;width:100%;z-index:999}\n.",[1],"expopup_con{background-color:#fff;border-radius:",[0,30]," ",[0,30]," 0 0;bottom:0;height:",[0,584],";left:0;position:absolute;width:100%;z-index:2}\n.",[1],"expopup_con .",[1],"swiper{display:-webkit-flex;display:flex;padding:",[0,60]," ",[0,55],";width:100%}\n.",[1],"expopup_con .",[1],"expopup_main,.",[1],"expopup_con .",[1],"expopup_main .",[1],"expopup_main_li{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column}\n.",[1],"expopup_con .",[1],"expopup_main .",[1],"expopup_main_li{-webkit-align-items:center;align-items:center;margin-right:",[0,48],"}\n.",[1],"expopup_con .",[1],"expopup_main .",[1],"expopup_main_li wx-image{height:",[0,96],";margin-bottom:",[0,16],";width:",[0,96],"}\n.",[1],"expopup_con .",[1],"expopup_tab{-webkit-align-items:center;align-items:center;border-bottom:",[0,2]," solid #f2f2f2;display:-webkit-flex;display:flex;height:",[0,82],";-webkit-justify-content:space-between;justify-content:space-between;margin-top:",[0,30],";width:100%}\n.",[1],"expopup_con .",[1],"expopup_tab .",[1],"expopup_tab_act{color:#ff932f!important;position:relative}\n.",[1],"expopup_con .",[1],"expopup_tab .",[1],"expopup_tab_act::before{background-color:#ff932f;border-radius:",[0,49],";bottom:",[0,-24],";content:\x22\x22;height:",[0,8],";left:50%;position:absolute;-webkit-transform:translateX(-50%);transform:translateX(-50%);width:",[0,36],"}\n.",[1],"expopup_con .",[1],"expopup_tab .",[1],"expopup_tab_li{color:#999;font-size:",[0,30],";text-align:center;width:25%}\n.",[1],"expopup_con .",[1],"expopup_tit{font-size:",[0,32],";font-weight:700;margin-top:",[0,32],";text-align:center}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/work/expopup1.wxss:1:1037)",{path:"./components/work/expopup1.wxss"});
}