$gwx_XC_29=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_29 || [];
function gz$gwx_XC_29_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_29_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_29_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_29_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__e'])
Z([3,'file_name'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'hide']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'file_name_con'])
Z([3,'flex_aro'])
Z(z[0])
Z([3,'file_name_li'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'rename']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'file_name_img'])
Z([3,'/static/images/work/name.png'])
Z([3,'修改名称'])
Z([[2,'==='],[[7],[3,'mytype']],[1,0]])
Z(z[8])
Z([[2,'==='],[[7],[3,'mytype']],[1,1]])
Z(z[0])
Z(z[6])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'remove']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[8])
Z([3,'/static/images/work/remove.png'])
Z([3,'删除'])
Z(z[0])
Z([3,'flex_cen file_name_btn'])
Z(z[2])
Z([3,'取消'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_29_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_29_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_29=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_29=true;
var x=['./components/work/file_name.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_29_1()
var o2Z=_mz(z,'view',['bindtap',0,'class',1,'data-event-opts',1],[],e,s,gg)
var f3Z=_n('view')
_rz(z,f3Z,'class',3,e,s,gg)
var c4Z=_n('view')
_rz(z,c4Z,'class',4,e,s,gg)
var c7Z=_mz(z,'view',['bindtap',5,'class',1,'data-event-opts',2],[],e,s,gg)
var o8Z=_mz(z,'image',['class',8,'src',1],[],e,s,gg)
_(c7Z,o8Z)
var l9Z=_n('text')
var a0Z=_oz(z,10,e,s,gg)
_(l9Z,a0Z)
_(c7Z,l9Z)
_(c4Z,c7Z)
var h5Z=_v()
_(c4Z,h5Z)
if(_oz(z,11,e,s,gg)){h5Z.wxVkey=1
var tA1=_n('view')
_rz(z,tA1,'class',12,e,s,gg)
_(h5Z,tA1)
}
var o6Z=_v()
_(c4Z,o6Z)
if(_oz(z,13,e,s,gg)){o6Z.wxVkey=1
var eB1=_mz(z,'view',['bindtap',14,'class',1,'data-event-opts',2],[],e,s,gg)
var bC1=_mz(z,'image',['class',17,'src',1],[],e,s,gg)
_(eB1,bC1)
var oD1=_n('text')
var xE1=_oz(z,19,e,s,gg)
_(oD1,xE1)
_(eB1,oD1)
_(o6Z,eB1)
}
h5Z.wxXCkey=1
o6Z.wxXCkey=1
_(f3Z,c4Z)
var oF1=_mz(z,'view',['bindtap',20,'class',1,'data-event-opts',2],[],e,s,gg)
var fG1=_oz(z,23,e,s,gg)
_(oF1,fG1)
_(f3Z,oF1)
_(o2Z,f3Z)
_(r,o2Z)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_29";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_29();	if (__vd_version_info__.delayedGwx) __wxAppCode__['components/work/file_name.wxml'] = [$gwx_XC_29, './components/work/file_name.wxml'];else __wxAppCode__['components/work/file_name.wxml'] = $gwx_XC_29( './components/work/file_name.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['components/work/file_name.wxss'] = setCssToHead([".",[1],"file_name{background:rgba(0,0,0,.5);height:100%;z-index:3333}\n.",[1],"file_name,.",[1],"file_name .",[1],"file_name_con{bottom:0;left:0;position:fixed;width:100%}\n.",[1],"file_name .",[1],"file_name_con{background-color:#fff;border-radius:",[0,30]," ",[0,30]," 0 0;height:",[0,453],";padding:",[0,56]," ",[0,30]," ",[0,24],"}\n.",[1],"file_name .",[1],"file_name_con .",[1],"file_name_btn{background-color:#f6f6f6;border-radius:",[0,20],";color:#999;font-size:",[0,32],";font-weight:700;height:",[0,96],";margin-top:",[0,58],";width:100%}\n.",[1],"file_name .",[1],"file_name_con .",[1],"file_name_li{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column}\n.",[1],"file_name .",[1],"file_name_con .",[1],"file_name_li wx-text{font-size:",[0,24],"}\n.",[1],"file_name .",[1],"file_name_con .",[1],"file_name_li .",[1],"file_name_img{height:",[0,96],";margin-bottom:",[0,16],";width:",[0,96],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./components/work/file_name.wxss:1:642)",{path:"./components/work/file_name.wxss"});
}