$gwx_XC_55=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_55 || [];
function gz$gwx_XC_55_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_55_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_55_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_55_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__e'])
Z([3,'u-notice data-v-9adf94ee'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'clickHandler']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[6],[[7],[3,'$slots']],[3,'icon']])
Z([3,'icon'])
Z([[7],[3,'icon']])
Z([3,'u-notice__left-icon data-v-9adf94ee'])
Z([3,'__l'])
Z([3,'data-v-9adf94ee'])
Z([[7],[3,'color']])
Z(z[5])
Z([3,'19'])
Z([3,'c11206c6-1'])
Z([3,'u-notice__content data-v-9adf94ee vue-ref'])
Z([3,'u-notice__content'])
Z([3,'u-notice__content__text data-v-9adf94ee vue-ref'])
Z([3,'u-notice__content__text'])
Z([[6],[[7],[3,'$root']],[3,'s0']])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'innerText']])
Z(z[18])
Z(z[8])
Z([[6],[[7],[3,'$root']],[3,'s1']])
Z([a,[[7],[3,'item']]])
Z([[6],[[7],[3,'$root']],[3,'g0']])
Z([3,'u-notice__right-icon data-v-9adf94ee'])
Z([[2,'==='],[[7],[3,'mode']],[1,'link']])
Z(z[7])
Z(z[8])
Z(z[9])
Z([3,'arrow-right'])
Z([1,17])
Z([3,'c11206c6-2'])
Z([[2,'==='],[[7],[3,'mode']],[1,'closable']])
Z(z[7])
Z(z[0])
Z(z[8])
Z(z[9])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'close']]]]]]]]])
Z([3,'close'])
Z([1,16])
Z([3,'c11206c6-3'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_55_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_55_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_55=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_55=true;
var x=['./uni_modules/uview-ui/components/u-row-notice/u-row-notice.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_55_1()
var hMVB=_mz(z,'view',['bindtap',0,'class',1,'data-event-opts',1],[],e,s,gg)
var oNVB=_v()
_(hMVB,oNVB)
if(_oz(z,3,e,s,gg)){oNVB.wxVkey=1
var oPVB=_n('slot')
_rz(z,oPVB,'name',4,e,s,gg)
_(oNVB,oPVB)
}
else{oNVB.wxVkey=2
var lQVB=_v()
_(oNVB,lQVB)
if(_oz(z,5,e,s,gg)){lQVB.wxVkey=1
var aRVB=_n('view')
_rz(z,aRVB,'class',6,e,s,gg)
var tSVB=_mz(z,'u-icon',['bind:__l',7,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(aRVB,tSVB)
_(lQVB,aRVB)
}
lQVB.wxXCkey=1
lQVB.wxXCkey=3
}
var eTVB=_mz(z,'view',['class',13,'data-ref',1],[],e,s,gg)
var bUVB=_mz(z,'view',['class',15,'data-ref',1,'style',2],[],e,s,gg)
var oVVB=_v()
_(bUVB,oVVB)
var xWVB=function(fYVB,oXVB,cZVB,gg){
var o2VB=_mz(z,'text',['class',22,'style',1],[],fYVB,oXVB,gg)
var c3VB=_oz(z,24,fYVB,oXVB,gg)
_(o2VB,c3VB)
_(cZVB,o2VB)
return cZVB
}
oVVB.wxXCkey=2
_2z(z,20,xWVB,e,s,gg,oVVB,'item','index','index')
_(eTVB,bUVB)
_(hMVB,eTVB)
var cOVB=_v()
_(hMVB,cOVB)
if(_oz(z,25,e,s,gg)){cOVB.wxVkey=1
var o4VB=_n('view')
_rz(z,o4VB,'class',26,e,s,gg)
var l5VB=_v()
_(o4VB,l5VB)
if(_oz(z,27,e,s,gg)){l5VB.wxVkey=1
var t7VB=_mz(z,'u-icon',['bind:__l',28,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(l5VB,t7VB)
}
var a6VB=_v()
_(o4VB,a6VB)
if(_oz(z,34,e,s,gg)){a6VB.wxVkey=1
var e8VB=_mz(z,'u-icon',['bind:__l',35,'bind:click',1,'class',2,'color',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],e,s,gg)
_(a6VB,e8VB)
}
l5VB.wxXCkey=1
l5VB.wxXCkey=3
a6VB.wxXCkey=1
a6VB.wxXCkey=3
_(cOVB,o4VB)
}
oNVB.wxXCkey=1
oNVB.wxXCkey=3
cOVB.wxXCkey=1
cOVB.wxXCkey=3
_(r,hMVB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_55";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_55();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uni_modules/uview-ui/components/u-row-notice/u-row-notice.wxml'] = [$gwx_XC_55, './uni_modules/uview-ui/components/u-row-notice/u-row-notice.wxml'];else __wxAppCode__['uni_modules/uview-ui/components/u-row-notice/u-row-notice.wxml'] = $gwx_XC_55( './uni_modules/uview-ui/components/u-row-notice/u-row-notice.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['uni_modules/uview-ui/components/u-row-notice/u-row-notice.wxss'] = setCssToHead(["wx-scroll-view.",[1],"data-v-9adf94ee,wx-swiper-item.",[1],"data-v-9adf94ee,wx-view.",[1],"data-v-9adf94ee{-webkit-align-content:flex-start;align-content:flex-start;-webkit-align-items:stretch;align-items:stretch;display:-webkit-flex;display:flex;-webkit-flex-basis:auto;flex-basis:auto;-webkit-flex-direction:column;flex-direction:column;-webkit-flex-grow:0;flex-grow:0;-webkit-flex-shrink:0;flex-shrink:0}\n.",[1],"u-notice.",[1],"data-v-9adf94ee{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row;-webkit-justify-content:space-between;justify-content:space-between}\n.",[1],"u-notice__left-icon.",[1],"data-v-9adf94ee{-webkit-align-items:center;align-items:center;margin-right:5px}\n.",[1],"u-notice__right-icon.",[1],"data-v-9adf94ee{-webkit-align-items:center;align-items:center;margin-left:5px}\n.",[1],"u-notice__content.",[1],"data-v-9adf94ee{-webkit-flex:1;flex:1;-webkit-flex-wrap:nowrap;flex-wrap:nowrap;overflow:hidden;text-align:right}\n.",[1],"u-notice__content.",[1],"data-v-9adf94ee,.",[1],"u-notice__content__text.",[1],"data-v-9adf94ee{display:-webkit-flex;display:flex;-webkit-flex-direction:row;flex-direction:row}\n.",[1],"u-notice__content__text.",[1],"data-v-9adf94ee{-webkit-animation:u-loop-animation-data-v-9adf94ee 10s linear infinite both;animation:u-loop-animation-data-v-9adf94ee 10s linear infinite both;color:#f9ae3d;font-size:14px;padding-left:100%;white-space:nowrap;word-break:keep-all}\n@-webkit-keyframes u-loop-animation-data-v-9adf94ee{0%{-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}\n100%{-webkit-transform:translate3d(-100%,0,0);transform:translate3d(-100%,0,0)}\n}@keyframes u-loop-animation-data-v-9adf94ee{0%{-webkit-transform:translate3d(0,0,0);transform:translate3d(0,0,0)}\n100%{-webkit-transform:translate3d(-100%,0,0);transform:translate3d(-100%,0,0)}\n}",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./uni_modules/uview-ui/components/u-row-notice/u-row-notice.wxss:1:1)",{path:"./uni_modules/uview-ui/components/u-row-notice/u-row-notice.wxss"});
}