$gwx_XC_55=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_55 || [];
function gz$gwx_XC_55_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_55_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_55_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_55_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__e'])
Z([3,'u-notice data-v-9adf94ee'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'clickHandler']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[6],[[7],[3,'$slots']],[3,'icon']])
Z([3,'icon'])
Z([[7],[3,'icon']])
Z([3,'__l'])
Z([3,'data-v-9adf94ee'])
Z([[7],[3,'color']])
Z(z[5])
Z([3,'19'])
Z([3,'c11206c6-1'])
Z([[6],[[7],[3,'$root']],[3,'g0']])
Z([3,'u-notice__right-icon data-v-9adf94ee'])
Z([[2,'==='],[[7],[3,'mode']],[1,'link']])
Z(z[6])
Z(z[7])
Z(z[8])
Z([3,'arrow-right'])
Z([1,17])
Z([3,'c11206c6-2'])
Z([[2,'==='],[[7],[3,'mode']],[1,'closable']])
Z(z[6])
Z(z[0])
Z(z[7])
Z(z[8])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'close']]]]]]]]])
Z([3,'close'])
Z([1,16])
Z([3,'c11206c6-3'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_55_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_55_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_55=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_55=true;
var x=['./uni_modules/uview-ui/components/u-row-notice/u-row-notice.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_55_1()
var oZN=_mz(z,'view',['bindtap',0,'class',1,'data-event-opts',1],[],e,s,gg)
var f1N=_v()
_(oZN,f1N)
if(_oz(z,3,e,s,gg)){f1N.wxVkey=1
var h3N=_n('slot')
_rz(z,h3N,'name',4,e,s,gg)
_(f1N,h3N)
}
else{f1N.wxVkey=2
var o4N=_v()
_(f1N,o4N)
if(_oz(z,5,e,s,gg)){o4N.wxVkey=1
var c5N=_mz(z,'u-icon',['bind:__l',6,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(o4N,c5N)
}
o4N.wxXCkey=1
o4N.wxXCkey=3
}
var c2N=_v()
_(oZN,c2N)
if(_oz(z,12,e,s,gg)){c2N.wxVkey=1
var o6N=_n('view')
_rz(z,o6N,'class',13,e,s,gg)
var l7N=_v()
_(o6N,l7N)
if(_oz(z,14,e,s,gg)){l7N.wxVkey=1
var t9N=_mz(z,'u-icon',['bind:__l',15,'class',1,'color',2,'name',3,'size',4,'vueId',5],[],e,s,gg)
_(l7N,t9N)
}
var a8N=_v()
_(o6N,a8N)
if(_oz(z,21,e,s,gg)){a8N.wxVkey=1
var e0N=_mz(z,'u-icon',['bind:__l',22,'bind:click',1,'class',2,'color',3,'data-event-opts',4,'name',5,'size',6,'vueId',7],[],e,s,gg)
_(a8N,e0N)
}
l7N.wxXCkey=1
l7N.wxXCkey=3
a8N.wxXCkey=1
a8N.wxXCkey=3
_(c2N,o6N)
}
f1N.wxXCkey=1
f1N.wxXCkey=3
c2N.wxXCkey=1
c2N.wxXCkey=3
_(r,oZN)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_55";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_55();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uni_modules/uview-ui/components/u-row-notice/u-row-notice.wxml'] = [$gwx_XC_55, './uni_modules/uview-ui/components/u-row-notice/u-row-notice.wxml'];else __wxAppCode__['uni_modules/uview-ui/components/u-row-notice/u-row-notice.wxml'] = $gwx_XC_55( './uni_modules/uview-ui/components/u-row-notice/u-row-notice.wxml' );
	;__wxRoute = "uni_modules/uview-ui/components/u-row-notice/u-row-notice";__wxRouteBegin = true;__wxAppCurrentFile__="uni_modules/uview-ui/components/u-row-notice/u-row-notice.js";define("uni_modules/uview-ui/components/u-row-notice/u-row-notice.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";

require("../../../../@babel/runtime/helpers/Arrayincludes");
(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["uni_modules/uview-ui/components/u-row-notice/u-row-notice"], {
  1666: function _(n, t, e) {
    "use strict";

    e.r(t);
    var i = e(1667),
      o = e(1669);
    for (var r in o) ["default"].indexOf(r) < 0 && function (n) {
      e.d(t, n, function () {
        return o[n];
      });
    }(r);
    e(1672);
    var u,
      c = e(230),
      a = Object(c["default"])(o["default"], i["render"], i["staticRenderFns"], !1, null, "9adf94ee", null, !1, i["components"], u);
    a.options.__file = "uni_modules/uview-ui/components/u-row-notice/u-row-notice.vue", t["default"] = a.exports;
  },
  1667: function _(n, t, e) {
    "use strict";

    e.r(t);
    var i = e(1668);
    e.d(t, "render", function () {
      return i["render"];
    }), e.d(t, "staticRenderFns", function () {
      return i["staticRenderFns"];
    }), e.d(t, "recyclableRender", function () {
      return i["recyclableRender"];
    }), e.d(t, "components", function () {
      return i["components"];
    });
  },
  1668: function _(n, t, e) {
    "use strict";

    var i;
    e.r(t), e.d(t, "render", function () {
      return o;
    }), e.d(t, "staticRenderFns", function () {
      return u;
    }), e.d(t, "recyclableRender", function () {
      return r;
    }), e.d(t, "components", function () {
      return i;
    });
    try {
      i = {
        uIcon: function uIcon() {
          return Promise.all([e.e("common/vendor"), e.e("uni_modules/uview-ui/components/u-icon/u-icon")]).then(e.bind(null, 1431));
        }
      };
    } catch (c) {
      if (-1 === c.message.indexOf("Cannot find module") || -1 === c.message.indexOf(".vue")) throw c;
      console.error(c.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
    }
    var o = function o() {
        var n = this,
          t = n.$createElement,
          e = (n._self._c, n.__get_style([n.animationStyle])),
          i = n.__get_style([n.textStyle]),
          o = ["link", "closable"].includes(n.mode);
        n.$mp.data = Object.assign({}, {
          $root: {
            s0: e,
            s1: i,
            g0: o
          }
        });
      },
      r = !1,
      u = [];
    o._withStripped = !0;
  },
  1669: function _(n, t, e) {
    "use strict";

    e.r(t);
    var i = e(1670),
      o = e.n(i);
    for (var r in i) ["default"].indexOf(r) < 0 && function (n) {
      e.d(t, n, function () {
        return i[n];
      });
    }(r);
    t["default"] = o.a;
  },
  1670: function _(n, t, e) {
    "use strict";

    (function (n) {
      var i = e(4);
      Object.defineProperty(t, "__esModule", {
        value: !0
      }), t.default = void 0;
      var o = i(e(255)),
        r = i(e(257)),
        u = i(e(1671)),
        c = {
          name: "u-row-notice",
          mixins: [n.$u.mpMixin, n.$u.mixin, u.default],
          data: function data() {
            return {
              animationDuration: "0",
              animationPlayState: "paused",
              nvueInit: !0,
              show: !0
            };
          },
          watch: {
            text: {
              immediate: !0,
              handler: function handler(t, e) {
                this.vue(), n.$u.test.string(t) || n.$u.error("noticebar组件direction为row时，要求text参数为字符串形式");
              }
            },
            fontSize: function fontSize() {
              this.vue();
            },
            speed: function speed() {
              this.vue();
            }
          },
          computed: {
            textStyle: function textStyle() {
              var t = {};
              return t.color = this.color, t.fontSize = n.$u.addUnit(this.fontSize), t;
            },
            animationStyle: function animationStyle() {
              var n = {};
              return n.animationDuration = this.animationDuration, n.animationPlayState = this.animationPlayState, n;
            },
            innerText: function innerText() {
              for (var n = [], t = 20, e = this.text.split(""), i = 0; i < e.length; i += t) n.push(e.slice(i, i + t).join(""));
              return n;
            }
          },
          mounted: function mounted() {
            this.init();
          },
          methods: {
            init: function init() {
              this.vue(), n.$u.test.string(this.text) || n.$u.error("noticebar组件direction为row时，要求text参数为字符串形式");
            },
            vue: function vue() {
              var t = this;
              return (0, r.default)(o.default.mark(function e() {
                var i;
                return o.default.wrap(function (e) {
                  while (1) switch (e.prev = e.next) {
                    case 0:
                      return 0, i = 0, e.next = 3, n.$u.sleep();
                    case 3:
                      return e.next = 5, t.$uGetRect(".u-notice__content__text");
                    case 5:
                      return i = e.sent.width, e.next = 8, t.$uGetRect(".u-notice__content");
                    case 8:
                      e.sent.width, t.animationDuration = "".concat(i / n.$u.getPx(t.speed), "s"), t.animationPlayState = "paused", setTimeout(function () {
                        t.animationPlayState = "running";
                      }, 10);
                    case 12:
                    case "end":
                      return e.stop();
                  }
                }, e);
              }))();
            },
            nvue: function nvue() {
              return (0, r.default)(o.default.mark(function n() {
                return o.default.wrap(function (n) {
                  while (1) switch (n.prev = n.next) {
                    case 0:
                    case "end":
                      return n.stop();
                  }
                }, n);
              }))();
            },
            loopAnimation: function loopAnimation(n, t) {},
            getNvueRect: function getNvueRect(n) {},
            clickHandler: function clickHandler(n) {
              this.$emit("click");
            },
            close: function close() {
              this.$emit("close");
            }
          }
        };
      t.default = c;
    }).call(this, e(2)["default"]);
  },
  1672: function _(n, t, e) {
    "use strict";

    e.r(t);
    var i = e(1673),
      o = e.n(i);
    for (var r in i) ["default"].indexOf(r) < 0 && function (n) {
      e.d(t, n, function () {
        return i[n];
      });
    }(r);
    t["default"] = o.a;
  },
  1673: function _(n, t, e) {}
}]);
//# sourceMappingURL=../../../../../.sourcemap/mp-weixin/uni_modules/uview-ui/components/u-row-notice/u-row-notice.js.map
;
(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['uni_modules/uview-ui/components/u-row-notice/u-row-notice-create-component', {
  'uni_modules/uview-ui/components/u-row-notice/u-row-notice-create-component': function uni_modulesUviewUiComponentsURowNoticeURowNoticeCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1666));
  }
}, [['uni_modules/uview-ui/components/u-row-notice/u-row-notice-create-component']]]);
},{isPage:false,isComponent:true,currentFile:'uni_modules/uview-ui/components/u-row-notice/u-row-notice.js'});require("uni_modules/uview-ui/components/u-row-notice/u-row-notice.js");