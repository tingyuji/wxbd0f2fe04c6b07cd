$gwx_XC_53=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_53 || [];
function gz$gwx_XC_53_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_53_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_53_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_53_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'__l'])
Z([3,'__e'])
Z([3,'data-v-1625041b'])
Z([3,'u-overlay'])
Z([[7],[3,'overlayStyle']])
Z([[4],[[5],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'clickHandler']]]]]]]]])
Z([[7],[3,'duration']])
Z([[7],[3,'show']])
Z([3,'a307ff6a-1'])
Z([[4],[[5],[1,'default']]])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_53_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_53_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_53=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_53=true;
var x=['./uni_modules/uview-ui/components/u-overlay/u-overlay.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_53_1()
var bIN=_mz(z,'u-transition',['bind:__l',0,'bind:click',1,'class',1,'customClass',2,'customStyle',3,'data-event-opts',4,'duration',5,'show',6,'vueId',7,'vueSlots',8],[],e,s,gg)
var oJN=_n('slot')
_(bIN,oJN)
_(r,bIN)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_53";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_53();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uni_modules/uview-ui/components/u-overlay/u-overlay.wxml'] = [$gwx_XC_53, './uni_modules/uview-ui/components/u-overlay/u-overlay.wxml'];else __wxAppCode__['uni_modules/uview-ui/components/u-overlay/u-overlay.wxml'] = $gwx_XC_53( './uni_modules/uview-ui/components/u-overlay/u-overlay.wxml' );
	;__wxRoute = "uni_modules/uview-ui/components/u-overlay/u-overlay";__wxRouteBegin = true;__wxAppCurrentFile__="uni_modules/uview-ui/components/u-overlay/u-overlay.js";define("uni_modules/uview-ui/components/u-overlay/u-overlay.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["uni_modules/uview-ui/components/u-overlay/u-overlay"], {
  1616: function _(n, e, t) {
    "use strict";

    t.r(e);
    var r = t(1617),
      o = t(1619);
    for (var u in o) ["default"].indexOf(u) < 0 && function (n) {
      t.d(e, n, function () {
        return o[n];
      });
    }(u);
    t(1622);
    var i,
      c = t(230),
      a = Object(c["default"])(o["default"], r["render"], r["staticRenderFns"], !1, null, "1625041b", null, !1, r["components"], i);
    a.options.__file = "uni_modules/uview-ui/components/u-overlay/u-overlay.vue", e["default"] = a.exports;
  },
  1617: function _(n, e, t) {
    "use strict";

    t.r(e);
    var r = t(1618);
    t.d(e, "render", function () {
      return r["render"];
    }), t.d(e, "staticRenderFns", function () {
      return r["staticRenderFns"];
    }), t.d(e, "recyclableRender", function () {
      return r["recyclableRender"];
    }), t.d(e, "components", function () {
      return r["components"];
    });
  },
  1618: function _(n, e, t) {
    "use strict";

    var r;
    t.r(e), t.d(e, "render", function () {
      return o;
    }), t.d(e, "staticRenderFns", function () {
      return i;
    }), t.d(e, "recyclableRender", function () {
      return u;
    }), t.d(e, "components", function () {
      return r;
    });
    try {
      r = {
        uTransition: function uTransition() {
          return Promise.all([t.e("common/vendor"), t.e("uni_modules/uview-ui/components/u-transition/u-transition")]).then(t.bind(null, 1624));
        }
      };
    } catch (c) {
      if (-1 === c.message.indexOf("Cannot find module") || -1 === c.message.indexOf(".vue")) throw c;
      console.error(c.message), console.error("1. 排查组件名称拼写是否正确"), console.error("2. 排查组件是否符合 easycom 规范，文档：https://uniapp.dcloud.net.cn/collocation/pages?id=easycom"), console.error("3. 若组件不符合 easycom 规范，需手动引入，并在 components 中注册该组件");
    }
    var o = function o() {
        var n = this,
          e = n.$createElement;
        n._self._c;
      },
      u = !1,
      i = [];
    o._withStripped = !0;
  },
  1619: function _(n, e, t) {
    "use strict";

    t.r(e);
    var r = t(1620),
      o = t.n(r);
    for (var u in r) ["default"].indexOf(u) < 0 && function (n) {
      t.d(e, n, function () {
        return r[n];
      });
    }(u);
    e["default"] = o.a;
  },
  1620: function _(n, e, t) {
    "use strict";

    (function (n) {
      var r = t(4);
      Object.defineProperty(e, "__esModule", {
        value: !0
      }), e.default = void 0;
      var o = r(t(1621)),
        u = {
          name: "u-overlay",
          mixins: [n.$u.mpMixin, n.$u.mixin, o.default],
          computed: {
            overlayStyle: function overlayStyle() {
              var e = {
                position: "fixed",
                top: 0,
                left: 0,
                right: 0,
                zIndex: this.zIndex,
                bottom: 0,
                "background-color": "rgba(0, 0, 0, ".concat(this.opacity, ")")
              };
              return n.$u.deepMerge(e, n.$u.addStyle(this.customStyle));
            }
          },
          methods: {
            clickHandler: function clickHandler() {
              this.$emit("click");
            }
          }
        };
      e.default = u;
    }).call(this, t(2)["default"]);
  },
  1622: function _(n, e, t) {
    "use strict";

    t.r(e);
    var r = t(1623),
      o = t.n(r);
    for (var u in r) ["default"].indexOf(u) < 0 && function (n) {
      t.d(e, n, function () {
        return r[n];
      });
    }(u);
    e["default"] = o.a;
  },
  1623: function _(n, e, t) {}
}]);
//# sourceMappingURL=../../../../../.sourcemap/mp-weixin/uni_modules/uview-ui/components/u-overlay/u-overlay.js.map
;
(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['uni_modules/uview-ui/components/u-overlay/u-overlay-create-component', {
  'uni_modules/uview-ui/components/u-overlay/u-overlay-create-component': function uni_modulesUviewUiComponentsUOverlayUOverlayCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1616));
  }
}, [['uni_modules/uview-ui/components/u-overlay/u-overlay-create-component']]]);
},{isPage:false,isComponent:true,currentFile:'uni_modules/uview-ui/components/u-overlay/u-overlay.js'});require("uni_modules/uview-ui/components/u-overlay/u-overlay.js");