$gwx_XC_58=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_58 || [];
function gz$gwx_XC_58_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_58_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_58_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_58_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_58_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_58_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_58=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_58=true;
var x=['./uni_modules/uview-ui/components/u-status-bar/u-status-bar.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_58_1()
var tMO=_n('slot')
_(r,tMO)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_58";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_58();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uni_modules/uview-ui/components/u-status-bar/u-status-bar.wxml'] = [$gwx_XC_58, './uni_modules/uview-ui/components/u-status-bar/u-status-bar.wxml'];else __wxAppCode__['uni_modules/uview-ui/components/u-status-bar/u-status-bar.wxml'] = $gwx_XC_58( './uni_modules/uview-ui/components/u-status-bar/u-status-bar.wxml' );
	;__wxRoute = "uni_modules/uview-ui/components/u-status-bar/u-status-bar";__wxRouteBegin = true;__wxAppCurrentFile__="uni_modules/uview-ui/components/u-status-bar/u-status-bar.js";define("uni_modules/uview-ui/components/u-status-bar/u-status-bar.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["uni_modules/uview-ui/components/u-status-bar/u-status-bar"], {
  1634: function _(t, n, e) {
    "use strict";

    e.r(n);
    var u = e(1635),
      r = e(1637);
    for (var i in r) ["default"].indexOf(i) < 0 && function (t) {
      e.d(n, t, function () {
        return r[t];
      });
    }(i);
    e(1640);
    var a,
      o = e(230),
      s = Object(o["default"])(r["default"], u["render"], u["staticRenderFns"], !1, null, "124d52a9", null, !1, u["components"], a);
    s.options.__file = "uni_modules/uview-ui/components/u-status-bar/u-status-bar.vue", n["default"] = s.exports;
  },
  1635: function _(t, n, e) {
    "use strict";

    e.r(n);
    var u = e(1636);
    e.d(n, "render", function () {
      return u["render"];
    }), e.d(n, "staticRenderFns", function () {
      return u["staticRenderFns"];
    }), e.d(n, "recyclableRender", function () {
      return u["recyclableRender"];
    }), e.d(n, "components", function () {
      return u["components"];
    });
  },
  1636: function _(t, n, e) {
    "use strict";

    var u;
    e.r(n), e.d(n, "render", function () {
      return r;
    }), e.d(n, "staticRenderFns", function () {
      return a;
    }), e.d(n, "recyclableRender", function () {
      return i;
    }), e.d(n, "components", function () {
      return u;
    });
    var r = function r() {
        var t = this,
          n = t.$createElement,
          e = (t._self._c, t.__get_style([t.style]));
        t.$mp.data = Object.assign({}, {
          $root: {
            s0: e
          }
        });
      },
      i = !1,
      a = [];
    r._withStripped = !0;
  },
  1637: function _(t, n, e) {
    "use strict";

    e.r(n);
    var u = e(1638),
      r = e.n(u);
    for (var i in u) ["default"].indexOf(i) < 0 && function (t) {
      e.d(n, t, function () {
        return u[t];
      });
    }(i);
    n["default"] = r.a;
  },
  1638: function _(t, n, e) {
    "use strict";

    (function (t) {
      var u = e(4);
      Object.defineProperty(n, "__esModule", {
        value: !0
      }), n.default = void 0;
      var r = u(e(1639)),
        i = {
          name: "u-status-bar",
          mixins: [t.$u.mpMixin, t.$u.mixin, r.default],
          data: function data() {
            return {};
          },
          computed: {
            style: function style() {
              var n = {};
              return n.height = t.$u.addUnit(t.$u.sys().statusBarHeight, "px"), n.backgroundColor = this.bgColor, t.$u.deepMerge(n, t.$u.addStyle(this.customStyle));
            }
          }
        };
      n.default = i;
    }).call(this, e(2)["default"]);
  },
  1640: function _(t, n, e) {
    "use strict";

    e.r(n);
    var u = e(1641),
      r = e.n(u);
    for (var i in u) ["default"].indexOf(i) < 0 && function (t) {
      e.d(n, t, function () {
        return u[t];
      });
    }(i);
    n["default"] = r.a;
  },
  1641: function _(t, n, e) {}
}]);
//# sourceMappingURL=../../../../../.sourcemap/mp-weixin/uni_modules/uview-ui/components/u-status-bar/u-status-bar.js.map
;
(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['uni_modules/uview-ui/components/u-status-bar/u-status-bar-create-component', {
  'uni_modules/uview-ui/components/u-status-bar/u-status-bar-create-component': function uni_modulesUviewUiComponentsUStatusBarUStatusBarCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1634));
  }
}, [['uni_modules/uview-ui/components/u-status-bar/u-status-bar-create-component']]]);
},{isPage:false,isComponent:true,currentFile:'uni_modules/uview-ui/components/u-status-bar/u-status-bar.js'});require("uni_modules/uview-ui/components/u-status-bar/u-status-bar.js");