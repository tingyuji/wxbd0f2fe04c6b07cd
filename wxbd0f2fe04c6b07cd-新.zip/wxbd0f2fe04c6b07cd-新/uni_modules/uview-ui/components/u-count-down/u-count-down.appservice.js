$gwx_XC_46=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_46 || [];
function gz$gwx_XC_46_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_46_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_46_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_46_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'u-count-down data-v-463368ae'])
Z([[6],[[7],[3,'$slots']],[3,'default']])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_46_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_46_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_46=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_46=true;
var x=['./uni_modules/uview-ui/components/u-count-down/u-count-down.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_46_1()
var aNM=_n('view')
_rz(z,aNM,'class',0,e,s,gg)
var tOM=_v()
_(aNM,tOM)
if(_oz(z,1,e,s,gg)){tOM.wxVkey=1
var ePM=_n('slot')
_(tOM,ePM)
}
else{tOM.wxVkey=2
}
tOM.wxXCkey=1
_(r,aNM)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_46";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
try{
main(env,{},root,global);
_tsd(root)
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_46();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uni_modules/uview-ui/components/u-count-down/u-count-down.wxml'] = [$gwx_XC_46, './uni_modules/uview-ui/components/u-count-down/u-count-down.wxml'];else __wxAppCode__['uni_modules/uview-ui/components/u-count-down/u-count-down.wxml'] = $gwx_XC_46( './uni_modules/uview-ui/components/u-count-down/u-count-down.wxml' );
	;__wxRoute = "uni_modules/uview-ui/components/u-count-down/u-count-down";__wxRouteBegin = true;__wxAppCurrentFile__="uni_modules/uview-ui/components/u-count-down/u-count-down.js";define("uni_modules/uview-ui/components/u-count-down/u-count-down.js",function(require,module,exports,window,document,frames,self,location,navigator,localStorage,history,Caches,screen,alert,confirm,prompt,XMLHttpRequest,WebSocket,Reporter,webkit,WeixinJSCore){
"use strict";

(global["webpackJsonp"] = global["webpackJsonp"] || []).push([["uni_modules/uview-ui/components/u-count-down/u-count-down"], {
  1401: function _(t, n, i) {
    "use strict";

    i.r(n);
    var e = i(1402),
      r = i(1404);
    for (var u in r) ["default"].indexOf(u) < 0 && function (t) {
      i.d(n, t, function () {
        return r[t];
      });
    }(u);
    i(1408);
    var o,
      a = i(230),
      c = Object(a["default"])(r["default"], e["render"], e["staticRenderFns"], !1, null, "463368ae", null, !1, e["components"], o);
    c.options.__file = "uni_modules/uview-ui/components/u-count-down/u-count-down.vue", n["default"] = c.exports;
  },
  1402: function _(t, n, i) {
    "use strict";

    i.r(n);
    var e = i(1403);
    i.d(n, "render", function () {
      return e["render"];
    }), i.d(n, "staticRenderFns", function () {
      return e["staticRenderFns"];
    }), i.d(n, "recyclableRender", function () {
      return e["recyclableRender"];
    }), i.d(n, "components", function () {
      return e["components"];
    });
  },
  1403: function _(t, n, i) {
    "use strict";

    var e;
    i.r(n), i.d(n, "render", function () {
      return r;
    }), i.d(n, "staticRenderFns", function () {
      return o;
    }), i.d(n, "recyclableRender", function () {
      return u;
    }), i.d(n, "components", function () {
      return e;
    });
    var r = function r() {
        var t = this,
          n = t.$createElement;
        t._self._c;
      },
      u = !1,
      o = [];
    r._withStripped = !0;
  },
  1404: function _(t, n, i) {
    "use strict";

    i.r(n);
    var e = i(1405),
      r = i.n(e);
    for (var u in e) ["default"].indexOf(u) < 0 && function (t) {
      i.d(n, t, function () {
        return e[t];
      });
    }(u);
    n["default"] = r.a;
  },
  1405: function _(t, n, i) {
    "use strict";

    (function (t) {
      var e = i(4);
      Object.defineProperty(n, "__esModule", {
        value: !0
      }), n.default = void 0;
      var r = e(i(1406)),
        u = i(1407),
        o = {
          name: "u-count-down",
          mixins: [t.$u.mpMixin, t.$u.mixin, r.default],
          data: function data() {
            return {
              timer: null,
              timeData: (0, u.parseTimeData)(0),
              formattedTime: "0",
              runing: !1,
              endTime: 0,
              remainTime: 0
            };
          },
          watch: {
            time: function time(t) {
              this.reset();
            }
          },
          mounted: function mounted() {
            this.init();
          },
          methods: {
            init: function init() {
              this.reset();
            },
            start: function start() {
              this.runing || (this.runing = !0, this.endTime = Date.now() + this.remainTime, this.toTick());
            },
            toTick: function toTick() {
              this.millisecond ? this.microTick() : this.macroTick();
            },
            macroTick: function macroTick() {
              var t = this;
              this.clearTimeout(), this.timer = setTimeout(function () {
                var n = t.getRemainTime();
                (0, u.isSameSecond)(n, t.remainTime) && 0 !== n || t.setRemainTime(n), 0 !== t.remainTime && t.macroTick();
              }, 30);
            },
            microTick: function microTick() {
              var t = this;
              this.clearTimeout(), this.timer = setTimeout(function () {
                t.setRemainTime(t.getRemainTime()), 0 !== t.remainTime && t.microTick();
              }, 50);
            },
            getRemainTime: function getRemainTime() {
              return Math.max(this.endTime - Date.now(), 0);
            },
            setRemainTime: function setRemainTime(t) {
              this.remainTime = t;
              var n = (0, u.parseTimeData)(t);
              this.$emit("change", n), this.formattedTime = (0, u.parseFormat)(this.format, n), t <= 0 && (this.pause(), this.$emit("finish"));
            },
            reset: function reset() {
              this.pause(), this.remainTime = this.time, this.setRemainTime(this.remainTime), this.autoStart && this.start();
            },
            pause: function pause() {
              this.runing = !1, this.clearTimeout();
            },
            clearTimeout: function (t) {
              function n() {
                return t.apply(this, arguments);
              }
              return n.toString = function () {
                return t.toString();
              }, n;
            }(function () {
              clearTimeout(this.timer), this.timer = null;
            })
          },
          beforeDestroy: function beforeDestroy() {
            this.clearTimeout();
          }
        };
      n.default = o;
    }).call(this, i(2)["default"]);
  },
  1408: function _(t, n, i) {
    "use strict";

    i.r(n);
    var e = i(1409),
      r = i.n(e);
    for (var u in e) ["default"].indexOf(u) < 0 && function (t) {
      i.d(n, t, function () {
        return e[t];
      });
    }(u);
    n["default"] = r.a;
  },
  1409: function _(t, n, i) {}
}]);
//# sourceMappingURL=../../../../../.sourcemap/mp-weixin/uni_modules/uview-ui/components/u-count-down/u-count-down.js.map
;
(global["webpackJsonp"] = global["webpackJsonp"] || []).push(['uni_modules/uview-ui/components/u-count-down/u-count-down-create-component', {
  'uni_modules/uview-ui/components/u-count-down/u-count-down-create-component': function uni_modulesUviewUiComponentsUCountDownUCountDownCreateComponent(module, exports, __webpack_require__) {
    __webpack_require__('2')['createComponent'](__webpack_require__(1401));
  }
}, [['uni_modules/uview-ui/components/u-count-down/u-count-down-create-component']]]);
},{isPage:false,isComponent:true,currentFile:'uni_modules/uview-ui/components/u-count-down/u-count-down.js'});require("uni_modules/uview-ui/components/u-count-down/u-count-down.js");