$gwx_XC_52=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_52 || [];
function gz$gwx_XC_52_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_52_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_52_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_52_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([[7],[3,'show']])
Z([3,'u-notice-bar data-v-24c07869'])
Z([[6],[[7],[3,'$root']],[3,'s0']])
Z([[2,'||'],[[2,'==='],[[7],[3,'direction']],[1,'column']],[[2,'&&'],[[2,'==='],[[7],[3,'direction']],[1,'row']],[[7],[3,'step']]]])
Z([[7],[3,'bgColor']])
Z([3,'__l'])
Z([3,'__e'])
Z(z[6])
Z([3,'data-v-24c07869'])
Z([[7],[3,'color']])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'^close']],[[4],[[5],[[4],[[5],[1,'close']]]]]]]],[[4],[[5],[[5],[1,'^click']],[[4],[[5],[[4],[[5],[1,'click']]]]]]]]])
Z([[7],[3,'disableTouch']])
Z([[7],[3,'duration']])
Z([[7],[3,'fontSize']])
Z([[7],[3,'icon']])
Z([[7],[3,'mode']])
Z([[7],[3,'step']])
Z([[7],[3,'text']])
Z([3,'734f15bd-1'])
Z(z[4])
Z(z[5])
Z(z[6])
Z(z[6])
Z(z[8])
Z(z[9])
Z(z[10])
Z(z[13])
Z(z[14])
Z([[7],[3,'linkType']])
Z(z[15])
Z([[7],[3,'speed']])
Z(z[17])
Z([[7],[3,'url']])
Z([3,'734f15bd-2'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_52_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_52_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_52=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_52=true;
var x=['./uni_modules/uview-ui/components/u-notice-bar/u-notice-bar.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_52_1()
var aZUB=_v()
_(r,aZUB)
if(_oz(z,0,e,s,gg)){aZUB.wxVkey=1
var t1UB=_mz(z,'view',['class',1,'style',1],[],e,s,gg)
var e2UB=_v()
_(t1UB,e2UB)
if(_oz(z,3,e,s,gg)){e2UB.wxVkey=1
var b3UB=_mz(z,'u-column-notice',['bgColor',4,'bind:__l',1,'bind:click',2,'bind:close',3,'class',4,'color',5,'data-event-opts',6,'disableTouch',7,'duration',8,'fontSize',9,'icon',10,'mode',11,'step',12,'text',13,'vueId',14],[],e,s,gg)
_(e2UB,b3UB)
}
else{e2UB.wxVkey=2
var o4UB=_mz(z,'u-row-notice',['bgColor',19,'bind:__l',1,'bind:click',2,'bind:close',3,'class',4,'color',5,'data-event-opts',6,'fontSize',7,'icon',8,'linkType',9,'mode',10,'speed',11,'text',12,'url',13,'vueId',14],[],e,s,gg)
_(e2UB,o4UB)
}
e2UB.wxXCkey=1
e2UB.wxXCkey=3
e2UB.wxXCkey=3
_(aZUB,t1UB)
}
aZUB.wxXCkey=1
aZUB.wxXCkey=3
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_52";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_52();	if (__vd_version_info__.delayedGwx) __wxAppCode__['uni_modules/uview-ui/components/u-notice-bar/u-notice-bar.wxml'] = [$gwx_XC_52, './uni_modules/uview-ui/components/u-notice-bar/u-notice-bar.wxml'];else __wxAppCode__['uni_modules/uview-ui/components/u-notice-bar/u-notice-bar.wxml'] = $gwx_XC_52( './uni_modules/uview-ui/components/u-notice-bar/u-notice-bar.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['uni_modules/uview-ui/components/u-notice-bar/u-notice-bar.wxss'] = setCssToHead(["wx-scroll-view.",[1],"data-v-24c07869,wx-swiper-item.",[1],"data-v-24c07869,wx-view.",[1],"data-v-24c07869{-webkit-align-content:flex-start;align-content:flex-start;-webkit-align-items:stretch;align-items:stretch;display:-webkit-flex;display:flex;-webkit-flex-basis:auto;flex-basis:auto;-webkit-flex-direction:column;flex-direction:column;-webkit-flex-grow:0;flex-grow:0;-webkit-flex-shrink:0;flex-shrink:0}\n.",[1],"u-notice-bar.",[1],"data-v-24c07869{-webkit-flex:1;flex:1;overflow:hidden;padding:9px 12px}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./uni_modules/uview-ui/components/u-notice-bar/u-notice-bar.wxss:1:1)",{path:"./uni_modules/uview-ui/components/u-notice-bar/u-notice-bar.wxss"});
}