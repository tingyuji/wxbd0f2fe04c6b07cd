$gwx_XC_39=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_39 || [];
function gz$gwx_XC_39_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_39_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_39_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_39_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'real_top'])
Z([3,'top_con'])
Z([3,'real_search'])
Z([[2,'+'],[[2,'+'],[1,'padding-top:'],[[2,'?:'],[[6],[[7],[3,'app_config']],[3,'nozdy']],[1,''],[[2,'+'],[[6],[[7],[3,'titleInfo']],[3,'top']],[1,'px']]]],[1,';']])
Z([3,'font-size:36rpx;font-weight:bold;margin-right:30rpx;'])
Z([3,'真人主播'])
Z([3,'__e'])
Z([3,'real_input flex_ali'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'searchReal']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'search_img'])
Z([3,'/static/images/index/search.png'])
Z([3,'搜索主播名称'])
Z([3,'text'])
Z([[6],[[7],[3,'$root']],[3,'g0']])
Z([3,'__l'])
Z([3,'closable'])
Z([[7],[3,'noticeText']])
Z([3,'bbb45c00-1'])
Z([3,'flex_bet recommend'])
Z([3,'recommend_text'])
Z([3,'每日推荐'])
Z([3,'flex_ali'])
Z(z[6])
Z([3,'recommend_text2'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'jumpRealDemo']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([3,'全部样例'])
Z([3,'right_icon'])
Z([3,'/static/images/index/right.png'])
Z([3,'recommend_list'])
Z([3,'true'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'recommend']])
Z([3,'id'])
Z(z[6])
Z([3,'recommend_li'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'jumpRealInfo']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'recommend']],[1,'id']],[[6],[[7],[3,'item']],[3,'id']]],[1,'speakerid']]]]]]]]]]]]]]])
Z(z[6])
Z([3,'play_icon'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e0']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[8],'item',[[7],[3,'item']]])
Z([[2,'!'],[[2,'!=='],[[6],[[7],[3,'item']],[3,'soundurl']],[[6],[[7],[3,'audio']],[3,'audiourl']]]])
Z([3,'https://pysqstoss.shipook.com/static/minisource/10767/real_play.png'])
Z(z[6])
Z(z[38])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'e1']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z(z[40])
Z([[2,'!'],[[2,'==='],[[6],[[7],[3,'item']],[3,'soundurl']],[[6],[[7],[3,'audio']],[3,'audiourl']]]])
Z([3,'https://pysqstoss.shipook.com/static/minisource/10767/real_stop.png'])
Z([3,'ovhide recommend_li_name'])
Z([a,[[6],[[7],[3,'item']],[3,'soundname']]])
Z([3,'flex_cen recommend_li_label'])
Z([a,[[2,'+'],[1,'专题：'],[[6],[[7],[3,'item']],[3,'label']]]])
Z([3,'recommend_li_btn'])
Z([3,'查看'])
Z([3,'real_list'])
Z([[2,'+'],[[2,'+'],[1,'height:'],[[2,'+'],[[2,'+'],[1,'calc(100vh - '],[[7],[3,'top_height']]],[1,'px)']]],[1,';']])
Z(z[6])
Z([3,'real_tab'])
Z([[4],[[5],[[4],[[5],[[5],[1,'scroll']],[[4],[[5],[[4],[[5],[[5],[1,'scrollMove']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[7],[3,'scrollLeft']])
Z([1,true])
Z(z[29])
Z(z[30])
Z(z[31])
Z([[7],[3,'catlist']])
Z(z[30])
Z(z[6])
Z([[4],[[5],[[5],[1,'real_tab_li']],[[2,'?:'],[[2,'==='],[[7],[3,'real_tab']],[[7],[3,'index']]],[1,'real_tab_act'],[1,'']]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'setTab']],[[4],[[5],[[5],[[7],[3,'index']]],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[1,'catlist']],[1,'']],[[7],[3,'index']]]]]]]]]]]]]]]])
Z([[2,'+'],[1,'ele'],[[7],[3,'index']]])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'item']],[3,'catname']]],[1,'']]])
Z(z[6])
Z([3,'real_main'])
Z([[4],[[5],[[4],[[5],[[5],[1,'scrolltolower']],[[4],[[5],[[4],[[5],[[5],[1,'getlivebycat']],[[4],[[5],[1,true]]]]]]]]]]])
Z([[7],[3,'scroll_top']])
Z(z[29])
Z([3,'index2'])
Z([3,'item2'])
Z([[7],[3,'reallist']])
Z([3,'speakerid'])
Z(z[6])
Z([3,'real_li'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[[5],[1,'jumpRealInfo']],[[4],[[5],[1,'$0']]]],[[4],[[5],[[4],[[5],[[4],[[5],[[5],[[5],[[5],[1,'reallist']],[1,'speakerid']],[[6],[[7],[3,'item2']],[3,'speakerid']]],[1,'speakerid']]]]]]]]]]]]]]])
Z([3,'flex_bet real_li_con'])
Z(z[21])
Z([3,'real_avt'])
Z([3,'aspectFill'])
Z([[6],[[7],[3,'item2']],[3,'cover']])
Z([3,'real_name'])
Z([a,[[6],[[7],[3,'item2']],[3,'speakername']]])
Z([3,'ovhide real_desp'])
Z([a,[[6],[[7],[3,'item2']],[3,'desp']]])
Z([3,'flex_ali real_num'])
Z([3,'/static/images/index/real_listen.png'])
Z([a,[[6],[[7],[3,'item2']],[3,'musicnum']]])
Z([3,'/static/images/index/real_num.png'])
Z([a,[[6],[[7],[3,'item2']],[3,'hot']]])
Z([3,'flex_cen real_collect'])
Z([3,'使用'])
Z([3,'flex_cen'])
Z([3,'width:100%;'])
Z(z[14])
Z([[2,'?:'],[[7],[3,'lastPage']],[1,'nomore'],[1,'loading']])
Z([3,'bbb45c00-2'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_39_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_39_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_39=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_39=true;
var x=['./pages/real/real.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_39_1()
var o8EB=_n('view')
_rz(z,o8EB,'class',0,e,s,gg)
var f9EB=_n('view')
_rz(z,f9EB,'id',1,e,s,gg)
var hAFB=_mz(z,'view',['class',2,'style',1],[],e,s,gg)
var oBFB=_n('view')
_rz(z,oBFB,'style',4,e,s,gg)
var cCFB=_oz(z,5,e,s,gg)
_(oBFB,cCFB)
_(hAFB,oBFB)
var oDFB=_mz(z,'view',['bindtap',6,'class',1,'data-event-opts',2],[],e,s,gg)
var lEFB=_mz(z,'image',['class',9,'src',1],[],e,s,gg)
_(oDFB,lEFB)
var aFFB=_mz(z,'input',['placeholder',11,'type',1],[],e,s,gg)
_(oDFB,aFFB)
_(hAFB,oDFB)
_(f9EB,hAFB)
var c0EB=_v()
_(f9EB,c0EB)
if(_oz(z,13,e,s,gg)){c0EB.wxVkey=1
var tGFB=_n('view')
var eHFB=_mz(z,'u-notice-bar',['bind:__l',14,'mode',1,'text',2,'vueId',3],[],e,s,gg)
_(tGFB,eHFB)
_(c0EB,tGFB)
}
var bIFB=_n('view')
_rz(z,bIFB,'class',18,e,s,gg)
var oJFB=_n('text')
_rz(z,oJFB,'class',19,e,s,gg)
var xKFB=_oz(z,20,e,s,gg)
_(oJFB,xKFB)
_(bIFB,oJFB)
var oLFB=_n('view')
_rz(z,oLFB,'class',21,e,s,gg)
var fMFB=_mz(z,'text',['bindtap',22,'class',1,'data-event-opts',2],[],e,s,gg)
var cNFB=_oz(z,25,e,s,gg)
_(fMFB,cNFB)
_(oLFB,fMFB)
var hOFB=_mz(z,'image',['class',26,'src',1],[],e,s,gg)
_(oLFB,hOFB)
_(bIFB,oLFB)
_(f9EB,bIFB)
var oPFB=_mz(z,'scroll-view',['class',28,'scrollX',1],[],e,s,gg)
var cQFB=_v()
_(oPFB,cQFB)
var oRFB=function(aTFB,lSFB,tUFB,gg){
var bWFB=_mz(z,'view',['bindtap',34,'class',1,'data-event-opts',2],[],aTFB,lSFB,gg)
var oXFB=_mz(z,'image',['catchtap',37,'class',1,'data-event-opts',2,'data-event-params',3,'hidden',4,'src',5],[],aTFB,lSFB,gg)
_(bWFB,oXFB)
var xYFB=_mz(z,'image',['catchtap',43,'class',1,'data-event-opts',2,'data-event-params',3,'hidden',4,'src',5],[],aTFB,lSFB,gg)
_(bWFB,xYFB)
var oZFB=_n('view')
_rz(z,oZFB,'class',49,aTFB,lSFB,gg)
var f1FB=_oz(z,50,aTFB,lSFB,gg)
_(oZFB,f1FB)
_(bWFB,oZFB)
var c2FB=_n('view')
_rz(z,c2FB,'class',51,aTFB,lSFB,gg)
var h3FB=_oz(z,52,aTFB,lSFB,gg)
_(c2FB,h3FB)
_(bWFB,c2FB)
var o4FB=_n('view')
_rz(z,o4FB,'class',53,aTFB,lSFB,gg)
var c5FB=_oz(z,54,aTFB,lSFB,gg)
_(o4FB,c5FB)
_(bWFB,o4FB)
_(tUFB,bWFB)
return tUFB
}
cQFB.wxXCkey=2
_2z(z,32,oRFB,e,s,gg,cQFB,'item','index','id')
_(f9EB,oPFB)
c0EB.wxXCkey=1
c0EB.wxXCkey=3
_(o8EB,f9EB)
var o6FB=_mz(z,'view',['class',55,'style',1],[],e,s,gg)
var l7FB=_mz(z,'scroll-view',['bindscroll',57,'class',1,'data-event-opts',2,'scrollLeft',3,'scrollWithAnimation',4,'scrollX',5],[],e,s,gg)
var a8FB=_v()
_(l7FB,a8FB)
var t9FB=function(bAGB,e0FB,oBGB,gg){
var oDGB=_mz(z,'view',['bindtap',67,'class',1,'data-event-opts',2,'id',3],[],bAGB,e0FB,gg)
var fEGB=_oz(z,71,bAGB,e0FB,gg)
_(oDGB,fEGB)
_(oBGB,oDGB)
return oBGB
}
a8FB.wxXCkey=2
_2z(z,65,t9FB,e,s,gg,a8FB,'item','index','index')
_(o6FB,l7FB)
var cFGB=_mz(z,'scroll-view',['bindscrolltolower',72,'class',1,'data-event-opts',2,'scrollTop',3,'scrollY',4],[],e,s,gg)
var hGGB=_v()
_(cFGB,hGGB)
var oHGB=function(oJGB,cIGB,lKGB,gg){
var tMGB=_mz(z,'view',['bindtap',81,'class',1,'data-event-opts',2],[],oJGB,cIGB,gg)
var eNGB=_n('view')
_rz(z,eNGB,'class',84,oJGB,cIGB,gg)
var bOGB=_n('view')
_rz(z,bOGB,'class',85,oJGB,cIGB,gg)
var oPGB=_mz(z,'image',['class',86,'mode',1,'src',2],[],oJGB,cIGB,gg)
_(bOGB,oPGB)
var xQGB=_n('view')
var oRGB=_n('view')
_rz(z,oRGB,'class',89,oJGB,cIGB,gg)
var fSGB=_oz(z,90,oJGB,cIGB,gg)
_(oRGB,fSGB)
_(xQGB,oRGB)
var cTGB=_n('view')
_rz(z,cTGB,'class',91,oJGB,cIGB,gg)
var hUGB=_oz(z,92,oJGB,cIGB,gg)
_(cTGB,hUGB)
_(xQGB,cTGB)
var oVGB=_n('view')
_rz(z,oVGB,'class',93,oJGB,cIGB,gg)
var cWGB=_n('image')
_rz(z,cWGB,'src',94,oJGB,cIGB,gg)
_(oVGB,cWGB)
var oXGB=_n('text')
var lYGB=_oz(z,95,oJGB,cIGB,gg)
_(oXGB,lYGB)
_(oVGB,oXGB)
var aZGB=_n('image')
_rz(z,aZGB,'src',96,oJGB,cIGB,gg)
_(oVGB,aZGB)
var t1GB=_n('text')
var e2GB=_oz(z,97,oJGB,cIGB,gg)
_(t1GB,e2GB)
_(oVGB,t1GB)
_(xQGB,oVGB)
_(bOGB,xQGB)
_(eNGB,bOGB)
var b3GB=_n('view')
_rz(z,b3GB,'class',98,oJGB,cIGB,gg)
var o4GB=_oz(z,99,oJGB,cIGB,gg)
_(b3GB,o4GB)
_(eNGB,b3GB)
_(tMGB,eNGB)
_(lKGB,tMGB)
return lKGB
}
hGGB.wxXCkey=2
_2z(z,79,oHGB,e,s,gg,hGGB,'item2','index2','speakerid')
var x5GB=_mz(z,'view',['class',100,'style',1],[],e,s,gg)
var o6GB=_mz(z,'u-loadmore',['bind:__l',102,'status',1,'vueId',2],[],e,s,gg)
_(x5GB,o6GB)
_(cFGB,x5GB)
_(o6FB,cFGB)
_(o8EB,o6FB)
_(r,o8EB)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_39";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_39();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/real/real.wxml'] = [$gwx_XC_39, './pages/real/real.wxml'];else __wxAppCode__['pages/real/real.wxml'] = $gwx_XC_39( './pages/real/real.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/real/real.wxss'] = setCssToHead(["wx-text,wx-view{font-size:",[0,28],"}\n.",[1],"flex_col{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column}\n.",[1],"widthFix{display:block;height:0;height:auto;width:100%}\n.",[1],"heightFix{display:block;height:100%;width:0;width:auto}\n::-webkit-scrollbar{color:transparent}\nbody{height:100%}\nwx-text,wx-view{box-sizing:border-box;color:#333}\n.",[1],"mian,.",[1],"netmb{width:100%}\n.",[1],"netmb{-webkit-align-items:center;align-items:center;background-color:rgba(0,0,0,.8);display:-webkit-flex;display:flex;-webkit-flex-wrap:wrap;flex-wrap:wrap;height:100%;position:fixed;z-index:99999}\n.",[1],"netbtn{background-color:#ffba00;border-radius:",[0,19],";height:",[0,80],";line-height:",[0,76],";margin-left:25%;margin-top:",[0,40],";width:50%}\n.",[1],"netbtn,.",[1],"nettext{color:#fff;text-align:center}\n.",[1],"netcon,.",[1],"nettext{width:100%}\n.",[1],"agreementpopup{-webkit-align-items:center;align-items:center;background-color:rgba(0,0,0,.4);display:-webkit-flex;display:flex;height:100%;left:0;position:fixed;top:0;width:100%;z-index:999999}\n.",[1],"agreementcon{background-color:#fff;border-radius:",[0,12],";height:",[0,750],";margin-left:10%;width:80%}\n.",[1],"agreetit{font-size:",[0,32],";margin-top:",[0,40],";text-align:center}\n.",[1],"agreetext{height:",[0,400],";margin-left:4%;margin-top:",[0,20],";width:92%}\n.",[1],"agreebtn{background-color:#ff3e2c;color:#fff;margin-top:",[0,20],"}\n.",[1],"agreebtn,.",[1],"agreeunbtn{-webkit-align-items:center;align-items:center;border-radius:",[0,8],";display:-webkit-flex;display:flex;height:",[0,100],";-webkit-justify-content:space-around;justify-content:space-around;margin-left:4%;width:92%}\n.",[1],"agreeunbtn{color:#999}\n.",[1],"agreetext wx-view{color:#666;font-size:",[0,24],";line-height:",[0,34],"}\n.",[1],"agreetext wx-text{color:#282195}\n.",[1],"placeorder{-webkit-align-items:center;align-items:center;background-color:#ffc107;border-radius:",[0,16],";color:#fff;display:-webkit-flex;display:flex;font-size:",[0,24],";height:",[0,48],";-webkit-justify-content:space-around;justify-content:space-around;width:",[0,118],"}\n.",[1],"zhuboply{bottom:",[0,14],"!important;height:",[0,32],"!important;position:absolute;right:",[0,14],"!important;width:",[0,32],"!important;z-index:1}\n.",[1],"upgrade{background-color:rgba(0,0,0,.4);height:100%;left:0;position:fixed;top:0;width:100%;z-index:99999}\n.",[1],"upgradecon{height:",[0,640],";left:50%;margin-left:",[0,-240],";margin-top:",[0,-320],";position:absolute;top:50%;width:",[0,480],"}\n.",[1],"upgradeimg{height:100%;left:0;position:absolute;top:0;width:100%;z-index:-1}\n.",[1],"upgradetext{height:",[0,250],";margin-top:",[0,250],";width:100%}\n.",[1],"upgradebtn{-webkit-align-items:center;align-items:center;background-color:#f3b043;border-radius:",[0,16],";color:#fff;display:-webkit-flex;display:flex;height:",[0,64],";-webkit-justify-content:space-around;justify-content:space-around;margin:",[0,8]," auto;width:",[0,380],"}\n.",[1],"offupgrade{bottom:",[0,-90],";height:",[0,72],";left:50%;margin-left:",[0,-36],";position:absolute;width:",[0,72],"}\n.",[1],"srcolltop{background-color:#fff;left:0;padding-bottom:",[0,20],";position:fixed;top:0;width:100%;z-index:99999}\n.",[1],"audio_detail_box{background:#fff;border:",[0,2]," solid #eee;border-radius:",[0,40],";height:",[0,200],";-webkit-justify-content:space-between;justify-content:space-between;margin:",[0,32]," auto 0;padding:",[0,40],";width:",[0,686],"}\n.",[1],"audio_detail_box,.",[1],"box_left{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex}\n.",[1],"left_img{position:relative}\n.",[1],"img_bg,.",[1],"left_img wx-image{border-radius:50%;height:",[0,120],";width:",[0,120],"}\n.",[1],"img_bg{background:rgba(0,0,0,.2);left:0;position:absolute;top:0}\n.",[1],"play_state_img{border-radius:0!important;height:",[0,44],"!important;left:",[0,38],";position:absolute;top:",[0,38],";width:",[0,44],"!important}\n.",[1],"box_con{margin-left:",[0,20],"}\n.",[1],"con_title{color:#333;font-size:",[0,28],";font-weight:700;margin-bottom:",[0,12],"}\n.",[1],"con_text{color:#666;font-size:",[0,20],"}\n.",[1],"change_btn wx-image{height:",[0,64],";width:",[0,160],"}\n.",[1],"more_btn{display:-webkit-flex;display:flex;-webkit-justify-content:space-between;justify-content:space-between;width:",[0,156],"}\n.",[1],"more_btn wx-image{height:",[0,40],";width:",[0,40],"}\n.",[1],"box_left_con .",[1],"con_top{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex}\n.",[1],"box_left_con .",[1],"con_top_title{color:#333;font-size:",[0,28],";font-weight:700}\n.",[1],"box_left_con .",[1],"con_top_lable{color:#999;font-size:",[0,20],";margin-left:",[0,20],"}\n.",[1],"box_left_con .",[1],"con_btm{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;margin-top:",[0,26],"}\nwx-slider{margin:0!important}\n.",[1],"splice_slider{width:",[0,300],"}\n.",[1],"splice_slider_value{color:#ffc22d;font-size:",[0,32],";font-weight:700;margin-left:",[0,20],"}\n.",[1],"audio_detail{margin-top:",[0,32],";text-align:center}\n.",[1],"audio_detail wx-image{height:",[0,200],";width:",[0,686],"}\n.",[1],"audio_detail_title{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;margin:",[0,60]," 0 ",[0,20]," 4%;width:92%}\n.",[1],"audio_detail_title wx-image{height:",[0,40],";width:",[0,40],"}\n.",[1],"audio_detail_title .",[1],"title{color:#333;font-size:",[0,32],";font-weight:700;margin-left:",[0,12],"}\n.",[1],"bg_con{height:100%;left:0;top:0;width:100%;z-index:1}\n.",[1],"bg_con,.",[1],"pos_cen{position:absolute}\n.",[1],"pos_cen{left:50%;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);z-index:2}\n.",[1],"flex_ali,.",[1],"flex_aro{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex}\n.",[1],"flex_aro{-webkit-justify-content:space-around;justify-content:space-around}\n.",[1],"flex_bet{-webkit-justify-content:space-between;justify-content:space-between}\n.",[1],"flex_bet,.",[1],"flex_cen{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex}\n.",[1],"flex_cen{-webkit-justify-content:center;justify-content:center}\n.",[1],"con{box-sizing:border-box;padding:0 ",[0,32],";width:100%}\n.",[1],"ovhide{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.",[1],"allpopupbg{background-color:rgba(0,0,0,.5);height:100%;left:0;position:fixed;top:0;width:100%}\n.",[1],"status_bar{height:25px;width:100%}\n.",[1],"wxParse{color:#333;font-family:Helvetica,PingFangSC,Microsoft Yahei,微软雅黑,Arial,sans-serif;font-size:1em;line-height:1.5;text-align:justify;-webkit-user-select:none;user-select:none;width:100%}\n.",[1],"wxParse wx-uni-view,.",[1],"wxParse wx-view{word-break:break-word}\n.",[1],"wxParse .",[1],"p{clear:both;padding-bottom:.5em}\n.",[1],"wxParse .",[1],"inline{display:inline;margin:0;padding:0}\n.",[1],"wxParse .",[1],"div{display:block;margin:0;padding:0}\n.",[1],"wxParse .",[1],"h1{font-size:2em;line-height:1.2em;margin:.67em 0}\n.",[1],"wxParse .",[1],"h2{font-size:1.5em;margin:.83em 0}\n.",[1],"wxParse .",[1],"h3{font-size:1.17em;margin:1em 0}\n.",[1],"wxParse .",[1],"h4{margin:1.33em 0}\n.",[1],"wxParse .",[1],"h5,.",[1],"wxParse .",[1],"h6{font-size:.83em;margin:1.67em 0}\n.",[1],"wxParse .",[1],"b,.",[1],"wxParse .",[1],"h1,.",[1],"wxParse .",[1],"h2,.",[1],"wxParse .",[1],"h3,.",[1],"wxParse .",[1],"h4,.",[1],"wxParse .",[1],"h5,.",[1],"wxParse .",[1],"h6,.",[1],"wxParse .",[1],"strong{font-weight:bolder}\n.",[1],"wxParse .",[1],"address,.",[1],"wxParse .",[1],"cite,.",[1],"wxParse .",[1],"em,.",[1],"wxParse .",[1],"i,.",[1],"wxParse .",[1],"var{font-style:italic}\n.",[1],"wxParse .",[1],"spaceshow{white-space:pre}\n.",[1],"wxParse .",[1],"code,.",[1],"wxParse .",[1],"kbd,.",[1],"wxParse .",[1],"pre,.",[1],"wxParse .",[1],"samp,.",[1],"wxParse .",[1],"tt{font-family:monospace}\n.",[1],"wxParse .",[1],"code,.",[1],"wxParse .",[1],"pre{background:#f5f5f5;font-size:",[0,24],";margin:1em ",[0,0],";overflow:auto;padding:",[0,16],";white-space:pre}\n.",[1],"wxParse .",[1],"big{font-size:1.17em}\n.",[1],"wxParse .",[1],"small,.",[1],"wxParse .",[1],"sub,.",[1],"wxParse .",[1],"sup{font-size:.83em}\n.",[1],"wxParse .",[1],"sub{vertical-align:sub}\n.",[1],"wxParse .",[1],"sup{vertical-align:super}\n.",[1],"wxParse .",[1],"del,.",[1],"wxParse .",[1],"s,.",[1],"wxParse .",[1],"strike{text-decoration:line-through}\n.",[1],"wxParse .",[1],"s,.",[1],"wxParse .",[1],"span,.",[1],"wxParse .",[1],"strong,.",[1],"wxParse .",[1],"text{display:inline}\n.",[1],"wxParse .",[1],"a{color:#00bfff}\n.",[1],"wxParse .",[1],"video{margin:",[0,22]," 0;text-align:center}\n.",[1],"wxParse .",[1],"video-video{width:100%}\n.",[1],"wxParse .",[1],"img,.",[1],"wxParse .",[1],"uni-image{max-width:100%}\n.",[1],"wxParse .",[1],"img{display:block;margin-bottom:0;overflow:hidden}\n.",[1],"wxParse .",[1],"blockquote{background:#f5f5f5;border-left:",[0,6]," solid #dbdbdb;font-family:Courier,Calibri,宋体;margin:",[0,10]," 0;padding:",[0,22]," 0 ",[0,22]," ",[0,22],"}\n.",[1],"wxParse .",[1],"blockquote .",[1],"p{margin:0}\n.",[1],"wxParse .",[1],"ol,.",[1],"wxParse .",[1],"ul{display:block;margin:1em 0;padding-left:2em}\n.",[1],"wxParse .",[1],"ol{list-style-type:disc;list-style-type:decimal}\n.",[1],"wxParse .",[1],"ol\x3e.",[1],"li,.",[1],"wxParse .",[1],"ol\x3ewx-weixin-parse-template,.",[1],"wxParse .",[1],"ul\x3e.",[1],"li,.",[1],"wxParse .",[1],"ul\x3ewx-weixin-parse-template{-webkit-align-items:baseline;align-items:baseline;display:list-item;text-align:match-parent}\n.",[1],"wxParse .",[1],"ol .",[1],"ul,.",[1],"wxParse .",[1],"ul .",[1],"ul{list-style-type:circle}\n.",[1],"wxParse .",[1],"ol .",[1],"ol .",[1],"ul,.",[1],"wxParse .",[1],"ol .",[1],"ul .",[1],"ul,.",[1],"wxParse .",[1],"ul .",[1],"ol .",[1],"ul,.",[1],"wxParse .",[1],"ul .",[1],"ul .",[1],"ul{list-style-type:square}\n.",[1],"wxParse .",[1],"u{text-decoration:underline}\n.",[1],"wxParse .",[1],"hide{display:none}\n.",[1],"wxParse .",[1],"del{display:inline}\n.",[1],"wxParse .",[1],"figure{overflow:hidden}\n.",[1],"wxParse .",[1],"tablebox{background-color:#f5f5f5;background:#f5f5f5;font-size:13px;overflow:auto;padding:8px}\n.",[1],"wxParse .",[1],"table,.",[1],"wxParse .",[1],"table .",[1],"table{border-collapse:collapse;box-sizing:border-box;overflow:auto;white-space:pre}\n.",[1],"wxParse .",[1],"tbody{border:1px solid #dadada;border-collapse:collapse;box-sizing:border-box}\n.",[1],"wxParse .",[1],"table .",[1],"tfoot,.",[1],"wxParse .",[1],"table .",[1],"th,.",[1],"wxParse .",[1],"table .",[1],"thead{background:#ececec;border-collapse:collapse;box-sizing:border-box;font-weight:40}\n.",[1],"wxParse .",[1],"table .",[1],"td,.",[1],"wxParse .",[1],"table .",[1],"th,.",[1],"wxParse .",[1],"table .",[1],"tr{border-collapse:collapse;box-sizing:border-box;overflow:auto}\n.",[1],"wxParse .",[1],"table .",[1],"td,.",[1],"wxParse .",[1],"table .",[1],"th{border:",[0,2]," solid #dadada}\n.",[1],"wxParse .",[1],"audio,.",[1],"wxParse .",[1],"uni-audio-default{display:block}\n.",[1],"u-line-1{-webkit-line-clamp:1}\n.",[1],"u-line-1,.",[1],"u-line-2{-webkit-box-orient:vertical!important;display:-webkit-box!important;overflow:hidden;text-overflow:ellipsis;word-break:break-all}\n.",[1],"u-line-2{-webkit-line-clamp:2}\n.",[1],"u-line-3{-webkit-line-clamp:3}\n.",[1],"u-line-3,.",[1],"u-line-4{-webkit-box-orient:vertical!important;display:-webkit-box!important;overflow:hidden;text-overflow:ellipsis;word-break:break-all}\n.",[1],"u-line-4{-webkit-line-clamp:4}\n.",[1],"u-line-5{-webkit-line-clamp:5;-webkit-box-orient:vertical!important;display:-webkit-box!important;overflow:hidden;text-overflow:ellipsis;word-break:break-all}\n.",[1],"u-border{border-color:#dadbde!important;border-style:solid;border-width:.5px!important}\n.",[1],"u-border-top{border-color:#dadbde!important;border-top-style:solid;border-top-width:.5px!important}\n.",[1],"u-border-left{border-color:#dadbde!important;border-left-style:solid;border-left-width:.5px!important}\n.",[1],"u-border-right{border-color:#dadbde!important;border-right-style:solid;border-right-width:.5px!important}\n.",[1],"u-border-bottom{border-bottom-style:solid;border-bottom-width:.5px!important;border-color:#dadbde!important}\n.",[1],"u-border-top-bottom{border-bottom-style:solid;border-bottom-width:.5px!important;border-color:#dadbde!important;border-top-style:solid;border-top-width:.5px!important}\n.",[1],"u-reset-button{background-color:initial;color:inherit;font-size:inherit;line-height:inherit;padding:0}\n.",[1],"u-reset-button::after{border:none}\n.",[1],"u-hover-class{opacity:.7}\n.",[1],"u-primary-light{color:#ecf5ff}\n.",[1],"u-warning-light{color:#fdf6ec}\n.",[1],"u-success-light{color:#f5fff0}\n.",[1],"u-error-light{color:#fef0f0}\n.",[1],"u-info-light{color:#f4f4f5}\n.",[1],"u-primary-light-bg{background-color:#ecf5ff}\n.",[1],"u-warning-light-bg{background-color:#fdf6ec}\n.",[1],"u-success-light-bg{background-color:#f5fff0}\n.",[1],"u-error-light-bg{background-color:#fef0f0}\n.",[1],"u-info-light-bg{background-color:#f4f4f5}\n.",[1],"u-primary-dark{color:#398ade}\n.",[1],"u-warning-dark{color:#f1a532}\n.",[1],"u-success-dark{color:#53c21d}\n.",[1],"u-error-dark{color:#e45656}\n.",[1],"u-info-dark{color:#767a82}\n.",[1],"u-primary-dark-bg{background-color:#398ade}\n.",[1],"u-warning-dark-bg{background-color:#f1a532}\n.",[1],"u-success-dark-bg{background-color:#53c21d}\n.",[1],"u-error-dark-bg{background-color:#e45656}\n.",[1],"u-info-dark-bg{background-color:#767a82}\n.",[1],"u-primary-disabled{color:#9acafc}\n.",[1],"u-warning-disabled{color:#f9d39b}\n.",[1],"u-success-disabled{color:#a9e08f}\n.",[1],"u-error-disabled{color:#f7b2b2}\n.",[1],"u-info-disabled{color:#c4c6c9}\n.",[1],"u-primary{color:#3c9cff}\n.",[1],"u-warning{color:#f9ae3d}\n.",[1],"u-success{color:#5ac725}\n.",[1],"u-error{color:#f56c6c}\n.",[1],"u-info{color:#909399}\n.",[1],"u-primary-bg{background-color:#3c9cff}\n.",[1],"u-warning-bg{background-color:#f9ae3d}\n.",[1],"u-success-bg{background-color:#5ac725}\n.",[1],"u-error-bg{background-color:#f56c6c}\n.",[1],"u-info-bg{background-color:#909399}\n.",[1],"u-main-color{color:#303133}\n.",[1],"u-content-color{color:#606266}\n.",[1],"u-tips-color{color:#909193}\n.",[1],"u-light-color{color:#c0c4cc}\n.",[1],"u-safe-area-inset-top{padding-top:env(safe-area-inset-top)}\n.",[1],"u-safe-area-inset-right{padding-right:env(safe-area-inset-right)}\n.",[1],"u-safe-area-inset-bottom{padding-bottom:env(safe-area-inset-bottom)}\n.",[1],"u-safe-area-inset-left{padding-left:env(safe-area-inset-left)}\n::-webkit-scrollbar{-webkit-appearance:none;background:transparent;display:none;height:0!important;width:0!important}\n.",[1],"real_main_swiper{height:calc(100% - ",[0,88],");width:100%}\n.",[1],"real_main{height:91%;width:100%}\n.",[1],"real_main .",[1],"real_li{padding:0 ",[0,30],"}\n.",[1],"real_main .",[1],"real_li .",[1],"real_li_con{border-bottom:",[0,2]," solid #f4f4f4;padding:",[0,32]," 0}\n.",[1],"real_main .",[1],"real_li .",[1],"real_li_con .",[1],"real_collect{border:",[0,2]," solid #fff5e3;border-radius:",[0,50],";color:#ff932f;font-size:",[0,24],";font-weight:700;height:",[0,58],";width:",[0,112],"}\n.",[1],"real_main .",[1],"real_li .",[1],"real_li_con .",[1],"real_num{margin-top:",[0,14],"}\n.",[1],"real_main .",[1],"real_li .",[1],"real_li_con .",[1],"real_num wx-text{color:#bdbdbd;font-size:",[0,24],";margin-right:",[0,28],"}\n.",[1],"real_main .",[1],"real_li .",[1],"real_li_con .",[1],"real_num wx-text:last-of-type{margin-right:0}\n.",[1],"real_main .",[1],"real_li .",[1],"real_li_con .",[1],"real_num wx-image{margin-right:",[0,8],"}\n.",[1],"real_main .",[1],"real_li .",[1],"real_li_con .",[1],"real_num wx-image:first-of-type{height:",[0,22],";width:",[0,24],"}\n.",[1],"real_main .",[1],"real_li .",[1],"real_li_con .",[1],"real_num wx-image:last-of-type{height:",[0,26],";width:",[0,22],"}\n.",[1],"real_main .",[1],"real_li .",[1],"real_li_con .",[1],"real_desp{color:#999;font-size:",[0,24],";margin-top:",[0,10],";width:",[0,360],"}\n.",[1],"real_main .",[1],"real_li .",[1],"real_li_con .",[1],"real_name{font-size:",[0,32],"}\n.",[1],"real_main .",[1],"real_li .",[1],"real_avt{background-color:#eee;border-radius:50%;height:",[0,108],";margin-right:",[0,30],";width:",[0,108],"}\n.",[1],"real_tab{height:",[0,88],";white-space:nowrap;width:100%}\n.",[1],"real_tab .",[1],"real_tab_act{color:#ff932f!important;font-weight:700;position:relative}\n.",[1],"real_tab .",[1],"real_tab_act::before{background-color:#ff932f;border-radius:",[0,4],";bottom:0;content:\x22\x22;height:",[0,8],";left:50%;position:absolute;-webkit-transform:translateX(-50%);transform:translateX(-50%);width:",[0,36],"}\n.",[1],"real_tab .",[1],"real_tab_li{color:#999;display:inline-block;height:100%;line-height:",[0,88],";padding:0 ",[0,24],"}\n.",[1],"real_top{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:100vh;-webkit-justify-content:space-between;justify-content:space-between;left:0;position:fixed;top:0}\n.",[1],"real_top,.",[1],"real_top .",[1],"real_list{width:100%}\n.",[1],"real_top .",[1],"recommend_list{height:",[0,262],";margin-top:",[0,24],";white-space:nowrap;width:100%}\n.",[1],"real_top .",[1],"recommend_list .",[1],"recommend_li{border:",[0,2]," solid #f2f2f0;border-radius:",[0,20],";display:inline-block;height:100%;margin-left:",[0,24],";padding-top:",[0,24],";text-align:center;width:",[0,204],"}\n.",[1],"real_top .",[1],"recommend_list .",[1],"recommend_li .",[1],"recommend_li_name{margin:0 auto;width:80%}\n.",[1],"real_top .",[1],"recommend_list .",[1],"recommend_li .",[1],"recommend_li_label{color:#999;font-size:",[0,20],";margin-top:",[0,8],"}\n.",[1],"real_top .",[1],"recommend_list .",[1],"recommend_li .",[1],"recommend_li_btn{-webkit-align-items:center;align-items:center;background-color:#fff5e3;border-radius:",[0,50],";color:#ff932f;display:-webkit-flex;display:flex;font-size:",[0,24],";font-weight:700;height:",[0,46],";-webkit-justify-content:center;justify-content:center;margin:",[0,12]," auto 0;width:",[0,96],"}\n.",[1],"real_top .",[1],"recommend_list .",[1],"recommend_li .",[1],"play_icon{height:",[0,64],";margin-bottom:",[0,6],";width:",[0,64],"}\n.",[1],"real_top .",[1],"recommend_list .",[1],"recommend_li:first-of-type{margin-left:",[0,30],"}\n.",[1],"real_top .",[1],"recommend_list .",[1],"recommend_li:last-of-type{margin-right:",[0,30],"}\n.",[1],"real_top .",[1],"recommend{padding:0 ",[0,30],"}\n.",[1],"real_top .",[1],"recommend .",[1],"recommend_text2{color:#999}\n.",[1],"real_top .",[1],"recommend .",[1],"recommend_text{font-size:",[0,32],";font-weight:700}\n.",[1],"real_top .",[1],"recommend .",[1],"right_icon{height:",[0,24],";margin-left:",[0,8],";width:",[0,24],"}\n.",[1],"real_top .",[1],"real_search{-webkit-align-items:center;align-items:center;background:linear-gradient(180deg,#fffaf1,hsla(0,0%,100%,0));display:-webkit-flex;display:flex;margin-bottom:",[0,44],";padding:0 ",[0,30],"}\n.",[1],"real_top .",[1],"real_search .",[1],"real_input{background-color:#fff;border:",[0,2]," solid rgba(255,147,47,.06);border-radius:",[0,20],";box-shadow:",[0,0]," ",[0,4]," ",[0,16]," ",[0,0]," #f8efe7;height:",[0,67],";width:",[0,308],"}\n.",[1],"real_top .",[1],"real_search .",[1],"real_input wx-input{width:calc(100% - ",[0,82],")}\n.",[1],"real_top .",[1],"real_search .",[1],"real_input .",[1],"search_img{height:",[0,32],";padding:",[0,20]," ",[0,20]," ",[0,20]," ",[0,30],";width:",[0,32],"}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/real/real.wxss:1:15192)",{path:"./pages/real/real.wxss"});
}