$gwx_XC_36=function(_,_v,_n,_p,_s,_wp,_wl,$gwn,$gwl,$gwh,wh,$gstack,$gwrt,gra,grb,TestTest,wfor,_ca,_da,_r,_rz,_o,_oz,_1,_1z,_2,_2z,_m,_mz,nv_getDate,nv_getRegExp,nv_console,nv_parseInt,nv_parseFloat,nv_isNaN,nv_isFinite,nv_decodeURI,nv_decodeURIComponent,nv_encodeURI,nv_encodeURIComponent,$gdc,nv_JSON,_af,_gv,_ai,_grp,_gd,_gapi,$ixc,_ic,_w,_ev,_tsd){return function(path,global){
if(typeof global==='undefined'){if (typeof __GWX_GLOBAL__==='undefined')global={};else global=__GWX_GLOBAL__;}if(typeof __WXML_GLOBAL__ === 'undefined') {__WXML_GLOBAL__={};
}__WXML_GLOBAL__.modules = __WXML_GLOBAL__.modules || {};
var e_={}
if(typeof(global.entrys)==='undefined')global.entrys={};e_=global.entrys;
var d_={}
if(typeof(global.defines)==='undefined')global.defines={};d_=global.defines;
var f_={}
if(typeof(global.modules)==='undefined')global.modules={};f_=global.modules || {};
var p_={}
__WXML_GLOBAL__.ops_cached = __WXML_GLOBAL__.ops_cached || {}
__WXML_GLOBAL__.ops_set = __WXML_GLOBAL__.ops_set || {};
__WXML_GLOBAL__.ops_init = __WXML_GLOBAL__.ops_init || {};
var z=__WXML_GLOBAL__.ops_set.$gwx_XC_36 || [];
function gz$gwx_XC_36_1(){
if( __WXML_GLOBAL__.ops_cached.$gwx_XC_36_1)return __WXML_GLOBAL__.ops_cached.$gwx_XC_36_1
__WXML_GLOBAL__.ops_cached.$gwx_XC_36_1=[];
(function(z){var a=11;function Z(ops){z.push(ops)}
Z([3,'announcer'])
Z([3,'__e'])
Z([3,'announcer_search flex_bet'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[1,'jumppage']]]]]]]]])
Z([3,'announcer_input flex_bet'])
Z([3,'/static/images/index/search.png'])
Z([3,'true'])
Z([3,'搜索全部700+主播'])
Z([3,'text'])
Z([3,'anchoralltab'])
Z(z[1])
Z([3,'announcer_tab'])
Z([[4],[[5],[[4],[[5],[[5],[1,'scroll']],[[4],[[5],[[4],[[5],[[5],[1,'scrollMove']],[[4],[[5],[1,'$event']]]]]]]]]]])
Z([[7],[3,'tabLiIndex']])
Z([[7],[3,'scrollLeft']])
Z([1,true])
Z(z[6])
Z([[2,'>'],[[6],[[7],[3,'$root']],[3,'g0']],[1,0]])
Z(z[1])
Z([[4],[[5],[[5],[1,'antab_li']],[[2,'?:'],[[2,'==='],[[7],[3,'tab']],[[2,'-'],[1,1]]],[1,'antab_act'],[1,'']]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'setTab']],[[4],[[5],[[2,'-'],[1,1]]]]]]]]]]]])
Z([3,'ele-1'])
Z([3,'收藏'])
Z([[2,'=='],[[7],[3,'tab']],[[2,'-'],[1,1]]])
Z([3,'antab_act_gang'])
Z([3,'index'])
Z([3,'item'])
Z([[7],[3,'tab_list']])
Z(z[25])
Z(z[1])
Z([[4],[[5],[[5],[1,'antab_li']],[[2,'?:'],[[2,'=='],[[7],[3,'tab']],[[7],[3,'index']]],[1,'antab_act'],[1,'']]]])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[[5],[1,'setTab']],[[4],[[5],[[7],[3,'index']]]]]]]]]]]])
Z([[2,'+'],[1,'ele'],[[7],[3,'index']]])
Z([a,[[2,'+'],[[2,'+'],[1,''],[[6],[[7],[3,'item']],[3,'catname']]],[1,'']]])
Z([[2,'=='],[[7],[3,'tab']],[[7],[3,'index']]])
Z(z[24])
Z([3,'announcer_main flex_bet'])
Z([[6],[[7],[3,'$root']],[3,'g1']])
Z(z[1])
Z(z[1])
Z([3,'announcer_list'])
Z([[4],[[5],[[5],[[4],[[5],[[5],[1,'scrolltolower']],[[4],[[5],[[4],[[5],[[5],[1,'loadAnchor']],[[4],[[5],[[5],[1,'bottom']],[1,'$event']]]]]]]]]],[[4],[[5],[[5],[1,'refresherrefresh']],[[4],[[5],[[4],[[5],[[5],[1,'loadAnchor']],[[4],[[5],[1,'top']]]]]]]]]]])
Z([3,'160'])
Z(z[15])
Z([[7],[3,'triggered']])
Z([[7],[3,'anchorLiIndex']])
Z([[7],[3,'scrolly']])
Z([[2,'=='],[[7],[3,'tab']],[[2,'-'],[1,3]]])
Z(z[1])
Z([3,'cltop_bg'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[1,'gotoCloning']]]]]]]]])
Z([3,'cltop'])
Z([3,'img1'])
Z([3,'https://pysq.stoss.shipook.com/static/minisource/10767/sykl.svg'])
Z([3,'声音不够用？继续试试声音克隆'])
Z([3,'img2'])
Z([3,'/static/images/make/bluejiantou.svg'])
Z([3,'index2'])
Z([3,'item2'])
Z([[6],[[7],[3,'$root']],[3,'l0']])
Z([3,'m0'])
Z([[2,'+'],[1,'anchorLi'],[[6],[[6],[[7],[3,'item2']],[3,'$orig']],[3,'zbid']]])
Z([3,'__l'])
Z(z[1])
Z(z[1])
Z(z[1])
Z(z[1])
Z(z[1])
Z([3,'vue-ref-in-for'])
Z([[4],[[5],[[5],[[5],[[5],[[5],[[4],[[5],[[5],[1,'^collect']],[[4],[[5],[[4],[[5],[1,'collectAnchor']]]]]]]],[[4],[[5],[[5],[1,'^playEmotion']],[[4],[[5],[[4],[[5],[1,'playEmotion']]]]]]]],[[4],[[5],[[5],[1,'^stopEmotion']],[[4],[[5],[[4],[[5],[1,'stopEmotion']]]]]]]],[[4],[[5],[[5],[1,'^useAnchor']],[[4],[[5],[[4],[[5],[1,'useAnchor']]]]]]]],[[4],[[5],[[5],[1,'^upPay']],[[4],[[5],[[4],[[5],[1,'qryTtsTrain']]]]]]]]])
Z([3,'myAnchorLi'])
Z([[6],[[7],[3,'item2']],[3,'m1']])
Z([[7],[3,'mypageZb']])
Z([[2,'+'],[1,'67e1d0ce-1-'],[[7],[3,'index2']]])
Z([[6],[[7],[3,'item2']],[3,'$orig']])
Z([[2,'>'],[[6],[[7],[3,'$root']],[3,'g2']],[1,0]])
Z([3,'flex_cen'])
Z([3,'width:100%;'])
Z([[2,'=='],[[6],[[6],[[6],[[7],[3,'tab_list']],[[7],[3,'tab']]],[3,'pageflag']],[3,'nextpage']],[[2,'-'],[1,1]]])
Z([3,'hasend flex_cen'])
Z([3,'text1'])
Z([3,'已经到底啦~'])
Z([3,'text2'])
Z([3,'没有想要的主播？可提交主播信息，'])
Z(z[82])
Z([3,'我们会努力开发！'])
Z(z[1])
Z([3,'hasend_tj flex_cen'])
Z([[4],[[5],[[4],[[5],[[5],[1,'tap']],[[4],[[5],[[4],[[5],[1,'submit']]]]]]]]])
Z([3,'去提交'])
Z([[2,'||'],[[2,'=='],[[7],[3,'tab']],[[2,'-'],[1,1]]],[[2,'=='],[[7],[3,'tab']],[[2,'-'],[1,3]]]])
Z(z[62])
Z([3,'已经到底啦~'])
Z([3,'nomore'])
Z([3,'67e1d0ce-2'])
Z(z[62])
Z([3,'loading'])
Z([3,'67e1d0ce-3'])
Z([[6],[[7],[3,'$root']],[3,'g3']])
Z([3,'cloningNull flex_cen'])
Z([3,'cloningNull_top flex_cen'])
Z([3,'https://pysq.stoss.shipook.com/static/minisource/10767/cloningNull.png'])
Z([3,'_span'])
Z([3,'暂无克隆声音'])
Z([3,'cloningNull_fgx'])
Z([3,'cloningNull_bot flex_cen'])
Z([3,'高品质定制克隆声音'])
Z(z[102])
Z([3,'1000+人正在使用'])
Z([3,'cloningNull_bot_icon'])
Z(z[25])
Z(z[26])
Z([[7],[3,'cloningList']])
Z(z[25])
Z([3,'icon_li flex_cen'])
Z([[6],[[7],[3,'item']],[3,'icon']])
Z([a,[[6],[[7],[3,'item']],[3,'title']]])
Z(z[1])
Z([3,'qkl flex_cen'])
Z(z[50])
Z([3,'去克隆'])
})(__WXML_GLOBAL__.ops_cached.$gwx_XC_36_1);return __WXML_GLOBAL__.ops_cached.$gwx_XC_36_1
}
__WXML_GLOBAL__.ops_set.$gwx_XC_36=z;
__WXML_GLOBAL__.ops_init.$gwx_XC_36=true;
var x=['./pages/make/anchor.wxml'];d_[x[0]]={}
var m0=function(e,s,r,gg){
var z=gz$gwx_XC_36_1()
var cD5=_n('view')
_rz(z,cD5,'class',0,e,s,gg)
var hE5=_mz(z,'view',['bindtap',1,'class',1,'data-event-opts',2],[],e,s,gg)
var oF5=_n('view')
_rz(z,oF5,'class',4,e,s,gg)
var cG5=_n('image')
_rz(z,cG5,'src',5,e,s,gg)
_(oF5,cG5)
var oH5=_mz(z,'input',['disabled',6,'placeholder',1,'type',2],[],e,s,gg)
_(oF5,oH5)
_(hE5,oF5)
_(cD5,hE5)
var lI5=_n('view')
_rz(z,lI5,'class',9,e,s,gg)
var aJ5=_mz(z,'scroll-view',['bindscroll',10,'class',1,'data-event-opts',2,'scrollIntoView',3,'scrollLeft',4,'scrollWithAnimation',5,'scrollX',6],[],e,s,gg)
var tK5=_v()
_(aJ5,tK5)
if(_oz(z,17,e,s,gg)){tK5.wxVkey=1
var eL5=_mz(z,'view',['bindtap',18,'class',1,'data-event-opts',2,'id',3],[],e,s,gg)
var oN5=_oz(z,22,e,s,gg)
_(eL5,oN5)
var bM5=_v()
_(eL5,bM5)
if(_oz(z,23,e,s,gg)){bM5.wxVkey=1
var xO5=_n('view')
_rz(z,xO5,'class',24,e,s,gg)
_(bM5,xO5)
}
bM5.wxXCkey=1
_(tK5,eL5)
}
var oP5=_v()
_(aJ5,oP5)
var fQ5=function(hS5,cR5,oT5,gg){
var oV5=_mz(z,'view',['catchtap',29,'class',1,'data-event-opts',2,'id',3],[],hS5,cR5,gg)
var aX5=_oz(z,33,hS5,cR5,gg)
_(oV5,aX5)
var lW5=_v()
_(oV5,lW5)
if(_oz(z,34,hS5,cR5,gg)){lW5.wxVkey=1
var tY5=_n('view')
_rz(z,tY5,'class',35,hS5,cR5,gg)
_(lW5,tY5)
}
lW5.wxXCkey=1
_(oT5,oV5)
return oT5
}
oP5.wxXCkey=2
_2z(z,27,fQ5,e,s,gg,oP5,'item','index','index')
tK5.wxXCkey=1
_(lI5,aJ5)
_(cD5,lI5)
var eZ5=_n('view')
_rz(z,eZ5,'class',36,e,s,gg)
var b15=_v()
_(eZ5,b15)
if(_oz(z,37,e,s,gg)){b15.wxVkey=1
var x35=_mz(z,'scroll-view',['bindrefresherrefresh',38,'bindscrolltolower',1,'class',2,'data-event-opts',3,'lowerThreshold',4,'refresherEnabled',5,'refresherTriggered',6,'scrollIntoView',7,'scrollY',8],[],e,s,gg)
var o45=_v()
_(x35,o45)
if(_oz(z,47,e,s,gg)){o45.wxVkey=1
var c65=_mz(z,'view',['bindtap',48,'class',1,'data-event-opts',2],[],e,s,gg)
var h75=_n('view')
_rz(z,h75,'class',51,e,s,gg)
var o85=_mz(z,'image',['mode',-1,'class',52,'src',1],[],e,s,gg)
_(h75,o85)
var c95=_n('view')
var o05=_oz(z,54,e,s,gg)
_(c95,o05)
_(h75,c95)
var lA6=_mz(z,'image',['mode',-1,'class',55,'src',1],[],e,s,gg)
_(h75,lA6)
_(c65,h75)
_(o45,c65)
}
var aB6=_v()
_(x35,aB6)
var tC6=function(bE6,eD6,oF6,gg){
var oH6=_n('view')
_rz(z,oH6,'id',61,bE6,eD6,gg)
var fI6=_mz(z,'anchor-li',['bind:__l',62,'bind:collect',1,'bind:playEmotion',2,'bind:stopEmotion',3,'bind:upPay',4,'bind:useAnchor',5,'class',6,'data-event-opts',7,'data-ref',8,'hasCollected',9,'mypageZb',10,'vueId',11,'zbdetail',12],[],bE6,eD6,gg)
_(oH6,fI6)
_(oF6,oH6)
return oF6
}
aB6.wxXCkey=4
_2z(z,59,tC6,e,s,gg,aB6,'item2','index2','m0')
var f55=_v()
_(x35,f55)
if(_oz(z,75,e,s,gg)){f55.wxVkey=1
var cJ6=_mz(z,'view',['class',76,'style',1],[],e,s,gg)
var hK6=_v()
_(cJ6,hK6)
if(_oz(z,78,e,s,gg)){hK6.wxVkey=1
var oL6=_n('view')
_rz(z,oL6,'class',79,e,s,gg)
var cM6=_n('text')
_rz(z,cM6,'class',80,e,s,gg)
var oN6=_oz(z,81,e,s,gg)
_(cM6,oN6)
_(oL6,cM6)
var lO6=_n('text')
_rz(z,lO6,'class',82,e,s,gg)
var aP6=_oz(z,83,e,s,gg)
_(lO6,aP6)
_(oL6,lO6)
var tQ6=_n('text')
_rz(z,tQ6,'class',84,e,s,gg)
var eR6=_oz(z,85,e,s,gg)
_(tQ6,eR6)
_(oL6,tQ6)
var bS6=_mz(z,'view',['bindtap',86,'class',1,'data-event-opts',2],[],e,s,gg)
var oT6=_oz(z,89,e,s,gg)
_(bS6,oT6)
_(oL6,bS6)
_(hK6,oL6)
}
else{hK6.wxVkey=2
var xU6=_v()
_(hK6,xU6)
if(_oz(z,90,e,s,gg)){xU6.wxVkey=1
var oV6=_mz(z,'u-loadmore',['bind:__l',91,'nomoreText',1,'status',2,'vueId',3],[],e,s,gg)
_(xU6,oV6)
}
else{xU6.wxVkey=2
var fW6=_mz(z,'u-loadmore',['bind:__l',95,'status',1,'vueId',2],[],e,s,gg)
_(xU6,fW6)
}
xU6.wxXCkey=1
xU6.wxXCkey=3
xU6.wxXCkey=3
}
hK6.wxXCkey=1
hK6.wxXCkey=3
_(f55,cJ6)
}
o45.wxXCkey=1
f55.wxXCkey=1
f55.wxXCkey=3
_(b15,x35)
}
var o25=_v()
_(eZ5,o25)
if(_oz(z,98,e,s,gg)){o25.wxVkey=1
var cX6=_n('view')
_rz(z,cX6,'class',99,e,s,gg)
var hY6=_n('view')
_rz(z,hY6,'class',100,e,s,gg)
var oZ6=_mz(z,'image',['mode',-1,'src',101],[],e,s,gg)
_(hY6,oZ6)
var c16=_n('label')
_rz(z,c16,'class',102,e,s,gg)
var o26=_oz(z,103,e,s,gg)
_(c16,o26)
_(hY6,c16)
_(cX6,hY6)
var l36=_n('view')
_rz(z,l36,'class',104,e,s,gg)
_(cX6,l36)
var a46=_n('view')
_rz(z,a46,'class',105,e,s,gg)
var t56=_n('text')
var e66=_oz(z,106,e,s,gg)
_(t56,e66)
_(a46,t56)
var b76=_n('label')
_rz(z,b76,'class',107,e,s,gg)
var o86=_oz(z,108,e,s,gg)
_(b76,o86)
_(a46,b76)
var x96=_n('view')
_rz(z,x96,'class',109,e,s,gg)
var o06=_v()
_(x96,o06)
var fA7=function(hC7,cB7,oD7,gg){
var oF7=_n('view')
_rz(z,oF7,'class',114,hC7,cB7,gg)
var lG7=_mz(z,'image',['mode',-1,'src',115],[],hC7,cB7,gg)
_(oF7,lG7)
var aH7=_n('text')
var tI7=_oz(z,116,hC7,cB7,gg)
_(aH7,tI7)
_(oF7,aH7)
_(oD7,oF7)
return oD7
}
o06.wxXCkey=2
_2z(z,112,fA7,e,s,gg,o06,'item','index','index')
_(a46,x96)
var eJ7=_mz(z,'view',['bindtap',117,'class',1,'data-event-opts',2],[],e,s,gg)
var bK7=_oz(z,120,e,s,gg)
_(eJ7,bK7)
_(a46,eJ7)
_(cX6,a46)
_(o25,cX6)
}
b15.wxXCkey=1
b15.wxXCkey=3
o25.wxXCkey=1
_(cD5,eZ5)
_(r,cD5)
return r
}
e_[x[0]]={f:m0,j:[],i:[],ti:[],ic:[]}
if(path&&e_[path]){
outerGlobal.__wxml_comp_version__=0.02
return function(env,dd,global){$gwxc=0;var root={"tag":"wx-page"};root.children=[]
;g="$gwx_XC_36";var main=e_[path].f
if (typeof global==="undefined")global={};global.f=$gdc(f_[path],"",1);
if(typeof(outerGlobal.__webview_engine_version__)!='undefined'&&outerGlobal.__webview_engine_version__+1e-6>=0.02+1e-6&&outerGlobal.__mergeData__)
{
env=outerGlobal.__mergeData__(env,dd);
}
try{
main(env,{},root,global);
_tsd(root)
if(typeof(outerGlobal.__webview_engine_version__)=='undefined'|| outerGlobal.__webview_engine_version__+1e-6<0.01+1e-6){return _ev(root);}
}catch(err){
console.log(err)
}
;g="";
return root;
}
}
}
}(__g.a,__g.b,__g.c,__g.d,__g.e,__g.f,__g.g,__g.h,__g.i,__g.j,__g.k,__g.l,__g.m,__g.n,__g.o,__g.p,__g.q,__g.r,__g.s,__g.t,__g.u,__g.v,__g.w,__g.x,__g.y,__g.z,__g.A,__g.B,__g.C,__g.D,__g.E,__g.F,__g.G,__g.H,__g.I,__g.J,__g.K,__g.L,__g.M,__g.N,__g.O,__g.P,__g.Q,__g.R,__g.S,__g.T,__g.U,__g.V,__g.W,__g.X,__g.Y,__g.Z,__g.aa);if(__vd_version_info__.delayedGwx||false)$gwx_XC_36();	if (__vd_version_info__.delayedGwx) __wxAppCode__['pages/make/anchor.wxml'] = [$gwx_XC_36, './pages/make/anchor.wxml'];else __wxAppCode__['pages/make/anchor.wxml'] = $gwx_XC_36( './pages/make/anchor.wxml' );
	
var noCss=typeof __vd_version_info__!=='undefined'&&__vd_version_info__.noCss===true;if(!noCss){__wxAppCode__['pages/make/anchor.wxss'] = setCssToHead(["wx-text,wx-view{font-size:",[0,28],"}\n.",[1],"flex_col{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column}\n.",[1],"widthFix{display:block;height:0;height:auto;width:100%}\n.",[1],"heightFix{display:block;height:100%;width:0;width:auto}\n::-webkit-scrollbar{color:transparent}\nbody{height:100%}\nwx-text,wx-view{box-sizing:border-box;color:#333}\n.",[1],"mian,.",[1],"netmb{width:100%}\n.",[1],"netmb{-webkit-align-items:center;align-items:center;background-color:rgba(0,0,0,.8);display:-webkit-flex;display:flex;-webkit-flex-wrap:wrap;flex-wrap:wrap;height:100%;position:fixed;z-index:99999}\n.",[1],"netbtn{background-color:#ffba00;border-radius:",[0,19],";height:",[0,80],";line-height:",[0,76],";margin-left:25%;margin-top:",[0,40],";width:50%}\n.",[1],"netbtn,.",[1],"nettext{color:#fff;text-align:center}\n.",[1],"netcon,.",[1],"nettext{width:100%}\n.",[1],"agreementpopup{-webkit-align-items:center;align-items:center;background-color:rgba(0,0,0,.4);display:-webkit-flex;display:flex;height:100%;left:0;position:fixed;top:0;width:100%;z-index:999999}\n.",[1],"agreementcon{background-color:#fff;border-radius:",[0,12],";height:",[0,750],";margin-left:10%;width:80%}\n.",[1],"agreetit{font-size:",[0,32],";margin-top:",[0,40],";text-align:center}\n.",[1],"agreetext{height:",[0,400],";margin-left:4%;margin-top:",[0,20],";width:92%}\n.",[1],"agreebtn{background-color:#ff3e2c;color:#fff;margin-top:",[0,20],"}\n.",[1],"agreebtn,.",[1],"agreeunbtn{-webkit-align-items:center;align-items:center;border-radius:",[0,8],";display:-webkit-flex;display:flex;height:",[0,100],";-webkit-justify-content:space-around;justify-content:space-around;margin-left:4%;width:92%}\n.",[1],"agreeunbtn{color:#999}\n.",[1],"agreetext wx-view{color:#666;font-size:",[0,24],";line-height:",[0,34],"}\n.",[1],"agreetext wx-text{color:#282195}\n.",[1],"placeorder{-webkit-align-items:center;align-items:center;background-color:#ffc107;border-radius:",[0,16],";color:#fff;display:-webkit-flex;display:flex;font-size:",[0,24],";height:",[0,48],";-webkit-justify-content:space-around;justify-content:space-around;width:",[0,118],"}\n.",[1],"zhuboply{bottom:",[0,14],"!important;height:",[0,32],"!important;position:absolute;right:",[0,14],"!important;width:",[0,32],"!important;z-index:1}\n.",[1],"upgrade{background-color:rgba(0,0,0,.4);height:100%;left:0;position:fixed;top:0;width:100%;z-index:99999}\n.",[1],"upgradecon{height:",[0,640],";left:50%;margin-left:",[0,-240],";margin-top:",[0,-320],";position:absolute;top:50%;width:",[0,480],"}\n.",[1],"upgradeimg{height:100%;left:0;position:absolute;top:0;width:100%;z-index:-1}\n.",[1],"upgradetext{height:",[0,250],";margin-top:",[0,250],";width:100%}\n.",[1],"upgradebtn{-webkit-align-items:center;align-items:center;background-color:#f3b043;border-radius:",[0,16],";color:#fff;display:-webkit-flex;display:flex;height:",[0,64],";-webkit-justify-content:space-around;justify-content:space-around;margin:",[0,8]," auto;width:",[0,380],"}\n.",[1],"offupgrade{bottom:",[0,-90],";height:",[0,72],";left:50%;margin-left:",[0,-36],";position:absolute;width:",[0,72],"}\n.",[1],"srcolltop{background-color:#fff;left:0;padding-bottom:",[0,20],";position:fixed;top:0;width:100%;z-index:99999}\n.",[1],"audio_detail_box{background:#fff;border:",[0,2]," solid #eee;border-radius:",[0,40],";height:",[0,200],";-webkit-justify-content:space-between;justify-content:space-between;margin:",[0,32]," auto 0;padding:",[0,40],";width:",[0,686],"}\n.",[1],"audio_detail_box,.",[1],"box_left{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex}\n.",[1],"left_img{position:relative}\n.",[1],"img_bg,.",[1],"left_img wx-image{border-radius:50%;height:",[0,120],";width:",[0,120],"}\n.",[1],"img_bg{background:rgba(0,0,0,.2);left:0;position:absolute;top:0}\n.",[1],"play_state_img{border-radius:0!important;height:",[0,44],"!important;left:",[0,38],";position:absolute;top:",[0,38],";width:",[0,44],"!important}\n.",[1],"box_con{margin-left:",[0,20],"}\n.",[1],"con_title{color:#333;font-size:",[0,28],";font-weight:700;margin-bottom:",[0,12],"}\n.",[1],"con_text{color:#666;font-size:",[0,20],"}\n.",[1],"change_btn wx-image{height:",[0,64],";width:",[0,160],"}\n.",[1],"more_btn{display:-webkit-flex;display:flex;-webkit-justify-content:space-between;justify-content:space-between;width:",[0,156],"}\n.",[1],"more_btn wx-image{height:",[0,40],";width:",[0,40],"}\n.",[1],"box_left_con .",[1],"con_top{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex}\n.",[1],"box_left_con .",[1],"con_top_title{color:#333;font-size:",[0,28],";font-weight:700}\n.",[1],"box_left_con .",[1],"con_top_lable{color:#999;font-size:",[0,20],";margin-left:",[0,20],"}\n.",[1],"box_left_con .",[1],"con_btm{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;margin-top:",[0,26],"}\nwx-slider{margin:0!important}\n.",[1],"splice_slider{width:",[0,300],"}\n.",[1],"splice_slider_value{color:#ffc22d;font-size:",[0,32],";font-weight:700;margin-left:",[0,20],"}\n.",[1],"audio_detail{margin-top:",[0,32],";text-align:center}\n.",[1],"audio_detail wx-image{height:",[0,200],";width:",[0,686],"}\n.",[1],"audio_detail_title{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;margin:",[0,60]," 0 ",[0,20]," 4%;width:92%}\n.",[1],"audio_detail_title wx-image{height:",[0,40],";width:",[0,40],"}\n.",[1],"audio_detail_title .",[1],"title{color:#333;font-size:",[0,32],";font-weight:700;margin-left:",[0,12],"}\n.",[1],"bg_con{height:100%;left:0;top:0;width:100%;z-index:1}\n.",[1],"bg_con,.",[1],"pos_cen{position:absolute}\n.",[1],"pos_cen{left:50%;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);z-index:2}\n.",[1],"flex_ali,.",[1],"flex_aro{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex}\n.",[1],"flex_aro{-webkit-justify-content:space-around;justify-content:space-around}\n.",[1],"flex_bet{-webkit-justify-content:space-between;justify-content:space-between}\n.",[1],"flex_bet,.",[1],"flex_cen{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex}\n.",[1],"flex_cen{-webkit-justify-content:center;justify-content:center}\n.",[1],"con{box-sizing:border-box;padding:0 ",[0,32],";width:100%}\n.",[1],"ovhide{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.",[1],"allpopupbg{background-color:rgba(0,0,0,.5);height:100%;left:0;position:fixed;top:0;width:100%}\n.",[1],"status_bar{height:25px;width:100%}\n.",[1],"wxParse{color:#333;font-family:Helvetica,PingFangSC,Microsoft Yahei,微软雅黑,Arial,sans-serif;font-size:1em;line-height:1.5;text-align:justify;-webkit-user-select:none;user-select:none;width:100%}\n.",[1],"wxParse wx-uni-view,.",[1],"wxParse wx-view{word-break:break-word}\n.",[1],"wxParse .",[1],"p{clear:both;padding-bottom:.5em}\n.",[1],"wxParse .",[1],"inline{display:inline;margin:0;padding:0}\n.",[1],"wxParse .",[1],"div{display:block;margin:0;padding:0}\n.",[1],"wxParse .",[1],"h1{font-size:2em;line-height:1.2em;margin:.67em 0}\n.",[1],"wxParse .",[1],"h2{font-size:1.5em;margin:.83em 0}\n.",[1],"wxParse .",[1],"h3{font-size:1.17em;margin:1em 0}\n.",[1],"wxParse .",[1],"h4{margin:1.33em 0}\n.",[1],"wxParse .",[1],"h5,.",[1],"wxParse .",[1],"h6{font-size:.83em;margin:1.67em 0}\n.",[1],"wxParse .",[1],"b,.",[1],"wxParse .",[1],"h1,.",[1],"wxParse .",[1],"h2,.",[1],"wxParse .",[1],"h3,.",[1],"wxParse .",[1],"h4,.",[1],"wxParse .",[1],"h5,.",[1],"wxParse .",[1],"h6,.",[1],"wxParse .",[1],"strong{font-weight:bolder}\n.",[1],"wxParse .",[1],"address,.",[1],"wxParse .",[1],"cite,.",[1],"wxParse .",[1],"em,.",[1],"wxParse .",[1],"i,.",[1],"wxParse .",[1],"var{font-style:italic}\n.",[1],"wxParse .",[1],"spaceshow{white-space:pre}\n.",[1],"wxParse .",[1],"code,.",[1],"wxParse .",[1],"kbd,.",[1],"wxParse .",[1],"pre,.",[1],"wxParse .",[1],"samp,.",[1],"wxParse .",[1],"tt{font-family:monospace}\n.",[1],"wxParse .",[1],"code,.",[1],"wxParse .",[1],"pre{background:#f5f5f5;font-size:",[0,24],";margin:1em ",[0,0],";overflow:auto;padding:",[0,16],";white-space:pre}\n.",[1],"wxParse .",[1],"big{font-size:1.17em}\n.",[1],"wxParse .",[1],"small,.",[1],"wxParse .",[1],"sub,.",[1],"wxParse .",[1],"sup{font-size:.83em}\n.",[1],"wxParse .",[1],"sub{vertical-align:sub}\n.",[1],"wxParse .",[1],"sup{vertical-align:super}\n.",[1],"wxParse .",[1],"del,.",[1],"wxParse .",[1],"s,.",[1],"wxParse .",[1],"strike{text-decoration:line-through}\n.",[1],"wxParse .",[1],"s,.",[1],"wxParse .",[1],"span,.",[1],"wxParse .",[1],"strong,.",[1],"wxParse .",[1],"text{display:inline}\n.",[1],"wxParse .",[1],"a{color:#00bfff}\n.",[1],"wxParse .",[1],"video{margin:",[0,22]," 0;text-align:center}\n.",[1],"wxParse .",[1],"video-video{width:100%}\n.",[1],"wxParse .",[1],"img,.",[1],"wxParse .",[1],"uni-image{max-width:100%}\n.",[1],"wxParse .",[1],"img{display:block;margin-bottom:0;overflow:hidden}\n.",[1],"wxParse .",[1],"blockquote{background:#f5f5f5;border-left:",[0,6]," solid #dbdbdb;font-family:Courier,Calibri,宋体;margin:",[0,10]," 0;padding:",[0,22]," 0 ",[0,22]," ",[0,22],"}\n.",[1],"wxParse .",[1],"blockquote .",[1],"p{margin:0}\n.",[1],"wxParse .",[1],"ol,.",[1],"wxParse .",[1],"ul{display:block;margin:1em 0;padding-left:2em}\n.",[1],"wxParse .",[1],"ol{list-style-type:disc;list-style-type:decimal}\n.",[1],"wxParse .",[1],"ol\x3e.",[1],"li,.",[1],"wxParse .",[1],"ol\x3ewx-weixin-parse-template,.",[1],"wxParse .",[1],"ul\x3e.",[1],"li,.",[1],"wxParse .",[1],"ul\x3ewx-weixin-parse-template{-webkit-align-items:baseline;align-items:baseline;display:list-item;text-align:match-parent}\n.",[1],"wxParse .",[1],"ol .",[1],"ul,.",[1],"wxParse .",[1],"ul .",[1],"ul{list-style-type:circle}\n.",[1],"wxParse .",[1],"ol .",[1],"ol .",[1],"ul,.",[1],"wxParse .",[1],"ol .",[1],"ul .",[1],"ul,.",[1],"wxParse .",[1],"ul .",[1],"ol .",[1],"ul,.",[1],"wxParse .",[1],"ul .",[1],"ul .",[1],"ul{list-style-type:square}\n.",[1],"wxParse .",[1],"u{text-decoration:underline}\n.",[1],"wxParse .",[1],"hide{display:none}\n.",[1],"wxParse .",[1],"del{display:inline}\n.",[1],"wxParse .",[1],"figure{overflow:hidden}\n.",[1],"wxParse .",[1],"tablebox{background-color:#f5f5f5;background:#f5f5f5;font-size:13px;overflow:auto;padding:8px}\n.",[1],"wxParse .",[1],"table,.",[1],"wxParse .",[1],"table .",[1],"table{border-collapse:collapse;box-sizing:border-box;overflow:auto;white-space:pre}\n.",[1],"wxParse .",[1],"tbody{border:1px solid #dadada;border-collapse:collapse;box-sizing:border-box}\n.",[1],"wxParse .",[1],"table .",[1],"tfoot,.",[1],"wxParse .",[1],"table .",[1],"th,.",[1],"wxParse .",[1],"table .",[1],"thead{background:#ececec;border-collapse:collapse;box-sizing:border-box;font-weight:40}\n.",[1],"wxParse .",[1],"table .",[1],"td,.",[1],"wxParse .",[1],"table .",[1],"th,.",[1],"wxParse .",[1],"table .",[1],"tr{border-collapse:collapse;box-sizing:border-box;overflow:auto}\n.",[1],"wxParse .",[1],"table .",[1],"td,.",[1],"wxParse .",[1],"table .",[1],"th{border:",[0,2]," solid #dadada}\n.",[1],"wxParse .",[1],"audio,.",[1],"wxParse .",[1],"uni-audio-default{display:block}\n.",[1],"u-line-1{-webkit-line-clamp:1}\n.",[1],"u-line-1,.",[1],"u-line-2{-webkit-box-orient:vertical!important;display:-webkit-box!important;overflow:hidden;text-overflow:ellipsis;word-break:break-all}\n.",[1],"u-line-2{-webkit-line-clamp:2}\n.",[1],"u-line-3{-webkit-line-clamp:3}\n.",[1],"u-line-3,.",[1],"u-line-4{-webkit-box-orient:vertical!important;display:-webkit-box!important;overflow:hidden;text-overflow:ellipsis;word-break:break-all}\n.",[1],"u-line-4{-webkit-line-clamp:4}\n.",[1],"u-line-5{-webkit-line-clamp:5;-webkit-box-orient:vertical!important;display:-webkit-box!important;overflow:hidden;text-overflow:ellipsis;word-break:break-all}\n.",[1],"u-border{border-color:#dadbde!important;border-style:solid;border-width:.5px!important}\n.",[1],"u-border-top{border-color:#dadbde!important;border-top-style:solid;border-top-width:.5px!important}\n.",[1],"u-border-left{border-color:#dadbde!important;border-left-style:solid;border-left-width:.5px!important}\n.",[1],"u-border-right{border-color:#dadbde!important;border-right-style:solid;border-right-width:.5px!important}\n.",[1],"u-border-bottom{border-bottom-style:solid;border-bottom-width:.5px!important;border-color:#dadbde!important}\n.",[1],"u-border-top-bottom{border-bottom-style:solid;border-bottom-width:.5px!important;border-color:#dadbde!important;border-top-style:solid;border-top-width:.5px!important}\n.",[1],"u-reset-button{background-color:initial;color:inherit;font-size:inherit;line-height:inherit;padding:0}\n.",[1],"u-reset-button::after{border:none}\n.",[1],"u-hover-class{opacity:.7}\n.",[1],"u-primary-light{color:#ecf5ff}\n.",[1],"u-warning-light{color:#fdf6ec}\n.",[1],"u-success-light{color:#f5fff0}\n.",[1],"u-error-light{color:#fef0f0}\n.",[1],"u-info-light{color:#f4f4f5}\n.",[1],"u-primary-light-bg{background-color:#ecf5ff}\n.",[1],"u-warning-light-bg{background-color:#fdf6ec}\n.",[1],"u-success-light-bg{background-color:#f5fff0}\n.",[1],"u-error-light-bg{background-color:#fef0f0}\n.",[1],"u-info-light-bg{background-color:#f4f4f5}\n.",[1],"u-primary-dark{color:#398ade}\n.",[1],"u-warning-dark{color:#f1a532}\n.",[1],"u-success-dark{color:#53c21d}\n.",[1],"u-error-dark{color:#e45656}\n.",[1],"u-info-dark{color:#767a82}\n.",[1],"u-primary-dark-bg{background-color:#398ade}\n.",[1],"u-warning-dark-bg{background-color:#f1a532}\n.",[1],"u-success-dark-bg{background-color:#53c21d}\n.",[1],"u-error-dark-bg{background-color:#e45656}\n.",[1],"u-info-dark-bg{background-color:#767a82}\n.",[1],"u-primary-disabled{color:#9acafc}\n.",[1],"u-warning-disabled{color:#f9d39b}\n.",[1],"u-success-disabled{color:#a9e08f}\n.",[1],"u-error-disabled{color:#f7b2b2}\n.",[1],"u-info-disabled{color:#c4c6c9}\n.",[1],"u-primary{color:#3c9cff}\n.",[1],"u-warning{color:#f9ae3d}\n.",[1],"u-success{color:#5ac725}\n.",[1],"u-error{color:#f56c6c}\n.",[1],"u-info{color:#909399}\n.",[1],"u-primary-bg{background-color:#3c9cff}\n.",[1],"u-warning-bg{background-color:#f9ae3d}\n.",[1],"u-success-bg{background-color:#5ac725}\n.",[1],"u-error-bg{background-color:#f56c6c}\n.",[1],"u-info-bg{background-color:#909399}\n.",[1],"u-main-color{color:#303133}\n.",[1],"u-content-color{color:#606266}\n.",[1],"u-tips-color{color:#909193}\n.",[1],"u-light-color{color:#c0c4cc}\n.",[1],"u-safe-area-inset-top{padding-top:env(safe-area-inset-top)}\n.",[1],"u-safe-area-inset-right{padding-right:env(safe-area-inset-right)}\n.",[1],"u-safe-area-inset-bottom{padding-bottom:env(safe-area-inset-bottom)}\n.",[1],"u-safe-area-inset-left{padding-left:env(safe-area-inset-left)}\n::-webkit-scrollbar{-webkit-appearance:none;background:transparent;display:none;height:0!important;width:0!important}\n.",[1],"cltop_bg{padding:",[0,32],"}\n.",[1],"cltop_bg,.",[1],"cltop_bg .",[1],"cltop{display:-webkit-flex;display:flex;width:100%}\n.",[1],"cltop_bg .",[1],"cltop{-webkit-align-items:center;align-items:center;-webkit-align-self:stretch;align-self:stretch;background:#f0f3f5;border-radius:",[0,24],";gap:",[0,20],";padding:",[0,16]," ",[0,24],"}\n.",[1],"cltop_bg .",[1],"cltop .",[1],"img1{height:",[0,48],";width:",[0,48],"}\n.",[1],"cltop_bg .",[1],"cltop .",[1],"img2{height:",[0,32],";width:",[0,32],"}\n.",[1],"cltop_bg .",[1],"cltop wx-view{color:#2cb5f4;-webkit-flex:1 0 0;flex:1 0 0;font-size:",[0,28],";font-weight:500}\n.",[1],"cloningNull,.",[1],"cloningNull .",[1],"cloningNull_bot{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;width:100%}\n.",[1],"cloningNull .",[1],"cloningNull_bot{padding:",[0,96]," ",[0,64],"}\n.",[1],"cloningNull .",[1],"cloningNull_bot .",[1],"qkl{background:#ffe411;border-radius:",[0,2024],";color:#262626;font-size:",[0,32],";font-weight:500;padding:",[0,24]," ",[0,96],"}\n.",[1],"cloningNull .",[1],"cloningNull_bot .",[1],"cloningNull_bot_icon{-webkit-align-items:center;align-items:center;display:-webkit-flex;display:flex;gap:",[0,24],";margin:",[0,48]," 0;width:100%}\n.",[1],"cloningNull .",[1],"cloningNull_bot .",[1],"cloningNull_bot_icon .",[1],"icon_li{-webkit-flex:1 0 0;flex:1 0 0;-webkit-flex-direction:column;flex-direction:column;gap:",[0,8],";padding:",[0,4]," 0}\n.",[1],"cloningNull .",[1],"cloningNull_bot .",[1],"cloningNull_bot_icon .",[1],"icon_li wx-image{height:",[0,48],";width:",[0,48],"}\n.",[1],"cloningNull .",[1],"cloningNull_bot .",[1],"cloningNull_bot_icon .",[1],"icon_li wx-text{color:#525252;font-size:",[0,24],"}\n.",[1],"cloningNull .",[1],"cloningNull_bot wx-text{color:#262626;font-size:",[0,40],";font-weight:500}\n.",[1],"cloningNull .",[1],"cloningNull_bot .",[1],"_span{color:#737373;font-size:",[0,26],";margin-top:",[0,24],"}\n.",[1],"cloningNull .",[1],"cloningNull_fgx{background-color:#e5e5e5;height:",[0,1],";width:calc(100% - ",[0,128],")}\n.",[1],"cloningNull .",[1],"cloningNull_top{-webkit-flex-direction:column;flex-direction:column;padding:",[0,96]," ",[0,64],"}\n.",[1],"cloningNull .",[1],"cloningNull_top wx-image{height:",[0,256],";width:",[0,256],"}\n.",[1],"cloningNull .",[1],"cloningNull_top .",[1],"_span{color:#646566;font-size:",[0,32],"}\n.",[1],"hasend{-webkit-flex-direction:column;flex-direction:column;width:100%}\n.",[1],"hasend .",[1],"text1{color:#666;font-family:PingFang SC;font-size:",[0,28],";margin-top:",[0,64],"}\n.",[1],"hasend .",[1],"text2{color:#666;font-size:",[0,28],";margin-top:",[0,8],";text-align:center}\n.",[1],"hasend .",[1],"hasend_tj{background:#262626;border-radius:",[0,2024],";color:#fff;font-size:",[0,28],";font-weight:500;margin:",[0,24]," 0 ",[0,128],";padding:",[0,24]," ",[0,64],"}\n.",[1],"announcer{display:-webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;height:100vh;width:100vw}\n.",[1],"announcer .",[1],"anchoralltab{background:#fff;border-bottom:",[0,1]," solid rgba(0,0,0,.05);height:",[0,84],";width:100vw}\n.",[1],"announcer .",[1],"anchoralltab .",[1],"announcer_tab{height:",[0,84],";white-space:nowrap;width:100vw}\n.",[1],"announcer .",[1],"anchoralltab .",[1],"announcer_tab .",[1],"antab_act{color:#262626!important;font-weight:500!important}\n.",[1],"announcer .",[1],"anchoralltab .",[1],"announcer_tab .",[1],"antab_li{color:#737373;display:inline-block;font-size:",[0,32],";height:",[0,84],";padding:",[0,20],";position:relative;text-align:center}\n.",[1],"announcer .",[1],"anchoralltab .",[1],"announcer_tab .",[1],"antab_act_gang{background:#ffe411;border-radius:",[0,999],";bottom:0;height:",[0,6],";left:50%;position:absolute;-webkit-transform:translateX(-50%);transform:translateX(-50%);width:",[0,52],"}\n.",[1],"announcer .",[1],"announcer_search{height:",[0,80],";margin-bottom:",[0,16],";padding:0 ",[0,30],";width:100%}\n.",[1],"announcer .",[1],"announcer_search .",[1],"announcer_input{background-color:#f7f7f5;border-radius:",[0,20],";height:",[0,80],";width:100%}\n.",[1],"announcer .",[1],"announcer_search .",[1],"announcer_input wx-input{height:100%;width:calc(100% - ",[0,82],")}\n.",[1],"announcer .",[1],"announcer_search .",[1],"announcer_input wx-image{height:",[0,32],";padding:",[0,24]," ",[0,20]," ",[0,24]," ",[0,30],";width:",[0,32],"}\n.",[1],"announcer .",[1],"announcer_main{height:calc(100% - ",[0,180],");width:100%}\n.",[1],"announcer .",[1],"announcer_main .",[1],"announcer_list{height:100%}\n",],"Some selectors are not allowed in component wxss, including tag name selectors, ID selectors, and attribute selectors.(./pages/make/anchor.wxss:1:15027)",{path:"./pages/make/anchor.wxss"});
}